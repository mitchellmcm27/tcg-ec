#include "endmembers/Forsterite_xmelts.h"
#include "tcgversion.h"

//-----------------------------------------------------------------------------
Forsterite_xmelts::Forsterite_xmelts()
{
  // Do Nothing
}
//-----------------------------------------------------------------------------
Forsterite_xmelts::~Forsterite_xmelts()
{
  // Do nothing
}
//-----------------------------------------------------------------------------
std::string Forsterite_xmelts::identifier()
{
    std::string _str(Forsterite_xmelts_coder_calib_identifier());
    return _str;
}
//-----------------------------------------------------------------------------
std::string Forsterite_xmelts::name()
{
    std::string _str(Forsterite_xmelts_coder_calib_name());
    return _str;
}
//-----------------------------------------------------------------------------
std::string Forsterite_xmelts::tcg_build_version()
{
    return TCG_VERSION;
}
//-----------------------------------------------------------------------------
std::string Forsterite_xmelts::tcg_build_git_sha()
{
    return TCG_GIT_SHA;
}
//-----------------------------------------------------------------------------
std::string Forsterite_xmelts::tcg_generation_version()
{
    return "0.6.9";
}
//-----------------------------------------------------------------------------
std::string Forsterite_xmelts::tcg_generation_git_sha()
{
    return "117d758197e2d445579ad671f573064c0650429d Mon Aug 1 00:36:24 2022 +0000";
}
//-----------------------------------------------------------------------------
std::string Forsterite_xmelts::formula()
{
    std::string _str(Forsterite_xmelts_coder_calib_formula());
    return _str;
}
//-----------------------------------------------------------------------------
double Forsterite_xmelts::molecular_weight()
{
    return Forsterite_xmelts_coder_calib_mw();
}
//-----------------------------------------------------------------------------
std::vector<double> Forsterite_xmelts::elements()
{
  std::vector<double> _elements;
  const double *el = Forsterite_xmelts_coder_calib_elements();
  _elements.assign(el, el + 106);
  return _elements;
}
//-----------------------------------------------------------------------------
double Forsterite_xmelts::G(const double &T, const double &P)
{
  return Forsterite_xmelts_coder_calib_g(T,P);
}
//-----------------------------------------------------------------------------
double Forsterite_xmelts::dGdT(const double &T, const double &P)
{
  return Forsterite_xmelts_coder_calib_dgdt(T,P);
}
//-----------------------------------------------------------------------------
double Forsterite_xmelts::dGdP(const double &T, const double &P)
{
  return Forsterite_xmelts_coder_calib_dgdp(T,P);
}
//-----------------------------------------------------------------------------
double Forsterite_xmelts::d2GdT2(const double &T, const double &P)
{
  return Forsterite_xmelts_coder_calib_d2gdt2(T,P);
}
//-----------------------------------------------------------------------------
double Forsterite_xmelts::d2GdTdP(const double &T, const double &P)
{
  return Forsterite_xmelts_coder_calib_d2gdtdp(T,P);
}
//-----------------------------------------------------------------------------
double Forsterite_xmelts::d2GdP2(const double &T, const double &P)
{
  return Forsterite_xmelts_coder_calib_d2gdp2(T,P);
}
//-----------------------------------------------------------------------------
double Forsterite_xmelts::d3GdT3(const double &T, const double &P)
{
  return Forsterite_xmelts_coder_calib_d3gdt3(T,P);
}
//-----------------------------------------------------------------------------
double Forsterite_xmelts::d3GdT2dP(const double &T, const double &P)
{
  return Forsterite_xmelts_coder_calib_d3gdt2dp(T,P);
}
//-----------------------------------------------------------------------------
double Forsterite_xmelts::d3GdTdP2(const double &T, const double &P)
{
  return Forsterite_xmelts_coder_calib_d3gdtdp2(T,P);
}
//-----------------------------------------------------------------------------
double Forsterite_xmelts::d3GdP3(const double &T, const double &P)
{
  return Forsterite_xmelts_coder_calib_d3gdp3(T,P);
}
//**************************************************************************
// Convenience functions of T and P
//**************************************************************************

//-----------------------------------------------------------------------------
double Forsterite_xmelts::S(const double& T, const double& P)
{
  return Forsterite_xmelts_coder_calib_s(T,P);
}
//-----------------------------------------------------------------------------
double Forsterite_xmelts::V(const double& T, const double& P)
{
  return Forsterite_xmelts_coder_calib_v(T,P);
}
//-----------------------------------------------------------------------------
double Forsterite_xmelts::dVdT(const double& T, const double& P)
{
  return Forsterite_xmelts_coder_calib_d2gdtdp(T,P);
}
//-----------------------------------------------------------------------------
double Forsterite_xmelts::dVdP(const double& T, const double& P)
{
  return Forsterite_xmelts_coder_calib_d2gdp2(T,P);
}
//-----------------------------------------------------------------------------
double Forsterite_xmelts::Cv(const double& T, const double& P)
{
  return Forsterite_xmelts_coder_calib_cv(T,P);
}
//-----------------------------------------------------------------------------
double Forsterite_xmelts::Cp(const double& T, const double& P)
{
  return Forsterite_xmelts_coder_calib_cp(T,P);
}
//-----------------------------------------------------------------------------
double Forsterite_xmelts::dCpdT(const double& T, const double& P)
{
  return Forsterite_xmelts_coder_calib_dcpdt(T,P);
}
//-----------------------------------------------------------------------------
double Forsterite_xmelts::alpha(const double& T, const double& P)
{
  return Forsterite_xmelts_coder_calib_alpha(T,P);
}
//-----------------------------------------------------------------------------
double Forsterite_xmelts::beta(const double& T, const double& P)
{
  return Forsterite_xmelts_coder_calib_beta(T,P);
}
//-----------------------------------------------------------------------------
double Forsterite_xmelts::K(const double& T, const double& P)
{
  return Forsterite_xmelts_coder_calib_K(T,P);
}
//-----------------------------------------------------------------------------
double Forsterite_xmelts::Kp(const double& T, const double& P)
{
  return Forsterite_xmelts_coder_calib_Kp(T,P);
}
//**************************************************************************
// Active parameter functions directly from coder
//**************************************************************************

//-----------------------------------------------------------------------------
int Forsterite_xmelts::get_param_number()
{
   return Forsterite_xmelts_coder_get_param_number();
}
//-----------------------------------------------------------------------------
std::vector<std::string> Forsterite_xmelts::get_param_names()
{
  std::vector<std::string> _param_names;
  const char **p = Forsterite_xmelts_coder_get_param_names();
  _param_names.assign(p, p + Forsterite_xmelts_coder_get_param_number());
  return _param_names;
}
//-----------------------------------------------------------------------------
std::vector<std::string> Forsterite_xmelts::get_param_units()
{
  std::vector<std::string> _param_units;
  const char **p = Forsterite_xmelts_coder_get_param_units();
  _param_units.assign(p, p + Forsterite_xmelts_coder_get_param_number());
  return _param_units;
}
//-----------------------------------------------------------------------------
std::vector<double> Forsterite_xmelts::get_param_values()
{
  std::vector<double> values(Forsterite_xmelts_coder_get_param_number());
  double* v = values.data();
  double** v_ptr = &v;
  Forsterite_xmelts_coder_get_param_values(v_ptr);
  return values;
}
//-----------------------------------------------------------------------------
void Forsterite_xmelts::get_param_values(std::vector<double>& values)
{
  double* v = values.data();
  double** v_ptr = &v;
  Forsterite_xmelts_coder_get_param_values(v_ptr);
}
//-----------------------------------------------------------------------------
int Forsterite_xmelts::set_param_values(std::vector<double>& values)
{
  Forsterite_xmelts_coder_set_param_values(values.data());
  return 1;
}
//-----------------------------------------------------------------------------
double Forsterite_xmelts::get_param_value(int& index)
{
  return Forsterite_xmelts_coder_get_param_value(index);
}
//-----------------------------------------------------------------------------
int Forsterite_xmelts::set_param_value(int& index, double& value)
{
  return Forsterite_xmelts_coder_set_param_value(index,value);
}
//-----------------------------------------------------------------------------
double Forsterite_xmelts::dparam_g(double& T, double& P, int& index)
{
  return Forsterite_xmelts_coder_dparam_g(T,P,index);
}
//-----------------------------------------------------------------------------
double Forsterite_xmelts::dparam_dgdt(double& T, double& P, int& index)
{
  return Forsterite_xmelts_coder_dparam_dgdt(T,P,index);
}
//-----------------------------------------------------------------------------
double Forsterite_xmelts::dparam_dgdp(double& T, double& P, int& index)
{
  return Forsterite_xmelts_coder_dparam_dgdp(T,P,index);
}
//-----------------------------------------------------------------------------
double Forsterite_xmelts::dparam_d2gdt2(double& T, double& P, int& index)
{
  return Forsterite_xmelts_coder_dparam_d2gdt2(T,P,index);
}
//-----------------------------------------------------------------------------
double Forsterite_xmelts::dparam_d2gdtdp(double& T, double& P, int& index)
{
  return Forsterite_xmelts_coder_dparam_d2gdtdp(T,P,index);
}
//-----------------------------------------------------------------------------
double Forsterite_xmelts::dparam_d2gdp2(double& T, double& P, int& index)
{
  return Forsterite_xmelts_coder_dparam_d2gdp2(T,P,index);
}
//-----------------------------------------------------------------------------
double Forsterite_xmelts::dparam_d3gdt3(double& T, double& P, int& index)
{
  return Forsterite_xmelts_coder_dparam_d3gdt3(T,P,index);
}
//-----------------------------------------------------------------------------
double Forsterite_xmelts::dparam_d3gdt2dp(double& T, double& P, int& index)
{
  return Forsterite_xmelts_coder_dparam_d3gdt2dp(T,P,index);
}
//-----------------------------------------------------------------------------
double Forsterite_xmelts::dparam_d3gdtdp2(double& T, double& P, int& index)
{
  return Forsterite_xmelts_coder_dparam_d3gdtdp2(T,P,index);
}
//-----------------------------------------------------------------------------
double Forsterite_xmelts::dparam_d3gdp3(double& T, double& P, int& index)
{
  return Forsterite_xmelts_coder_dparam_d3gdp3(T,P,index);
}
//-----------------------------------------------------------------------------
