#include <math.h>


static double coder_g(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    
    double x0 = 1.0*n2;
    double x1 = 1.0*n3;
    double x2 = 1.0*n5;
    double x3 = 1.0*n1 + x0 + x1 + x2;
    double x4 = 3.5*n4 + x3;
    double x5 = 12349.999999999998*n3 + 20222.222222222219*n4 + 12149.999999999998*n5;
    double x6 = n1 + n3;
    double x7 = n4 + n5;
    double x8 = 1.0/(n2 + x6 + x7);
    double x9 = 1.0*n4;
    double x10 = n1 + n2 + n4;

result = (n1*x5 + n2*x5 + 0.027777777777777773*n3*(444600.0*n1 + 444600.0*n2 + 1682800.0*n4 + 828000.0*n5) + 0.0085352842554488641*n4*(2369250.0*n1 + 2369250.0*n2 + 5476612.5*n3 + 911250.0*n5) + 0.027777777777777773*n5*(437400.0*n1 + 437400.0*n2 + 828000.0*n3 + 280000.0*n4) + x4*(8.3144626181532395*T*(x0*log(n2*x8) + x1*log(n3*x8) + 1.0*x10*log(x10*x8) + x2*log(n5*x8) + 1.0*x6*log(x6*x8) + 1.0*x7*log(x7*x8) + x9*(log(n4*x8) - 0.69314718055994495) + (2.0*n1 + 2.0*n2 + 2.0*n3 + 2.0*n5 + x9)*log(x8*(0.5*n4 + x3))) + n1*(*endmember[0].mu0)(T, P) + n2*(*endmember[1].mu0)(T, P) + n3*(*endmember[2].mu0)(T, P) + n4*(*endmember[3].mu0)(T, P) + n5*(*endmember[4].mu0)(T, P)))/x4;
    return result;
}
        
static void coder_dgdn(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = 3.5*n4;
    double x1 = 1.0*n5;
    double x2 = 1.0*n2;
    double x3 = 1.0*n1;
    double x4 = 1.0*n3;
    double x5 = x3 + x4;
    double x6 = x1 + x2 + x5;
    double x7 = x0 + x6;
    double x8 = 12349.999999999998*n3 + 20222.222222222219*n4 + 12149.999999999998*n5;
    double x9 = (*endmember[0].mu0)(T, P);
    double x10 = n1*x9;
    double x11 = (*endmember[1].mu0)(T, P);
    double x12 = n2*x11;
    double x13 = (*endmember[2].mu0)(T, P);
    double x14 = n3*x13;
    double x15 = (*endmember[3].mu0)(T, P);
    double x16 = (*endmember[4].mu0)(T, P);
    double x17 = n5*x16;
    double x18 = n1 + n3;
    double x19 = n4 + n5;
    double x20 = n2 + x18 + x19;
    double x21 = 1.0/x20;
    double x22 = log(n2*x21);
    double x23 = log(n3*x21);
    double x24 = log(n5*x21);
    double x25 = log(n4*x21);
    double x26 = 1.0*n4;
    double x27 = 1.0*log(x18*x21);
    double x28 = 1.0*log(x19*x21);
    double x29 = n1 + n2 + n4;
    double x30 = 1.0*log(x21*x29);
    double x31 = 2.0*n1 + 2.0*n2 + 2.0*n3 + 2.0*n5 + x26;
    double x32 = 0.5*n4 + x6;
    double x33 = log(x21*x32);
    double x34 = x1*x24 + x18*x27 + x19*x28 + x2*x22 + x23*x4 + x26*(x25 - 0.69314718055994495) + x29*x30 + x31*x33;
    double x35 = 8.3144626181532395*T;
    double x36 = x34*x35;
    double x37 = (n1*x8 + n2*x8 + 0.027777777777777773*n3*(444600.0*n1 + 444600.0*n2 + 1682800.0*n4 + 828000.0*n5) + 0.0085352842554488641*n4*(2369250.0*n1 + 2369250.0*n2 + 5476612.5*n3 + 911250.0*n5) + 0.027777777777777773*n5*(437400.0*n1 + 437400.0*n2 + 828000.0*n3 + 280000.0*n4) + x7*(n4*x15 + x10 + x12 + x14 + x17 + x36))/((x7)*(x7));
    double x38 = -1.0*x37;
    double x39 = 1.0/x7;
    double x40 = 2.0*x33;
    double x41 = -x2*x21;
    double x42 = -x21*x4;
    double x43 = -x21*x26;
    double x44 = pow(x20, -2);
    double x45 = -x32*x44;
    double x46 = x20*x31/x32;
    double x47 = x46*(1.0*x21 + x45);
    double x48 = x40 + x41 + x42 + x43 + x47;
    double x49 = x1 + x26;
    double x50 = -x21*x49;
    double x51 = -x1*x21;
    double x52 = x2 + x26 + x3;
    double x53 = x20*x52*(x21 - x29*x44)/x29 + x30 + x51;
    double x54 = x50 + x53;
    double x55 = x27 + x20*x5*(-x18*x44 + x21)/x18;
    double x56 = x1*x16 + x11*x2 + x13*x4 + x15*x26 + x3*x9 + x36;
    double x57 = 24699.999999999996*n3 + 40444.444444444438*n4 + 24299.999999999996*n5 + x56;
    double x58 = 1.0*x20;
    double x59 = -x21*x5;
    double x60 = x42 + x59;
    double x61 = x40 + x43 + x47;
    double x62 = -x21*x52;
    double x63 = x28 + x20*x49*(-x19*x44 + x21)/x19;

result[0] = x38 + x39*(x57 + x7*(x35*(x48 + x54 + x55) + x9));
result[1] = x38 + x39*(x57 + x7*(x11 + x35*(1.0*x22 + x54 + x58*(-n2*x44 + x21) + x60 + x61)));
result[2] = x38 + x39*(24699.999999999996*n1 + 24699.999999999996*n2 + 93488.888888888876*n4 + 45999.999999999993*n5 + x56 + x7*(x13 + x35*(1.0*x23 + x41 + x50 + x51 + x55 + x58*(-n3*x44 + x21) + x61 + x62)));
result[3] = -3.5*x37 + x39*(29.100619163536336*T*x34 + 40444.444444444438*n1 + 40444.444444444438*n2 + 93488.888888888876*n3 + 15555.555555555555*n5 + x0*x15 + 3.5*x10 + 3.5*x12 + 3.5*x14 + 3.5*x17 + x7*(x15 + x35*(1.0*x25 + 1.0*x33 + x41 + x46*(0.5*x21 + x45) + x53 + x58*(-n4*x44 + x21) + x60 + x63 - 0.69314718055994495)));
result[4] = x38 + x39*(24299.999999999996*n1 + 24299.999999999996*n2 + 45999.999999999993*n3 + 15555.555555555555*n4 + x56 + x7*(x16 + x35*(1.0*x24 + x48 + x58*(-n5*x44 + x21) + x59 + x62 + x63)));
}
        
static void coder_d2gdn2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = 3.5*n4;
    double x1 = 1.0*n5;
    double x2 = 1.0*n2;
    double x3 = 1.0*n1;
    double x4 = 1.0*n3;
    double x5 = x3 + x4;
    double x6 = x1 + x2 + x5;
    double x7 = x0 + x6;
    double x8 = 12349.999999999998*n3 + 20222.222222222219*n4 + 12149.999999999998*n5;
    double x9 = (*endmember[0].mu0)(T, P);
    double x10 = n1*x9;
    double x11 = (*endmember[1].mu0)(T, P);
    double x12 = n2*x11;
    double x13 = (*endmember[2].mu0)(T, P);
    double x14 = n3*x13;
    double x15 = (*endmember[3].mu0)(T, P);
    double x16 = (*endmember[4].mu0)(T, P);
    double x17 = n5*x16;
    double x18 = n1 + n3;
    double x19 = n4 + n5;
    double x20 = n2 + x18 + x19;
    double x21 = 1.0/x20;
    double x22 = log(n2*x21);
    double x23 = log(n3*x21);
    double x24 = log(n5*x21);
    double x25 = log(n4*x21);
    double x26 = 1.0*n4;
    double x27 = 1.0*log(x18*x21);
    double x28 = 1.0*log(x19*x21);
    double x29 = n1 + n2 + n4;
    double x30 = 1.0*log(x21*x29);
    double x31 = 2.0*n2;
    double x32 = 2.0*n3;
    double x33 = 2.0*n5;
    double x34 = 2.0*n1 + x26 + x31 + x32 + x33;
    double x35 = 0.5*n4 + x6;
    double x36 = log(x21*x35);
    double x37 = x1*x24 + x18*x27 + x19*x28 + x2*x22 + x23*x4 + x26*(x25 - 0.69314718055994495) + x29*x30 + x34*x36;
    double x38 = 8.3144626181532395*T;
    double x39 = x37*x38;
    double x40 = (n1*x8 + n2*x8 + 0.027777777777777773*n3*(444600.0*n1 + 444600.0*n2 + 1682800.0*n4 + 828000.0*n5) + 0.0085352842554488641*n4*(2369250.0*n1 + 2369250.0*n2 + 5476612.5*n3 + 911250.0*n5) + 0.027777777777777773*n5*(437400.0*n1 + 437400.0*n2 + 828000.0*n3 + 280000.0*n4) + x7*(n4*x15 + x10 + x12 + x14 + x17 + x39))/((x7)*(x7)*(x7));
    double x41 = 2.0*x40;
    double x42 = pow(x7, -2);
    double x43 = 2.0*x36;
    double x44 = -x2*x21;
    double x45 = -x21*x4;
    double x46 = -x21*x26;
    double x47 = 1.0*x21;
    double x48 = pow(x20, -2);
    double x49 = -x35*x48;
    double x50 = x47 + x49;
    double x51 = 1.0/x35;
    double x52 = x34*x51;
    double x53 = x50*x52;
    double x54 = x20*x53;
    double x55 = x43 + x44 + x45 + x46 + x54;
    double x56 = x1 + x26;
    double x57 = -x21*x56;
    double x58 = -x1*x21;
    double x59 = x2 + x26 + x3;
    double x60 = 1.0/x29;
    double x61 = x21 - x29*x48;
    double x62 = x60*x61;
    double x63 = x59*x62;
    double x64 = x20*x63 + x30 + x58;
    double x65 = x57 + x64;
    double x66 = 1.0/x18;
    double x67 = -x18*x48 + x21;
    double x68 = x66*x67;
    double x69 = x5*x68;
    double x70 = x20*x69 + x27;
    double x71 = T*(x55 + x65 + x70);
    double x72 = 8.3144626181532395*x71;
    double x73 = x1*x16 + x11*x2 + x13*x4 + x15*x26 + x3*x9 + x39;
    double x74 = 24699.999999999996*n3 + 40444.444444444438*n4 + 24299.999999999996*n5 + x73;
    double x75 = x42*(x7*(x72 + x9) + x74);
    double x76 = 1.0/x7;
    double x77 = x50*x51;
    double x78 = -2.0*x48;
    double x79 = pow(x20, -3);
    double x80 = 2*x79;
    double x81 = x35*x80;
    double x82 = x20*x52;
    double x83 = 1.0*x20;
    double x84 = x34/((x35)*(x35));
    double x85 = x50*x84;
    double x86 = 4.0*x20*x77 + x82*(x78 + x81) - x83*x85;
    double x87 = 2.0*x20;
    double x88 = x62*x87;
    double x89 = -2*x48;
    double x90 = x20*x59;
    double x91 = x60*x90;
    double x92 = x91*(x29*x80 + x89);
    double x93 = -x61*x90/((x29)*(x29));
    double x94 = x2*x48;
    double x95 = x4*x48;
    double x96 = x1*x48;
    double x97 = x63 + x94 + x95 + x96;
    double x98 = x88 + x92 + x93 + x97;
    double x99 = x86 + x98;
    double x100 = x26*x48;
    double x101 = -x26;
    double x102 = x100 - x48*(-x1 + x101) + x53;
    double x103 = x20*x5;
    double x104 = x103*x66;
    double x105 = -x103*x67/((x18)*(x18)) + x104*(x18*x80 + x89) + x68*x87 + x69;
    double x106 = x102 + x105;
    double x107 = x38*x7;
    double x108 = -x48;
    double x109 = -n1;
    double x110 = x104*(x108 - x80*(-n3 + x109));
    double x111 = x110 + x69;
    double x112 = -2.0*x21;
    double x113 = x102 + x112;
    double x114 = x72 + 1.0*x9;
    double x115 = x83*(-n2*x48 + x21);
    double x116 = -x21*x5;
    double x117 = x116 + x45;
    double x118 = x43 + x46 + x54;
    double x119 = x115 + x117 + x118 + 1.0*x22 + x65;
    double x120 = x119*x38;
    double x121 = 1.0*x11 + x120;
    double x122 = x7*(x11 + x120) + x74;
    double x123 = 1.0*x42;
    double x124 = -x122*x123;
    double x125 = x41 - 1.0*x75;
    double x126 = x91*(x108 - x80*(-n2 - n4 + x109));
    double x127 = x126 + x97;
    double x128 = x127 + x86;
    double x129 = -x21*x59;
    double x130 = x83*(-n3*x48 + x21);
    double x131 = x118 + x129 + x130 + 1.0*x23 + x44 + x57 + x58 + x70;
    double x132 = x131*x38;
    double x133 = 1.0*x13 + x132;
    double x134 = x133 + 24699.999999999996;
    double x135 = 24699.999999999996*n1 + 24699.999999999996*n2 + 93488.888888888876*n4 + 45999.999999999993*n5 + x7*(x13 + x132) + x73;
    double x136 = -x123*x135;
    double x137 = -3.0*x21;
    double x138 = x100 + x48*x56 + x53;
    double x139 = x111 + x138;
    double x140 = 0.5*x20;
    double x141 = 0.5*x21 + x49;
    double x142 = x141*x51*x87;
    double x143 = x142 + x77*x83 + x82*(-1.5*x48 + x81);
    double x144 = -x140*x85 + x143;
    double x145 = x83*(-n4*x48 + x21);
    double x146 = x141*x52;
    double x147 = 1.0/x19;
    double x148 = -x19*x48 + x21;
    double x149 = x147*x148;
    double x150 = x149*x56;
    double x151 = x150*x20 + x28;
    double x152 = x117 + x145 + x146*x20 + x151 + 1.0*x25 + 1.0*x36 + x44 + x64 - 0.69314718055994495;
    double x153 = x152*x38;
    double x154 = 1.0*x15 + x153;
    double x155 = x154 + 40444.444444444438;
    double x156 = 29.100619163536336*T;
    double x157 = 40444.444444444438*n1 + 40444.444444444438*n2 + 93488.888888888876*n3 + 15555.555555555555*n5 + x0*x15 + 3.5*x10 + 3.5*x12 + 3.5*x14 + x156*x37 + 3.5*x17 + x7*(x15 + x153);
    double x158 = -x123*x157 + 7.0*x40;
    double x159 = x110 + x138 - 4.0*x21 + x69;
    double x160 = x83*(-n5*x48 + x21);
    double x161 = x116 + x129 + x151 + x160 + 1.0*x24 + x55;
    double x162 = x161*x38;
    double x163 = 1.0*x16 + x162;
    double x164 = x163 + 24299.999999999996;
    double x165 = 24299.999999999996*n1 + 24299.999999999996*n2 + 45999.999999999993*n3 + 15555.555555555555*n4 + x7*(x16 + x162) + x73;
    double x166 = -x123*x165;
    double x167 = x122*x42;
    double x168 = 16.628925236306479*T;
    double x169 = -x94;
    double x170 = x31*x79;
    double x171 = x88 + x92 + x93;
    double x172 = x86 + x96;
    double x173 = -x3;
    double x174 = -x48*(x173 - x4);
    double x175 = x174 + x47;
    double x176 = x175 + x95;
    double x177 = x137 + x86 + x96;
    double x178 = -1.0*x48;
    double x179 = x169 + x20*(x170 + x178) + x63 + x95;
    double x180 = x126 + x177 + x179;
    double x181 = x124 + x41;
    double x182 = x138 + x174;
    double x183 = x144 + x96;
    double x184 = x135*x42;
    double x185 = -x95;
    double x186 = x32*x79;
    double x187 = -x48*(x101 + x173 - x2) + x94;
    double x188 = x185 + x20*(x178 + x186);
    double x189 = 2.0*n4*x79;
    double x190 = x141*x84;
    double x191 = x20*x56;
    double x192 = x147*x191*(x19*x80 + x89) - x148*x191/((x19)*(x19)) + x149*x87 + x150;
    double x193 = -x100 + x146 + x192;
    double x194 = x165*x42;

result[0] = x41 - 2.0*x75 + x76*(x107*(x106 + x99) + 16.628925236306479*x71 + 2.0*x9);
result[1] = x124 + x125 + x76*(x107*(x111 + x113 + x99) + x114 + x121);
result[2] = x125 + x136 + x76*(x107*(x105 + x113 + x128) + x114 + x134);
result[3] = x158 - 3.5*x75 + x76*(x107*(x137 + x139 + x144 + x98) + x155 + 29.100619163536336*x71 + 3.5*x9);
result[4] = x125 + x166 + x76*(x107*(x128 + x159) + x114 + x164);
result[5] = -2.0*x167 + x41 + x76*(x107*(x102 + x169 + x171 + x172 + x176 + x20*(x170 + x78) + x63 + x115/n2) + 2.0*x11 + x119*x168);
result[6] = x136 + x181 + x76*(x107*(x102 + x180 + x48*x5) + x121 + x134);
result[7] = x158 - 3.5*x167 + x76*(x107*(x112 + x171 + x179 + x182 + x183) + 3.5*x11 + x119*x156 + x155);
result[8] = x166 + x181 + x76*(x107*(x180 + x182) + x121 + x164);
result[9] = -2.0*x184 + x41 + x76*(x107*(x106 + x172 + x185 + x187 + x20*(x186 + x78) + x47 + x130/n3) + 2.0*x13 + x131*x168);
result[10] = x158 - 3.5*x184 + x76*(x107*(x159 + x183 + x188 + x48*x59 + x94) + 3.5*x13 + x131*x156 + x154 + 93488.888888888876);
result[11] = x136 + x166 + x41 + x76*(x107*(x139 + x177 + x187 + x188) + x133 + x163 + 45999.999999999993);
result[12] = -7.0*x157*x42 + 24.5*x40 + x76*(58.201238327072673*T*x152 + x107*(-x140*x190 + x142 + x175 + x193 + x20*(x189 + x78) + x82*(x178 + x81) + x98 + x145/n4) + 7.0*x15);
result[13] = x158 - 3.5*x194 + x76*(x107*(x112 + x127 + x143 + x174 - x190*x83 + x193 + x20*(x178 + x189)) + x154 + x156*x161 + 3.5*x16 + 15555.555555555555);
result[14] = -2.0*x194 + x41 + x76*(x107*(x100 + x176 + x187 + x192 + x20*(x33*x79 + x78) + x53 + x86 - x96 + x160/n5) + 2.0*x16 + x161*x168);
}
        
static void coder_d3gdn3(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = 3.5*n4;
    double x1 = 1.0*n5;
    double x2 = 1.0*n2;
    double x3 = 1.0*n1;
    double x4 = 1.0*n3;
    double x5 = x3 + x4;
    double x6 = x1 + x2 + x5;
    double x7 = x0 + x6;
    double x8 = 12349.999999999998*n3 + 20222.222222222219*n4 + 12149.999999999998*n5;
    double x9 = (*endmember[0].mu0)(T, P);
    double x10 = n1*x9;
    double x11 = (*endmember[1].mu0)(T, P);
    double x12 = n2*x11;
    double x13 = (*endmember[2].mu0)(T, P);
    double x14 = n3*x13;
    double x15 = (*endmember[3].mu0)(T, P);
    double x16 = (*endmember[4].mu0)(T, P);
    double x17 = n5*x16;
    double x18 = n1 + n3;
    double x19 = n4 + n5;
    double x20 = n2 + x18 + x19;
    double x21 = 1.0/x20;
    double x22 = log(n2*x21);
    double x23 = log(n3*x21);
    double x24 = log(n5*x21);
    double x25 = log(n4*x21);
    double x26 = 1.0*n4;
    double x27 = 1.0*log(x18*x21);
    double x28 = 1.0*log(x19*x21);
    double x29 = n1 + n2 + n4;
    double x30 = 1.0*log(x21*x29);
    double x31 = 2.0*n2;
    double x32 = 2.0*n3;
    double x33 = 2.0*n5;
    double x34 = 2.0*n1 + x26 + x31 + x32 + x33;
    double x35 = 0.5*n4 + x6;
    double x36 = log(x21*x35);
    double x37 = x1*x24 + x18*x27 + x19*x28 + x2*x22 + x23*x4 + x26*(x25 - 0.69314718055994495) + x29*x30 + x34*x36;
    double x38 = 8.3144626181532395*T;
    double x39 = x37*x38;
    double x40 = (n1*x8 + n2*x8 + 0.027777777777777773*n3*(444600.0*n1 + 444600.0*n2 + 1682800.0*n4 + 828000.0*n5) + 0.0085352842554488641*n4*(2369250.0*n1 + 2369250.0*n2 + 5476612.5*n3 + 911250.0*n5) + 0.027777777777777773*n5*(437400.0*n1 + 437400.0*n2 + 828000.0*n3 + 280000.0*n4) + x7*(n4*x15 + x10 + x12 + x14 + x17 + x39))/((x7)*(x7)*(x7)*(x7));
    double x41 = -6.0*x40;
    double x42 = pow(x7, -3);
    double x43 = 2.0*x36;
    double x44 = -x2*x21;
    double x45 = -x21*x4;
    double x46 = -x21*x26;
    double x47 = 1.0/x35;
    double x48 = 1.0*x21;
    double x49 = pow(x20, -2);
    double x50 = -x35*x49;
    double x51 = x48 + x50;
    double x52 = x47*x51;
    double x53 = x34*x52;
    double x54 = x20*x53;
    double x55 = x43 + x44 + x45 + x46 + x54;
    double x56 = x1 + x26;
    double x57 = -x21*x56;
    double x58 = -x1*x21;
    double x59 = x2 + x26 + x3;
    double x60 = 1.0/x29;
    double x61 = x21 - x29*x49;
    double x62 = x60*x61;
    double x63 = x59*x62;
    double x64 = x20*x63 + x30 + x58;
    double x65 = x57 + x64;
    double x66 = 1.0/x18;
    double x67 = -x18*x49 + x21;
    double x68 = x66*x67;
    double x69 = x5*x68;
    double x70 = x20*x69 + x27;
    double x71 = x55 + x65 + x70;
    double x72 = x38*x71;
    double x73 = x1*x16 + x11*x2 + x13*x4 + x15*x26 + x3*x9 + x39;
    double x74 = 24699.999999999996*n3 + 40444.444444444438*n4 + 24299.999999999996*n5 + x73;
    double x75 = x42*(x7*(x72 + x9) + x74);
    double x76 = pow(x7, -2);
    double x77 = 16.628925236306479*T;
    double x78 = 4.0*x20;
    double x79 = 2.0*x49;
    double x80 = -x79;
    double x81 = pow(x20, -3);
    double x82 = 2*x81;
    double x83 = x35*x82;
    double x84 = x80 + x83;
    double x85 = x34*x47;
    double x86 = x84*x85;
    double x87 = 1.0*x20;
    double x88 = pow(x35, -2);
    double x89 = x51*x88;
    double x90 = x34*x89;
    double x91 = x20*x86 + x52*x78 - x87*x90;
    double x92 = 2.0*x62;
    double x93 = x20*x92;
    double x94 = -2*x49;
    double x95 = x29*x82 + x94;
    double x96 = x59*x60;
    double x97 = x95*x96;
    double x98 = x20*x97;
    double x99 = pow(x29, -2);
    double x100 = x61*x99;
    double x101 = x100*x59;
    double x102 = -x101*x20;
    double x103 = x2*x49;
    double x104 = x4*x49;
    double x105 = x1*x49;
    double x106 = x103 + x104 + x105 + x63;
    double x107 = x102 + x106 + x93 + x98;
    double x108 = x107 + x91;
    double x109 = x26*x49;
    double x110 = -x26;
    double x111 = -x1 + x110;
    double x112 = x109 - x111*x49 + x53;
    double x113 = 2.0*x68;
    double x114 = x18*x82 + x94;
    double x115 = x5*x66;
    double x116 = x114*x115;
    double x117 = pow(x18, -2);
    double x118 = x117*x67;
    double x119 = x118*x5;
    double x120 = x113*x20 + x116*x20 - x119*x20 + x69;
    double x121 = x112 + x120;
    double x122 = T*(x108 + x121);
    double x123 = 8.3144626181532395*x122;
    double x124 = x76*(x123*x7 + x71*x77 + 2.0*x9);
    double x125 = 1.0/x7;
    double x126 = x31*x81;
    double x127 = -x126;
    double x128 = 3.0*x20;
    double x129 = 6*x81;
    double x130 = pow(x20, -4);
    double x131 = 6*x130;
    double x132 = x115*x20;
    double x133 = x117*x5;
    double x134 = 2*x20;
    double x135 = x114*x128*x66 - x114*x133*x134 + 2*x116 - x118*x128 - 2*x119 + x132*(x129 - x131*x18) + x134*x5*x67/((x18)*(x18)*(x18)) + 3.0*x68;
    double x136 = x127 + x135;
    double x137 = -x56*x82;
    double x138 = x32*x81;
    double x139 = -x138;
    double x140 = 2.0*x81;
    double x141 = n4*x140;
    double x142 = -x141;
    double x143 = x33*x81;
    double x144 = -x143;
    double x145 = x139 + x142 + x144;
    double x146 = x137 + x145;
    double x147 = 6.0*x20;
    double x148 = x47*x84;
    double x149 = 2.0*x34;
    double x150 = 6.0*x81;
    double x151 = -x131*x35;
    double x152 = x20*x85;
    double x153 = x149*x20;
    double x154 = pow(x35, -3);
    double x155 = x154*x51;
    double x156 = x84*x88;
    double x157 = x147*x148 - x147*x89 - x149*x89 + x152*(x150 + x151) + x153*x155 - x153*x156 + 6.0*x52 + 2*x86;
    double x158 = x146 + x157;
    double x159 = x20*x96;
    double x160 = x59*x99;
    double x161 = -x100*x128 - 2*x101 + x128*x60*x95 - x134*x160*x95 + x134*x59*x61/((x29)*(x29)*(x29)) + x159*(x129 - x131*x29) + 3.0*x62 + 2*x97;
    double x162 = x158 + x161;
    double x163 = x38*x7;
    double x164 = -x49;
    double x165 = -n1;
    double x166 = -n3 + x165;
    double x167 = x164 - x166*x82;
    double x168 = x115*x167;
    double x169 = x168*x20;
    double x170 = x169 + x69;
    double x171 = -2.0*x21;
    double x172 = x112 + x171;
    double x173 = x108 + x170 + x172;
    double x174 = x173*x77;
    double x175 = 1.0*x49;
    double x176 = x167*x20;
    double x177 = 4*x81;
    double x178 = 2*n1;
    double x179 = 2*n3;
    double x180 = 3*x130;
    double x181 = -x180*(x178 + x179);
    double x182 = x116 - x119 - x133*x176 + x168;
    double x183 = x113 + x132*(x177 + x181) + 2.0*x176*x66 + x182;
    double x184 = x127 + x183;
    double x185 = -n2*x49 + x21;
    double x186 = x185*x87;
    double x187 = -x21*x5;
    double x188 = x187 + x45;
    double x189 = x43 + x46 + x54;
    double x190 = x186 + x188 + x189 + 1.0*x22 + x65;
    double x191 = x190*x38;
    double x192 = x7*(x11 + x191) + x74;
    double x193 = 2.0*x42;
    double x194 = x192*x193;
    double x195 = x173*x38;
    double x196 = x72 + 1.0*x9;
    double x197 = 1.0*x11 + x191;
    double x198 = x195*x7 + x196 + x197;
    double x199 = 2.0*x76;
    double x200 = -x198*x199 + x41;
    double x201 = -1.0*x124 + 4.0*x75;
    double x202 = -n2 - n4 + x165;
    double x203 = x164 - x202*x82;
    double x204 = x203*x96;
    double x205 = x20*x204;
    double x206 = x106 + x205;
    double x207 = x206 + x91;
    double x208 = x120 + x172 + x207;
    double x209 = x208*x77;
    double x210 = x20*x203;
    double x211 = 2*n2;
    double x212 = 2*n4;
    double x213 = -x180*(x178 + x211 + x212);
    double x214 = -x101 - x160*x210 + x204 + x97;
    double x215 = x159*(x177 + x213) + 2.0*x210*x60 + x214 + x92;
    double x216 = -x21*x59;
    double x217 = -n3*x49 + x21;
    double x218 = x217*x87;
    double x219 = x189 + x216 + x218 + 1.0*x23 + x44 + x57 + x58 + x70;
    double x220 = x219*x38;
    double x221 = 24699.999999999996*n1 + 24699.999999999996*n2 + 93488.888888888876*n4 + 45999.999999999993*n5 + x7*(x13 + x220) + x73;
    double x222 = x193*x221;
    double x223 = x208*x38;
    double x224 = 1.0*x13 + x220;
    double x225 = x224 + 24699.999999999996;
    double x226 = x196 + x223*x7 + x225;
    double x227 = -x199*x226;
    double x228 = x201 + x41;
    double x229 = -3.0*x21;
    double x230 = x109 + x49*x56 + x53;
    double x231 = x170 + x230;
    double x232 = 0.5*x20;
    double x233 = 0.5*x21 + x50;
    double x234 = x233*x47;
    double x235 = 2.0*x234;
    double x236 = x20*x235;
    double x237 = -1.5*x49 + x83;
    double x238 = x237*x85;
    double x239 = x20*x238 + x236 + x52*x87;
    double x240 = -x232*x90 + x239;
    double x241 = x107 + x229 + x231 + x240;
    double x242 = x111*x82;
    double x243 = x34*x87;
    double x244 = x243*x88;
    double x245 = -x237*x244;
    double x246 = x232*x34;
    double x247 = x237*x47;
    double x248 = x148*x87 + x152*(x151 + 5.0*x81) + x247*x78;
    double x249 = x155*x243 - x156*x246 + x238 + x248 + x86 - 1.5*x90;
    double x250 = -x128*x89 + x242 + x245 + x249 + 5.0*x52;
    double x251 = x145 + x250;
    double x252 = x161 + x251;
    double x253 = x184 + x79;
    double x254 = 29.100619163536336*T;
    double x255 = x241*x38;
    double x256 = -n4*x49 + x21;
    double x257 = x256*x87;
    double x258 = x233*x85;
    double x259 = 1.0/x19;
    double x260 = -x19*x49 + x21;
    double x261 = x259*x260;
    double x262 = x261*x56;
    double x263 = x20*x262 + x28;
    double x264 = x188 + x20*x258 + 1.0*x25 + x257 + x263 + 1.0*x36 + x44 + x64 - 0.69314718055994495;
    double x265 = x264*x38;
    double x266 = 1.0*x15 + x265;
    double x267 = x266 + 40444.444444444438;
    double x268 = x254*x71 + x255*x7 + x267 + 3.5*x9;
    double x269 = 40444.444444444438*n1 + 40444.444444444438*n2 + 93488.888888888876*n3 + 15555.555555555555*n5 + x0*x15 + 3.5*x10 + 3.5*x12 + 3.5*x14 + 3.5*x17 + x254*x37 + x7*(x15 + x265);
    double x270 = x193*x269 - 21.0*x40;
    double x271 = x169 - 4.0*x21 + x230 + x69;
    double x272 = x207 + x271;
    double x273 = x272*x77;
    double x274 = x157 + x242;
    double x275 = x145 + x274;
    double x276 = x215 + x275;
    double x277 = -n5*x49 + x21;
    double x278 = x277*x87;
    double x279 = x187 + x216 + 1.0*x24 + x263 + x278 + x55;
    double x280 = x279*x38;
    double x281 = 24299.999999999996*n1 + 24299.999999999996*n2 + 45999.999999999993*n3 + 15555.555555555555*n4 + x7*(x16 + x280) + x73;
    double x282 = x193*x281;
    double x283 = x272*x38;
    double x284 = 1.0*x16 + x280;
    double x285 = x284 + 24299.999999999996;
    double x286 = x196 + x283*x7 + x285;
    double x287 = -x199*x286;
    double x288 = -x103;
    double x289 = 1.0/n2;
    double x290 = x102 + x93 + x98;
    double x291 = x105 + x91;
    double x292 = -x3;
    double x293 = x292 - x4;
    double x294 = -x293*x49;
    double x295 = x294 + x48;
    double x296 = x104 + x295;
    double x297 = x112 + x186*x289 + x20*(x126 + x80) + x288 + x290 + x291 + x296 + x63;
    double x298 = x297*x38;
    double x299 = x132*(x181 + x82) + 2*x168;
    double x300 = x127 + x299;
    double x301 = 3.0*x49;
    double x302 = x158 + x301;
    double x303 = 2.0*x75;
    double x304 = x192*x42;
    double x305 = 2.0*x11 + x190*x77 + x298*x7;
    double x306 = 1.0*x76;
    double x307 = 4.0*x304 - x305*x306;
    double x308 = x105 + x229 + x91;
    double x309 = -x175;
    double x310 = x104 + x20*(x126 + x309) + x288 + x63;
    double x311 = x205 + x308 + x310;
    double x312 = x112 + x311 + x49*x5;
    double x313 = x312*x38;
    double x314 = -x226*x306;
    double x315 = x197 + x225 + x313*x7;
    double x316 = x222 - x306*x315;
    double x317 = x303 + x41;
    double x318 = x194 - x198*x306 + x317;
    double x319 = x230 + x294;
    double x320 = x105 + x240;
    double x321 = x171 + x290 + x310 + x319 + x320;
    double x322 = x321*x38;
    double x323 = 4.0*x49;
    double x324 = x300 + x323;
    double x325 = 3.5*x76;
    double x326 = -x268*x306 + x270 + 7.0*x75;
    double x327 = 3.5*x11 + x190*x254 + x267 + x322*x7;
    double x328 = 7.0*x304 - x306*x327;
    double x329 = x311 + x319;
    double x330 = x329*x38;
    double x331 = x197 + x285 + x330*x7;
    double x332 = -x306*x331;
    double x333 = x282 - x286*x306;
    double x334 = -x104;
    double x335 = 1.0/n3;
    double x336 = x110 - x2 + x292;
    double x337 = x103 - x336*x49;
    double x338 = x121 + x20*(x138 + x80) + x218*x335 + x291 + x334 + x337 + x48;
    double x339 = x338*x38;
    double x340 = 2*x204;
    double x341 = x159*(x213 + x82);
    double x342 = x127 + x340 + x341;
    double x343 = x158 + x342;
    double x344 = x221*x42;
    double x345 = 2.0*x13 + x219*x77 + x339*x7;
    double x346 = -x306*x345 + 4.0*x344;
    double x347 = x20*(x138 + x309) + x334;
    double x348 = x103 + x271 + x320 + x347 + x49*x59;
    double x349 = x348*x38;
    double x350 = x183 + x323;
    double x351 = x159*(x131*x202 + x177) + x203*x60*x87 + x214 + 1.0*x62;
    double x352 = 3.5*x13 + x219*x254 + x266 + x349*x7 + 93488.888888888876;
    double x353 = -x306*x352 + 7.0*x344;
    double x354 = x231 + x308 + x337 + x347;
    double x355 = x354*x38;
    double x356 = x224 + x284 + x355*x7 + 45999.999999999993;
    double x357 = -x306*x356;
    double x358 = 58.201238327072673*T;
    double x359 = 1.0/n4;
    double x360 = x309 + x83;
    double x361 = x360*x85;
    double x362 = x233*x88;
    double x363 = x34*x362;
    double x364 = 2.0*x20;
    double x365 = x20*x56;
    double x366 = x19*x82 + x94;
    double x367 = x259*x366;
    double x368 = pow(x19, -2);
    double x369 = x260*x368;
    double x370 = x261*x364 + x262 + x365*x367 - x365*x369;
    double x371 = -x109 + x258 + x370;
    double x372 = x107 + x20*x361 + x20*(x141 + x80) - x232*x363 + x236 + x257*x359 + x295 + x371;
    double x373 = x372*x38;
    double x374 = x300 + 5.0*x49;
    double x375 = x362*x87;
    double x376 = 2*x238 - x87*x89;
    double x377 = x360*x47;
    double x378 = 4.0*x81;
    double x379 = x152*(x151 + x378) + x247*x364 + x364*x377;
    double x380 = x155*x246 - x375 + x376 + x379 + 2.0*x52 - 1.0*x90;
    double x381 = x235 + x245;
    double x382 = x146 + x381;
    double x383 = x161 + x380 + x382;
    double x384 = 7.0*x76;
    double x385 = x269*x42;
    double x386 = 7.0*x15 + x264*x358 + x373*x7;
    double x387 = -x306*x386 + 14.0*x385 - 73.5*x40;
    double x388 = x171 + x20*(x141 + x309) + x206 + x239 + x294 - x34*x375 + x371;
    double x389 = x38*x388;
    double x390 = x249 - x362*x364 - x364*x89 + 3.0*x52;
    double x391 = x374 + x390;
    double x392 = x215 + x382;
    double x393 = x281*x42;
    double x394 = 3.5*x16 + x254*x279 + x266 + x389*x7 + 15555.555555555555;
    double x395 = -x306*x394 + 7.0*x393;
    double x396 = 1.0/n5;
    double x397 = -x105 + x109 + x20*(x143 + x80) + x278*x396 + x296 + x337 + x370 + x53 + x91;
    double x398 = x38*x397;
    double x399 = x299 + 6.0*x49;
    double x400 = 2.0*x16 + x279*x77 + x398*x7;
    double x401 = -x306*x400 + 4.0*x393;
    double x402 = 3.0*x76;
    double x403 = 24.943387854459719*T;
    double x404 = 1.0*x185*x289;
    double x405 = 6.0*x130;
    double x406 = -n2*x405;
    double x407 = x211*x81;
    double x408 = x289*x87;
    double x409 = -x5*x82;
    double x410 = n2*x378;
    double x411 = x158 + x410;
    double x412 = x409 + x411;
    double x413 = -x323;
    double x414 = x161 + x413;
    double x415 = x312*x77;
    double x416 = x20*(x378 + x406) + x309 + x404 + x408*(x164 + x407);
    double x417 = x215 + x416;
    double x418 = -x199*x315;
    double x419 = x307 + x41;
    double x420 = x409 + x410;
    double x421 = x251 + x420;
    double x422 = x329*x77;
    double x423 = x275 + x420;
    double x424 = -x199*x331;
    double x425 = x20*(x140 + x406);
    double x426 = x323 + x425;
    double x427 = x340 + x341 + x426;
    double x428 = x163*(x412 + x427);
    double x429 = x194 + x41;
    double x430 = x270 + x328;
    double x431 = x301 + x420 + x425;
    double x432 = -n3*x405;
    double x433 = x179*x81;
    double x434 = x335*x87;
    double x435 = n3*x378 + x142 + x144;
    double x436 = 1.0*x217*x335 + x435;
    double x437 = -x59*x82;
    double x438 = x157 + x437;
    double x439 = x413 + x438;
    double x440 = x183 + x20*(x378 + x432) + x434*(x164 + x433) + x436;
    double x441 = x354*x77;
    double x442 = x127 + x437;
    double x443 = -x199*x356 + x41;
    double x444 = x137 + x20*(x140 + x432) + x435;
    double x445 = x381 + x444;
    double x446 = -n4*x405;
    double x447 = x212*x81;
    double x448 = x359*x87;
    double x449 = x154*x233;
    double x450 = n4*x378 + x144;
    double x451 = 2*x56;
    double x452 = 2*x365;
    double x453 = x128*x367 - x128*x369 + x139 + x259*x365*(x129 - x131*x19) + 3.0*x261 - x366*x368*x452 + x367*x451 - x369*x451 + x409 + x260*x452/((x19)*(x19)*(x19));
    double x454 = x127 + x453;
    double x455 = -x244*x360 + 1.0*x256*x359 + x454;
    double x456 = x237*x88;
    double x457 = 4.0*x234 + x450;

result[0] = -3.0*x124 + x125*(24.943387854459719*x122 + x163*(x136 + x162)) + x41 + 6.0*x75;
result[1] = x125*(x123 + x163*(x162 + x175 + x184) + x174) + x194 + x200 + x201;
result[2] = x125*(x123 + x163*(x136 + x158 + x175 + x215) + x209) + x222 + x227 + x228;
result[3] = -3.5*x124 + x125*(29.100619163536336*x122 + x163*(x252 + x253) + x241*x77) - x199*x268 + x270 + 14.0*x75;
result[4] = x125*(x123 + x163*(x253 + x276) + x273) + x228 + x282 + x287;
result[5] = x125*(x163*(x161 + x300 + x302) + x174 + x298) + x200 + x303 + x307;
result[6] = x125*(x163*(x127 + x132*(x131*x166 + x177) + x167*x66*x87 + x182 + x215 + x302 + 1.0*x68) + x195 + x223 + x313) + x314 + x316 + x318;
result[7] = x125*(x163*(x252 + x324) + x173*x254 + x255 + x322) - x198*x325 + x326 + x328;
result[8] = x125*(x163*(x276 + x324) + x195 + x283 + x330) + x318 + x332 + x333;
result[9] = x125*(x163*(x135 + x301 + x343) + x209 + x339) + x227 + x317 + x346;
result[10] = x125*(x163*(x127 + x251 + x350 + x351) + x208*x254 + x255 + x349) - x226*x325 + x326 + x353;
result[11] = x125*(x163*(x275 + x342 + x350) + x223 + x283 + x355) + x222 + x314 + x317 + x333 + x357;
result[12] = x125*(x163*(x374 + x383) + x241*x358 + x373) - x268*x384 + x387 + 24.5*x75;
result[13] = x125*(x163*(x391 + x392) + x254*x272 + x255 + x389) - x286*x325 + x326 + x395;
result[14] = x125*(x163*(x343 + x399) + x273 + x398) + x287 + x317 + x401;
result[15] = x125*(x163*(x20*(x150 + x406) + x404 + x408*(x407 + x94) + x412 + x414 - x186/((n2)*(n2))) + x297*x403) + 6.0*x304 - x305*x402 + x41;
result[16] = x125*(x163*(x293*x82 + x411 + x417) + x298 + x415) + x222 + x418 + x419;
result[17] = x125*(x163*(x161 + x416 + x421) + x254*x297 + x321*x77) - x199*x327 + x270 + 14.0*x304 - x305*x325;
result[18] = x125*(x163*(x417 + x423) + x298 + x422) + x282 + x419 + x424;
result[19] = x125*(x339 + x415 + x428) + x346 + x418 + x429;
result[20] = x125*(x163*(x351 + x421 + x426) + x254*x312 + x322 + x349) - x315*x325 + x353 + x430;
result[21] = x125*(x163*(x423 + x427) + x313 + x330 + x355) + x282 + x316 + x332 + x357 + x429;
result[22] = x125*(x163*(x383 + x431) + x321*x358 + x373) + 24.5*x304 - x327*x384 + x387;
result[23] = x125*(x163*(x390 + x392 + x431) + x254*x329 + x322 + x389) - x325*x331 + x395 + x430;
result[24] = x125*(x398 + x422 + x428) + x401 + x424 + x429;
result[25] = x125*(x163*(x136 + x137 + x20*(x150 + x432) + x434*(x433 + x94) + x436 + x439 - x218/((n3)*(n3))) + x338*x403) + 6.0*x344 - x345*x402 + x41;
result[26] = x125*(x163*(x127 + x250 + x336*x82 + x440) + x254*x338 + x348*x77) - x199*x352 + x270 - x325*x345 + 14.0*x344;
result[27] = x125*(x163*(x274 + x309 + x440 + x442) + x339 + x441) + x282 + x346 + x443;
result[28] = x125*(x163*(x380 + x399 + x442 + x445) + x348*x358 + x373) + 24.5*x344 - x352*x384 + x387;
result[29] = x125*(x163*(x391 + x437 + x445) + x254*x354 + x349 + x389) + x270 - x325*x356 + x353 + x395;
result[30] = x125*(x163*(x324 + x438 + x444) + x398 + x441) + x222 + x401 + x443;
result[31] = x125*(87.301857490609009*T*x372 + x163*(x128*x377 + x152*(x151 + 3.0*x81) - 1.5*x20*x362 + x20*(x150 + x446) + 3.0*x234 + x246*x449 + 2*x361 - 1.0*x363 + x414 + x448*(x447 + x94) + x450 + x455 - x257/((n4)*(n4)))) + 73.5*x385 - 10.5*x386*x76 - 257.25*x40;
result[32] = x125*(x163*(-x128*x362 + x20*(x378 + x446) + x215 + x238 + x243*x449 - x246*x456 + x361 - 1.5*x363 + x379 + x448*(x164 + x447) + x455 + x457 + x80) + x358*x388 + x373) - x384*x394 + x387 + 24.5*x393;
result[33] = x125*(x163*(-x149*x362 + x153*x449 - x153*x456 + x20*(x140 + x446) + x248 + x342 - x362*x78 + x376 + x453 + x457 + 1.0*x52 + x79) + x254*x397 + x388*x77) - x199*x394 + x270 - x325*x400 + 14.0*x393;
result[34] = x125*(x163*(n5*x378 + x142 + x20*(-n5*x405 + x150) + 1.0*x277*x396 + x396*x87*(n5*x82 + x94) + x439 + x454 - x278/((n5)*(n5))) + x397*x403) + 6.0*x393 - x400*x402 + x41;
}
        
static double coder_dgdt(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    
    double x0 = n1 + n3;
    double x1 = n4 + n5;
    double x2 = 1.0/(n2 + x0 + x1);
    double x3 = n1 + n2 + n4;

result = n1*(*endmember[0].dmu0dT)(T, P) + 8.3144626181532395*n2*log(n2*x2) + n2*(*endmember[1].dmu0dT)(T, P) + 8.3144626181532395*n3*log(n3*x2) + n3*(*endmember[2].dmu0dT)(T, P) + 8.3144626181532395*n4*(log(n4*x2) - 0.69314718055994495) + n4*(*endmember[3].dmu0dT)(T, P) + 8.3144626181532395*n5*log(n5*x2) + n5*(*endmember[4].dmu0dT)(T, P) + 8.3144626181532395*x0*log(x0*x2) + 8.3144626181532395*x1*log(x1*x2) + 8.3144626181532395*x3*log(x2*x3) + 8.3144626181532395*(2.0*n1 + 2.0*n2 + 2.0*n3 + 1.0*n4 + 2.0*n5)*log(x2*(1.0*n1 + 1.0*n2 + 1.0*n3 + 0.5*n4 + 1.0*n5));
    return result;
}
        
static void coder_d2gdndt(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = n1 + n3;
    double x1 = n4 + n5;
    double x2 = n2 + x0 + x1;
    double x3 = 1.0/x2;
    double x4 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 0.5*n4 + 1.0*n5;
    double x5 = log(x3*x4);
    double x6 = 16.628925236306479*x5;
    double x7 = 8.3144626181532395*n2;
    double x8 = -x3*x7;
    double x9 = 8.3144626181532395*n3;
    double x10 = -x3*x9;
    double x11 = 8.3144626181532395*n4;
    double x12 = -x11*x3;
    double x13 = pow(x2, -2);
    double x14 = -x13*x4;
    double x15 = x2*(16.628925236306479*n1 + 16.628925236306479*n2 + 16.628925236306479*n3 + 16.628925236306479*n5 + x11)/x4;
    double x16 = x15*(x14 + 1.0*x3);
    double x17 = x10 + x12 + x16 + x6 + x8;
    double x18 = 8.3144626181532395*n5;
    double x19 = x11 + x18;
    double x20 = -x19*x3;
    double x21 = n1 + n2 + n4;
    double x22 = -x18*x3;
    double x23 = 8.3144626181532395*n1;
    double x24 = x11 + x23 + x7;
    double x25 = x2*x24*(-x13*x21 + x3)/x21 + x22 + 8.3144626181532395*log(x21*x3);
    double x26 = x20 + x25;
    double x27 = x23 + x9;
    double x28 = 8.3144626181532395*log(x0*x3) + x2*x27*(-x0*x13 + x3)/x0;
    double x29 = 8.3144626181532395*x2;
    double x30 = -x27*x3;
    double x31 = x10 + x30;
    double x32 = x12 + x16 + x6;
    double x33 = -x24*x3;
    double x34 = 8.3144626181532395*log(x1*x3) + x19*x2*(-x1*x13 + x3)/x1;

result[0] = x17 + x26 + x28 + (*endmember[0].dmu0dT)(T, P);
result[1] = x26 + x29*(-n2*x13 + x3) + x31 + x32 + 8.3144626181532395*log(n2*x3) + (*endmember[1].dmu0dT)(T, P);
result[2] = x20 + x22 + x28 + x29*(-n3*x13 + x3) + x32 + x33 + x8 + 8.3144626181532395*log(n3*x3) + (*endmember[2].dmu0dT)(T, P);
result[3] = x15*(x14 + 0.5*x3) + x25 + x29*(-n4*x13 + x3) + x31 + x34 + 8.3144626181532395*x5 + x8 + 8.3144626181532395*log(n4*x3) + (*endmember[3].dmu0dT)(T, P) - 5.7631463216439762;
result[4] = x17 + x29*(-n5*x13 + x3) + x30 + x33 + x34 + 8.3144626181532395*log(n5*x3) + (*endmember[4].dmu0dT)(T, P);
}
        
static void coder_d3gdn2dt(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 0.5*n4 + 1.0*n5;
    double x1 = 1.0/x0;
    double x2 = n1 + n3;
    double x3 = n4 + n5;
    double x4 = n2 + x2 + x3;
    double x5 = 1.0/x4;
    double x6 = pow(x4, -2);
    double x7 = -x0*x6;
    double x8 = 1.0*x5 + x7;
    double x9 = x4*x8;
    double x10 = x1*x9;
    double x11 = pow(x4, -3);
    double x12 = 2*x11;
    double x13 = x0*x12;
    double x14 = 16.628925236306479*n2;
    double x15 = 16.628925236306479*n3;
    double x16 = 8.3144626181532395*n4;
    double x17 = 16.628925236306479*n5;
    double x18 = 16.628925236306479*n1 + x14 + x15 + x16 + x17;
    double x19 = x1*x18;
    double x20 = x19*x4;
    double x21 = x18/((x0)*(x0));
    double x22 = x21*x9;
    double x23 = 33.257850472612958*x10 + x20*(x13 - 2.0*x6) - 1.0*x22;
    double x24 = n1 + n2 + n4;
    double x25 = 1.0/x24;
    double x26 = -x24*x6 + x5;
    double x27 = x25*x26;
    double x28 = 16.628925236306479*x4;
    double x29 = x27*x28;
    double x30 = -2*x6;
    double x31 = 8.3144626181532395*n1;
    double x32 = 8.3144626181532395*n2;
    double x33 = x16 + x31 + x32;
    double x34 = x33*x4;
    double x35 = x25*x34;
    double x36 = x35*(x12*x24 + x30);
    double x37 = -x26*x34/((x24)*(x24));
    double x38 = x32*x6;
    double x39 = 8.3144626181532395*n3;
    double x40 = x39*x6;
    double x41 = 8.3144626181532395*n5;
    double x42 = x41*x6;
    double x43 = x27*x33;
    double x44 = x38 + x40 + x42 + x43;
    double x45 = x29 + x36 + x37 + x44;
    double x46 = x23 + x45;
    double x47 = x16*x6;
    double x48 = x19*x8;
    double x49 = -x16;
    double x50 = x47 + x48 - x6*(-x41 + x49);
    double x51 = x31 + x39;
    double x52 = 1.0/x2;
    double x53 = -x2*x6 + x5;
    double x54 = x52*x53;
    double x55 = x51*x54;
    double x56 = x4*x51;
    double x57 = x52*x56;
    double x58 = x28*x54 + x55 + x57*(x12*x2 + x30) - x53*x56/((x2)*(x2));
    double x59 = x50 + x58;
    double x60 = -x6;
    double x61 = -n1;
    double x62 = x57*(-x12*(-n3 + x61) + x60);
    double x63 = x55 + x62;
    double x64 = -16.628925236306479*x5;
    double x65 = x50 + x64;
    double x66 = x35*(-x12*(-n2 - n4 + x61) + x60);
    double x67 = x44 + x66;
    double x68 = x23 + x67;
    double x69 = -24.943387854459719*x5;
    double x70 = x16 + x41;
    double x71 = x47 + x48 + x6*x70;
    double x72 = x63 + x71;
    double x73 = 0.5*x5 + x7;
    double x74 = x1*x28*x73;
    double x75 = 8.3144626181532395*x10 + x20*(x13 - 1.5*x6) + x74;
    double x76 = -0.5*x22 + x75;
    double x77 = -33.257850472612958*x5 + x55 + x62 + x71;
    double x78 = -x38;
    double x79 = -16.628925236306479*x6;
    double x80 = x11*x14;
    double x81 = 8.3144626181532395*x4;
    double x82 = x29 + x36 + x37;
    double x83 = x23 + x42;
    double x84 = -x31;
    double x85 = -x6*(-x39 + x84);
    double x86 = 8.3144626181532395*x5;
    double x87 = x85 + x86;
    double x88 = x40 + x87;
    double x89 = x23 + x42 + x69;
    double x90 = -8.3144626181532395*x6;
    double x91 = x4*(x80 + x90) + x40 + x43 + x78;
    double x92 = x66 + x89 + x91;
    double x93 = x71 + x85;
    double x94 = x42 + x76;
    double x95 = -x40;
    double x96 = x11*x15;
    double x97 = x38 - x6*(-x32 + x49 + x84);
    double x98 = x4*(x90 + x96) + x95;
    double x99 = 16.628925236306479*n4*x11;
    double x100 = x21*x4*x73;
    double x101 = 1.0/x3;
    double x102 = -x3*x6 + x5;
    double x103 = x101*x102;
    double x104 = x4*x70;
    double x105 = x101*x104*(x12*x3 + x30) - x102*x104/((x3)*(x3)) + x103*x28 + x103*x70;
    double x106 = x105 + x19*x73 - x47;

result[0] = x46 + x59;
result[1] = x46 + x63 + x65;
result[2] = x58 + x65 + x68;
result[3] = x45 + x69 + x72 + x76;
result[4] = x68 + x77;
result[5] = x4*(x79 + x80) + x43 + x50 + x78 + x82 + x83 + x88 + x81*(-n2*x6 + x5)/n2;
result[6] = x50 + x51*x6 + x92;
result[7] = x64 + x82 + x91 + x93 + x94;
result[8] = x92 + x93;
result[9] = x4*(x79 + x96) + x59 + x83 + x86 + x95 + x97 + x81*(-n3*x6 + x5)/n3;
result[10] = x33*x6 + x38 + x77 + x94 + x98;
result[11] = x72 + x89 + x97 + x98;
result[12] = -0.5*x100 + x106 + x20*(x13 - 1.0*x6) + x4*(x79 + x99) + x45 + x74 + x87 + x81*(-n4*x6 + x5)/n4;
result[13] = -1.0*x100 + x106 + x4*(x90 + x99) + x64 + x67 + x75 + x85;
result[14] = x105 + x23 + x4*(x11*x17 + x79) - x42 + x47 + x48 + x88 + x97 + x81*(-n5*x6 + x5)/n5;
}
        
static void coder_d4gdn3dt(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = n1 + n3;
    double x1 = n4 + n5;
    double x2 = n2 + x0 + x1;
    double x3 = pow(x2, -3);
    double x4 = 16.628925236306479*n2;
    double x5 = -x3*x4;
    double x6 = 1.0/x0;
    double x7 = 1.0/x2;
    double x8 = pow(x2, -2);
    double x9 = -x0*x8 + x7;
    double x10 = x6*x9;
    double x11 = 8.3144626181532395*n1;
    double x12 = 8.3144626181532395*n3;
    double x13 = x11 + x12;
    double x14 = pow(x0, -2);
    double x15 = x14*x9;
    double x16 = x13*x15;
    double x17 = -2*x8;
    double x18 = 2*x3;
    double x19 = x0*x18 + x17;
    double x20 = x13*x6;
    double x21 = x19*x20;
    double x22 = 24.943387854459719*x2;
    double x23 = 6*x3;
    double x24 = pow(x2, -4);
    double x25 = 6*x24;
    double x26 = x2*x20;
    double x27 = x13*x14;
    double x28 = 2*x2;
    double x29 = 24.943387854459719*x10 - x15*x22 - 2*x16 + x19*x22*x6 - x19*x27*x28 + 2*x21 + x26*(-x0*x25 + x23) + x13*x28*x9/((x0)*(x0)*(x0));
    double x30 = x29 + x5;
    double x31 = 8.3144626181532395*n4;
    double x32 = 8.3144626181532395*n5;
    double x33 = x31 + x32;
    double x34 = -x18*x33;
    double x35 = 16.628925236306479*n3;
    double x36 = -x3*x35;
    double x37 = 16.628925236306479*x3;
    double x38 = -n4*x37;
    double x39 = 16.628925236306479*n5;
    double x40 = -x3*x39;
    double x41 = x36 + x38 + x40;
    double x42 = x34 + x41;
    double x43 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 0.5*n4 + 1.0*n5;
    double x44 = 1.0/x43;
    double x45 = -x43*x8;
    double x46 = x45 + 1.0*x7;
    double x47 = x44*x46;
    double x48 = x18*x43;
    double x49 = x48 - 2.0*x8;
    double x50 = 16.628925236306479*n1 + x31 + x35 + x39 + x4;
    double x51 = x44*x50;
    double x52 = x49*x51;
    double x53 = 49.886775708919437*x2;
    double x54 = x44*x49;
    double x55 = pow(x43, -2);
    double x56 = x46*x55;
    double x57 = 2.0*x50;
    double x58 = -x25*x43;
    double x59 = x2*x51;
    double x60 = x2*x57;
    double x61 = pow(x43, -3);
    double x62 = x46*x61;
    double x63 = x49*x55;
    double x64 = 49.886775708919437*x47 + 2*x52 + x53*x54 - x53*x56 - x56*x57 + x59*(6.0*x3 + x58) + x60*x62 - x60*x63;
    double x65 = x42 + x64;
    double x66 = n1 + n2 + n4;
    double x67 = 1.0/x66;
    double x68 = -x66*x8 + x7;
    double x69 = x67*x68;
    double x70 = 8.3144626181532395*n2;
    double x71 = x11 + x31 + x70;
    double x72 = pow(x66, -2);
    double x73 = x68*x72;
    double x74 = x71*x73;
    double x75 = x17 + x18*x66;
    double x76 = x67*x71;
    double x77 = x75*x76;
    double x78 = x2*x76;
    double x79 = x71*x72;
    double x80 = x22*x67*x75 - x22*x73 - x28*x75*x79 + x28*x68*x71/((x66)*(x66)*(x66)) + 24.943387854459719*x69 - 2*x74 + 2*x77 + x78*(x23 - x25*x66);
    double x81 = x65 + x80;
    double x82 = 8.3144626181532395*x8;
    double x83 = -x8;
    double x84 = -n1;
    double x85 = -n3 + x84;
    double x86 = -x18*x85 + x83;
    double x87 = x2*x86;
    double x88 = x6*x87;
    double x89 = 4*x3;
    double x90 = 2*n1;
    double x91 = 2*n3;
    double x92 = 3*x24;
    double x93 = -x92*(x90 + x91);
    double x94 = x20*x86;
    double x95 = -x16 + x21 - x27*x87 + x94;
    double x96 = 16.628925236306479*x10 + x26*(x89 + x93) + 16.628925236306479*x88 + x95;
    double x97 = x5 + x96;
    double x98 = -n2 - n4 + x84;
    double x99 = -x18*x98 + x83;
    double x100 = x2*x99;
    double x101 = x100*x67;
    double x102 = 2*n2;
    double x103 = 2*n4;
    double x104 = -x92*(x102 + x103 + x90);
    double x105 = x76*x99;
    double x106 = -x100*x79 + x105 - x74 + x77;
    double x107 = 16.628925236306479*x101 + x106 + 16.628925236306479*x69 + x78*(x104 + x89);
    double x108 = -x31;
    double x109 = x18*(x108 - x32);
    double x110 = x48 - 1.5*x8;
    double x111 = x2*x50;
    double x112 = 1.0*x111;
    double x113 = x112*x55;
    double x114 = -x110*x113;
    double x115 = x110*x51;
    double x116 = x50*x56;
    double x117 = 0.5*x111;
    double x118 = 8.3144626181532395*x2;
    double x119 = x2*x44;
    double x120 = x110*x119;
    double x121 = x118*x54 + 33.257850472612958*x120 + x59*(5.0*x3 + x58);
    double x122 = x112*x62 + x115 - 1.5*x116 - x117*x63 + x121 + x52;
    double x123 = x109 + x114 + x122 - x22*x56 + 41.572313090766201*x47;
    double x124 = x123 + x41;
    double x125 = x124 + x80;
    double x126 = 16.628925236306479*x8;
    double x127 = x126 + x97;
    double x128 = x109 + x64;
    double x129 = x128 + x41;
    double x130 = x107 + x129;
    double x131 = x26*(x18 + x93) + 2*x94;
    double x132 = x131 + x5;
    double x133 = 24.943387854459719*x8;
    double x134 = x133 + x65;
    double x135 = 33.257850472612958*x8;
    double x136 = x132 + x135;
    double x137 = 2*x105;
    double x138 = x78*(x104 + x18);
    double x139 = x137 + x138 + x5;
    double x140 = x139 + x65;
    double x141 = x135 + x96;
    double x142 = 8.3144626181532395*x101 + x106 + 8.3144626181532395*x69 + x78*(x25*x98 + x89);
    double x143 = x132 + 41.572313090766201*x8;
    double x144 = x45 + 0.5*x7;
    double x145 = x144*x55;
    double x146 = 2*x115 - x118*x56;
    double x147 = x48 - 1.0*x8;
    double x148 = 16.628925236306479*x119*x147 + 16.628925236306479*x120 + x59*(4.0*x3 + x58);
    double x149 = -1.0*x116 + x117*x62 - x118*x145 + x146 + x148 + 16.628925236306479*x47;
    double x150 = x144*x44;
    double x151 = x114 + 16.628925236306479*x150;
    double x152 = x151 + x42;
    double x153 = x149 + x152 + x80;
    double x154 = 16.628925236306479*x2;
    double x155 = x122 - x145*x154 - x154*x56 + 24.943387854459719*x47;
    double x156 = x143 + x155;
    double x157 = x107 + x152;
    double x158 = x131 + 49.886775708919444*x8;
    double x159 = -n2*x8 + x7;
    double x160 = 8.3144626181532395/n2;
    double x161 = x159*x160;
    double x162 = 49.886775708919437*x3;
    double x163 = 49.886775708919437*x24;
    double x164 = -n2*x163;
    double x165 = x102*x3;
    double x166 = x160*x2;
    double x167 = -x13*x18;
    double x168 = 33.257850472612958*x3;
    double x169 = n2*x168;
    double x170 = x169 + x65;
    double x171 = x167 + x170;
    double x172 = -x135;
    double x173 = x172 + x80;
    double x174 = -x11;
    double x175 = -x82;
    double x176 = x161 + x166*(x165 + x83) + x175 + x2*(x164 + x168);
    double x177 = x107 + x176;
    double x178 = x167 + x169;
    double x179 = x124 + x178;
    double x180 = x129 + x178;
    double x181 = x2*(x164 + x37);
    double x182 = x135 + x181;
    double x183 = x137 + x138 + x182;
    double x184 = x171 + x183;
    double x185 = x133 + x178 + x181;
    double x186 = -n3*x163;
    double x187 = x3*x91;
    double x188 = 8.3144626181532395/n3;
    double x189 = x188*x2;
    double x190 = -n3*x8 + x7;
    double x191 = n3*x168 + x38 + x40;
    double x192 = x188*x190 + x191;
    double x193 = -x18*x71;
    double x194 = x193 + x64;
    double x195 = x172 + x194;
    double x196 = x189*(x187 + x83) + x192 + x2*(x168 + x186) + x96;
    double x197 = x193 + x5;
    double x198 = x191 + x2*(x186 + x37) + x34;
    double x199 = x151 + x198;
    double x200 = -n4*x163;
    double x201 = x147*x51;
    double x202 = x103*x3;
    double x203 = 8.3144626181532395/n4;
    double x204 = x2*x203;
    double x205 = x145*x50;
    double x206 = -n4*x8 + x7;
    double x207 = x145*x2;
    double x208 = x144*x61;
    double x209 = n4*x168 + x40;
    double x210 = -x1*x8 + x7;
    double x211 = 1.0/x1;
    double x212 = 24.943387854459719*x211;
    double x213 = 2*x33;
    double x214 = pow(x1, -2);
    double x215 = x210*x214;
    double x216 = x1*x18 + x17;
    double x217 = x213*x216;
    double x218 = x167 + x2*x211*x33*(-x1*x25 + x23) + x2*x212*x216 - x2*x214*x217 + x210*x212 + x211*x217 - x213*x215 - x215*x22 + x36 + x2*x210*x213/((x1)*(x1)*(x1));
    double x219 = x218 + x5;
    double x220 = -x113*x147 + x203*x206 + x219;
    double x221 = x110*x55;
    double x222 = 33.257850472612958*x150 + x209;
    double x223 = -n5*x8 + x7;
    double x224 = 8.3144626181532395/n5;

result[0] = x30 + x81;
result[1] = x81 + x82 + x97;
result[2] = x107 + x30 + x65 + x82;
result[3] = x125 + x127;
result[4] = x127 + x130;
result[5] = x132 + x134 + x80;
result[6] = 8.3144626181532395*x10 + x107 + x134 + x26*(x25*x85 + x89) + x5 + 8.3144626181532395*x88 + x95;
result[7] = x125 + x136;
result[8] = x130 + x136;
result[9] = x133 + x140 + x29;
result[10] = x124 + x141 + x142 + x5;
result[11] = x129 + x139 + x141;
result[12] = x143 + x153;
result[13] = x156 + x157;
result[14] = x140 + x158;
result[15] = x161 + x166*(x165 + x17) + x171 + x173 + x2*(x162 + x164) - x118*x159/((n2)*(n2));
result[16] = x170 + x177 + x18*(-x12 + x174);
result[17] = x176 + x179 + x80;
result[18] = x177 + x180;
result[19] = x184;
result[20] = x142 + x179 + x182;
result[21] = x180 + x183;
result[22] = x153 + x185;
result[23] = x155 + x157 + x185;
result[24] = x184;
result[25] = x189*(x17 + x187) + x192 + x195 + x2*(x162 + x186) + x30 + x34 - x118*x190/((n3)*(n3));
result[26] = x123 + x18*(x108 + x174 - x70) + x196 + x5;
result[27] = x128 + x175 + x196 + x197;
result[28] = x149 + x158 + x197 + x199;
result[29] = x156 + x193 + x199;
result[30] = x136 + x194 + x198;
result[31] = x117*x208 + x147*x22*x44 + 24.943387854459719*x150 + x173 + x2*(x162 + x200) + 2*x201 + x204*(x17 + x202) - 1.0*x205 - 12.471693927229859*x207 + x209 + x220 + x59*(3.0*x3 + x58) - x118*x206/((n4)*(n4));
result[32] = x107 + x112*x208 + x115 - x117*x221 - x126 - x145*x22 + x148 + x2*(x168 + x200) + x201 + x204*(x202 + x83) - 1.5*x205 + x220 + x222;
result[33] = x121 + x126 + x139 - x145*x57 + x146 + x2*(x200 + x37) - 33.257850472612958*x207 + x208*x60 + x218 - x221*x60 + x222 + 8.3144626181532395*x47;
result[34] = n5*x168 + x195 + x2*x224*(n5*x18 + x17) + x2*(-n5*x163 + x162) + x219 + x223*x224 + x38 - x118*x223/((n5)*(n5));
}
        
static double coder_dgdp(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    

result = n1*(*endmember[0].dmu0dP)(T, P) + n2*(*endmember[1].dmu0dP)(T, P) + n3*(*endmember[2].dmu0dP)(T, P) + n4*(*endmember[3].dmu0dP)(T, P) + n5*(*endmember[4].dmu0dP)(T, P);
    return result;
}
        
static void coder_d2gdndp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = (*endmember[0].dmu0dP)(T, P);
result[1] = (*endmember[1].dmu0dP)(T, P);
result[2] = (*endmember[2].dmu0dP)(T, P);
result[3] = (*endmember[3].dmu0dP)(T, P);
result[4] = (*endmember[4].dmu0dP)(T, P);
}
        
static void coder_d3gdn2dp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
}
        
static void coder_d4gdn3dp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
result[20] = 0;
result[21] = 0;
result[22] = 0;
result[23] = 0;
result[24] = 0;
result[25] = 0;
result[26] = 0;
result[27] = 0;
result[28] = 0;
result[29] = 0;
result[30] = 0;
result[31] = 0;
result[32] = 0;
result[33] = 0;
result[34] = 0;
}
        
static double coder_d2gdt2(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    

result = n1*(*endmember[0].d2mu0dT2)(T, P) + n2*(*endmember[1].d2mu0dT2)(T, P) + n3*(*endmember[2].d2mu0dT2)(T, P) + n4*(*endmember[3].d2mu0dT2)(T, P) + n5*(*endmember[4].d2mu0dT2)(T, P);
    return result;
}
        
static void coder_d3gdndt2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = (*endmember[0].d2mu0dT2)(T, P);
result[1] = (*endmember[1].d2mu0dT2)(T, P);
result[2] = (*endmember[2].d2mu0dT2)(T, P);
result[3] = (*endmember[3].d2mu0dT2)(T, P);
result[4] = (*endmember[4].d2mu0dT2)(T, P);
}
        
static void coder_d4gdn2dt2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
}
        
static void coder_d5gdn3dt2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
result[20] = 0;
result[21] = 0;
result[22] = 0;
result[23] = 0;
result[24] = 0;
result[25] = 0;
result[26] = 0;
result[27] = 0;
result[28] = 0;
result[29] = 0;
result[30] = 0;
result[31] = 0;
result[32] = 0;
result[33] = 0;
result[34] = 0;
}
        
static double coder_d2gdtdp(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    

result = n1*(*endmember[0].d2mu0dTdP)(T, P) + n2*(*endmember[1].d2mu0dTdP)(T, P) + n3*(*endmember[2].d2mu0dTdP)(T, P) + n4*(*endmember[3].d2mu0dTdP)(T, P) + n5*(*endmember[4].d2mu0dTdP)(T, P);
    return result;
}
        
static void coder_d3gdndtdp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = (*endmember[0].d2mu0dTdP)(T, P);
result[1] = (*endmember[1].d2mu0dTdP)(T, P);
result[2] = (*endmember[2].d2mu0dTdP)(T, P);
result[3] = (*endmember[3].d2mu0dTdP)(T, P);
result[4] = (*endmember[4].d2mu0dTdP)(T, P);
}
        
static void coder_d4gdn2dtdp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
}
        
static void coder_d5gdn3dtdp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
result[20] = 0;
result[21] = 0;
result[22] = 0;
result[23] = 0;
result[24] = 0;
result[25] = 0;
result[26] = 0;
result[27] = 0;
result[28] = 0;
result[29] = 0;
result[30] = 0;
result[31] = 0;
result[32] = 0;
result[33] = 0;
result[34] = 0;
}
        
static double coder_d2gdp2(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    

result = n1*(*endmember[0].d2mu0dP2)(T, P) + n2*(*endmember[1].d2mu0dP2)(T, P) + n3*(*endmember[2].d2mu0dP2)(T, P) + n4*(*endmember[3].d2mu0dP2)(T, P) + n5*(*endmember[4].d2mu0dP2)(T, P);
    return result;
}
        
static void coder_d3gdndp2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = (*endmember[0].d2mu0dP2)(T, P);
result[1] = (*endmember[1].d2mu0dP2)(T, P);
result[2] = (*endmember[2].d2mu0dP2)(T, P);
result[3] = (*endmember[3].d2mu0dP2)(T, P);
result[4] = (*endmember[4].d2mu0dP2)(T, P);
}
        
static void coder_d4gdn2dp2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
}
        
static void coder_d5gdn3dp2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
result[20] = 0;
result[21] = 0;
result[22] = 0;
result[23] = 0;
result[24] = 0;
result[25] = 0;
result[26] = 0;
result[27] = 0;
result[28] = 0;
result[29] = 0;
result[30] = 0;
result[31] = 0;
result[32] = 0;
result[33] = 0;
result[34] = 0;
}
        
static double coder_d3gdt3(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    

result = n1*(*endmember[0].d3mu0dT3)(T, P) + n2*(*endmember[1].d3mu0dT3)(T, P) + n3*(*endmember[2].d3mu0dT3)(T, P) + n4*(*endmember[3].d3mu0dT3)(T, P) + n5*(*endmember[4].d3mu0dT3)(T, P);
    return result;
}
        
static void coder_d4gdndt3(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = (*endmember[0].d3mu0dT3)(T, P);
result[1] = (*endmember[1].d3mu0dT3)(T, P);
result[2] = (*endmember[2].d3mu0dT3)(T, P);
result[3] = (*endmember[3].d3mu0dT3)(T, P);
result[4] = (*endmember[4].d3mu0dT3)(T, P);
}
        
static void coder_d5gdn2dt3(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
}
        
static void coder_d6gdn3dt3(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
result[20] = 0;
result[21] = 0;
result[22] = 0;
result[23] = 0;
result[24] = 0;
result[25] = 0;
result[26] = 0;
result[27] = 0;
result[28] = 0;
result[29] = 0;
result[30] = 0;
result[31] = 0;
result[32] = 0;
result[33] = 0;
result[34] = 0;
}
        
static double coder_d3gdt2dp(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    

result = n1*(*endmember[0].d3mu0dT2dP)(T, P) + n2*(*endmember[1].d3mu0dT2dP)(T, P) + n3*(*endmember[2].d3mu0dT2dP)(T, P) + n4*(*endmember[3].d3mu0dT2dP)(T, P) + n5*(*endmember[4].d3mu0dT2dP)(T, P);
    return result;
}
        
static void coder_d4gdndt2dp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = (*endmember[0].d3mu0dT2dP)(T, P);
result[1] = (*endmember[1].d3mu0dT2dP)(T, P);
result[2] = (*endmember[2].d3mu0dT2dP)(T, P);
result[3] = (*endmember[3].d3mu0dT2dP)(T, P);
result[4] = (*endmember[4].d3mu0dT2dP)(T, P);
}
        
static void coder_d5gdn2dt2dp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
}
        
static void coder_d6gdn3dt2dp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
result[20] = 0;
result[21] = 0;
result[22] = 0;
result[23] = 0;
result[24] = 0;
result[25] = 0;
result[26] = 0;
result[27] = 0;
result[28] = 0;
result[29] = 0;
result[30] = 0;
result[31] = 0;
result[32] = 0;
result[33] = 0;
result[34] = 0;
}
        
static double coder_d3gdtdp2(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    

result = n1*(*endmember[0].d3mu0dTdP2)(T, P) + n2*(*endmember[1].d3mu0dTdP2)(T, P) + n3*(*endmember[2].d3mu0dTdP2)(T, P) + n4*(*endmember[3].d3mu0dTdP2)(T, P) + n5*(*endmember[4].d3mu0dTdP2)(T, P);
    return result;
}
        
static void coder_d4gdndtdp2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = (*endmember[0].d3mu0dTdP2)(T, P);
result[1] = (*endmember[1].d3mu0dTdP2)(T, P);
result[2] = (*endmember[2].d3mu0dTdP2)(T, P);
result[3] = (*endmember[3].d3mu0dTdP2)(T, P);
result[4] = (*endmember[4].d3mu0dTdP2)(T, P);
}
        
static void coder_d5gdn2dtdp2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
}
        
static void coder_d6gdn3dtdp2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
result[20] = 0;
result[21] = 0;
result[22] = 0;
result[23] = 0;
result[24] = 0;
result[25] = 0;
result[26] = 0;
result[27] = 0;
result[28] = 0;
result[29] = 0;
result[30] = 0;
result[31] = 0;
result[32] = 0;
result[33] = 0;
result[34] = 0;
}
        
static double coder_d3gdp3(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    

result = n1*(*endmember[0].d3mu0dP3)(T, P) + n2*(*endmember[1].d3mu0dP3)(T, P) + n3*(*endmember[2].d3mu0dP3)(T, P) + n4*(*endmember[3].d3mu0dP3)(T, P) + n5*(*endmember[4].d3mu0dP3)(T, P);
    return result;
}
        
static void coder_d4gdndp3(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = (*endmember[0].d3mu0dP3)(T, P);
result[1] = (*endmember[1].d3mu0dP3)(T, P);
result[2] = (*endmember[2].d3mu0dP3)(T, P);
result[3] = (*endmember[3].d3mu0dP3)(T, P);
result[4] = (*endmember[4].d3mu0dP3)(T, P);
}
        
static void coder_d5gdn2dp3(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
}
        
static void coder_d6gdn3dp3(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
result[20] = 0;
result[21] = 0;
result[22] = 0;
result[23] = 0;
result[24] = 0;
result[25] = 0;
result[26] = 0;
result[27] = 0;
result[28] = 0;
result[29] = 0;
result[30] = 0;
result[31] = 0;
result[32] = 0;
result[33] = 0;
result[34] = 0;
}
        
static double coder_s(double T, double P, double n[5]) {
    double result = -coder_dgdt(T, P, n);
    return result;
}

static double coder_v(double T, double P, double n[5]) {
    double result = coder_dgdp(T, P, n);
    return result;
}

static double coder_cv(double T, double P, double n[5]) {
    double result = -T*coder_d2gdt2(T, P, n);
    double dvdt = coder_d2gdtdp(T, P, n);
    double dvdp = coder_d2gdp2(T, P, n);
    result += T*dvdt*dvdt/dvdp;
    return result;
}

static double coder_cp(double T, double P, double n[5]) {
    double result = -T*coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdt(double T, double P, double n[5]) {
    double result = -T*coder_d3gdt3(T, P, n) - coder_d2gdt2(T, P, n);
    return result;
}

static double coder_alpha(double T, double P, double n[5]) {
    double result = coder_d2gdtdp(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_beta(double T, double P, double n[5]) {
    double result = -coder_d2gdp2(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_K(double T, double P, double n[5]) {
    double result = -coder_dgdp(T, P, n)/coder_d2gdp2(T, P, n);
    return result;
}

static double coder_Kp(double T, double P, double n[5]) {
    double result = coder_dgdp(T, P, n);
    result *= coder_d3gdp3(T, P, n);
    result /= pow(coder_d2gdp2(T, P, n), 2.0);
    return result - 1.0;
}

