#include <math.h>

#include "coder_external_functions.h"


static double coder_dparam_g(double T, double P, double n[3], int index) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


        double x0 = n1*(*endmember[0].mu0)(T, P);
    double x1 = n1*(*endmember[1].mu0)(T, P);
    double x2 = n1*(*endmember[2].mu0)(T, P);
    double x3 = LAbsMax(3, x0, x1, x2, x0, x1, x2);
    double x4 = -x3;
    double x5 = x0 + x4;
    double x6 = exp(t*x5);
    double x7 = x1 + x4;
    double x8 = exp(t*x7);
    double x9 = x2 + x4;
    double x10 = exp(t*x9);
    double x11 = x10 + x6 + x8;

    
    double result = 0.0;
    switch (index) {
    case 0:
        result = (x3 + (x10*x9 + x5*x6 + x7*x8)/x11)/t - (t*x3 + log(x11))/((t)*(t));
        break;

    default:
        break;
    }
        return result;
}

static double coder_dparam_dgdt(double T, double P, double n[3], int index) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


        double x0 = (*endmember[0].mu0)(T, P);
    double x1 = n1*(*endmember[0].dmu0dT)(T, P);
    double x2 = (*endmember[1].mu0)(T, P);
    double x3 = n1*(*endmember[1].dmu0dT)(T, P);
    double x4 = (*endmember[2].mu0)(T, P);
    double x5 = n1*(*endmember[2].dmu0dT)(T, P);
    double x6 = n1*x0;
    double x7 = n1*x2;
    double x8 = n1*x4;
    double x9 = LAbsMax(3, x1, x3, x5, x6, x7, x8);
    double x10 = -LAbsMax(3, x6, x7, x8, x6, x7, x8);
    double x11 = x10 + x6;
    double x12 = t*x11;
    double x13 = exp(x12);
    double x14 = x10 + x7;
    double x15 = t*x14;
    double x16 = exp(x15);
    double x17 = x10 + x8;
    double x18 = t*x17;
    double x19 = exp(x18);
    double x20 = x13 + x16 + x19;
    double x21 = 1.0/x20;
    double x22 = -x9;
    double x23 = x13*(x1 + x22);
    double x24 = x16*(x22 + x3);
    double x25 = x19*(x22 + x5);
    double x26 = t*x23 + t*x24 + t*x25;

    
    double result = 0.0;
    switch (index) {
    case 0:
        result = (x21*(x12*x23 + x15*x24 + x18*x25 + x23 + x24 + x25) + x9 + x26*(-x11*x13 - x14*x16 - x17*x19)/((x20)*(x20)))/t - (t*x9 + x21*x26)/((t)*(t));
        break;

    default:
        break;
    }
        return result;
}

static double coder_dparam_dgdp(double T, double P, double n[3], int index) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


        double x0 = (*endmember[0].mu0)(T, P);
    double x1 = n1*(*endmember[0].dmu0dP)(T, P);
    double x2 = (*endmember[1].mu0)(T, P);
    double x3 = n1*(*endmember[1].dmu0dP)(T, P);
    double x4 = (*endmember[2].mu0)(T, P);
    double x5 = n1*(*endmember[2].dmu0dP)(T, P);
    double x6 = n1*x0;
    double x7 = n1*x2;
    double x8 = n1*x4;
    double x9 = LAbsMax(3, x1, x3, x5, x6, x7, x8);
    double x10 = -LAbsMax(3, x6, x7, x8, x6, x7, x8);
    double x11 = x10 + x6;
    double x12 = t*x11;
    double x13 = exp(x12);
    double x14 = x10 + x7;
    double x15 = t*x14;
    double x16 = exp(x15);
    double x17 = x10 + x8;
    double x18 = t*x17;
    double x19 = exp(x18);
    double x20 = x13 + x16 + x19;
    double x21 = 1.0/x20;
    double x22 = -x9;
    double x23 = x13*(x1 + x22);
    double x24 = x16*(x22 + x3);
    double x25 = x19*(x22 + x5);
    double x26 = t*x23 + t*x24 + t*x25;

    
    double result = 0.0;
    switch (index) {
    case 0:
        result = (x21*(x12*x23 + x15*x24 + x18*x25 + x23 + x24 + x25) + x9 + x26*(-x11*x13 - x14*x16 - x17*x19)/((x20)*(x20)))/t - (t*x9 + x21*x26)/((t)*(t));
        break;

    default:
        break;
    }
        return result;
}

static double coder_dparam_d2gdt2(double T, double P, double n[3], int index) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


        double x0 = (*endmember[0].mu0)(T, P);
    double x1 = n1*x0;
    double x2 = (*endmember[1].mu0)(T, P);
    double x3 = n1*x2;
    double x4 = (*endmember[2].mu0)(T, P);
    double x5 = n1*x4;
    double x6 = -LAbsMax(3, x1, x3, x5, x1, x3, x5);
    double x7 = x1 + x6;
    double x8 = t*x7;
    double x9 = exp(x8);
    double x10 = x3 + x6;
    double x11 = t*x10;
    double x12 = exp(x11);
    double x13 = x5 + x6;
    double x14 = t*x13;
    double x15 = exp(x14);
    double x16 = x12 + x15 + x9;
    double x17 = pow(x16, -2);
    double x18 = n1*(*endmember[0].dmu0dT)(T, P);
    double x19 = n1*(*endmember[1].dmu0dT)(T, P);
    double x20 = n1*(*endmember[2].dmu0dT)(T, P);
    double x21 = -LAbsMax(3, x18, x19, x20, x1, x3, x5);
    double x22 = x18 + x21;
    double x23 = x22*x9;
    double x24 = x19 + x21;
    double x25 = x12*x24;
    double x26 = x20 + x21;
    double x27 = x15*x26;
    double x28 = x23 + x25 + x27;
    double x29 = ((x28)*(x28));
    double x30 = x7*x9;
    double x31 = x10*x12;
    double x32 = x13*x15;
    double x33 = n1*(*endmember[0].d2mu0dT2)(T, P);
    double x34 = n1*(*endmember[1].d2mu0dT2)(T, P);
    double x35 = n1*(*endmember[2].d2mu0dT2)(T, P);
    double x36 = -LAbsMax(3, x33, x34, x35, x1, x3, x5);
    double x37 = x33 + x36;
    double x38 = x34 + x36;
    double x39 = x35 + x36;
    double x40 = ((x22)*(x22))*x9;
    double x41 = x12*((x24)*(x24));
    double x42 = x15*((x26)*(x26));

    
    double result = 0.0;
    switch (index) {
    case 0:
        result = -t*x17*x28*(2*x10*x25 + 2*x13*x27 + 2*x23*x7) - t*x29*(-2*x30 - 2*x31 - 2*x32)/((x16)*(x16)*(x16)) - x17*x29 + x17*(-x30 - x31 - x32)*(t*x40 + t*x41 + t*x42 + x12*x38 + x15*x39 + x37*x9) + (x11*x41 + x14*x42 + x30*x37 + x31*x38 + x32*x39 + x40*x8 + x40 + x41 + x42)/x16;
        break;

    default:
        break;
    }
        return result;
}

static double coder_dparam_d2gdtdp(double T, double P, double n[3], int index) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


        double x0 = (*endmember[0].mu0)(T, P);
    double x1 = n1*x0;
    double x2 = (*endmember[1].mu0)(T, P);
    double x3 = n1*x2;
    double x4 = (*endmember[2].mu0)(T, P);
    double x5 = n1*x4;
    double x6 = -LAbsMax(3, x1, x3, x5, x1, x3, x5);
    double x7 = x1 + x6;
    double x8 = t*x7;
    double x9 = exp(x8);
    double x10 = n1*(*endmember[0].dmu0dT)(T, P);
    double x11 = n1*(*endmember[1].dmu0dT)(T, P);
    double x12 = n1*(*endmember[2].dmu0dT)(T, P);
    double x13 = -LAbsMax(3, x10, x11, x12, x1, x3, x5);
    double x14 = x10 + x13;
    double x15 = x3 + x6;
    double x16 = t*x15;
    double x17 = exp(x16);
    double x18 = x11 + x13;
    double x19 = x5 + x6;
    double x20 = t*x19;
    double x21 = exp(x20);
    double x22 = x12 + x13;
    double x23 = x14*x9 + x17*x18 + x21*x22;
    double x24 = x17 + x21 + x9;
    double x25 = pow(x24, -2);
    double x26 = n1*(*endmember[0].dmu0dP)(T, P);
    double x27 = n1*(*endmember[1].dmu0dP)(T, P);
    double x28 = n1*(*endmember[2].dmu0dP)(T, P);
    double x29 = -LAbsMax(3, x26, x27, x28, x1, x3, x5);
    double x30 = x26 + x29;
    double x31 = x30*x9;
    double x32 = x27 + x29;
    double x33 = x17*x32;
    double x34 = x28 + x29;
    double x35 = x21*x34;
    double x36 = x31 + x33 + x35;
    double x37 = x25*x36;
    double x38 = x7*x9;
    double x39 = x15*x17;
    double x40 = x19*x21;
    double x41 = t*x23;
    double x42 = n1*(*endmember[0].d2mu0dTdP)(T, P);
    double x43 = n1*(*endmember[1].d2mu0dTdP)(T, P);
    double x44 = n1*(*endmember[2].d2mu0dTdP)(T, P);
    double x45 = -LAbsMax(3, x42, x43, x44, x1, x3, x5);
    double x46 = x42 + x45;
    double x47 = x43 + x45;
    double x48 = x44 + x45;
    double x49 = x14*x31;
    double x50 = x18*x33;
    double x51 = x22*x35;

    
    double result = 0.0;
    switch (index) {
    case 0:
        result = -t*x37*(x14*x38 + x18*x39 + x22*x40) - x23*x37 - x25*x41*(x30*x38 + x32*x39 + x34*x40) + x25*(-x38 - x39 - x40)*(t*x49 + t*x50 + t*x51 + x17*x47 + x21*x48 + x46*x9) + (x16*x50 + x20*x51 + x38*x46 + x39*x47 + x40*x48 + x49*x8 + x49 + x50 + x51)/x24 - x36*x41*(-2*x38 - 2*x39 - 2*x40)/((x24)*(x24)*(x24));
        break;

    default:
        break;
    }
        return result;
}

static double coder_dparam_d2gdp2(double T, double P, double n[3], int index) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


        double x0 = (*endmember[0].mu0)(T, P);
    double x1 = n1*x0;
    double x2 = (*endmember[1].mu0)(T, P);
    double x3 = n1*x2;
    double x4 = (*endmember[2].mu0)(T, P);
    double x5 = n1*x4;
    double x6 = -LAbsMax(3, x1, x3, x5, x1, x3, x5);
    double x7 = x1 + x6;
    double x8 = t*x7;
    double x9 = exp(x8);
    double x10 = x3 + x6;
    double x11 = t*x10;
    double x12 = exp(x11);
    double x13 = x5 + x6;
    double x14 = t*x13;
    double x15 = exp(x14);
    double x16 = x12 + x15 + x9;
    double x17 = pow(x16, -2);
    double x18 = n1*(*endmember[0].dmu0dP)(T, P);
    double x19 = n1*(*endmember[1].dmu0dP)(T, P);
    double x20 = n1*(*endmember[2].dmu0dP)(T, P);
    double x21 = -LAbsMax(3, x18, x19, x20, x1, x3, x5);
    double x22 = x18 + x21;
    double x23 = x22*x9;
    double x24 = x19 + x21;
    double x25 = x12*x24;
    double x26 = x20 + x21;
    double x27 = x15*x26;
    double x28 = x23 + x25 + x27;
    double x29 = ((x28)*(x28));
    double x30 = x7*x9;
    double x31 = x10*x12;
    double x32 = x13*x15;
    double x33 = n1*(*endmember[0].d2mu0dP2)(T, P);
    double x34 = n1*(*endmember[1].d2mu0dP2)(T, P);
    double x35 = n1*(*endmember[2].d2mu0dP2)(T, P);
    double x36 = -LAbsMax(3, x33, x34, x35, x1, x3, x5);
    double x37 = x33 + x36;
    double x38 = x34 + x36;
    double x39 = x35 + x36;
    double x40 = ((x22)*(x22))*x9;
    double x41 = x12*((x24)*(x24));
    double x42 = x15*((x26)*(x26));

    
    double result = 0.0;
    switch (index) {
    case 0:
        result = -t*x17*x28*(2*x10*x25 + 2*x13*x27 + 2*x23*x7) - t*x29*(-2*x30 - 2*x31 - 2*x32)/((x16)*(x16)*(x16)) - x17*x29 + x17*(-x30 - x31 - x32)*(t*x40 + t*x41 + t*x42 + x12*x38 + x15*x39 + x37*x9) + (x11*x41 + x14*x42 + x30*x37 + x31*x38 + x32*x39 + x40*x8 + x40 + x41 + x42)/x16;
        break;

    default:
        break;
    }
        return result;
}

static double coder_dparam_d3gdt3(double T, double P, double n[3], int index) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


        double x0 = (*endmember[0].mu0)(T, P);
    double x1 = n1*x0;
    double x2 = (*endmember[1].mu0)(T, P);
    double x3 = n1*x2;
    double x4 = (*endmember[2].mu0)(T, P);
    double x5 = n1*x4;
    double x6 = -LAbsMax(3, x1, x3, x5, x1, x3, x5);
    double x7 = x1 + x6;
    double x8 = t*x7;
    double x9 = exp(x8);
    double x10 = n1*(*endmember[0].dmu0dT)(T, P);
    double x11 = n1*(*endmember[1].dmu0dT)(T, P);
    double x12 = n1*(*endmember[2].dmu0dT)(T, P);
    double x13 = LAbsMax(3, x10, x11, x12, x1, x3, x5);
    double x14 = -x13;
    double x15 = x10 + x14;
    double x16 = x15*x9;
    double x17 = x3 + x6;
    double x18 = t*x17;
    double x19 = exp(x18);
    double x20 = x11 + x14;
    double x21 = x19*x20;
    double x22 = x5 + x6;
    double x23 = t*x22;
    double x24 = exp(x23);
    double x25 = x12 + x14;
    double x26 = x24*x25;
    double x27 = x16 + x21 + x26;
    double x28 = ((x27)*(x27)*(x27));
    double x29 = x19 + x24 + x9;
    double x30 = pow(x29, -3);
    double x31 = t*x30;
    double x32 = x7*x9;
    double x33 = x17*x19;
    double x34 = x22*x24;
    double x35 = ((t)*(t));
    double x36 = 2*x35;
    double x37 = x15*x32;
    double x38 = x20*x33;
    double x39 = x25*x34;
    double x40 = n1*(*endmember[0].d2mu0dT2)(T, P);
    double x41 = n1*(*endmember[1].d2mu0dT2)(T, P);
    double x42 = n1*(*endmember[2].d2mu0dT2)(T, P);
    double x43 = -LAbsMax(3, x40, x41, x42, x1, x3, x5);
    double x44 = x40 + x43;
    double x45 = x44*x9;
    double x46 = x41 + x43;
    double x47 = x19*x46;
    double x48 = x42 + x43;
    double x49 = x24*x48;
    double x50 = ((x15)*(x15))*x9;
    double x51 = x19*((x20)*(x20));
    double x52 = x24*((x25)*(x25));
    double x53 = t*x50 + t*x51 + t*x52 + x45 + x47 + x49;
    double x54 = pow(x29, -2);
    double x55 = 3*x27*x54;
    double x56 = 3*t;
    double x57 = n1*(*endmember[0].d3mu0dT3)(T, P);
    double x58 = n1*(*endmember[1].d3mu0dT3)(T, P);
    double x59 = n1*(*endmember[2].d3mu0dT3)(T, P);
    double x60 = -LAbsMax(3, x57, x58, x59, x1, x3, x5);
    double x61 = x57 + x60;
    double x62 = x58 + x60;
    double x63 = x59 + x60;
    double x64 = ((x15)*(x15)*(x15));
    double x65 = x64*x9;
    double x66 = ((x20)*(x20)*(x20));
    double x67 = x19*x66;
    double x68 = ((x25)*(x25)*(x25));
    double x69 = x24*x68;
    double x70 = x16*x44;
    double x71 = x21*x46;
    double x72 = x26*x48;
    double x73 = 2*t;
    double x74 = -3*x13;

    
    double result = 0.0;
    switch (index) {
    case 0:
        result = -t*x55*(x18*x51 + x23*x52 + x32*x44 + x33*x46 + x34*x48 + x50*x8 + x50 + x51 + x52) + ((x27)*(x27))*x30*x36*(3*x37 + 3*x38 + 3*x39) - 3*x27*x31*x53*(-2*x32 - 2*x33 - 2*x34) + 4*x28*x31 + x28*x36*(-3*x32 - 3*x33 - 3*x34)/((x29)*(x29)*(x29)*(x29)) - x53*x54*x56*(x37 + x38 + x39) - x53*x55 + x54*(-x32 - x33 - x34)*(x19*x62 + x24*x63 + x35*x65 + x35*x67 + x35*x69 + x56*x70 + x56*x71 + x56*x72 + x61*x9) + (3*x18*x71 + 3*x23*x72 + x32*x35*x64 + x32*x61 + x33*x35*x66 + x33*x62 + x34*x35*x68 + x34*x63 + x45*(3*x10 + x74) + x47*(3*x11 + x74) + x49*(3*x12 + x74) + x65*x73 + x67*x73 + x69*x73 + 3*x70*x8)/x29;
        break;

    default:
        break;
    }
        return result;
}

static double coder_dparam_d3gdt2dp(double T, double P, double n[3], int index) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


        double x0 = (*endmember[0].mu0)(T, P);
    double x1 = n1*x0;
    double x2 = (*endmember[1].mu0)(T, P);
    double x3 = n1*x2;
    double x4 = (*endmember[2].mu0)(T, P);
    double x5 = n1*x4;
    double x6 = -LAbsMax(3, x1, x3, x5, x1, x3, x5);
    double x7 = x1 + x6;
    double x8 = t*x7;
    double x9 = exp(x8);
    double x10 = n1*(*endmember[0].dmu0dT)(T, P);
    double x11 = n1*(*endmember[1].dmu0dT)(T, P);
    double x12 = n1*(*endmember[2].dmu0dT)(T, P);
    double x13 = LAbsMax(3, x10, x11, x12, x1, x3, x5);
    double x14 = -x13;
    double x15 = x10 + x14;
    double x16 = x15*x9;
    double x17 = x3 + x6;
    double x18 = t*x17;
    double x19 = exp(x18);
    double x20 = x11 + x14;
    double x21 = x19*x20;
    double x22 = x5 + x6;
    double x23 = t*x22;
    double x24 = exp(x23);
    double x25 = x12 + x14;
    double x26 = x24*x25;
    double x27 = x16 + x21 + x26;
    double x28 = ((x27)*(x27));
    double x29 = x19 + x24 + x9;
    double x30 = pow(x29, -3);
    double x31 = x28*x30;
    double x32 = n1*(*endmember[0].dmu0dP)(T, P);
    double x33 = n1*(*endmember[1].dmu0dP)(T, P);
    double x34 = n1*(*endmember[2].dmu0dP)(T, P);
    double x35 = -LAbsMax(3, x32, x33, x34, x1, x3, x5);
    double x36 = x32 + x35;
    double x37 = x36*x9;
    double x38 = x33 + x35;
    double x39 = x19*x38;
    double x40 = x34 + x35;
    double x41 = x24*x40;
    double x42 = x37 + x39 + x41;
    double x43 = t*x42;
    double x44 = x7*x9;
    double x45 = x36*x44;
    double x46 = x17*x19;
    double x47 = x38*x46;
    double x48 = x22*x24;
    double x49 = x40*x48;
    double x50 = x45 + x47 + x49;
    double x51 = ((t)*(t));
    double x52 = 2*x51;
    double x53 = n1*(*endmember[0].d2mu0dT2)(T, P);
    double x54 = n1*(*endmember[1].d2mu0dT2)(T, P);
    double x55 = n1*(*endmember[2].d2mu0dT2)(T, P);
    double x56 = -LAbsMax(3, x53, x54, x55, x1, x3, x5);
    double x57 = x53 + x56;
    double x58 = x54 + x56;
    double x59 = x55 + x56;
    double x60 = ((x15)*(x15));
    double x61 = x60*x9;
    double x62 = ((x20)*(x20));
    double x63 = x19*x62;
    double x64 = ((x25)*(x25));
    double x65 = x24*x64;
    double x66 = t*x61 + t*x63 + t*x65 + x19*x58 + x24*x59 + x57*x9;
    double x67 = pow(x29, -2);
    double x68 = x42*x67;
    double x69 = x15*x44;
    double x70 = x20*x46;
    double x71 = x25*x48;
    double x72 = 2*x27;
    double x73 = t*x67;
    double x74 = n1*(*endmember[0].d2mu0dTdP)(T, P);
    double x75 = n1*(*endmember[1].d2mu0dTdP)(T, P);
    double x76 = n1*(*endmember[2].d2mu0dTdP)(T, P);
    double x77 = -LAbsMax(3, x74, x75, x76, x1, x3, x5);
    double x78 = x74 + x77;
    double x79 = x78*x9;
    double x80 = x75 + x77;
    double x81 = x19*x80;
    double x82 = x76 + x77;
    double x83 = x24*x82;
    double x84 = x15*x37;
    double x85 = x20*x39;
    double x86 = x25*x41;
    double x87 = t*x84 + t*x85 + t*x86 + x79 + x81 + x83;
    double x88 = x67*x72;
    double x89 = x30*(-2*x44 - 2*x46 - 2*x48);
    double x90 = n1*(*endmember[0].d3mu0dT2dP)(T, P);
    double x91 = n1*(*endmember[1].d3mu0dT2dP)(T, P);
    double x92 = n1*(*endmember[2].d3mu0dT2dP)(T, P);
    double x93 = -LAbsMax(3, x90, x91, x92, x1, x3, x5);
    double x94 = x90 + x93;
    double x95 = x91 + x93;
    double x96 = x92 + x93;
    double x97 = x37*x57;
    double x98 = x39*x58;
    double x99 = x41*x59;
    double x100 = x37*x60;
    double x101 = x39*x62;
    double x102 = x41*x64;
    double x103 = 2*t;
    double x104 = x16*x78;
    double x105 = x21*x80;
    double x106 = x26*x82;
    double x107 = -2*x13;

    
    double result = 0.0;
    switch (index) {
    case 0:
        result = -t*x68*(x18*x63 + x23*x65 + x44*x57 + x46*x58 + x48*x59 + x61*x8 + x61 + x63 + x65) - t*x72*x87*x89 - t*x88*(x18*x85 + x23*x86 + x44*x78 + x46*x80 + x48*x82 + x8*x84 + x84 + x85 + x86) + x28*x42*x52*(-3*x44 - 3*x46 - 3*x48)/((x29)*(x29)*(x29)*(x29)) + x30*x42*x51*x72*(2*x69 + 2*x70 + 2*x71) + 4*x31*x43 + x31*x50*x52 - x43*x66*x89 - x50*x66*x73 - x66*x68 + x67*(-x44 - x46 - x48)*(t*x97 + t*x98 + t*x99 + x100*x51 + x101*x51 + x102*x51 + x103*x104 + x103*x105 + x103*x106 + x19*x95 + x24*x96 + x9*x94) - 2*x73*x87*(x69 + x70 + x71) - x87*x88 + (x100*x103 + x101*x103 + x102*x103 + 2*x104*x8 + 2*x105*x18 + 2*x106*x23 + x18*x98 + x23*x99 + x44*x94 + x45*x51*x60 + x46*x95 + x47*x51*x62 + x48*x96 + x49*x51*x64 + x79*(2*x10 + x107) + x8*x97 + x81*(x107 + 2*x11) + x83*(x107 + 2*x12) + x97 + x98 + x99)/x29;
        break;

    default:
        break;
    }
        return result;
}

static double coder_dparam_d3gdtdp2(double T, double P, double n[3], int index) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


        double x0 = (*endmember[0].mu0)(T, P);
    double x1 = n1*x0;
    double x2 = (*endmember[1].mu0)(T, P);
    double x3 = n1*x2;
    double x4 = (*endmember[2].mu0)(T, P);
    double x5 = n1*x4;
    double x6 = -LAbsMax(3, x1, x3, x5, x1, x3, x5);
    double x7 = x1 + x6;
    double x8 = t*x7;
    double x9 = exp(x8);
    double x10 = n1*(*endmember[0].dmu0dP)(T, P);
    double x11 = n1*(*endmember[1].dmu0dP)(T, P);
    double x12 = n1*(*endmember[2].dmu0dP)(T, P);
    double x13 = LAbsMax(3, x10, x11, x12, x1, x3, x5);
    double x14 = -x13;
    double x15 = x10 + x14;
    double x16 = x15*x9;
    double x17 = x3 + x6;
    double x18 = t*x17;
    double x19 = exp(x18);
    double x20 = x11 + x14;
    double x21 = x19*x20;
    double x22 = x5 + x6;
    double x23 = t*x22;
    double x24 = exp(x23);
    double x25 = x12 + x14;
    double x26 = x24*x25;
    double x27 = x16 + x21 + x26;
    double x28 = ((x27)*(x27));
    double x29 = x19 + x24 + x9;
    double x30 = pow(x29, -3);
    double x31 = x28*x30;
    double x32 = n1*(*endmember[0].dmu0dT)(T, P);
    double x33 = n1*(*endmember[1].dmu0dT)(T, P);
    double x34 = n1*(*endmember[2].dmu0dT)(T, P);
    double x35 = -LAbsMax(3, x32, x33, x34, x1, x3, x5);
    double x36 = x32 + x35;
    double x37 = x36*x9;
    double x38 = x33 + x35;
    double x39 = x19*x38;
    double x40 = x34 + x35;
    double x41 = x24*x40;
    double x42 = x37 + x39 + x41;
    double x43 = t*x42;
    double x44 = x7*x9;
    double x45 = x36*x44;
    double x46 = x17*x19;
    double x47 = x38*x46;
    double x48 = x22*x24;
    double x49 = x40*x48;
    double x50 = x45 + x47 + x49;
    double x51 = ((t)*(t));
    double x52 = 2*x51;
    double x53 = n1*(*endmember[0].d2mu0dP2)(T, P);
    double x54 = n1*(*endmember[1].d2mu0dP2)(T, P);
    double x55 = n1*(*endmember[2].d2mu0dP2)(T, P);
    double x56 = -LAbsMax(3, x53, x54, x55, x1, x3, x5);
    double x57 = x53 + x56;
    double x58 = x54 + x56;
    double x59 = x55 + x56;
    double x60 = ((x15)*(x15));
    double x61 = x60*x9;
    double x62 = ((x20)*(x20));
    double x63 = x19*x62;
    double x64 = ((x25)*(x25));
    double x65 = x24*x64;
    double x66 = t*x61 + t*x63 + t*x65 + x19*x58 + x24*x59 + x57*x9;
    double x67 = pow(x29, -2);
    double x68 = x42*x67;
    double x69 = x15*x44;
    double x70 = x20*x46;
    double x71 = x25*x48;
    double x72 = 2*x27;
    double x73 = t*x67;
    double x74 = n1*(*endmember[0].d2mu0dTdP)(T, P);
    double x75 = n1*(*endmember[1].d2mu0dTdP)(T, P);
    double x76 = n1*(*endmember[2].d2mu0dTdP)(T, P);
    double x77 = -LAbsMax(3, x74, x75, x76, x1, x3, x5);
    double x78 = x74 + x77;
    double x79 = x78*x9;
    double x80 = x75 + x77;
    double x81 = x19*x80;
    double x82 = x76 + x77;
    double x83 = x24*x82;
    double x84 = x15*x37;
    double x85 = x20*x39;
    double x86 = x25*x41;
    double x87 = t*x84 + t*x85 + t*x86 + x79 + x81 + x83;
    double x88 = x67*x72;
    double x89 = x30*(-2*x44 - 2*x46 - 2*x48);
    double x90 = n1*(*endmember[0].d3mu0dTdP2)(T, P);
    double x91 = n1*(*endmember[1].d3mu0dTdP2)(T, P);
    double x92 = n1*(*endmember[2].d3mu0dTdP2)(T, P);
    double x93 = -LAbsMax(3, x90, x91, x92, x1, x3, x5);
    double x94 = x90 + x93;
    double x95 = x91 + x93;
    double x96 = x92 + x93;
    double x97 = x37*x57;
    double x98 = x39*x58;
    double x99 = x41*x59;
    double x100 = x37*x60;
    double x101 = x39*x62;
    double x102 = x41*x64;
    double x103 = 2*t;
    double x104 = x16*x78;
    double x105 = x21*x80;
    double x106 = x26*x82;
    double x107 = -2*x13;

    
    double result = 0.0;
    switch (index) {
    case 0:
        result = -t*x68*(x18*x63 + x23*x65 + x44*x57 + x46*x58 + x48*x59 + x61*x8 + x61 + x63 + x65) - t*x72*x87*x89 - t*x88*(x18*x85 + x23*x86 + x44*x78 + x46*x80 + x48*x82 + x8*x84 + x84 + x85 + x86) + x28*x42*x52*(-3*x44 - 3*x46 - 3*x48)/((x29)*(x29)*(x29)*(x29)) + x30*x42*x51*x72*(2*x69 + 2*x70 + 2*x71) + 4*x31*x43 + x31*x50*x52 - x43*x66*x89 - x50*x66*x73 - x66*x68 + x67*(-x44 - x46 - x48)*(t*x97 + t*x98 + t*x99 + x100*x51 + x101*x51 + x102*x51 + x103*x104 + x103*x105 + x103*x106 + x19*x95 + x24*x96 + x9*x94) - 2*x73*x87*(x69 + x70 + x71) - x87*x88 + (x100*x103 + x101*x103 + x102*x103 + 2*x104*x8 + 2*x105*x18 + 2*x106*x23 + x18*x98 + x23*x99 + x44*x94 + x45*x51*x60 + x46*x95 + x47*x51*x62 + x48*x96 + x49*x51*x64 + x79*(2*x10 + x107) + x8*x97 + x81*(x107 + 2*x11) + x83*(x107 + 2*x12) + x97 + x98 + x99)/x29;
        break;

    default:
        break;
    }
        return result;
}

static double coder_dparam_d3gdp3(double T, double P, double n[3], int index) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


        double x0 = (*endmember[0].mu0)(T, P);
    double x1 = n1*x0;
    double x2 = (*endmember[1].mu0)(T, P);
    double x3 = n1*x2;
    double x4 = (*endmember[2].mu0)(T, P);
    double x5 = n1*x4;
    double x6 = -LAbsMax(3, x1, x3, x5, x1, x3, x5);
    double x7 = x1 + x6;
    double x8 = t*x7;
    double x9 = exp(x8);
    double x10 = n1*(*endmember[0].dmu0dP)(T, P);
    double x11 = n1*(*endmember[1].dmu0dP)(T, P);
    double x12 = n1*(*endmember[2].dmu0dP)(T, P);
    double x13 = LAbsMax(3, x10, x11, x12, x1, x3, x5);
    double x14 = -x13;
    double x15 = x10 + x14;
    double x16 = x15*x9;
    double x17 = x3 + x6;
    double x18 = t*x17;
    double x19 = exp(x18);
    double x20 = x11 + x14;
    double x21 = x19*x20;
    double x22 = x5 + x6;
    double x23 = t*x22;
    double x24 = exp(x23);
    double x25 = x12 + x14;
    double x26 = x24*x25;
    double x27 = x16 + x21 + x26;
    double x28 = ((x27)*(x27)*(x27));
    double x29 = x19 + x24 + x9;
    double x30 = pow(x29, -3);
    double x31 = t*x30;
    double x32 = x7*x9;
    double x33 = x17*x19;
    double x34 = x22*x24;
    double x35 = ((t)*(t));
    double x36 = 2*x35;
    double x37 = x15*x32;
    double x38 = x20*x33;
    double x39 = x25*x34;
    double x40 = n1*(*endmember[0].d2mu0dP2)(T, P);
    double x41 = n1*(*endmember[1].d2mu0dP2)(T, P);
    double x42 = n1*(*endmember[2].d2mu0dP2)(T, P);
    double x43 = -LAbsMax(3, x40, x41, x42, x1, x3, x5);
    double x44 = x40 + x43;
    double x45 = x44*x9;
    double x46 = x41 + x43;
    double x47 = x19*x46;
    double x48 = x42 + x43;
    double x49 = x24*x48;
    double x50 = ((x15)*(x15))*x9;
    double x51 = x19*((x20)*(x20));
    double x52 = x24*((x25)*(x25));
    double x53 = t*x50 + t*x51 + t*x52 + x45 + x47 + x49;
    double x54 = pow(x29, -2);
    double x55 = 3*x27*x54;
    double x56 = 3*t;
    double x57 = n1*(*endmember[0].d3mu0dP3)(T, P);
    double x58 = n1*(*endmember[1].d3mu0dP3)(T, P);
    double x59 = n1*(*endmember[2].d3mu0dP3)(T, P);
    double x60 = -LAbsMax(3, x57, x58, x59, x1, x3, x5);
    double x61 = x57 + x60;
    double x62 = x58 + x60;
    double x63 = x59 + x60;
    double x64 = ((x15)*(x15)*(x15));
    double x65 = x64*x9;
    double x66 = ((x20)*(x20)*(x20));
    double x67 = x19*x66;
    double x68 = ((x25)*(x25)*(x25));
    double x69 = x24*x68;
    double x70 = x16*x44;
    double x71 = x21*x46;
    double x72 = x26*x48;
    double x73 = 2*t;
    double x74 = -3*x13;

    
    double result = 0.0;
    switch (index) {
    case 0:
        result = -t*x55*(x18*x51 + x23*x52 + x32*x44 + x33*x46 + x34*x48 + x50*x8 + x50 + x51 + x52) + ((x27)*(x27))*x30*x36*(3*x37 + 3*x38 + 3*x39) - 3*x27*x31*x53*(-2*x32 - 2*x33 - 2*x34) + 4*x28*x31 + x28*x36*(-3*x32 - 3*x33 - 3*x34)/((x29)*(x29)*(x29)*(x29)) - x53*x54*x56*(x37 + x38 + x39) - x53*x55 + x54*(-x32 - x33 - x34)*(x19*x62 + x24*x63 + x35*x65 + x35*x67 + x35*x69 + x56*x70 + x56*x71 + x56*x72 + x61*x9) + (3*x18*x71 + 3*x23*x72 + x32*x35*x64 + x32*x61 + x33*x35*x66 + x33*x62 + x34*x35*x68 + x34*x63 + x45*(3*x10 + x74) + x47*(3*x11 + x74) + x49*(3*x12 + x74) + x65*x73 + x67*x73 + x69*x73 + 3*x70*x8)/x29;
        break;

    default:
        break;
    }
        return result;
}
static void coder_dparam_dgdn(double T, double P, double n[3], int index, double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[1].mu0)(T, P);
    double x2 = (*endmember[2].mu0)(T, P);
    double x3 = n1*x0;
    double x4 = n1*x1;
    double x5 = n1*x2;
    double x6 = LAbsMax(3, x0, x1, x2, x3, x4, x5);
    double x7 = -LAbsMax(3, x3, x4, x5, x3, x4, x5);
    double x8 = x3 + x7;
    double x9 = t*x8;
    double x10 = exp(x9);
    double x11 = x4 + x7;
    double x12 = t*x11;
    double x13 = exp(x12);
    double x14 = x5 + x7;
    double x15 = t*x14;
    double x16 = exp(x15);
    double x17 = x10 + x13 + x16;
    double x18 = 1.0/x17;
    double x19 = -x6;
    double x20 = x10*(x0 + x19);
    double x21 = t*x20;
    double x22 = x13*(x1 + x19);
    double x23 = t*x22;
    double x24 = x16*(x19 + x2);
    double x25 = t*x24;

    switch (index) {
    case 0:
    result[0] = (x18*(x12*x22 + x15*x24 + x20*x9 + x20 + x22 + x24) + x6 + (-x21 - x23 - x25)*(x10*x8 + x11*x13 + x14*x16)/((x17)*(x17)))/t - (t*x6 + x18*(x21 + x23 + x25))/((t)*(t));
result[1] = 0;
result[2] = 0;
        break;
    default:
        break;
    }
}

static int coder_get_param_number(void) {
    return 1;
}

static const char *paramNames[1] = {"t"};
static const char *paramUnits[1] = {"'None'"};

static const char **coder_get_param_names(void) {
    return paramNames;
}

static const char **coder_get_param_units(void) {
    return paramUnits;
}

static void coder_get_param_values(double **values) {
    (*values)[0] = t;

}

static int coder_set_param_values(double *values) {
    t = values[0];

    return 1;
}

static double coder_get_param_value(int index) {
    double result = 0.0;
    switch (index) {
    case 0:
        result = t;
        break;

    default:
        break;
    }
    return result;
}

static int coder_set_param_value(int index, double value) {
    int result = 1;
    switch (index) {
    case 0:
        t = value;
        break;

    default:
        result = 0;
        break;
    }
    return result;
}

