#include <math.h>

#include "coder_external_functions.h"


static double coder_dparam_g(double T, double P, double n[3], int index) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


        double x0 = (*endmember[0].mu0)(T, P);
    double x1 = n1*x0;
    double x2 = (*endmember[1].mu0)(T, P);
    double x3 = n1*x2;
    double x4 = (*endmember[2].mu0)(T, P);
    double x5 = n1*x4;
    double x6 = -LAbsMax(3, x1, x3, x5, x1, x3, x5);
    double x7 = x1 + x6;
    double x8 = exp(t*x7);
    double x9 = x3 + x6;
    double x10 = exp(t*x9);
    double x11 = x5 + x6;
    double x12 = exp(t*x11);
    double x13 = x10 + x12 + x8;
    double x14 = x0*x8;
    double x15 = x10*x2;
    double x16 = x12*x4;

    
    double result = 0.0;
    switch (index) {
    case 0:
        result = n1*(x11*x16 + x14*x7 + x15*x9)/x13 + n1*(x14 + x15 + x16)*(-x10*x9 - x11*x12 - x7*x8)/((x13)*(x13));
        break;

    default:
        break;
    }
        return result;
}

static double coder_dparam_dgdt(double T, double P, double n[3], int index) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


        double x0 = (*endmember[0].mu0)(T, P);
    double x1 = n1*x0;
    double x2 = (*endmember[1].mu0)(T, P);
    double x3 = n1*x2;
    double x4 = (*endmember[2].mu0)(T, P);
    double x5 = n1*x4;
    double x6 = -LAbsMax(3, x1, x3, x5, x1, x3, x5);
    double x7 = x1 + x6;
    double x8 = t*x7;
    double x9 = exp(x8);
    double x10 = x0*x9;
    double x11 = x3 + x6;
    double x12 = t*x11;
    double x13 = exp(x12);
    double x14 = x13*x2;
    double x15 = x5 + x6;
    double x16 = t*x15;
    double x17 = exp(x16);
    double x18 = x17*x4;
    double x19 = (*endmember[0].dmu0dT)(T, P);
    double x20 = n1*x19;
    double x21 = (*endmember[1].dmu0dT)(T, P);
    double x22 = n1*x21;
    double x23 = (*endmember[2].dmu0dT)(T, P);
    double x24 = n1*x23;
    double x25 = LAbsMax(3, x20, x22, x24, x1, x3, x5);
    double x26 = -x25;
    double x27 = x20 + x26;
    double x28 = x27*x9;
    double x29 = x22 + x26;
    double x30 = x13*x29;
    double x31 = x24 + x26;
    double x32 = x17*x31;
    double x33 = -t*x28 - t*x30 - t*x32;
    double x34 = x13 + x17 + x9;
    double x35 = n1/((x34)*(x34));
    double x36 = x10 + x14 + x18;
    double x37 = x7*x9;
    double x38 = x11*x13;
    double x39 = x15*x17;
    double x40 = x10*x27;
    double x41 = x14*x29;
    double x42 = x18*x31;

    
    double result = 0.0;
    switch (index) {
    case 0:
        result = n1*x33*x36*(-2*x37 - 2*x38 - 2*x39)/((x34)*(x34)*(x34)) + n1*(x12*x41 + x16*x42 + x19*x37 + x21*x38 + x23*x39 + x40*x8 + x40 + x41 + x42)/x34 + x33*x35*(x10*x7 + x11*x14 + x15*x18) + x35*x36*(-x12*x30 + x13*(-x22 + x25) - x16*x32 + x17*(-x24 + x25) - x28*x8 + x9*(-x20 + x25)) + x35*(-x37 - x38 - x39)*(t*x40 + t*x41 + t*x42 + x13*x21 + x17*x23 + x19*x9);
        break;

    default:
        break;
    }
        return result;
}

static double coder_dparam_dgdp(double T, double P, double n[3], int index) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


        double x0 = (*endmember[0].mu0)(T, P);
    double x1 = n1*x0;
    double x2 = (*endmember[1].mu0)(T, P);
    double x3 = n1*x2;
    double x4 = (*endmember[2].mu0)(T, P);
    double x5 = n1*x4;
    double x6 = -LAbsMax(3, x1, x3, x5, x1, x3, x5);
    double x7 = x1 + x6;
    double x8 = t*x7;
    double x9 = exp(x8);
    double x10 = x0*x9;
    double x11 = x3 + x6;
    double x12 = t*x11;
    double x13 = exp(x12);
    double x14 = x13*x2;
    double x15 = x5 + x6;
    double x16 = t*x15;
    double x17 = exp(x16);
    double x18 = x17*x4;
    double x19 = (*endmember[0].dmu0dP)(T, P);
    double x20 = n1*x19;
    double x21 = (*endmember[1].dmu0dP)(T, P);
    double x22 = n1*x21;
    double x23 = (*endmember[2].dmu0dP)(T, P);
    double x24 = n1*x23;
    double x25 = LAbsMax(3, x20, x22, x24, x1, x3, x5);
    double x26 = -x25;
    double x27 = x20 + x26;
    double x28 = x27*x9;
    double x29 = x22 + x26;
    double x30 = x13*x29;
    double x31 = x24 + x26;
    double x32 = x17*x31;
    double x33 = -t*x28 - t*x30 - t*x32;
    double x34 = x13 + x17 + x9;
    double x35 = n1/((x34)*(x34));
    double x36 = x10 + x14 + x18;
    double x37 = x7*x9;
    double x38 = x11*x13;
    double x39 = x15*x17;
    double x40 = x10*x27;
    double x41 = x14*x29;
    double x42 = x18*x31;

    
    double result = 0.0;
    switch (index) {
    case 0:
        result = n1*x33*x36*(-2*x37 - 2*x38 - 2*x39)/((x34)*(x34)*(x34)) + n1*(x12*x41 + x16*x42 + x19*x37 + x21*x38 + x23*x39 + x40*x8 + x40 + x41 + x42)/x34 + x33*x35*(x10*x7 + x11*x14 + x15*x18) + x35*x36*(-x12*x30 + x13*(-x22 + x25) - x16*x32 + x17*(-x24 + x25) - x28*x8 + x9*(-x20 + x25)) + x35*(-x37 - x38 - x39)*(t*x40 + t*x41 + t*x42 + x13*x21 + x17*x23 + x19*x9);
        break;

    default:
        break;
    }
        return result;
}

static double coder_dparam_d2gdt2(double T, double P, double n[3], int index) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


        double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[0].d2mu0dT2)(T, P);
    double x2 = n1*x0;
    double x3 = (*endmember[1].mu0)(T, P);
    double x4 = n1*x3;
    double x5 = (*endmember[2].mu0)(T, P);
    double x6 = n1*x5;
    double x7 = -LAbsMax(3, x2, x4, x6, x2, x4, x6);
    double x8 = x2 + x7;
    double x9 = t*x8;
    double x10 = exp(x9);
    double x11 = (*endmember[1].d2mu0dT2)(T, P);
    double x12 = x4 + x7;
    double x13 = t*x12;
    double x14 = exp(x13);
    double x15 = (*endmember[2].d2mu0dT2)(T, P);
    double x16 = x6 + x7;
    double x17 = t*x16;
    double x18 = exp(x17);
    double x19 = n1*x1;
    double x20 = n1*x11;
    double x21 = n1*x15;
    double x22 = -LAbsMax(3, x19, x20, x21, x2, x4, x6);
    double x23 = x19 + x22;
    double x24 = x0*x10;
    double x25 = x23*x24;
    double x26 = x20 + x22;
    double x27 = x14*x3;
    double x28 = x26*x27;
    double x29 = x21 + x22;
    double x30 = x18*x5;
    double x31 = x29*x30;
    double x32 = ((t)*(t));
    double x33 = (*endmember[0].dmu0dT)(T, P);
    double x34 = n1*x33;
    double x35 = (*endmember[1].dmu0dT)(T, P);
    double x36 = n1*x35;
    double x37 = (*endmember[2].dmu0dT)(T, P);
    double x38 = n1*x37;
    double x39 = LAbsMax(3, x34, x36, x38, x2, x4, x6);
    double x40 = -x39;
    double x41 = x34 + x40;
    double x42 = ((x41)*(x41));
    double x43 = x24*x42;
    double x44 = x36 + x40;
    double x45 = ((x44)*(x44));
    double x46 = x27*x45;
    double x47 = x38 + x40;
    double x48 = ((x47)*(x47));
    double x49 = x30*x48;
    double x50 = 2*t;
    double x51 = x10*x41;
    double x52 = x33*x51;
    double x53 = x14*x44;
    double x54 = x35*x53;
    double x55 = x18*x47;
    double x56 = x37*x55;
    double x57 = x24 + x27 + x30;
    double x58 = x10 + x14 + x18;
    double x59 = pow(x58, -2);
    double x60 = x51 + x53 + x55;
    double x61 = ((x60)*(x60));
    double x62 = x59*x61;
    double x63 = 2*x32;
    double x64 = x62*x63;
    double x65 = x10*x23;
    double x66 = x14*x26;
    double x67 = x18*x29;
    double x68 = x10*x42;
    double x69 = x14*x45;
    double x70 = x18*x48;
    double x71 = t*x68 + t*x69 + t*x70 + x65 + x66 + x67;
    double x72 = 1.0/x58;
    double x73 = x57*x72;
    double x74 = x71*x73;
    double x75 = x10*x33;
    double x76 = x14*x35;
    double x77 = x18*x37;
    double x78 = x24*x41;
    double x79 = x27*x44;
    double x80 = x30*x47;
    double x81 = t*x78 + t*x79 + t*x80 + x75 + x76 + x77;
    double x82 = 2*x60;
    double x83 = x72*x82;
    double x84 = x81*x83;
    double x85 = x10*x8;
    double x86 = x12*x14;
    double x87 = x16*x18;
    double x88 = x59*(-x85 - x86 - x87);
    double x89 = -2*x39;
    double x90 = x24*x8;
    double x91 = x12*x27;
    double x92 = x16*x30;
    double x93 = t*x57;
    double x94 = x90 + x91 + x92;
    double x95 = x51*x8;
    double x96 = x12*x53;
    double x97 = x16*x55;
    double x98 = t*x72;

    
    double result = 0.0;
    switch (index) {
    case 0:
        result = n1*x72*(-t*x73*(x12*x66 + x13*x69 + x16*x67 + x17*x70 + x65*x8 + x68*x9 + x68 + x69 + x70) - t*x81*x82*x88 - t*x83*(x12*x76 + x13*x79 + x16*x77 + x17*x80 + x75*x8 + x78*x9 + x78 + x79 + x80) + x1*x85 + x11*x86 + x13*x28 + 2*x13*x54 + x15*x87 + x17*x31 + 2*x17*x56 + x25*x9 + x25 + x28 + x31 + x32*x42*x90 + x32*x45*x91 + x32*x48*x92 + x32*x57*x59*x82*(2*x95 + 2*x96 + 2*x97) + x43*x50 + x46*x50 + x49*x50 + 2*x52*x9 + x57*x61*x63*(-2*x85 - 2*x86 - 2*x87)/((x58)*(x58)*(x58)) + 4*x62*x93 + x64*x94 - x71*x88*x93 - x71*x94*x98 - x74 + x75*(2*x34 + x89) + x76*(2*x36 + x89) + x77*(2*x38 + x89) - 2*x81*x98*(x95 + x96 + x97) - x84) + n1*x88*(t*x25 + t*x28 + t*x31 - t*x74 - t*x84 + x1*x10 + x11*x14 + x15*x18 + x32*x43 + x32*x46 + x32*x49 + x50*x52 + x50*x54 + x50*x56 + x57*x64);
        break;

    default:
        break;
    }
        return result;
}

static double coder_dparam_d2gdtdp(double T, double P, double n[3], int index) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


        double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[0].d2mu0dTdP)(T, P);
    double x2 = n1*x0;
    double x3 = (*endmember[1].mu0)(T, P);
    double x4 = n1*x3;
    double x5 = (*endmember[2].mu0)(T, P);
    double x6 = n1*x5;
    double x7 = -LAbsMax(3, x2, x4, x6, x2, x4, x6);
    double x8 = x2 + x7;
    double x9 = t*x8;
    double x10 = exp(x9);
    double x11 = (*endmember[1].d2mu0dTdP)(T, P);
    double x12 = x4 + x7;
    double x13 = t*x12;
    double x14 = exp(x13);
    double x15 = (*endmember[2].d2mu0dTdP)(T, P);
    double x16 = x6 + x7;
    double x17 = t*x16;
    double x18 = exp(x17);
    double x19 = (*endmember[0].dmu0dT)(T, P);
    double x20 = (*endmember[0].dmu0dP)(T, P);
    double x21 = n1*x20;
    double x22 = (*endmember[1].dmu0dP)(T, P);
    double x23 = n1*x22;
    double x24 = (*endmember[2].dmu0dP)(T, P);
    double x25 = n1*x24;
    double x26 = -LAbsMax(3, x21, x23, x25, x2, x4, x6);
    double x27 = x10*(x21 + x26);
    double x28 = x19*x27;
    double x29 = n1*x19;
    double x30 = (*endmember[1].dmu0dT)(T, P);
    double x31 = n1*x30;
    double x32 = (*endmember[2].dmu0dT)(T, P);
    double x33 = n1*x32;
    double x34 = -LAbsMax(3, x29, x31, x33, x2, x4, x6);
    double x35 = x29 + x34;
    double x36 = x10*x35;
    double x37 = x20*x36;
    double x38 = x14*(x23 + x26);
    double x39 = x30*x38;
    double x40 = x31 + x34;
    double x41 = x14*x40;
    double x42 = x22*x41;
    double x43 = x18*(x25 + x26);
    double x44 = x32*x43;
    double x45 = x33 + x34;
    double x46 = x18*x45;
    double x47 = x24*x46;
    double x48 = n1*x1;
    double x49 = n1*x11;
    double x50 = n1*x15;
    double x51 = -LAbsMax(3, x48, x49, x50, x2, x4, x6);
    double x52 = x48 + x51;
    double x53 = x0*x10;
    double x54 = x52*x53;
    double x55 = x49 + x51;
    double x56 = x14*x3;
    double x57 = x55*x56;
    double x58 = x50 + x51;
    double x59 = x18*x5;
    double x60 = x58*x59;
    double x61 = ((t)*(t));
    double x62 = x0*x27;
    double x63 = x35*x61*x62;
    double x64 = x3*x38;
    double x65 = x40*x61*x64;
    double x66 = x43*x5;
    double x67 = x45*x61*x66;
    double x68 = x53 + x56 + x59;
    double x69 = x27 + x38 + x43;
    double x70 = x36 + x41 + x46;
    double x71 = x10 + x14 + x18;
    double x72 = pow(x71, -2);
    double x73 = x69*x70*x72;
    double x74 = 2*x61;
    double x75 = x73*x74;
    double x76 = x10*x19;
    double x77 = x14*x30;
    double x78 = x18*x32;
    double x79 = x0*x36;
    double x80 = x3*x41;
    double x81 = x46*x5;
    double x82 = t*x79 + t*x80 + t*x81 + x76 + x77 + x78;
    double x83 = 1.0/x71;
    double x84 = x69*x83;
    double x85 = x82*x84;
    double x86 = x10*x20;
    double x87 = x14*x22;
    double x88 = x18*x24;
    double x89 = t*x62;
    double x90 = t*x64;
    double x91 = t*x66;
    double x92 = x86 + x87 + x88 + x89 + x90 + x91;
    double x93 = x70*x83;
    double x94 = x92*x93;
    double x95 = x10*x52;
    double x96 = x14*x55;
    double x97 = x18*x58;
    double x98 = x27*x35;
    double x99 = x38*x40;
    double x100 = x43*x45;
    double x101 = t*x100 + t*x98 + t*x99 + x95 + x96 + x97;
    double x102 = x68*x83;
    double x103 = x101*x102;
    double x104 = x10*x8;
    double x105 = x12*x14;
    double x106 = x16*x18;
    double x107 = x72*(-x104 - x105 - x106);
    double x108 = x12*x56 + x16*x59 + x53*x8;
    double x109 = x12*x41 + x16*x46 + x36*x8;
    double x110 = x68*x72*x74;
    double x111 = x12*x38 + x16*x43 + x27*x8;
    double x112 = t*x83;
    double x113 = t*x107;

    
    double result = 0.0;
    switch (index) {
    case 0:
        result = n1*x107*(-t*x103 + t*x28 + t*x37 + t*x39 + t*x42 + t*x44 + t*x47 + t*x54 + t*x57 + t*x60 - t*x85 - t*x94 + x1*x10 + x11*x14 + x15*x18 + x63 + x65 + x67 + x68*x75) + n1*x83*(-t*x102*(x100*x17 + x100 + x12*x96 + x13*x99 + x16*x97 + x8*x95 + x9*x98 + x98 + x99) + 4*t*x68*x73 - t*x84*(x12*x77 + x13*x80 + x16*x78 + x17*x81 + x76*x8 + x79*x9 + x79 + x80 + x81) - t*x93*(x12*x87 + x13*x64 + x16*x88 + x17*x66 + x62*x9 + x62 + x64 + x66 + x8*x86) + x1*x104 - x101*x108*x112 - x101*x113*x68 - x103 + x105*x11 + x106*x15 + x108*x75 + x109*x110*x69 - x109*x112*x92 + x110*x111*x70 - x111*x112*x82 - x113*x69*x82 - x113*x70*x92 + x12*x65 + x13*x39 + x13*x42 + x13*x57 + x16*x67 + x17*x44 + x17*x47 + x17*x60 + x28*x9 + x28 + 2*x35*x89 + x37*x9 + x37 + x39 + 2*x40*x90 + x42 + x44 + 2*x45*x91 + x47 + x54*x9 + x54 + x57 + x60 + x63*x8 + x68*x69*x70*x74*(-2*x104 - 2*x105 - 2*x106)/((x71)*(x71)*(x71)) - x85 - x94);
        break;

    default:
        break;
    }
        return result;
}

static double coder_dparam_d2gdp2(double T, double P, double n[3], int index) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


        double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[0].d2mu0dP2)(T, P);
    double x2 = n1*x0;
    double x3 = (*endmember[1].mu0)(T, P);
    double x4 = n1*x3;
    double x5 = (*endmember[2].mu0)(T, P);
    double x6 = n1*x5;
    double x7 = -LAbsMax(3, x2, x4, x6, x2, x4, x6);
    double x8 = x2 + x7;
    double x9 = t*x8;
    double x10 = exp(x9);
    double x11 = (*endmember[1].d2mu0dP2)(T, P);
    double x12 = x4 + x7;
    double x13 = t*x12;
    double x14 = exp(x13);
    double x15 = (*endmember[2].d2mu0dP2)(T, P);
    double x16 = x6 + x7;
    double x17 = t*x16;
    double x18 = exp(x17);
    double x19 = n1*x1;
    double x20 = n1*x11;
    double x21 = n1*x15;
    double x22 = -LAbsMax(3, x19, x20, x21, x2, x4, x6);
    double x23 = x19 + x22;
    double x24 = x0*x10;
    double x25 = x23*x24;
    double x26 = x20 + x22;
    double x27 = x14*x3;
    double x28 = x26*x27;
    double x29 = x21 + x22;
    double x30 = x18*x5;
    double x31 = x29*x30;
    double x32 = ((t)*(t));
    double x33 = (*endmember[0].dmu0dP)(T, P);
    double x34 = n1*x33;
    double x35 = (*endmember[1].dmu0dP)(T, P);
    double x36 = n1*x35;
    double x37 = (*endmember[2].dmu0dP)(T, P);
    double x38 = n1*x37;
    double x39 = LAbsMax(3, x34, x36, x38, x2, x4, x6);
    double x40 = -x39;
    double x41 = x34 + x40;
    double x42 = ((x41)*(x41));
    double x43 = x24*x42;
    double x44 = x36 + x40;
    double x45 = ((x44)*(x44));
    double x46 = x27*x45;
    double x47 = x38 + x40;
    double x48 = ((x47)*(x47));
    double x49 = x30*x48;
    double x50 = 2*t;
    double x51 = x10*x41;
    double x52 = x33*x51;
    double x53 = x14*x44;
    double x54 = x35*x53;
    double x55 = x18*x47;
    double x56 = x37*x55;
    double x57 = x24 + x27 + x30;
    double x58 = x10 + x14 + x18;
    double x59 = pow(x58, -2);
    double x60 = x51 + x53 + x55;
    double x61 = ((x60)*(x60));
    double x62 = x59*x61;
    double x63 = 2*x32;
    double x64 = x62*x63;
    double x65 = x10*x23;
    double x66 = x14*x26;
    double x67 = x18*x29;
    double x68 = x10*x42;
    double x69 = x14*x45;
    double x70 = x18*x48;
    double x71 = t*x68 + t*x69 + t*x70 + x65 + x66 + x67;
    double x72 = 1.0/x58;
    double x73 = x57*x72;
    double x74 = x71*x73;
    double x75 = x10*x33;
    double x76 = x14*x35;
    double x77 = x18*x37;
    double x78 = x24*x41;
    double x79 = x27*x44;
    double x80 = x30*x47;
    double x81 = t*x78 + t*x79 + t*x80 + x75 + x76 + x77;
    double x82 = 2*x60;
    double x83 = x72*x82;
    double x84 = x81*x83;
    double x85 = x10*x8;
    double x86 = x12*x14;
    double x87 = x16*x18;
    double x88 = x59*(-x85 - x86 - x87);
    double x89 = -2*x39;
    double x90 = x24*x8;
    double x91 = x12*x27;
    double x92 = x16*x30;
    double x93 = t*x57;
    double x94 = x90 + x91 + x92;
    double x95 = x51*x8;
    double x96 = x12*x53;
    double x97 = x16*x55;
    double x98 = t*x72;

    
    double result = 0.0;
    switch (index) {
    case 0:
        result = n1*x72*(-t*x73*(x12*x66 + x13*x69 + x16*x67 + x17*x70 + x65*x8 + x68*x9 + x68 + x69 + x70) - t*x81*x82*x88 - t*x83*(x12*x76 + x13*x79 + x16*x77 + x17*x80 + x75*x8 + x78*x9 + x78 + x79 + x80) + x1*x85 + x11*x86 + x13*x28 + 2*x13*x54 + x15*x87 + x17*x31 + 2*x17*x56 + x25*x9 + x25 + x28 + x31 + x32*x42*x90 + x32*x45*x91 + x32*x48*x92 + x32*x57*x59*x82*(2*x95 + 2*x96 + 2*x97) + x43*x50 + x46*x50 + x49*x50 + 2*x52*x9 + x57*x61*x63*(-2*x85 - 2*x86 - 2*x87)/((x58)*(x58)*(x58)) + 4*x62*x93 + x64*x94 - x71*x88*x93 - x71*x94*x98 - x74 + x75*(2*x34 + x89) + x76*(2*x36 + x89) + x77*(2*x38 + x89) - 2*x81*x98*(x95 + x96 + x97) - x84) + n1*x88*(t*x25 + t*x28 + t*x31 - t*x74 - t*x84 + x1*x10 + x11*x14 + x15*x18 + x32*x43 + x32*x46 + x32*x49 + x50*x52 + x50*x54 + x50*x56 + x57*x64);
        break;

    default:
        break;
    }
        return result;
}

static double coder_dparam_d3gdt3(double T, double P, double n[3], int index) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


        double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[0].d3mu0dT3)(T, P);
    double x2 = n1*x0;
    double x3 = (*endmember[1].mu0)(T, P);
    double x4 = n1*x3;
    double x5 = (*endmember[2].mu0)(T, P);
    double x6 = n1*x5;
    double x7 = -LAbsMax(3, x2, x4, x6, x2, x4, x6);
    double x8 = x2 + x7;
    double x9 = t*x8;
    double x10 = exp(x9);
    double x11 = (*endmember[1].d3mu0dT3)(T, P);
    double x12 = x4 + x7;
    double x13 = t*x12;
    double x14 = exp(x13);
    double x15 = (*endmember[2].d3mu0dT3)(T, P);
    double x16 = x6 + x7;
    double x17 = t*x16;
    double x18 = exp(x17);
    double x19 = n1*x1;
    double x20 = n1*x11;
    double x21 = n1*x15;
    double x22 = -LAbsMax(3, x19, x20, x21, x2, x4, x6);
    double x23 = x19 + x22;
    double x24 = x0*x10;
    double x25 = x23*x24;
    double x26 = x20 + x22;
    double x27 = x14*x3;
    double x28 = x26*x27;
    double x29 = x21 + x22;
    double x30 = x18*x5;
    double x31 = x29*x30;
    double x32 = (*endmember[0].dmu0dT)(T, P);
    double x33 = n1*x32;
    double x34 = (*endmember[1].dmu0dT)(T, P);
    double x35 = n1*x34;
    double x36 = (*endmember[2].dmu0dT)(T, P);
    double x37 = n1*x36;
    double x38 = LAbsMax(3, x33, x35, x37, x2, x4, x6);
    double x39 = -x38;
    double x40 = x33 + x39;
    double x41 = ((x40)*(x40)*(x40));
    double x42 = ((t)*(t)*(t));
    double x43 = x41*x42;
    double x44 = x35 + x39;
    double x45 = ((x44)*(x44)*(x44));
    double x46 = x42*x45;
    double x47 = x37 + x39;
    double x48 = ((x47)*(x47)*(x47));
    double x49 = x42*x48;
    double x50 = (*endmember[0].d2mu0dT2)(T, P);
    double x51 = x10*x40;
    double x52 = 3*t;
    double x53 = x51*x52;
    double x54 = n1*x50;
    double x55 = (*endmember[1].d2mu0dT2)(T, P);
    double x56 = n1*x55;
    double x57 = (*endmember[2].d2mu0dT2)(T, P);
    double x58 = n1*x57;
    double x59 = LAbsMax(3, x54, x56, x58, x2, x4, x6);
    double x60 = -x59;
    double x61 = x54 + x60;
    double x62 = x10*x61;
    double x63 = x32*x62;
    double x64 = x14*x44;
    double x65 = x52*x64;
    double x66 = x56 + x60;
    double x67 = x14*x66;
    double x68 = x34*x67;
    double x69 = x18*x47;
    double x70 = x52*x69;
    double x71 = x58 + x60;
    double x72 = x18*x71;
    double x73 = x36*x72;
    double x74 = x10*x32;
    double x75 = ((x40)*(x40));
    double x76 = ((t)*(t));
    double x77 = x75*x76;
    double x78 = 3*x77;
    double x79 = x14*x34;
    double x80 = ((x44)*(x44));
    double x81 = x76*x80;
    double x82 = 3*x81;
    double x83 = x18*x36;
    double x84 = ((x47)*(x47));
    double x85 = x76*x84;
    double x86 = 3*x85;
    double x87 = x24*x61;
    double x88 = 3*x76;
    double x89 = x40*x88;
    double x90 = x27*x66;
    double x91 = x44*x88;
    double x92 = x30*x71;
    double x93 = x47*x88;
    double x94 = x24 + x27 + x30;
    double x95 = x51 + x64 + x69;
    double x96 = ((x95)*(x95)*(x95));
    double x97 = x10 + x14 + x18;
    double x98 = pow(x97, -3);
    double x99 = x96*x98;
    double x100 = 6*x42;
    double x101 = x100*x99;
    double x102 = x24*x40;
    double x103 = x27*x44;
    double x104 = x30*x47;
    double x105 = t*x102 + t*x103 + t*x104 + x74 + x79 + x83;
    double x106 = pow(x97, -2);
    double x107 = ((x95)*(x95));
    double x108 = x106*x107;
    double x109 = 6*x76;
    double x110 = x108*x109;
    double x111 = x10*x75;
    double x112 = x14*x80;
    double x113 = x18*x84;
    double x114 = t*x111 + t*x112 + t*x113 + x62 + x67 + x72;
    double x115 = x106*x95;
    double x116 = x76*x94;
    double x117 = 6*x116;
    double x118 = x115*x117;
    double x119 = 1.0/x97;
    double x120 = 3*x119;
    double x121 = x114*x120;
    double x122 = x105*x121;
    double x123 = x10*x23;
    double x124 = x14*x26;
    double x125 = x18*x29;
    double x126 = x10*x41;
    double x127 = x14*x45;
    double x128 = x18*x48;
    double x129 = x123 + x124 + x125 + x126*x76 + x127*x76 + x128*x76 + x53*x61 + x65*x66 + x70*x71;
    double x130 = x119*x94;
    double x131 = x129*x130;
    double x132 = x10*x50;
    double x133 = x14*x55;
    double x134 = x18*x57;
    double x135 = t*x87;
    double x136 = t*x90;
    double x137 = t*x92;
    double x138 = x24*x75;
    double x139 = x27*x80;
    double x140 = x30*x84;
    double x141 = 2*t;
    double x142 = x32*x51;
    double x143 = x34*x64;
    double x144 = x36*x69;
    double x145 = x132 + x133 + x134 + x135 + x136 + x137 + x138*x76 + x139*x76 + x140*x76 + x141*x142 + x141*x143 + x141*x144;
    double x146 = x120*x95;
    double x147 = x145*x146;
    double x148 = x10*x8;
    double x149 = x12*x14;
    double x150 = x16*x18;
    double x151 = x106*(-x148 - x149 - x150);
    double x152 = -3*x38;
    double x153 = x152 + 3*x33;
    double x154 = -3*x59;
    double x155 = x152 + 3*x35;
    double x156 = x152 + 3*x37;
    double x157 = x41*x76;
    double x158 = x45*x76;
    double x159 = x48*x76;
    double x160 = 6*t;
    double x161 = x24*x8;
    double x162 = x12*x27;
    double x163 = x16*x30;
    double x164 = 3*x9;
    double x165 = x164*x51;
    double x166 = 3*x13;
    double x167 = x166*x64;
    double x168 = 3*x17;
    double x169 = x168*x69;
    double x170 = x74*x8;
    double x171 = x12*x79;
    double x172 = x16*x83;
    double x173 = x161 + x162 + x163;
    double x174 = x100*x94;
    double x175 = 12*t;
    double x176 = x51*x8;
    double x177 = x12*x64;
    double x178 = x16*x69;
    double x179 = x107*x98;
    double x180 = -2*x148 - 2*x149 - 2*x150;
    double x181 = x105*x109;
    double x182 = x114*x115;
    double x183 = x176 + x177 + x178;
    double x184 = x114*x117;
    double x185 = x102*x9 + x102 + x103*x13 + x103 + x104*x17 + x104 + x170 + x171 + x172;
    double x186 = x151*x52;
    double x187 = t*x129;
    double x188 = t*x120;
    double x189 = x111*x9 + x111 + x112*x13 + x112 + x113*x17 + x113 + x12*x67 + x16*x72 + x62*x8;
    double x190 = -2*x38;

    
    double result = 0.0;
    switch (index) {
    case 0:
        result = n1*x119*(-t*x121*x185 - t*x130*(x12*x124 + x123*x8 + x125*x16 + x126*x141 + x127*x141 + x128*x141 + x148*x157 + x149*x158 + x150*x159 + x153*x62 + x155*x67 + x156*x72 + x165*x61 + x167*x66 + x169*x71) - t*x146*(x12*x133 + 2*x13*x143 + x13*x90 + x132*x8 + x134*x16 + x138*x141 + x139*x141 + x140*x141 + 2*x142*x9 + 2*x144*x17 + x161*x77 + x162*x81 + x163*x85 + x17*x92 + x74*(x190 + 2*x33) + x79*(x190 + 2*x35) + x83*(x190 + 2*x37) + x87*x9 + x87 + x90 + x92) + x1*x148 - x101*x173 + x105*x108*x175 - x105*x114*x186 - x105*x188*x189 + x106*x183*x184 + x109*x173*x182 + x11*x149 + x110*x185 + x115*x181*(2*x176 + 2*x177 + 2*x178) - 18*x116*x99 + x118*x189 - x119*x173*x187 - x122 + x13*x28 - x131 + x132*x153 + x133*x155 + x134*x156 + 6*x135*x40 + 6*x136*x44 + 6*x137*x47 - x145*x183*x188 - x145*x186*x95 - x147 + x15*x150 - x151*x187*x94 + 3*x157*x24 + 3*x158*x27 + 3*x159*x30 + x160*x74*x75 + x160*x79*x80 + x160*x83*x84 + x161*x43 + x161*x61*x89 + x162*x46 + x162*x66*x91 + x163*x49 + x163*x71*x93 + x164*x63 + x165*x50 + x166*x68 + x167*x55 + x168*x73 + x169*x57 + x17*x31 + x170*x78 + x171*x82 + x172*x86 - x174*x179*(3*x176 + 3*x177 + 3*x178) - x174*x96*(-3*x148 - 3*x149 - 3*x150)/((x97)*(x97)*(x97)*(x97)) + x175*x182*x94 + x179*x180*x181 + x180*x184*x95*x98 + x25*x9 + x25 + x28 + x31 + x74*(x154 + 3*x54) + x79*(x154 + 3*x56) + x83*(x154 + 3*x58)) + n1*x151*(-t*x122 - t*x131 - t*x147 + t*x25 + t*x28 + t*x31 + x1*x10 - x101*x94 + x105*x110 + x11*x14 + x114*x118 + x15*x18 + x24*x43 + x27*x46 + x30*x49 + x50*x53 + x52*x63 + x52*x68 + x52*x73 + x55*x65 + x57*x70 + x74*x78 + x79*x82 + x83*x86 + x87*x89 + x90*x91 + x92*x93);
        break;

    default:
        break;
    }
        return result;
}

static double coder_dparam_d3gdt2dp(double T, double P, double n[3], int index) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


        double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[0].d3mu0dT2dP)(T, P);
    double x2 = n1*x0;
    double x3 = (*endmember[1].mu0)(T, P);
    double x4 = n1*x3;
    double x5 = (*endmember[2].mu0)(T, P);
    double x6 = n1*x5;
    double x7 = -LAbsMax(3, x2, x4, x6, x2, x4, x6);
    double x8 = x2 + x7;
    double x9 = t*x8;
    double x10 = exp(x9);
    double x11 = (*endmember[1].d3mu0dT2dP)(T, P);
    double x12 = x4 + x7;
    double x13 = t*x12;
    double x14 = exp(x13);
    double x15 = (*endmember[2].d3mu0dT2dP)(T, P);
    double x16 = x6 + x7;
    double x17 = t*x16;
    double x18 = exp(x17);
    double x19 = (*endmember[0].d2mu0dT2)(T, P);
    double x20 = (*endmember[0].dmu0dP)(T, P);
    double x21 = n1*x20;
    double x22 = (*endmember[1].dmu0dP)(T, P);
    double x23 = n1*x22;
    double x24 = (*endmember[2].dmu0dP)(T, P);
    double x25 = n1*x24;
    double x26 = -LAbsMax(3, x21, x23, x25, x2, x4, x6);
    double x27 = x10*(x21 + x26);
    double x28 = x19*x27;
    double x29 = n1*x19;
    double x30 = (*endmember[1].d2mu0dT2)(T, P);
    double x31 = n1*x30;
    double x32 = (*endmember[2].d2mu0dT2)(T, P);
    double x33 = n1*x32;
    double x34 = -LAbsMax(3, x29, x31, x33, x2, x4, x6);
    double x35 = x29 + x34;
    double x36 = x10*x35;
    double x37 = x20*x36;
    double x38 = x14*(x23 + x26);
    double x39 = x30*x38;
    double x40 = x31 + x34;
    double x41 = x14*x40;
    double x42 = x22*x41;
    double x43 = x18*(x25 + x26);
    double x44 = x32*x43;
    double x45 = x33 + x34;
    double x46 = x18*x45;
    double x47 = x24*x46;
    double x48 = (*endmember[0].d2mu0dTdP)(T, P);
    double x49 = (*endmember[0].dmu0dT)(T, P);
    double x50 = n1*x49;
    double x51 = (*endmember[1].dmu0dT)(T, P);
    double x52 = n1*x51;
    double x53 = (*endmember[2].dmu0dT)(T, P);
    double x54 = n1*x53;
    double x55 = LAbsMax(3, x50, x52, x54, x2, x4, x6);
    double x56 = -x55;
    double x57 = x50 + x56;
    double x58 = x10*x57;
    double x59 = 2*t;
    double x60 = x58*x59;
    double x61 = (*endmember[1].d2mu0dTdP)(T, P);
    double x62 = x52 + x56;
    double x63 = x14*x62;
    double x64 = x59*x63;
    double x65 = (*endmember[2].d2mu0dTdP)(T, P);
    double x66 = x54 + x56;
    double x67 = x18*x66;
    double x68 = x59*x67;
    double x69 = x10*x20;
    double x70 = ((x57)*(x57));
    double x71 = ((t)*(t));
    double x72 = x70*x71;
    double x73 = x14*x22;
    double x74 = ((x62)*(x62));
    double x75 = x71*x74;
    double x76 = x18*x24;
    double x77 = ((x66)*(x66));
    double x78 = x71*x77;
    double x79 = n1*x1;
    double x80 = n1*x11;
    double x81 = n1*x15;
    double x82 = -LAbsMax(3, x79, x80, x81, x2, x4, x6);
    double x83 = x79 + x82;
    double x84 = x0*x10;
    double x85 = x83*x84;
    double x86 = x80 + x82;
    double x87 = x14*x3;
    double x88 = x86*x87;
    double x89 = x81 + x82;
    double x90 = x18*x5;
    double x91 = x89*x90;
    double x92 = n1*x48;
    double x93 = n1*x61;
    double x94 = n1*x65;
    double x95 = LAbsMax(3, x92, x93, x94, x2, x4, x6);
    double x96 = -x95;
    double x97 = x92 + x96;
    double x98 = x10*x97;
    double x99 = x49*x98;
    double x100 = x93 + x96;
    double x101 = x100*x14;
    double x102 = x101*x51;
    double x103 = x94 + x96;
    double x104 = x103*x18;
    double x105 = x104*x53;
    double x106 = x27*x35;
    double x107 = x0*x106*x71;
    double x108 = x38*x40;
    double x109 = x108*x3*x71;
    double x110 = x43*x45;
    double x111 = x110*x5*x71;
    double x112 = x0*x27;
    double x113 = ((t)*(t)*(t));
    double x114 = x113*x70;
    double x115 = x3*x38;
    double x116 = x113*x74;
    double x117 = x43*x5;
    double x118 = x113*x77;
    double x119 = x27*x49;
    double x120 = x57*x71;
    double x121 = 2*x120;
    double x122 = x38*x51;
    double x123 = x62*x71;
    double x124 = 2*x123;
    double x125 = x43*x53;
    double x126 = x66*x71;
    double x127 = 2*x126;
    double x128 = x84*x97;
    double x129 = x100*x87;
    double x130 = x103*x90;
    double x131 = x58 + x63 + x67;
    double x132 = ((x131)*(x131));
    double x133 = x10 + x14 + x18;
    double x134 = pow(x133, -3);
    double x135 = x132*x134;
    double x136 = x27 + x38 + x43;
    double x137 = x84 + x87 + x90;
    double x138 = x136*x137;
    double x139 = x135*x138;
    double x140 = 6*x113;
    double x141 = t*x112;
    double x142 = t*x115;
    double x143 = t*x117;
    double x144 = x141 + x142 + x143 + x69 + x73 + x76;
    double x145 = pow(x133, -2);
    double x146 = x132*x145;
    double x147 = 2*x71;
    double x148 = x146*x147;
    double x149 = x10*x70;
    double x150 = x14*x74;
    double x151 = x18*x77;
    double x152 = t*x149 + t*x150 + t*x151 + x36 + x41 + x46;
    double x153 = x145*x147;
    double x154 = x138*x153;
    double x155 = x10*x49;
    double x156 = x14*x51;
    double x157 = x18*x53;
    double x158 = x57*x84;
    double x159 = x62*x87;
    double x160 = x66*x90;
    double x161 = t*x158 + t*x159 + t*x160 + x155 + x156 + x157;
    double x162 = x136*x71;
    double x163 = x131*x145;
    double x164 = 4*x163;
    double x165 = x162*x164;
    double x166 = 1.0/x133;
    double x167 = x152*x166;
    double x168 = x144*x167;
    double x169 = x27*x57;
    double x170 = x38*x62;
    double x171 = x43*x66;
    double x172 = t*x169 + t*x170 + t*x171 + x101 + x104 + x98;
    double x173 = x164*x71;
    double x174 = x137*x173;
    double x175 = 2*x166;
    double x176 = x172*x175;
    double x177 = x161*x176;
    double x178 = x10*x19;
    double x179 = x14*x30;
    double x180 = x18*x32;
    double x181 = x35*x84;
    double x182 = x40*x87;
    double x183 = x45*x90;
    double x184 = t*x181 + t*x182 + t*x183 + x178 + x179 + x180 + x49*x60 + x51*x64 + x53*x68 + x72*x84 + x75*x87 + x78*x90;
    double x185 = x136*x166;
    double x186 = x184*x185;
    double x187 = x10*x83;
    double x188 = x14*x86;
    double x189 = x18*x89;
    double x190 = t*x106;
    double x191 = t*x108;
    double x192 = t*x110;
    double x193 = x100*x64 + x103*x68 + x187 + x188 + x189 + x190 + x191 + x192 + x27*x72 + x38*x75 + x43*x78 + x60*x97;
    double x194 = x137*x166;
    double x195 = x193*x194;
    double x196 = x10*x48;
    double x197 = x14*x61;
    double x198 = x18*x65;
    double x199 = t*x119;
    double x200 = x57*x69;
    double x201 = t*x122;
    double x202 = x62*x73;
    double x203 = t*x125;
    double x204 = x66*x76;
    double x205 = t*x128;
    double x206 = t*x129;
    double x207 = t*x130;
    double x208 = t*x200 + t*x202 + t*x204 + x112*x120 + x115*x123 + x117*x126 + x196 + x197 + x198 + x199 + x201 + x203 + x205 + x206 + x207;
    double x209 = x131*x175;
    double x210 = x208*x209;
    double x211 = x10*x8;
    double x212 = x12*x14;
    double x213 = x16*x18;
    double x214 = x145*(-x211 - x212 - x213);
    double x215 = -2*x55;
    double x216 = x215 + 2*x50;
    double x217 = x215 + 2*x52;
    double x218 = x215 + 2*x54;
    double x219 = x59*x70;
    double x220 = x59*x74;
    double x221 = x59*x77;
    double x222 = -2*x95;
    double x223 = 2*x9;
    double x224 = x223*x58;
    double x225 = 2*x13;
    double x226 = x225*x63;
    double x227 = 2*x17;
    double x228 = x227*x67;
    double x229 = x69*x8;
    double x230 = x12*x73;
    double x231 = x16*x76;
    double x232 = 4*x57;
    double x233 = 4*x62;
    double x234 = 4*x66;
    double x235 = x27*x8;
    double x236 = x0*x235;
    double x237 = x12*x38;
    double x238 = x237*x3;
    double x239 = x16*x43;
    double x240 = x239*x5;
    double x241 = x8*x84;
    double x242 = x12*x87;
    double x243 = x16*x90;
    double x244 = t*x144;
    double x245 = x241 + x242 + x243;
    double x246 = x136*x245;
    double x247 = x135*x140;
    double x248 = x235 + x237 + x239;
    double x249 = x137*x248;
    double x250 = x138*x140;
    double x251 = -2*x211 - 2*x212 - 2*x213;
    double x252 = x144*x147;
    double x253 = 4*x145;
    double x254 = x138*x152;
    double x255 = 8*t*x163;
    double x256 = x58*x8;
    double x257 = x12*x63;
    double x258 = x16*x67;
    double x259 = 2*x256 + 2*x257 + 2*x258;
    double x260 = x131*x134;
    double x261 = x152*x153;
    double x262 = x256 + x257 + x258;
    double x263 = x253*x262;
    double x264 = x161*x162;
    double x265 = x137*x172;
    double x266 = x112*x9 + x112 + x115*x13 + x115 + x117*x17 + x117 + x229 + x230 + x231;
    double x267 = 4*x251*x260;
    double x268 = x265*x71;
    double x269 = x214*x59;
    double x270 = t*x166;
    double x271 = x12*x41 + x13*x150 + x149*x9 + x149 + x150 + x151*x17 + x151 + x16*x46 + x36*x8;
    double x272 = x12*x156 + x13*x159 + x155*x8 + x157*x16 + x158*x9 + x158 + x159 + x160*x17 + x160;
    double x273 = t*x214;
    double x274 = x101*x12 + x104*x16 + x13*x170 + x169*x9 + x169 + x17*x171 + x170 + x171 + x8*x98;
    double x275 = t*x175;

    
    double result = 0.0;
    switch (index) {
    case 0:
        result = n1*x166*(-t*x167*x266 - t*x176*x272 - t*x185*(x12*x179 + x13*x182 + x155*x216 + x156*x217 + x157*x218 + x16*x180 + x17*x183 + x178*x8 + x181*x9 + x181 + x182 + x183 + x219*x84 + x220*x87 + x221*x90 + x224*x49 + x226*x51 + x228*x53 + x241*x72 + x242*x75 + x243*x78) - t*x194*(x100*x226 + x101*x217 + x103*x228 + x104*x218 + x106*x9 + x106 + x108*x13 + x108 + x110*x17 + x110 + x12*x188 + x16*x189 + x187*x8 + x216*x98 + x219*x27 + x220*x38 + x221*x43 + x224*x97 + x235*x72 + x237*x75 + x239*x78) - t*x209*(x119*x9 + x119 + x12*x197 + x120*x236 + x122*x13 + x122 + x123*x238 + x125*x17 + x125 + x126*x240 + x128*x9 + x128 + x129*x13 + x129 + x13*x202 + x130*x17 + x130 + 2*x141*x57 + 2*x142*x62 + 2*x143*x66 + x16*x198 + x17*x204 + x196*x8 + x200*x9 + x200 + x202 + x204) + t*x253*x254 + 2*x0*x190 + x1*x211 + x100*x124*x242 + x102*x225 + x103*x127*x243 + x105*x227 + x107*x8 + x109*x12 + x11*x212 + x111*x16 + 3*x112*x72 + x114*x236 + 3*x115*x75 + x116*x238 + 3*x117*x78 + x118*x240 + x121*x235*x49 + x121*x241*x97 + x124*x237*x51 + x127*x239*x53 + x13*x39 + x13*x42 + x13*x88 - x131*x208*x269 - x132*x250*(-3*x211 - 3*x212 - 3*x213)/((x133)*(x133)*(x133)*(x133)) + x134*x147*x251*x254 + x135*x251*x252 + x136*x161*x255 - x136*x184*x273 - x137*x193*x273 - 18*x139*x71 - x144*x270*x271 + 4*x146*x244 + x148*x266 + x15*x213 - x152*x214*x244 + x154*x271 + x155*(x222 + 2*x92) + x156*(x222 + 2*x93) + x157*(x222 + 2*x94) - x161*x172*x269 + x161*x173*x248 - x161*x274*x275 + x163*x252*x259 + x165*x272 - x168 + x17*x44 + x17*x47 + x17*x91 + x172*x173*x245 + x174*x274 - x177 - x184*x248*x270 - x186 + 2*x191*x3 + 2*x192*x5 - x193*x245*x270 - x195 + x196*x216 + x197*x217 + x198*x218 + x199*x232 + x201*x233 + x203*x234 + x205*x232 + x206*x233 + x207*x234 - x208*x262*x275 - x210 + x219*x69 + x220*x73 + x221*x76 + x223*x99 + x224*x48 + x226*x61 + x228*x65 + x229*x72 + x230*x75 + x231*x78 - x246*x247 + x246*x261 - x247*x249 + x249*x261 - x250*x259*x260 + x255*x265 + x263*x264 + x263*x268 + x264*x267 + x267*x268 + x28*x9 + x28 + x37*x9 + x37 + x39 + x42 + x44 + x47 + x85*x9 + x85 + x88 + x91) + n1*x214*(-t*x168 - t*x177 - t*x186 - t*x195 - t*x210 + t*x28 + t*x37 + t*x39 + t*x42 + t*x44 + t*x47 + t*x85 + t*x88 + t*x91 + x1*x10 + x102*x59 + x105*x59 + x107 + x109 + x11*x14 + x111 + x112*x114 + x115*x116 + x117*x118 + x119*x121 + x121*x128 + x122*x124 + x124*x129 + x125*x127 + x127*x130 - x139*x140 + x144*x148 + x15*x18 + x152*x154 + x161*x165 + x172*x174 + x48*x60 + x59*x99 + x61*x64 + x65*x68 + x69*x72 + x73*x75 + x76*x78);
        break;

    default:
        break;
    }
        return result;
}

static double coder_dparam_d3gdtdp2(double T, double P, double n[3], int index) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


        double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[0].d3mu0dTdP2)(T, P);
    double x2 = n1*x0;
    double x3 = (*endmember[1].mu0)(T, P);
    double x4 = n1*x3;
    double x5 = (*endmember[2].mu0)(T, P);
    double x6 = n1*x5;
    double x7 = -LAbsMax(3, x2, x4, x6, x2, x4, x6);
    double x8 = x2 + x7;
    double x9 = t*x8;
    double x10 = exp(x9);
    double x11 = (*endmember[1].d3mu0dTdP2)(T, P);
    double x12 = x4 + x7;
    double x13 = t*x12;
    double x14 = exp(x13);
    double x15 = (*endmember[2].d3mu0dTdP2)(T, P);
    double x16 = x6 + x7;
    double x17 = t*x16;
    double x18 = exp(x17);
    double x19 = (*endmember[0].dmu0dT)(T, P);
    double x20 = (*endmember[0].d2mu0dP2)(T, P);
    double x21 = n1*x20;
    double x22 = (*endmember[1].d2mu0dP2)(T, P);
    double x23 = n1*x22;
    double x24 = (*endmember[2].d2mu0dP2)(T, P);
    double x25 = n1*x24;
    double x26 = -LAbsMax(3, x21, x23, x25, x2, x4, x6);
    double x27 = x21 + x26;
    double x28 = x10*x27;
    double x29 = x19*x28;
    double x30 = n1*x19;
    double x31 = (*endmember[1].dmu0dT)(T, P);
    double x32 = n1*x31;
    double x33 = (*endmember[2].dmu0dT)(T, P);
    double x34 = n1*x33;
    double x35 = -LAbsMax(3, x30, x32, x34, x2, x4, x6);
    double x36 = x10*(x30 + x35);
    double x37 = x20*x36;
    double x38 = x23 + x26;
    double x39 = x14*x38;
    double x40 = x31*x39;
    double x41 = x14*(x32 + x35);
    double x42 = x22*x41;
    double x43 = x25 + x26;
    double x44 = x18*x43;
    double x45 = x33*x44;
    double x46 = x18*(x34 + x35);
    double x47 = x24*x46;
    double x48 = (*endmember[0].d2mu0dTdP)(T, P);
    double x49 = (*endmember[0].dmu0dP)(T, P);
    double x50 = n1*x49;
    double x51 = (*endmember[1].dmu0dP)(T, P);
    double x52 = n1*x51;
    double x53 = (*endmember[2].dmu0dP)(T, P);
    double x54 = n1*x53;
    double x55 = LAbsMax(3, x50, x52, x54, x2, x4, x6);
    double x56 = -x55;
    double x57 = x50 + x56;
    double x58 = x10*x57;
    double x59 = 2*t;
    double x60 = x58*x59;
    double x61 = (*endmember[1].d2mu0dTdP)(T, P);
    double x62 = x52 + x56;
    double x63 = x14*x62;
    double x64 = x59*x63;
    double x65 = (*endmember[2].d2mu0dTdP)(T, P);
    double x66 = x54 + x56;
    double x67 = x18*x66;
    double x68 = x59*x67;
    double x69 = x10*x19;
    double x70 = ((x57)*(x57));
    double x71 = ((t)*(t));
    double x72 = x70*x71;
    double x73 = x14*x31;
    double x74 = ((x62)*(x62));
    double x75 = x71*x74;
    double x76 = x18*x33;
    double x77 = ((x66)*(x66));
    double x78 = x71*x77;
    double x79 = n1*x1;
    double x80 = n1*x11;
    double x81 = n1*x15;
    double x82 = -LAbsMax(3, x79, x80, x81, x2, x4, x6);
    double x83 = x79 + x82;
    double x84 = x0*x10;
    double x85 = x83*x84;
    double x86 = x80 + x82;
    double x87 = x14*x3;
    double x88 = x86*x87;
    double x89 = x81 + x82;
    double x90 = x18*x5;
    double x91 = x89*x90;
    double x92 = n1*x48;
    double x93 = n1*x61;
    double x94 = n1*x65;
    double x95 = LAbsMax(3, x92, x93, x94, x2, x4, x6);
    double x96 = -x95;
    double x97 = x92 + x96;
    double x98 = x10*x97;
    double x99 = x49*x98;
    double x100 = x93 + x96;
    double x101 = x100*x14;
    double x102 = x101*x51;
    double x103 = x94 + x96;
    double x104 = x103*x18;
    double x105 = x104*x53;
    double x106 = x27*x36;
    double x107 = x0*x106*x71;
    double x108 = x38*x41;
    double x109 = x108*x3*x71;
    double x110 = x43*x46;
    double x111 = x110*x5*x71;
    double x112 = x0*x36;
    double x113 = ((t)*(t)*(t));
    double x114 = x113*x70;
    double x115 = x3*x41;
    double x116 = x113*x74;
    double x117 = x46*x5;
    double x118 = x113*x77;
    double x119 = x36*x49;
    double x120 = x57*x71;
    double x121 = 2*x120;
    double x122 = x41*x51;
    double x123 = x62*x71;
    double x124 = 2*x123;
    double x125 = x46*x53;
    double x126 = x66*x71;
    double x127 = 2*x126;
    double x128 = x84*x97;
    double x129 = x100*x87;
    double x130 = x103*x90;
    double x131 = x58 + x63 + x67;
    double x132 = ((x131)*(x131));
    double x133 = x10 + x14 + x18;
    double x134 = pow(x133, -3);
    double x135 = x132*x134;
    double x136 = x36 + x41 + x46;
    double x137 = x84 + x87 + x90;
    double x138 = x136*x137;
    double x139 = x135*x138;
    double x140 = 6*x113;
    double x141 = t*x112;
    double x142 = t*x115;
    double x143 = t*x117;
    double x144 = x141 + x142 + x143 + x69 + x73 + x76;
    double x145 = pow(x133, -2);
    double x146 = x132*x145;
    double x147 = 2*x71;
    double x148 = x146*x147;
    double x149 = x10*x70;
    double x150 = x14*x74;
    double x151 = x18*x77;
    double x152 = t*x149 + t*x150 + t*x151 + x28 + x39 + x44;
    double x153 = x145*x147;
    double x154 = x138*x153;
    double x155 = x10*x49;
    double x156 = x14*x51;
    double x157 = x18*x53;
    double x158 = x57*x84;
    double x159 = x62*x87;
    double x160 = x66*x90;
    double x161 = t*x158 + t*x159 + t*x160 + x155 + x156 + x157;
    double x162 = x136*x71;
    double x163 = x131*x145;
    double x164 = 4*x163;
    double x165 = x162*x164;
    double x166 = 1.0/x133;
    double x167 = x152*x166;
    double x168 = x144*x167;
    double x169 = x36*x57;
    double x170 = x41*x62;
    double x171 = x46*x66;
    double x172 = t*x169 + t*x170 + t*x171 + x101 + x104 + x98;
    double x173 = x164*x71;
    double x174 = x137*x173;
    double x175 = 2*x166;
    double x176 = x172*x175;
    double x177 = x161*x176;
    double x178 = x10*x20;
    double x179 = x14*x22;
    double x180 = x18*x24;
    double x181 = x27*x84;
    double x182 = x38*x87;
    double x183 = x43*x90;
    double x184 = t*x181 + t*x182 + t*x183 + x178 + x179 + x180 + x49*x60 + x51*x64 + x53*x68 + x72*x84 + x75*x87 + x78*x90;
    double x185 = x136*x166;
    double x186 = x184*x185;
    double x187 = x10*x83;
    double x188 = x14*x86;
    double x189 = x18*x89;
    double x190 = t*x106;
    double x191 = t*x108;
    double x192 = t*x110;
    double x193 = x100*x64 + x103*x68 + x187 + x188 + x189 + x190 + x191 + x192 + x36*x72 + x41*x75 + x46*x78 + x60*x97;
    double x194 = x137*x166;
    double x195 = x193*x194;
    double x196 = x10*x48;
    double x197 = x14*x61;
    double x198 = x18*x65;
    double x199 = x57*x69;
    double x200 = t*x119;
    double x201 = x62*x73;
    double x202 = t*x122;
    double x203 = x66*x76;
    double x204 = t*x125;
    double x205 = t*x128;
    double x206 = t*x129;
    double x207 = t*x130;
    double x208 = t*x199 + t*x201 + t*x203 + x112*x120 + x115*x123 + x117*x126 + x196 + x197 + x198 + x200 + x202 + x204 + x205 + x206 + x207;
    double x209 = x131*x175;
    double x210 = x208*x209;
    double x211 = x10*x8;
    double x212 = x12*x14;
    double x213 = x16*x18;
    double x214 = x145*(-x211 - x212 - x213);
    double x215 = -2*x55;
    double x216 = x215 + 2*x50;
    double x217 = x215 + 2*x52;
    double x218 = x215 + 2*x54;
    double x219 = x59*x70;
    double x220 = x59*x74;
    double x221 = x59*x77;
    double x222 = -2*x95;
    double x223 = 2*x9;
    double x224 = x223*x58;
    double x225 = 2*x13;
    double x226 = x225*x63;
    double x227 = 2*x17;
    double x228 = x227*x67;
    double x229 = x69*x8;
    double x230 = x12*x73;
    double x231 = x16*x76;
    double x232 = 4*x57;
    double x233 = 4*x62;
    double x234 = 4*x66;
    double x235 = x36*x8;
    double x236 = x0*x235;
    double x237 = x12*x41;
    double x238 = x237*x3;
    double x239 = x16*x46;
    double x240 = x239*x5;
    double x241 = x8*x84;
    double x242 = x12*x87;
    double x243 = x16*x90;
    double x244 = t*x144;
    double x245 = x241 + x242 + x243;
    double x246 = x136*x245;
    double x247 = x135*x140;
    double x248 = x235 + x237 + x239;
    double x249 = x137*x248;
    double x250 = x138*x140;
    double x251 = -2*x211 - 2*x212 - 2*x213;
    double x252 = x144*x147;
    double x253 = 4*x145;
    double x254 = x138*x152;
    double x255 = 8*t*x163;
    double x256 = x58*x8;
    double x257 = x12*x63;
    double x258 = x16*x67;
    double x259 = 2*x256 + 2*x257 + 2*x258;
    double x260 = x131*x134;
    double x261 = x152*x153;
    double x262 = x256 + x257 + x258;
    double x263 = x253*x262;
    double x264 = x161*x162;
    double x265 = x137*x172;
    double x266 = x112*x9 + x112 + x115*x13 + x115 + x117*x17 + x117 + x229 + x230 + x231;
    double x267 = 4*x251*x260;
    double x268 = x265*x71;
    double x269 = x214*x59;
    double x270 = t*x166;
    double x271 = x12*x39 + x13*x150 + x149*x9 + x149 + x150 + x151*x17 + x151 + x16*x44 + x28*x8;
    double x272 = x12*x156 + x13*x159 + x155*x8 + x157*x16 + x158*x9 + x158 + x159 + x160*x17 + x160;
    double x273 = t*x214;
    double x274 = x101*x12 + x104*x16 + x13*x170 + x169*x9 + x169 + x17*x171 + x170 + x171 + x8*x98;
    double x275 = t*x175;

    
    double result = 0.0;
    switch (index) {
    case 0:
        result = n1*x166*(-t*x167*x266 - t*x176*x272 - t*x185*(x12*x179 + x13*x182 + x155*x216 + x156*x217 + x157*x218 + x16*x180 + x17*x183 + x178*x8 + x181*x9 + x181 + x182 + x183 + x219*x84 + x220*x87 + x221*x90 + x224*x49 + x226*x51 + x228*x53 + x241*x72 + x242*x75 + x243*x78) - t*x194*(x100*x226 + x101*x217 + x103*x228 + x104*x218 + x106*x9 + x106 + x108*x13 + x108 + x110*x17 + x110 + x12*x188 + x16*x189 + x187*x8 + x216*x98 + x219*x36 + x220*x41 + x221*x46 + x224*x97 + x235*x72 + x237*x75 + x239*x78) - t*x209*(x119*x9 + x119 + x12*x197 + x120*x236 + x122*x13 + x122 + x123*x238 + x125*x17 + x125 + x126*x240 + x128*x9 + x128 + x129*x13 + x129 + x13*x201 + x130*x17 + x130 + 2*x141*x57 + 2*x142*x62 + 2*x143*x66 + x16*x198 + x17*x203 + x196*x8 + x199*x9 + x199 + x201 + x203) + t*x253*x254 + 2*x0*x190 + x1*x211 + x100*x124*x242 + x102*x225 + x103*x127*x243 + x105*x227 + x107*x8 + x109*x12 + x11*x212 + x111*x16 + 3*x112*x72 + x114*x236 + 3*x115*x75 + x116*x238 + 3*x117*x78 + x118*x240 + x121*x235*x49 + x121*x241*x97 + x124*x237*x51 + x127*x239*x53 + x13*x40 + x13*x42 + x13*x88 - x131*x208*x269 - x132*x250*(-3*x211 - 3*x212 - 3*x213)/((x133)*(x133)*(x133)*(x133)) + x134*x147*x251*x254 + x135*x251*x252 + x136*x161*x255 - x136*x184*x273 - x137*x193*x273 - 18*x139*x71 - x144*x270*x271 + 4*x146*x244 + x148*x266 + x15*x213 - x152*x214*x244 + x154*x271 + x155*(x222 + 2*x92) + x156*(x222 + 2*x93) + x157*(x222 + 2*x94) - x161*x172*x269 + x161*x173*x248 - x161*x274*x275 + x163*x252*x259 + x165*x272 - x168 + x17*x45 + x17*x47 + x17*x91 + x172*x173*x245 + x174*x274 - x177 - x184*x248*x270 - x186 + 2*x191*x3 + 2*x192*x5 - x193*x245*x270 - x195 + x196*x216 + x197*x217 + x198*x218 + x200*x232 + x202*x233 + x204*x234 + x205*x232 + x206*x233 + x207*x234 - x208*x262*x275 - x210 + x219*x69 + x220*x73 + x221*x76 + x223*x99 + x224*x48 + x226*x61 + x228*x65 + x229*x72 + x230*x75 + x231*x78 - x246*x247 + x246*x261 - x247*x249 + x249*x261 - x250*x259*x260 + x255*x265 + x263*x264 + x263*x268 + x264*x267 + x267*x268 + x29*x9 + x29 + x37*x9 + x37 + x40 + x42 + x45 + x47 + x85*x9 + x85 + x88 + x91) + n1*x214*(-t*x168 - t*x177 - t*x186 - t*x195 - t*x210 + t*x29 + t*x37 + t*x40 + t*x42 + t*x45 + t*x47 + t*x85 + t*x88 + t*x91 + x1*x10 + x102*x59 + x105*x59 + x107 + x109 + x11*x14 + x111 + x112*x114 + x115*x116 + x117*x118 + x119*x121 + x121*x128 + x122*x124 + x124*x129 + x125*x127 + x127*x130 - x139*x140 + x144*x148 + x15*x18 + x152*x154 + x161*x165 + x172*x174 + x48*x60 + x59*x99 + x61*x64 + x65*x68 + x69*x72 + x73*x75 + x76*x78);
        break;

    default:
        break;
    }
        return result;
}

static double coder_dparam_d3gdp3(double T, double P, double n[3], int index) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


        double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[0].d3mu0dP3)(T, P);
    double x2 = n1*x0;
    double x3 = (*endmember[1].mu0)(T, P);
    double x4 = n1*x3;
    double x5 = (*endmember[2].mu0)(T, P);
    double x6 = n1*x5;
    double x7 = -LAbsMax(3, x2, x4, x6, x2, x4, x6);
    double x8 = x2 + x7;
    double x9 = t*x8;
    double x10 = exp(x9);
    double x11 = (*endmember[1].d3mu0dP3)(T, P);
    double x12 = x4 + x7;
    double x13 = t*x12;
    double x14 = exp(x13);
    double x15 = (*endmember[2].d3mu0dP3)(T, P);
    double x16 = x6 + x7;
    double x17 = t*x16;
    double x18 = exp(x17);
    double x19 = n1*x1;
    double x20 = n1*x11;
    double x21 = n1*x15;
    double x22 = -LAbsMax(3, x19, x20, x21, x2, x4, x6);
    double x23 = x19 + x22;
    double x24 = x0*x10;
    double x25 = x23*x24;
    double x26 = x20 + x22;
    double x27 = x14*x3;
    double x28 = x26*x27;
    double x29 = x21 + x22;
    double x30 = x18*x5;
    double x31 = x29*x30;
    double x32 = (*endmember[0].dmu0dP)(T, P);
    double x33 = n1*x32;
    double x34 = (*endmember[1].dmu0dP)(T, P);
    double x35 = n1*x34;
    double x36 = (*endmember[2].dmu0dP)(T, P);
    double x37 = n1*x36;
    double x38 = LAbsMax(3, x33, x35, x37, x2, x4, x6);
    double x39 = -x38;
    double x40 = x33 + x39;
    double x41 = ((x40)*(x40)*(x40));
    double x42 = ((t)*(t)*(t));
    double x43 = x41*x42;
    double x44 = x35 + x39;
    double x45 = ((x44)*(x44)*(x44));
    double x46 = x42*x45;
    double x47 = x37 + x39;
    double x48 = ((x47)*(x47)*(x47));
    double x49 = x42*x48;
    double x50 = (*endmember[0].d2mu0dP2)(T, P);
    double x51 = x10*x40;
    double x52 = 3*t;
    double x53 = x51*x52;
    double x54 = n1*x50;
    double x55 = (*endmember[1].d2mu0dP2)(T, P);
    double x56 = n1*x55;
    double x57 = (*endmember[2].d2mu0dP2)(T, P);
    double x58 = n1*x57;
    double x59 = LAbsMax(3, x54, x56, x58, x2, x4, x6);
    double x60 = -x59;
    double x61 = x54 + x60;
    double x62 = x10*x61;
    double x63 = x32*x62;
    double x64 = x14*x44;
    double x65 = x52*x64;
    double x66 = x56 + x60;
    double x67 = x14*x66;
    double x68 = x34*x67;
    double x69 = x18*x47;
    double x70 = x52*x69;
    double x71 = x58 + x60;
    double x72 = x18*x71;
    double x73 = x36*x72;
    double x74 = x10*x32;
    double x75 = ((x40)*(x40));
    double x76 = ((t)*(t));
    double x77 = x75*x76;
    double x78 = 3*x77;
    double x79 = x14*x34;
    double x80 = ((x44)*(x44));
    double x81 = x76*x80;
    double x82 = 3*x81;
    double x83 = x18*x36;
    double x84 = ((x47)*(x47));
    double x85 = x76*x84;
    double x86 = 3*x85;
    double x87 = x24*x61;
    double x88 = 3*x76;
    double x89 = x40*x88;
    double x90 = x27*x66;
    double x91 = x44*x88;
    double x92 = x30*x71;
    double x93 = x47*x88;
    double x94 = x24 + x27 + x30;
    double x95 = x51 + x64 + x69;
    double x96 = ((x95)*(x95)*(x95));
    double x97 = x10 + x14 + x18;
    double x98 = pow(x97, -3);
    double x99 = x96*x98;
    double x100 = 6*x42;
    double x101 = x100*x99;
    double x102 = x24*x40;
    double x103 = x27*x44;
    double x104 = x30*x47;
    double x105 = t*x102 + t*x103 + t*x104 + x74 + x79 + x83;
    double x106 = pow(x97, -2);
    double x107 = ((x95)*(x95));
    double x108 = x106*x107;
    double x109 = 6*x76;
    double x110 = x108*x109;
    double x111 = x10*x75;
    double x112 = x14*x80;
    double x113 = x18*x84;
    double x114 = t*x111 + t*x112 + t*x113 + x62 + x67 + x72;
    double x115 = x106*x95;
    double x116 = x76*x94;
    double x117 = 6*x116;
    double x118 = x115*x117;
    double x119 = 1.0/x97;
    double x120 = 3*x119;
    double x121 = x114*x120;
    double x122 = x105*x121;
    double x123 = x10*x23;
    double x124 = x14*x26;
    double x125 = x18*x29;
    double x126 = x10*x41;
    double x127 = x14*x45;
    double x128 = x18*x48;
    double x129 = x123 + x124 + x125 + x126*x76 + x127*x76 + x128*x76 + x53*x61 + x65*x66 + x70*x71;
    double x130 = x119*x94;
    double x131 = x129*x130;
    double x132 = x10*x50;
    double x133 = x14*x55;
    double x134 = x18*x57;
    double x135 = t*x87;
    double x136 = t*x90;
    double x137 = t*x92;
    double x138 = x24*x75;
    double x139 = x27*x80;
    double x140 = x30*x84;
    double x141 = 2*t;
    double x142 = x32*x51;
    double x143 = x34*x64;
    double x144 = x36*x69;
    double x145 = x132 + x133 + x134 + x135 + x136 + x137 + x138*x76 + x139*x76 + x140*x76 + x141*x142 + x141*x143 + x141*x144;
    double x146 = x120*x95;
    double x147 = x145*x146;
    double x148 = x10*x8;
    double x149 = x12*x14;
    double x150 = x16*x18;
    double x151 = x106*(-x148 - x149 - x150);
    double x152 = -3*x38;
    double x153 = x152 + 3*x33;
    double x154 = -3*x59;
    double x155 = x152 + 3*x35;
    double x156 = x152 + 3*x37;
    double x157 = x41*x76;
    double x158 = x45*x76;
    double x159 = x48*x76;
    double x160 = 6*t;
    double x161 = x24*x8;
    double x162 = x12*x27;
    double x163 = x16*x30;
    double x164 = 3*x9;
    double x165 = x164*x51;
    double x166 = 3*x13;
    double x167 = x166*x64;
    double x168 = 3*x17;
    double x169 = x168*x69;
    double x170 = x74*x8;
    double x171 = x12*x79;
    double x172 = x16*x83;
    double x173 = x161 + x162 + x163;
    double x174 = x100*x94;
    double x175 = 12*t;
    double x176 = x51*x8;
    double x177 = x12*x64;
    double x178 = x16*x69;
    double x179 = x107*x98;
    double x180 = -2*x148 - 2*x149 - 2*x150;
    double x181 = x105*x109;
    double x182 = x114*x115;
    double x183 = x176 + x177 + x178;
    double x184 = x114*x117;
    double x185 = x102*x9 + x102 + x103*x13 + x103 + x104*x17 + x104 + x170 + x171 + x172;
    double x186 = x151*x52;
    double x187 = t*x129;
    double x188 = t*x120;
    double x189 = x111*x9 + x111 + x112*x13 + x112 + x113*x17 + x113 + x12*x67 + x16*x72 + x62*x8;
    double x190 = -2*x38;

    
    double result = 0.0;
    switch (index) {
    case 0:
        result = n1*x119*(-t*x121*x185 - t*x130*(x12*x124 + x123*x8 + x125*x16 + x126*x141 + x127*x141 + x128*x141 + x148*x157 + x149*x158 + x150*x159 + x153*x62 + x155*x67 + x156*x72 + x165*x61 + x167*x66 + x169*x71) - t*x146*(x12*x133 + 2*x13*x143 + x13*x90 + x132*x8 + x134*x16 + x138*x141 + x139*x141 + x140*x141 + 2*x142*x9 + 2*x144*x17 + x161*x77 + x162*x81 + x163*x85 + x17*x92 + x74*(x190 + 2*x33) + x79*(x190 + 2*x35) + x83*(x190 + 2*x37) + x87*x9 + x87 + x90 + x92) + x1*x148 - x101*x173 + x105*x108*x175 - x105*x114*x186 - x105*x188*x189 + x106*x183*x184 + x109*x173*x182 + x11*x149 + x110*x185 + x115*x181*(2*x176 + 2*x177 + 2*x178) - 18*x116*x99 + x118*x189 - x119*x173*x187 - x122 + x13*x28 - x131 + x132*x153 + x133*x155 + x134*x156 + 6*x135*x40 + 6*x136*x44 + 6*x137*x47 - x145*x183*x188 - x145*x186*x95 - x147 + x15*x150 - x151*x187*x94 + 3*x157*x24 + 3*x158*x27 + 3*x159*x30 + x160*x74*x75 + x160*x79*x80 + x160*x83*x84 + x161*x43 + x161*x61*x89 + x162*x46 + x162*x66*x91 + x163*x49 + x163*x71*x93 + x164*x63 + x165*x50 + x166*x68 + x167*x55 + x168*x73 + x169*x57 + x17*x31 + x170*x78 + x171*x82 + x172*x86 - x174*x179*(3*x176 + 3*x177 + 3*x178) - x174*x96*(-3*x148 - 3*x149 - 3*x150)/((x97)*(x97)*(x97)*(x97)) + x175*x182*x94 + x179*x180*x181 + x180*x184*x95*x98 + x25*x9 + x25 + x28 + x31 + x74*(x154 + 3*x54) + x79*(x154 + 3*x56) + x83*(x154 + 3*x58)) + n1*x151*(-t*x122 - t*x131 - t*x147 + t*x25 + t*x28 + t*x31 + x1*x10 - x101*x94 + x105*x110 + x11*x14 + x114*x118 + x15*x18 + x24*x43 + x27*x46 + x30*x49 + x50*x53 + x52*x63 + x52*x68 + x52*x73 + x55*x65 + x57*x70 + x74*x78 + x79*x82 + x83*x86 + x87*x89 + x90*x91 + x92*x93);
        break;

    default:
        break;
    }
        return result;
}
static void coder_dparam_dgdn(double T, double P, double n[3], int index, double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = n1*x0;
    double x2 = (*endmember[1].mu0)(T, P);
    double x3 = n1*x2;
    double x4 = (*endmember[2].mu0)(T, P);
    double x5 = n1*x4;
    double x6 = LAbsMax(3, x1, x3, x5, x1, x3, x5);
    double x7 = -x6;
    double x8 = x1 + x7;
    double x9 = t*x8;
    double x10 = exp(x9);
    double x11 = x3 + x7;
    double x12 = t*x11;
    double x13 = exp(x12);
    double x14 = x5 + x7;
    double x15 = t*x14;
    double x16 = exp(x15);
    double x17 = x10 + x13 + x16;
    double x18 = 1.0/x17;
    double x19 = x0*x10;
    double x20 = x13*x2;
    double x21 = x16*x4;
    double x22 = x11*x20 + x14*x21 + x19*x8;
    double x23 = -x10*x8 - x11*x13 - x14*x16;
    double x24 = pow(x17, -2);
    double x25 = x19 + x20 + x21;
    double x26 = x24*x25;
    double x27 = LAbsMax(3, x0, x2, x4, x1, x3, x5);
    double x28 = -x27;
    double x29 = x0 + x28;
    double x30 = x19*x29;
    double x31 = x2 + x28;
    double x32 = x20*x31;
    double x33 = x28 + x4;
    double x34 = x21*x33;
    double x35 = n1*x24;
    double x36 = t*x10*x29;
    double x37 = t*x13*x31;
    double x38 = t*x16*x33;

    switch (index) {
    case 0:
    result[0] = n1*x18*(x12*x32 + x15*x34 + x30*x9 + x30 + x32 + x34) + n1*x26*(x10*(-x0 + x27) + x13*(-x2 + x27) + x16*(x27 - x4) + x36*(-x1 + x6) + x37*(-x3 + x6) + x38*(-x5 + x6)) + n1*x23*x25*(-2*x36 - 2*x37 - 2*x38)/((x17)*(x17)*(x17)) + x18*x22 + x22*x35*(-x36 - x37 - x38) + x23*x26 + x23*x35*(t*x30 + t*x32 + t*x34);
result[1] = 0;
result[2] = 0;
        break;
    default:
        break;
    }
}

static int coder_get_param_number(void) {
    return 1;
}

static const char *paramNames[1] = {"t"};
static const char *paramUnits[1] = {"'None'"};

static const char **coder_get_param_names(void) {
    return paramNames;
}

static const char **coder_get_param_units(void) {
    return paramUnits;
}

static void coder_get_param_values(double **values) {
    (*values)[0] = t;

}

static int coder_set_param_values(double *values) {
    t = values[0];

    return 1;
}

static double coder_get_param_value(int index) {
    double result = 0.0;
    switch (index) {
    case 0:
        result = t;
        break;

    default:
        break;
    }
    return result;
}

static int coder_set_param_value(int index, double value) {
    int result = 1;
    switch (index) {
    case 0:
        t = value;
        break;

    default:
        result = 0;
        break;
    }
    return result;
}

