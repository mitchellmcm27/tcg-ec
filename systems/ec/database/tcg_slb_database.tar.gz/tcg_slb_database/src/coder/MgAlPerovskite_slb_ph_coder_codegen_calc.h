#include <math.h>


static double coder_g(double T, double P, double n[2]) {
    double n1 = n[0];
    double n2 = n[1];
    double result;
    
    double x0 = 1.0*n1 + 0.39000000000000001*n2;
    double x1 = 1.0/(n1 + n2);

result = (65093.525179856115*n1*n2 + x0*(16.628925236306479*T*(n1*log(n1*x1) + n2*log(n2*x1)) + n1*(*endmember[0].mu0)(T, P) + n2*(*endmember[1].mu0)(T, P)))/x0;
    return result;
}
        
static void coder_dgdn(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];

    double x0 = 1.0*n1;
    double x1 = 0.39000000000000001*n2;
    double x2 = x0 + x1;
    double x3 = 65093.525179856115*n2;
    double x4 = (*endmember[0].mu0)(T, P);
    double x5 = n1*x4;
    double x6 = (*endmember[1].mu0)(T, P);
    double x7 = n2*x6;
    double x8 = n1 + n2;
    double x9 = 1.0/x8;
    double x10 = n1*x9;
    double x11 = log(x10);
    double x12 = n2*x9;
    double x13 = log(x12);
    double x14 = n1*x11 + n2*x13;
    double x15 = 16.628925236306479*T;
    double x16 = x14*x15;
    double x17 = (n1*x3 + x2*(x16 + x5 + x7))/((x2)*(x2));
    double x18 = 1.0/x2;
    double x19 = pow(x8, -2);

result[0] = -1.0*x17 + x18*(x0*x4 + x16 + x2*(x15*(x11 - x12 + x8*(-n1*x19 + x9)) + x4) + x3 + 1.0*x7);
result[1] = -0.39000000000000001*x17 + x18*(6.4852808421595274*T*x14 + 65093.525179856115*n1 + x1*x6 + x2*(x15*(-x10 + x13 + x8*(-n2*x19 + x9)) + x6) + 0.39000000000000001*x5);
}
        
static void coder_d2gdn2(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];

    double x0 = 1.0*n1;
    double x1 = 0.39000000000000001*n2;
    double x2 = x0 + x1;
    double x3 = 65093.525179856115*n2;
    double x4 = (*endmember[0].mu0)(T, P);
    double x5 = n1*x4;
    double x6 = (*endmember[1].mu0)(T, P);
    double x7 = n2*x6;
    double x8 = n1 + n2;
    double x9 = 1.0/x8;
    double x10 = n1*x9;
    double x11 = log(x10);
    double x12 = n2*x9;
    double x13 = log(x12);
    double x14 = n1*x11 + n2*x13;
    double x15 = 16.628925236306479*T;
    double x16 = x14*x15;
    double x17 = (n1*x3 + x2*(x16 + x5 + x7))/((x2)*(x2)*(x2));
    double x18 = pow(x2, -2);
    double x19 = pow(x8, -2);
    double x20 = n1*x19;
    double x21 = -x20;
    double x22 = x21 + x9;
    double x23 = x22*x8;
    double x24 = T*(x11 - x12 + x23);
    double x25 = x18*(x0*x4 + x16 + x2*(16.628925236306479*x24 + x4) + x3 + 1.0*x7);
    double x26 = 1.0/x2;
    double x27 = n2*x19;
    double x28 = -2*x19;
    double x29 = 2/((x8)*(x8)*(x8));
    double x30 = n1*x29;
    double x31 = x15*x2;
    double x32 = -x27 + x9;
    double x33 = x32*x8;
    double x34 = -x10 + x13 + x33;
    double x35 = x15*x34;
    double x36 = x18*(6.4852808421595274*T*x14 + 65093.525179856115*n1 + x1*x6 + x2*(x35 + x6) + 0.39000000000000001*x5);

result[0] = 2.0*x17 - 2.0*x25 + x26*(33.257850472612958*x24 + x31*(x22 + x27 + x8*(x28 + x30) + x23/n1) + 2.0*x4);
result[1] = 0.78000000000000003*x17 - 0.39000000000000001*x25 + x26*(6.4852808421595274*x24 + x31*(x21 + x27 + x8*(-x19 + x30) - x9) + x35 + 0.39000000000000001*x4 + 1.0*x6 + 65093.525179856115) - 1.0*x36;
result[2] = 0.30420000000000003*x17 + x26*(12.970561684319055*T*x34 + x31*(x20 + x32 + x8*(n2*x29 + x28) + x33/n2) + 0.78000000000000003*x6) - 0.78000000000000003*x36;
}
        
static void coder_d3gdn3(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];

    double x0 = 1.0*n1;
    double x1 = 0.39000000000000001*n2;
    double x2 = x0 + x1;
    double x3 = 65093.525179856115*n2;
    double x4 = (*endmember[0].mu0)(T, P);
    double x5 = n1*x4;
    double x6 = (*endmember[1].mu0)(T, P);
    double x7 = n2*x6;
    double x8 = n1 + n2;
    double x9 = 1.0/x8;
    double x10 = n1*x9;
    double x11 = log(x10);
    double x12 = n2*x9;
    double x13 = log(x12);
    double x14 = n1*x11 + n2*x13;
    double x15 = 16.628925236306479*T;
    double x16 = x14*x15;
    double x17 = (n1*x3 + x2*(x16 + x5 + x7))/((x2)*(x2)*(x2)*(x2));
    double x18 = pow(x2, -3);
    double x19 = pow(x8, -2);
    double x20 = n1*x19;
    double x21 = -x20;
    double x22 = x21 + x9;
    double x23 = x22*x8;
    double x24 = x11 - x12 + x23;
    double x25 = x18*(x0*x4 + x16 + x2*(x15*x24 + x4) + x3 + 1.0*x7);
    double x26 = pow(x2, -2);
    double x27 = 33.257850472612958*T;
    double x28 = n2*x19;
    double x29 = -2*x19;
    double x30 = pow(x8, -3);
    double x31 = 2*x30;
    double x32 = n1*x31;
    double x33 = x8*(x29 + x32);
    double x34 = 1.0/n1;
    double x35 = x22*x34;
    double x36 = T*(x22 + x28 + x33 + x35*x8);
    double x37 = x26*(16.628925236306479*x2*x36 + x24*x27 + 2.0*x4);
    double x38 = 1.0/x2;
    double x39 = -4*x19;
    double x40 = 6*x30;
    double x41 = 6/((x8)*(x8)*(x8)*(x8));
    double x42 = -n1*x41;
    double x43 = n2*x31;
    double x44 = 4*x30;
    double x45 = n1*x44 - x43;
    double x46 = x35 + x45;
    double x47 = x15*x2;
    double x48 = 6.4852808421595274*T;
    double x49 = -x28 + x9;
    double x50 = x49*x8;
    double x51 = -x10 + x13 + x50;
    double x52 = x15*x51;
    double x53 = x18*(65093.525179856115*n1 + x1*x6 + x14*x48 + x2*(x52 + x6) + 0.39000000000000001*x5);
    double x54 = x8*(-x19 + x32);
    double x55 = x21 + x28 + x54 - x9;
    double x56 = x26*(x24*x48 + 0.39000000000000001*x4 + x47*x55 + x52 + 1.0*x6 + 65093.525179856115);
    double x57 = 12.970561684319055*T;
    double x58 = x8*(x29 + x43);
    double x59 = 1.0/n2;
    double x60 = x20 + x49 + x50*x59 + x58;
    double x61 = x15*x60;
    double x62 = x26*(x2*x61 + x51*x57 + 0.78000000000000003*x6);

result[0] = -6.0*x17 + 6.0*x25 - 3.0*x37 + x38*(49.886775708919437*x36 + x47*(x33*x34 + x39 + x46 + x8*(x40 + x42) - x23/((n1)*(n1))));
result[1] = -2.3399999999999999*x17 + 1.5600000000000001*x25 - 0.39000000000000001*x37 + x38*(x27*x55 + 6.4852808421595274*x36 + x47*(x29 + x34*x54 + x46 + x8*(x42 + x44))) + 2.0*x53 - 2.0*x56;
result[2] = -0.91259999999999997*x17 + 0.30420000000000003*x25 + x38*(x47*(x19 + x45 + x8*(x31 + x42)) + x55*x57 + x61) + 1.5600000000000001*x53 - 0.78000000000000003*x56 - 1.0*x62;
result[3] = -0.35591400000000001*x17 + x38*(19.455842526478584*T*x60 + x47*(n2*x44 - x32 + x39 + x49*x59 + x58*x59 + x8*(-n2*x41 + x40) - x50/((n2)*(n2)))) + 0.91260000000000008*x53 - 1.1699999999999999*x62;
}
        
static double coder_dgdt(double T, double P, double n[2]) {
    double n1 = n[0];
    double n2 = n[1];
    double result;
    
    double x0 = 1.0/(n1 + n2);

result = 16.628925236306479*n1*log(n1*x0) + n1*(*endmember[0].dmu0dT)(T, P) + 16.628925236306479*n2*log(n2*x0) + n2*(*endmember[1].dmu0dT)(T, P);
    return result;
}
        
static void coder_d2gdndt(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];

    double x0 = n1 + n2;
    double x1 = 1.0/x0;
    double x2 = n2*x1;
    double x3 = n1*x1;
    double x4 = pow(x0, -2);
    double x5 = 16.628925236306479*x0;

result[0] = -16.628925236306479*x2 + x5*(-n1*x4 + x1) + 16.628925236306479*log(x3) + (*endmember[0].dmu0dT)(T, P);
result[1] = -16.628925236306479*x3 + x5*(-n2*x4 + x1) + 16.628925236306479*log(x2) + (*endmember[1].dmu0dT)(T, P);
}
        
static void coder_d3gdn2dt(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];

    double x0 = n1 + n2;
    double x1 = 1.0/x0;
    double x2 = 16.628925236306479*x1;
    double x3 = 16.628925236306479*n1;
    double x4 = 16.628925236306479*n2;
    double x5 = x3 + x4;
    double x6 = pow(x0, -2);
    double x7 = -2*x6;
    double x8 = 2/((x0)*(x0)*(x0));
    double x9 = n1*x8;
    double x10 = 16.628925236306479*x0;
    double x11 = x4*x6;
    double x12 = x3*x6;
    double x13 = x11 - x12;

result[0] = x13 + x2 + x5*(x7 + x9) + x10*(-n1*x6 + x1)/n1;
result[1] = x13 - x2 + x5*(-x6 + x9);
result[2] = -x11 + x12 + x2 + x5*(n2*x8 + x7) + x10*(-n2*x6 + x1)/n2;
}
        
static void coder_d4gdn3dt(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];

    double x0 = n1 + n2;
    double x1 = pow(x0, -2);
    double x2 = -66.515700945225916*x1;
    double x3 = 16.628925236306479*n1 + 16.628925236306479*n2;
    double x4 = pow(x0, -3);
    double x5 = 6*x4;
    double x6 = 6/((x0)*(x0)*(x0)*(x0));
    double x7 = -n1*x6;
    double x8 = -2*x1;
    double x9 = 2*x4;
    double x10 = n1*x9;
    double x11 = 16.628925236306479/n1;
    double x12 = x0*x11;
    double x13 = 1.0/x0;
    double x14 = -n1*x1 + x13;
    double x15 = 16.628925236306479*x0;
    double x16 = 66.515700945225916*x4;
    double x17 = 33.257850472612958*x4;
    double x18 = n1*x16 - n2*x17;
    double x19 = x11*x14 + x18;
    double x20 = -n2*x1 + x13;
    double x21 = 16.628925236306479/n2;

result[0] = x12*(x10 + x8) + x19 + x2 + x3*(x5 + x7) - x14*x15/((n1)*(n1));
result[1] = -33.257850472612958*x1 + x12*(-x1 + x10) + x19 + x3*(4*x4 + x7);
result[2] = 16.628925236306479*x1 + x18 + x3*(x7 + x9);
result[3] = -n1*x17 + n2*x16 + x0*x21*(n2*x9 + x8) + x2 + x20*x21 + x3*(-n2*x6 + x5) - x15*x20/((n2)*(n2));
}
        
static double coder_dgdp(double T, double P, double n[2]) {
    double n1 = n[0];
    double n2 = n[1];
    double result;
    

result = n1*(*endmember[0].dmu0dP)(T, P) + n2*(*endmember[1].dmu0dP)(T, P);
    return result;
}
        
static void coder_d2gdndp(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = (*endmember[0].dmu0dP)(T, P);
result[1] = (*endmember[1].dmu0dP)(T, P);
}
        
static void coder_d3gdn2dp(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
}
        
static void coder_d4gdn3dp(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
}
        
static double coder_d2gdt2(double T, double P, double n[2]) {
    double n1 = n[0];
    double n2 = n[1];
    double result;
    

result = n1*(*endmember[0].d2mu0dT2)(T, P) + n2*(*endmember[1].d2mu0dT2)(T, P);
    return result;
}
        
static void coder_d3gdndt2(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = (*endmember[0].d2mu0dT2)(T, P);
result[1] = (*endmember[1].d2mu0dT2)(T, P);
}
        
static void coder_d4gdn2dt2(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
}
        
static void coder_d5gdn3dt2(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
}
        
static double coder_d2gdtdp(double T, double P, double n[2]) {
    double n1 = n[0];
    double n2 = n[1];
    double result;
    

result = n1*(*endmember[0].d2mu0dTdP)(T, P) + n2*(*endmember[1].d2mu0dTdP)(T, P);
    return result;
}
        
static void coder_d3gdndtdp(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = (*endmember[0].d2mu0dTdP)(T, P);
result[1] = (*endmember[1].d2mu0dTdP)(T, P);
}
        
static void coder_d4gdn2dtdp(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
}
        
static void coder_d5gdn3dtdp(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
}
        
static double coder_d2gdp2(double T, double P, double n[2]) {
    double n1 = n[0];
    double n2 = n[1];
    double result;
    

result = n1*(*endmember[0].d2mu0dP2)(T, P) + n2*(*endmember[1].d2mu0dP2)(T, P);
    return result;
}
        
static void coder_d3gdndp2(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = (*endmember[0].d2mu0dP2)(T, P);
result[1] = (*endmember[1].d2mu0dP2)(T, P);
}
        
static void coder_d4gdn2dp2(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
}
        
static void coder_d5gdn3dp2(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
}
        
static double coder_d3gdt3(double T, double P, double n[2]) {
    double n1 = n[0];
    double n2 = n[1];
    double result;
    

result = n1*(*endmember[0].d3mu0dT3)(T, P) + n2*(*endmember[1].d3mu0dT3)(T, P);
    return result;
}
        
static void coder_d4gdndt3(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = (*endmember[0].d3mu0dT3)(T, P);
result[1] = (*endmember[1].d3mu0dT3)(T, P);
}
        
static void coder_d5gdn2dt3(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
}
        
static void coder_d6gdn3dt3(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
}
        
static double coder_d3gdt2dp(double T, double P, double n[2]) {
    double n1 = n[0];
    double n2 = n[1];
    double result;
    

result = n1*(*endmember[0].d3mu0dT2dP)(T, P) + n2*(*endmember[1].d3mu0dT2dP)(T, P);
    return result;
}
        
static void coder_d4gdndt2dp(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = (*endmember[0].d3mu0dT2dP)(T, P);
result[1] = (*endmember[1].d3mu0dT2dP)(T, P);
}
        
static void coder_d5gdn2dt2dp(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
}
        
static void coder_d6gdn3dt2dp(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
}
        
static double coder_d3gdtdp2(double T, double P, double n[2]) {
    double n1 = n[0];
    double n2 = n[1];
    double result;
    

result = n1*(*endmember[0].d3mu0dTdP2)(T, P) + n2*(*endmember[1].d3mu0dTdP2)(T, P);
    return result;
}
        
static void coder_d4gdndtdp2(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = (*endmember[0].d3mu0dTdP2)(T, P);
result[1] = (*endmember[1].d3mu0dTdP2)(T, P);
}
        
static void coder_d5gdn2dtdp2(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
}
        
static void coder_d6gdn3dtdp2(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
}
        
static double coder_d3gdp3(double T, double P, double n[2]) {
    double n1 = n[0];
    double n2 = n[1];
    double result;
    

result = n1*(*endmember[0].d3mu0dP3)(T, P) + n2*(*endmember[1].d3mu0dP3)(T, P);
    return result;
}
        
static void coder_d4gdndp3(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = (*endmember[0].d3mu0dP3)(T, P);
result[1] = (*endmember[1].d3mu0dP3)(T, P);
}
        
static void coder_d5gdn2dp3(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
}
        
static void coder_d6gdn3dp3(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
}
        
static double coder_s(double T, double P, double n[2]) {
    double result = -coder_dgdt(T, P, n);
    return result;
}

static double coder_v(double T, double P, double n[2]) {
    double result = coder_dgdp(T, P, n);
    return result;
}

static double coder_cv(double T, double P, double n[2]) {
    double result = -T*coder_d2gdt2(T, P, n);
    double dvdt = coder_d2gdtdp(T, P, n);
    double dvdp = coder_d2gdp2(T, P, n);
    result += T*dvdt*dvdt/dvdp;
    return result;
}

static double coder_cp(double T, double P, double n[2]) {
    double result = -T*coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdt(double T, double P, double n[2]) {
    double result = -T*coder_d3gdt3(T, P, n) - coder_d2gdt2(T, P, n);
    return result;
}

static double coder_alpha(double T, double P, double n[2]) {
    double result = coder_d2gdtdp(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_beta(double T, double P, double n[2]) {
    double result = -coder_d2gdp2(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_K(double T, double P, double n[2]) {
    double result = -coder_dgdp(T, P, n)/coder_d2gdp2(T, P, n);
    return result;
}

static double coder_Kp(double T, double P, double n[2]) {
    double result = coder_dgdp(T, P, n);
    result *= coder_d3gdp3(T, P, n);
    result /= pow(coder_d2gdp2(T, P, n), 2.0);
    return result - 1.0;
}

