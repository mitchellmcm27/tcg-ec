#include <math.h>


static double coder_g(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = n1 + n2;
    double x1 = n3 + x0;
    double x2 = 1.0/x1;
    double x3 = 1.0*n2;
    double x4 = log(n3*x2);
    double x5 = 1.0*n3;
    double x6 = n1 + n3;

result = 1.0*x2*(48000.0*n2*n3 + 1.0*x1*(8.3144626181532395*T*(1.0*x0*log(x0*x2) + x3*log(n2*x2) + x4*x5 + x5*(x4 - 0.69314718055994495) + 1.0*x6*log(x2*x6) + (2.0*n1 + 2.0*n2 + x5)*log(x2*(1.0*n1 + 0.5*n3 + x3))) + n1*(*endmember[0].mu0)(T, P) + n2*(*endmember[1].mu0)(T, P) + n3*(*endmember[2].mu0)(T, P)));
    return result;
}
        
static void coder_dgdn(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = n1 + n2;
    double x1 = n3 + x0;
    double x2 = pow(x1, -2);
    double x3 = 48000.0*n3;
    double x4 = (*endmember[0].mu0)(T, P);
    double x5 = (*endmember[1].mu0)(T, P);
    double x6 = (*endmember[2].mu0)(T, P);
    double x7 = 1.0/x1;
    double x8 = log(n2*x7);
    double x9 = 1.0*n2;
    double x10 = n3*x7;
    double x11 = log(x10);
    double x12 = 1.0*n3;
    double x13 = 1.0*log(x0*x7);
    double x14 = n1 + n3;
    double x15 = 1.0*log(x14*x7);
    double x16 = 2.0*n1 + 2.0*n2 + x12;
    double x17 = 1.0*n1;
    double x18 = x17 + x9;
    double x19 = 0.5*n3 + x18;
    double x20 = log(x19*x7);
    double x21 = 8.3144626181532395*T;
    double x22 = x21*(x0*x13 + x11*x12 + x12*(x11 - 0.69314718055994495) + x14*x15 + x16*x20 + x8*x9);
    double x23 = 1.0*x1;
    double x24 = -1.0*x2*(n2*x3 + x23*(n1*x4 + n2*x5 + n3*x6 + x22));
    double x25 = x12 + x18;
    double x26 = x12 + x17;
    double x27 = x1*x26*(-x14*x2 + x7)/x14 + x15 - x7*x9;
    double x28 = 1.0*x7;
    double x29 = -x19*x2;
    double x30 = x1*x16/x19;
    double x31 = -2.0*x10 + x13 + 2.0*x20 + x30*(x28 + x29) + x1*x18*(-x0*x2 + x7)/x0;
    double x32 = x12*x6 + x17*x4 + x22 + x5*x9;

result[0] = x24 + x28*(x25*(x21*(x27 + x31) + x4) + x32);
result[1] = x24 + x28*(x25*(x21*(x23*(-n2*x2 + x7) - x26*x7 + x31 + 1.0*x8) + x5) + x3 + x32);
result[2] = x24 + x28*(48000.0*n2 + x25*(x21*(2.0*x1*(-n3*x2 + x7) + 2.0*x11 - x18*x7 + 1.0*x20 + x27 + x30*(x29 + 0.5*x7) - 0.69314718055994495) + x6) + x32);
}
        
static void coder_d2gdn2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = n1 + n2;
    double x1 = n3 + x0;
    double x2 = pow(x1, -3);
    double x3 = 48000.0*n3;
    double x4 = (*endmember[0].mu0)(T, P);
    double x5 = (*endmember[1].mu0)(T, P);
    double x6 = (*endmember[2].mu0)(T, P);
    double x7 = 1.0/x1;
    double x8 = log(n2*x7);
    double x9 = 1.0*n2;
    double x10 = n3*x7;
    double x11 = log(x10);
    double x12 = 1.0*n3;
    double x13 = 1.0*log(x0*x7);
    double x14 = n1 + n3;
    double x15 = 1.0*log(x14*x7);
    double x16 = 2.0*n2;
    double x17 = 2.0*n1 + x12 + x16;
    double x18 = 1.0*n1;
    double x19 = x18 + x9;
    double x20 = 0.5*n3 + x19;
    double x21 = log(x20*x7);
    double x22 = 8.3144626181532395*T;
    double x23 = x22*(x0*x13 + x11*x12 + x12*(x11 - 0.69314718055994495) + x14*x15 + x17*x21 + x8*x9);
    double x24 = 1.0*x1;
    double x25 = 2.0*x2*(n2*x3 + x24*(n1*x4 + n2*x5 + n3*x6 + x23));
    double x26 = x12 + x19;
    double x27 = x12 + x18;
    double x28 = 1.0/x14;
    double x29 = pow(x1, -2);
    double x30 = -x14*x29 + x7;
    double x31 = x28*x30;
    double x32 = x27*x31;
    double x33 = x1*x32 + x15 - x7*x9;
    double x34 = 1.0/x0;
    double x35 = -x0*x29 + x7;
    double x36 = x34*x35;
    double x37 = x19*x36;
    double x38 = 1.0*x7;
    double x39 = -x20*x29;
    double x40 = x38 + x39;
    double x41 = 1.0/x20;
    double x42 = x17*x41;
    double x43 = x40*x42;
    double x44 = x1*x37 + x1*x43 - 2.0*x10 + x13 + 2.0*x21;
    double x45 = T*(x33 + x44);
    double x46 = 8.3144626181532395*x45;
    double x47 = x12*x6 + x18*x4 + x23 + x5*x9;
    double x48 = x26*(x4 + x46) + x47;
    double x49 = 2.0*x29;
    double x50 = n3*x49;
    double x51 = x37 + x43 + x50;
    double x52 = x29*x9;
    double x53 = x32 + x52;
    double x54 = x51 + x53;
    double x55 = 2.0*x1;
    double x56 = x40*x41;
    double x57 = -2*x29;
    double x58 = 2*x2;
    double x59 = x1*x19;
    double x60 = x34*x59;
    double x61 = -x49;
    double x62 = x20*x58;
    double x63 = x1*x42;
    double x64 = x17/((x20)*(x20));
    double x65 = x40*x64;
    double x66 = 4.0*x1*x56 - x24*x65 + x36*x55 + x60*(x0*x58 + x57) + x63*(x61 + x62) - x35*x59/((x0)*(x0));
    double x67 = x54 + x66;
    double x68 = x1*x27;
    double x69 = x28*x68;
    double x70 = x31*x55 + x69*(x14*x58 + x57) - x30*x68/((x14)*(x14));
    double x71 = x22*x26;
    double x72 = 2.0*x7;
    double x73 = -x29;
    double x74 = -n1;
    double x75 = 1.0*x4 + x46;
    double x76 = x24*(-n2*x29 + x7);
    double x77 = -x27*x7 + x44 + x76 + 1.0*x8;
    double x78 = x22*x77;
    double x79 = 1.0*x5 + x78;
    double x80 = x26*(x5 + x78) + x3 + x47;
    double x81 = 1.0*x29;
    double x82 = -x80*x81;
    double x83 = x25 - x48*x81;
    double x84 = x39 + 0.5*x7;
    double x85 = x41*x55*x84;
    double x86 = 0.5*x1;
    double x87 = x24*x56 + x60*(-x58*(-n2 + x74) + x73) + x63*(-1.5*x29 + x62) - x65*x86 + x85;
    double x88 = x55*(-n3*x29 + x7);
    double x89 = x42*x84;
    double x90 = x1*x89 + 2.0*x11 - x19*x7 + 1.0*x21 + x33 + x88 - 0.69314718055994495;
    double x91 = x22*x90;
    double x92 = 1.0*x6 + x91;
    double x93 = 48000.0*n2 + x26*(x6 + x91) + x47;
    double x94 = -x81*x93;
    double x95 = 16.628925236306479*T;
    double x96 = x16*x2;
    double x97 = -x18;
    double x98 = x51 - x52;
    double x99 = -x81;

result[0] = x25 + x38*(2.0*x4 + 16.628925236306479*x45 + x71*(x67 + x70)) - x48*x49;
result[1] = x38*(x71*(x67 + x69*(-x58*(-n3 + x74) + x73) - x72) + x75 + x79) + x82 + x83;
result[2] = x38*(x71*(x54 - 3.0*x7 + x70 + x87) + x75 + x92) + x83 + x94;
result[3] = x25 + x38*(2.0*x5 + x71*(x1*(x61 + x96) - x29*(-x12 + x97) + x38 + x66 + x98 + x76/n2) + x77*x95) - x49*x80;
result[4] = x25 + x38*(x71*(x1*(x96 + x99) + x27*x29 - 4.0*x7 + x87 + x98) + x79 + x92 + 48000.0) + x82 + x94;
result[5] = x25 + x38*(2.0*x6 + x71*(x1*(4.0*n3*x2 - 4.0*x29) - x29*(-x9 + x97) - x50 + x53 + x63*(x62 + x99) - x64*x84*x86 + x70 + x72 + x85 + x89 + x88/n3) + x90*x95) - x49*x93;
}
        
static void coder_d3gdn3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = 48000.0*n3;
    double x1 = (*endmember[0].mu0)(T, P);
    double x2 = (*endmember[1].mu0)(T, P);
    double x3 = (*endmember[2].mu0)(T, P);
    double x4 = n1 + n2;
    double x5 = n3 + x4;
    double x6 = 1.0/x5;
    double x7 = log(n2*x6);
    double x8 = 1.0*n2;
    double x9 = n3*x6;
    double x10 = log(x9);
    double x11 = 1.0*n3;
    double x12 = 1.0*log(x4*x6);
    double x13 = n1 + n3;
    double x14 = 1.0*log(x13*x6);
    double x15 = 2.0*n2;
    double x16 = 2.0*n1 + x11 + x15;
    double x17 = 1.0*n1;
    double x18 = x17 + x8;
    double x19 = 0.5*n3 + x18;
    double x20 = log(x19*x6);
    double x21 = 8.3144626181532395*T;
    double x22 = x21*(x10*x11 + x11*(x10 - 0.69314718055994495) + x12*x4 + x13*x14 + x16*x20 + x7*x8);
    double x23 = 1.0*x5;
    double x24 = pow(x5, -4);
    double x25 = 6.0*x24;
    double x26 = -x25*(n2*x0 + x23*(n1*x1 + n2*x2 + n3*x3 + x22));
    double x27 = x11 + x18;
    double x28 = x11 + x17;
    double x29 = 1.0/x13;
    double x30 = pow(x5, -2);
    double x31 = -x13*x30 + x6;
    double x32 = x29*x31;
    double x33 = x28*x32;
    double x34 = x14 + x33*x5 - x6*x8;
    double x35 = 1.0/x4;
    double x36 = -x30*x4 + x6;
    double x37 = x35*x36;
    double x38 = x18*x37;
    double x39 = 1.0/x19;
    double x40 = 1.0*x6;
    double x41 = -x19*x30;
    double x42 = x40 + x41;
    double x43 = x39*x42;
    double x44 = x16*x43;
    double x45 = x12 + 2.0*x20 + x38*x5 + x44*x5 - 2.0*x9;
    double x46 = x34 + x45;
    double x47 = x21*x46;
    double x48 = x1*x17 + x11*x3 + x2*x8 + x22;
    double x49 = x27*(x1 + x47) + x48;
    double x50 = pow(x5, -3);
    double x51 = 6.0*x50;
    double x52 = 16.628925236306479*T;
    double x53 = 2.0*x30;
    double x54 = n3*x53;
    double x55 = x38 + x44 + x54;
    double x56 = x30*x8;
    double x57 = x33 + x56;
    double x58 = x55 + x57;
    double x59 = 2.0*x37;
    double x60 = 4.0*x5;
    double x61 = -2*x30;
    double x62 = 2*x50;
    double x63 = x4*x62 + x61;
    double x64 = x18*x35;
    double x65 = x63*x64;
    double x66 = -x53;
    double x67 = x19*x62;
    double x68 = x66 + x67;
    double x69 = x16*x39;
    double x70 = x68*x69;
    double x71 = pow(x4, -2);
    double x72 = x36*x71;
    double x73 = x18*x72;
    double x74 = pow(x19, -2);
    double x75 = x42*x74;
    double x76 = x16*x75;
    double x77 = -x23*x76 + x43*x60 + x5*x59 + x5*x65 + x5*x70 - x5*x73;
    double x78 = x58 + x77;
    double x79 = 2.0*x32;
    double x80 = x13*x62 + x61;
    double x81 = x28*x29;
    double x82 = x80*x81;
    double x83 = pow(x13, -2);
    double x84 = x31*x83;
    double x85 = x28*x84;
    double x86 = x5*x79 + x5*x82 - x5*x85;
    double x87 = T*(x78 + x86);
    double x88 = 8.3144626181532395*x87;
    double x89 = 2.0*x1 + x27*x88 + x46*x52;
    double x90 = 3.0*x30;
    double x91 = x15*x50;
    double x92 = -x91;
    double x93 = 4.0*x50;
    double x94 = n3*x93;
    double x95 = -x94;
    double x96 = 3.0*x5;
    double x97 = 6.0*x5;
    double x98 = x39*x68;
    double x99 = 6*x50;
    double x100 = 6*x24;
    double x101 = x5*x64;
    double x102 = -x100*x19;
    double x103 = x5*x69;
    double x104 = x18*x71;
    double x105 = 2*x5;
    double x106 = 2.0*x5;
    double x107 = x106*x16;
    double x108 = pow(x19, -3);
    double x109 = x108*x42;
    double x110 = x68*x74;
    double x111 = x101*(-x100*x4 + x99) + x103*(x102 + x51) - x104*x105*x63 + x105*x18*x36/((x4)*(x4)*(x4)) + x107*x109 - x107*x110 + x35*x63*x96 + 3.0*x37 + 6.0*x43 + 2*x65 + 2*x70 - x72*x96 - 2*x73 - x75*x97 - 2.0*x76 + x95 + x97*x98;
    double x112 = x111 + x92;
    double x113 = x5*x81;
    double x114 = x28*x83;
    double x115 = -x105*x114*x80 + x105*x28*x31/((x13)*(x13)*(x13)) + x113*(-x100*x13 + x99) + x29*x80*x96 + 3.0*x32 + 2*x82 - x84*x96 - 2*x85;
    double x116 = x21*x27;
    double x117 = 2.0*x6;
    double x118 = -x30;
    double x119 = -n1;
    double x120 = -n3 + x119;
    double x121 = x118 - x120*x62;
    double x122 = x121*x81;
    double x123 = -x117 + x122*x5 + x78;
    double x124 = x123*x52;
    double x125 = 1.0*x30;
    double x126 = x121*x5;
    double x127 = 4*x50;
    double x128 = 2*n1;
    double x129 = 2*n3;
    double x130 = 3*x24;
    double x131 = -x130*(x128 + x129);
    double x132 = -x114*x126 + x122 + x82 - x85;
    double x133 = -n2*x30 + x6;
    double x134 = x133*x23;
    double x135 = x134 - x28*x6 + x45 + 1.0*x7;
    double x136 = x135*x21;
    double x137 = x0 + x27*(x136 + x2) + x48;
    double x138 = 2.0*x50;
    double x139 = x137*x138;
    double x140 = x123*x21;
    double x141 = 1.0*x1 + x47;
    double x142 = x136 + 1.0*x2;
    double x143 = x140*x27 + x141 + x142;
    double x144 = -x143*x53 + x26;
    double x145 = -x125*x89 + x49*x93;
    double x146 = x41 + 0.5*x6;
    double x147 = x146*x39;
    double x148 = 2.0*x147;
    double x149 = x148*x5;
    double x150 = x118 - x62*(-n2 + x119);
    double x151 = x150*x64;
    double x152 = -1.5*x30 + x67;
    double x153 = x152*x69;
    double x154 = 0.5*x5;
    double x155 = x149 + x151*x5 + x153*x5 - x154*x76 + x23*x43;
    double x156 = x155 + x58 - 3.0*x6 + x86;
    double x157 = x156*x52;
    double x158 = x115 + x92;
    double x159 = x150*x5;
    double x160 = x152*x39;
    double x161 = 2*n2;
    double x162 = -x130*(x128 + x161);
    double x163 = x16*x23;
    double x164 = x154*x16;
    double x165 = x163*x74;
    double x166 = -x152*x165 + x95;
    double x167 = x101*(x127 + x162) + x103*(x102 + 5.0*x50) - x104*x159 + x109*x163 - x110*x164 + x151 + x153 + 2.0*x159*x35 + x160*x60 + x166 + x23*x98 + 5.0*x43 + x59 + x65 + x70 - x73 - x75*x96 - 1.5*x76;
    double x168 = -2.0*n3*x30 + 2.0*x6;
    double x169 = x168*x5;
    double x170 = x146*x69;
    double x171 = 2.0*x10 + x169 + x170*x5 - x18*x6 + 1.0*x20 + x34 - 0.69314718055994495;
    double x172 = x171*x21;
    double x173 = 48000.0*n2 + x27*(x172 + x3) + x48;
    double x174 = x138*x173;
    double x175 = x156*x21;
    double x176 = x172 + 1.0*x3;
    double x177 = x141 + x175*x27 + x176;
    double x178 = -x177*x53 + x26;
    double x179 = -x17;
    double x180 = -x11 + x179;
    double x181 = 1.0/n2;
    double x182 = x55 - x56;
    double x183 = x134*x181 - x180*x30 + x182 + x40 + x5*(x66 + x91) + x77;
    double x184 = x183*x21;
    double x185 = x138*x49;
    double x186 = x135*x52 + x184*x27 + 2.0*x2;
    double x187 = -x125*x186 + x137*x93;
    double x188 = -x125;
    double x189 = x155 + x182 + x28*x30 + x5*(x188 + x91) - 4.0*x6;
    double x190 = x189*x21;
    double x191 = x142 + x176 + x190*x27 + 48000.0;
    double x192 = 4.0*x30;
    double x193 = -x192;
    double x194 = 1.0/n3;
    double x195 = x188 + x67;
    double x196 = x146*x74;
    double x197 = x16*x196;
    double x198 = x103*x195 + x117 + x149 - x154*x197 + x169*x194 + x170 - x30*(x179 - x8) + x5*(x193 + x94) - x54 + x57 + x86;
    double x199 = x198*x21;
    double x200 = x195*x39;
    double x201 = x101*(x162 + x62) + x103*(x102 + x93) + x106*x160 + x106*x200 + x109*x164 + x148 + 2*x151 + 2*x153 + x166 - x196*x23 - x23*x75 + 2.0*x43 - 1.0*x76;
    double x202 = x171*x52 + x199*x27 + 2.0*x3;
    double x203 = -x125*x202 + x173*x93;
    double x204 = 24.943387854459719*T;
    double x205 = -n2*x25;
    double x206 = 1.0*x133*x181;
    double x207 = x161*x50;
    double x208 = x181*x23;
    double x209 = n2*x93;
    double x210 = x209 - x28*x62;
    double x211 = x189*x52;
    double x212 = -x191*x53 + x26;

result[0] = x26 + x40*(x116*(x112 + x115) + 24.943387854459719*x87) + x49*x51 - x89*x90;
result[1] = x139 + x144 + x145 + x40*(x116*(x112 + x113*(x127 + x131) + x125 + 2.0*x126*x29 + x132 + x79) + x124 + x88);
result[2] = x145 + x174 + x178 + x40*(x116*(x158 + x167 + x53) + x157 + x88);
result[3] = x144 + x185 + x187 + x40*(x116*(x112 + x113*(x131 + x62) + 2*x122 + x90) + x124 + x184);
result[4] = -x125*x143 - x125*x177 - x125*x191 + x139 + x174 + x185 + x26 + x40*(x116*(x113*(x100*x120 + x127) + x121*x23*x29 + x132 + x167 + x192 + 1.0*x32 + x92) + x140 + x175 + x190);
result[5] = x178 + x185 + x203 + x40*(x116*(x158 + x201 + 5.0*x30) + x157 + x199);
result[6] = x137*x51 - x186*x90 + x26 + x40*(x116*(x111 + x193 + x206 + x208*(x207 + x61) + x210 + x5*(x205 + x51) - x134/((n2)*(n2))) + x183*x204);
result[7] = x174 + x187 + x212 + x40*(x116*(x167 + x180*x62 + x206 + x208*(x118 + x207) + x209 + x5*(x205 + x93)) + x184 + x211);
result[8] = x139 + x203 + x212 + x40*(x116*(x201 + x210 + 6.0*x30 + x5*(x138 + x205)) + x199 + x211);
result[9] = x173*x51 - x202*x90 + x26 + x40*(x116*(8.0*n3*x50 + x103*(x102 + 3.0*x50) + x106*x194*(x129*x50 + x61) + x108*x146*x164 + 3.0*x147 + x158 - x165*x195 + x168*x194 - x18*x62 + 2*x195*x69 - 1.5*x196*x5 - 1.0*x197 + x200*x96 - 8.0*x30 + x5*(-12.0*n3*x24 + 12.0*x50) - x169/((n3)*(n3))) + x198*x204);
}
        
static double coder_dgdt(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = n1 + n2;
    double x1 = 1.0/(n3 + x0);
    double x2 = 1.0*n3;
    double x3 = 1.0*n1 + 1.0*n2;
    double x4 = log(n3*x1);
    double x5 = 8.3144626181532395*n3;
    double x6 = n1 + n3;

result = 1.0*x1*(x2 + x3)*(n1*(*endmember[0].dmu0dT)(T, P) + 8.3144626181532395*n2*log(n2*x1) + n2*(*endmember[1].dmu0dT)(T, P) + n3*(*endmember[2].dmu0dT)(T, P) + 8.3144626181532395*x0*log(x0*x1) + x4*x5 + x5*(x4 - 0.69314718055994495) + 8.3144626181532395*x6*log(x1*x6) + 8.3144626181532395*(2.0*n1 + 2.0*n2 + x2)*log(x1*(0.5*n3 + x3)));
    return result;
}
        
static void coder_d2gdndt(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = (*endmember[0].dmu0dT)(T, P);
    double x1 = n1 + n3;
    double x2 = n1 + n2;
    double x3 = n3 + x2;
    double x4 = 1.0/x3;
    double x5 = 8.3144626181532395*log(x1*x4);
    double x6 = n2*x4;
    double x7 = 8.3144626181532395*n1;
    double x8 = 8.3144626181532395*n3;
    double x9 = x7 + x8;
    double x10 = pow(x3, -2);
    double x11 = x5 - 8.3144626181532395*x6 + x3*x9*(-x1*x10 + x4)/x1;
    double x12 = 8.3144626181532395*log(x2*x4);
    double x13 = 1.0*n1 + 1.0*n2;
    double x14 = 0.5*n3 + x13;
    double x15 = log(x14*x4);
    double x16 = n3*x4;
    double x17 = 8.3144626181532395*n2;
    double x18 = x17 + x7;
    double x19 = 1.0*x4;
    double x20 = -x10*x14;
    double x21 = x3*(16.628925236306479*n1 + 16.628925236306479*n2 + x8)/x14;
    double x22 = x12 + 16.628925236306479*x15 - 16.628925236306479*x16 + x18*x3*(-x10*x2 + x4)/x2 + x21*(x19 + x20);
    double x23 = 1.0*n3;
    double x24 = x13 + x23;
    double x25 = x19*x24;
    double x26 = (*endmember[1].dmu0dT)(T, P);
    double x27 = (*endmember[2].dmu0dT)(T, P);
    double x28 = log(x6);
    double x29 = log(x16);
    double x30 = 8.3144626181532395*x15;
    double x31 = n1*x0 + n2*x26 + n3*x27 + x1*x5 + x12*x2 + x17*x28 + x29*x8 + x30*(2.0*n1 + 2.0*n2 + x23) + x8*(x29 - 0.69314718055994495);
    double x32 = -1.0*x10*x24*x31 + x19*x31;

result[0] = x25*(x0 + x11 + x22) + x32;
result[1] = x25*(x22 + x26 + 8.3144626181532395*x28 + 8.3144626181532395*x3*(-n2*x10 + x4) - x4*x9) + x32;
result[2] = x25*(x11 - x18*x4 + x21*(x20 + 0.5*x4) + x27 + 16.628925236306479*x29 + 16.628925236306479*x3*(-n3*x10 + x4) + x30 - 5.7631463216439762) + x32;
}
        
static void coder_d3gdn2dt(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = (*endmember[0].dmu0dT)(T, P);
    double x1 = n1 + n3;
    double x2 = n1 + n2;
    double x3 = n3 + x2;
    double x4 = 1.0/x3;
    double x5 = 8.3144626181532395*log(x1*x4);
    double x6 = 8.3144626181532395*n2;
    double x7 = 8.3144626181532395*n1;
    double x8 = 8.3144626181532395*n3;
    double x9 = x7 + x8;
    double x10 = 1.0/x1;
    double x11 = pow(x3, -2);
    double x12 = -x1*x11 + x4;
    double x13 = x10*x12;
    double x14 = x13*x9;
    double x15 = x14*x3 - x4*x6 + x5;
    double x16 = 8.3144626181532395*log(x2*x4);
    double x17 = 1.0*n1 + 1.0*n2;
    double x18 = 0.5*n3 + x17;
    double x19 = log(x18*x4);
    double x20 = n3*x4;
    double x21 = x6 + x7;
    double x22 = 1.0/x2;
    double x23 = -x11*x2 + x4;
    double x24 = x22*x23;
    double x25 = x21*x24;
    double x26 = 1.0*x4;
    double x27 = -x11*x18;
    double x28 = x26 + x27;
    double x29 = 1.0/x18;
    double x30 = 16.628925236306479*n2;
    double x31 = 16.628925236306479*n1 + x30 + x8;
    double x32 = x29*x31;
    double x33 = x28*x32;
    double x34 = x16 + 16.628925236306479*x19 - 16.628925236306479*x20 + x25*x3 + x3*x33;
    double x35 = x0 + x15 + x34;
    double x36 = 2.0*x4;
    double x37 = n3*x11;
    double x38 = 16.628925236306479*x37;
    double x39 = x25 + x33 + x38;
    double x40 = x11*x6;
    double x41 = x14 + x40;
    double x42 = x39 + x41;
    double x43 = 16.628925236306479*x3;
    double x44 = x28*x29;
    double x45 = -2*x11;
    double x46 = pow(x3, -3);
    double x47 = 2*x46;
    double x48 = x21*x3;
    double x49 = x22*x48;
    double x50 = 2.0*x11;
    double x51 = x18*x47;
    double x52 = x3*x32;
    double x53 = x3*x31/((x18)*(x18));
    double x54 = x28*x53;
    double x55 = x24*x43 + 33.257850472612958*x3*x44 + x49*(x2*x47 + x45) + x52*(-x50 + x51) - 1.0*x54 - x23*x48/((x2)*(x2));
    double x56 = x42 + x55;
    double x57 = x3*x9;
    double x58 = x10*x57;
    double x59 = x13*x43 + x58*(x1*x47 + x45) - x12*x57/((x1)*(x1));
    double x60 = 1.0*n3;
    double x61 = x17 + x60;
    double x62 = x26*x61;
    double x63 = x35*x61;
    double x64 = (*endmember[1].dmu0dT)(T, P);
    double x65 = (*endmember[2].dmu0dT)(T, P);
    double x66 = log(n2*x4);
    double x67 = log(x20);
    double x68 = 8.3144626181532395*x19;
    double x69 = n1*x0 + n2*x64 + n3*x65 + x1*x5 + x16*x2 + x6*x66 + x67*x8 + x68*(2.0*n1 + 2.0*n2 + x60) + x8*(x67 - 0.69314718055994495);
    double x70 = 2.0*x46*x61*x69 - x50*x69;
    double x71 = 16.628925236306479*x4;
    double x72 = -x11;
    double x73 = -n1;
    double x74 = 1.0*x11;
    double x75 = x26*x35 - x63*x74 + x70;
    double x76 = 8.3144626181532395*x3;
    double x77 = x76*(-n2*x11 + x4);
    double x78 = x34 - x4*x9 + x64 + 8.3144626181532395*x66 + x77;
    double x79 = x61*x74;
    double x80 = x26*x78 - x78*x79;
    double x81 = x27 + 0.5*x4;
    double x82 = x29*x43*x81;
    double x83 = x44*x76 + x49*(-x47*(-n2 + x73) + x72) + x52*(-1.5*x11 + x51) - 0.5*x54 + x82;
    double x84 = x43*(-x37 + x4);
    double x85 = x32*x81;
    double x86 = x15 - x21*x4 + x3*x85 + x65 + 16.628925236306479*x67 + x68 + x84 - 5.7631463216439762;
    double x87 = x26*x86 - x79*x86;
    double x88 = x30*x46;
    double x89 = -x7;
    double x90 = x39 - x40;
    double x91 = x50*x61;

result[0] = x35*x36 - x50*x63 + x62*(x56 + x59) + x70;
result[1] = x62*(x56 + x58*(-x47*(-n3 + x73) + x72) - x71) + x75 + x80;
result[2] = x62*(-24.943387854459719*x4 + x42 + x59 + x83) + x75 + x87;
result[3] = x36*x78 + x62*(-x11*(-x8 + x89) + x3*(-16.628925236306479*x11 + x88) + 8.3144626181532395*x4 + x55 + x90 + x77/n2) + x70 - x78*x91;
result[4] = x62*(x11*x9 + x3*(-8.3144626181532395*x11 + x88) - 33.257850472612958*x4 + x83 + x90) + x70 + x80 + x87;
result[5] = x36*x86 + x62*(-x11*(-x6 + x89) + x3*(33.257850472612958*n3*x46 - 33.257850472612958*x11) - x38 + x41 + x52*(x51 - x74) - 0.5*x53*x81 + x59 + x71 + x82 + x85 + x84/n3) + x70 - x86*x91;
}
        
static void coder_d4gdn3dt(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = n1 + n2;
    double x1 = n3 + x0;
    double x2 = pow(x1, -2);
    double x3 = n3*x2;
    double x4 = 16.628925236306479*x3;
    double x5 = 8.3144626181532395*n1;
    double x6 = 8.3144626181532395*n2;
    double x7 = x5 + x6;
    double x8 = 1.0/x0;
    double x9 = 1.0/x1;
    double x10 = -x0*x2 + x9;
    double x11 = x10*x8;
    double x12 = x11*x7;
    double x13 = 16.628925236306479*n2;
    double x14 = 8.3144626181532395*n3;
    double x15 = 16.628925236306479*n1 + x13 + x14;
    double x16 = 1.0*n1 + 1.0*n2;
    double x17 = 0.5*n3 + x16;
    double x18 = 1.0/x17;
    double x19 = 1.0*x9;
    double x20 = -x17*x2;
    double x21 = x19 + x20;
    double x22 = x18*x21;
    double x23 = x15*x22;
    double x24 = x12 + x23 + x4;
    double x25 = x2*x6;
    double x26 = x14 + x5;
    double x27 = n1 + n3;
    double x28 = 1.0/x27;
    double x29 = -x2*x27 + x9;
    double x30 = x28*x29;
    double x31 = x26*x30;
    double x32 = x25 + x31;
    double x33 = x24 + x32;
    double x34 = 16.628925236306479*x11;
    double x35 = x1*x22;
    double x36 = -2*x2;
    double x37 = pow(x1, -3);
    double x38 = 2*x37;
    double x39 = x0*x38 + x36;
    double x40 = x7*x8;
    double x41 = x39*x40;
    double x42 = 2.0*x2;
    double x43 = x17*x38;
    double x44 = -x42 + x43;
    double x45 = x15*x18;
    double x46 = x44*x45;
    double x47 = pow(x0, -2);
    double x48 = x10*x47;
    double x49 = x48*x7;
    double x50 = pow(x17, -2);
    double x51 = x21*x50;
    double x52 = x15*x51;
    double x53 = 1.0*x52;
    double x54 = x1*x34 + x1*x41 + x1*x46 - x1*x49 - x1*x53 + 33.257850472612958*x35;
    double x55 = x33 + x54;
    double x56 = 16.628925236306479*x30;
    double x57 = x27*x38 + x36;
    double x58 = x26*x28;
    double x59 = x57*x58;
    double x60 = pow(x27, -2);
    double x61 = x29*x60;
    double x62 = x26*x61;
    double x63 = x1*x56 + x1*x59 - x1*x62;
    double x64 = x55 + x63;
    double x65 = 3.0*x9;
    double x66 = (*endmember[0].dmu0dT)(T, P);
    double x67 = 8.3144626181532395*log(x27*x9);
    double x68 = x1*x31 - x6*x9 + x67;
    double x69 = 8.3144626181532395*log(x0*x9);
    double x70 = log(x17*x9);
    double x71 = n3*x9;
    double x72 = x1*x12 + x1*x23 + x69 + 16.628925236306479*x70 - 16.628925236306479*x71;
    double x73 = x66 + x68 + x72;
    double x74 = x2*x73;
    double x75 = x13*x37;
    double x76 = -x75;
    double x77 = 33.257850472612958*x37;
    double x78 = n3*x77;
    double x79 = -x78;
    double x80 = 24.943387854459719*x1;
    double x81 = 49.886775708919437*x1;
    double x82 = x18*x44;
    double x83 = 6*x37;
    double x84 = pow(x1, -4);
    double x85 = 6*x84;
    double x86 = x1*x40;
    double x87 = 6.0*x37;
    double x88 = -x17*x85;
    double x89 = x1*x45;
    double x90 = x47*x7;
    double x91 = 2*x1;
    double x92 = x1*x15;
    double x93 = 2.0*x92;
    double x94 = pow(x17, -3);
    double x95 = x21*x94;
    double x96 = x44*x50;
    double x97 = 24.943387854459719*x11 + 49.886775708919437*x22 + x39*x8*x80 - x39*x90*x91 + 2*x41 + 2*x46 - x48*x80 - 2*x49 - x51*x81 - 2.0*x52 + x79 + x81*x82 + x86*(-x0*x85 + x83) + x89*(x87 + x88) + x93*x95 - x93*x96 + x10*x7*x91/((x0)*(x0)*(x0));
    double x98 = x76 + x97;
    double x99 = x1*x58;
    double x100 = x26*x60;
    double x101 = -x100*x57*x91 + x26*x29*x91/((x27)*(x27)*(x27)) + x28*x57*x80 + 24.943387854459719*x30 + 2*x59 - x61*x80 - 2*x62 + x99*(-x27*x85 + x83);
    double x102 = 1.0*n3;
    double x103 = x102 + x16;
    double x104 = x103*x19;
    double x105 = x103*x73;
    double x106 = x103*x64;
    double x107 = 3.0*x2;
    double x108 = (*endmember[1].dmu0dT)(T, P);
    double x109 = (*endmember[2].dmu0dT)(T, P);
    double x110 = log(n2*x9);
    double x111 = log(x71);
    double x112 = 8.3144626181532395*x70;
    double x113 = n1*x66 + n2*x108 + n3*x109 + x0*x69 + x110*x6 + x111*x14 + x112*(2.0*n1 + 2.0*n2 + x102) + x14*(x111 - 0.69314718055994495) + x27*x67;
    double x114 = -6.0*x103*x113*x84 + x113*x87;
    double x115 = 8.3144626181532395*x2;
    double x116 = -x2;
    double x117 = -n1;
    double x118 = -n3 + x117;
    double x119 = x116 - x118*x38;
    double x120 = x1*x119;
    double x121 = x120*x28;
    double x122 = 4*x37;
    double x123 = 2*n1;
    double x124 = 2*n3;
    double x125 = 3*x84;
    double x126 = -x125*(x123 + x124);
    double x127 = x119*x58;
    double x128 = -x100*x120 + x127 + x59 - x62;
    double x129 = 16.628925236306479*x9;
    double x130 = x1*x127 - x129 + x55;
    double x131 = 2.0*x9;
    double x132 = x103*x42;
    double x133 = x114 + x130*x131 - x130*x132;
    double x134 = -8.3144626181532395*n2*x2 + 8.3144626181532395*x9;
    double x135 = x1*x134;
    double x136 = x108 + 8.3144626181532395*x110 + x135 - x26*x9 + x72;
    double x137 = 2.0*x37;
    double x138 = x103*x136;
    double x139 = -x136*x42 + x137*x138;
    double x140 = 4.0*x37;
    double x141 = 1.0*x2;
    double x142 = x105*x140 - x106*x141 + x19*x64 - 4.0*x74;
    double x143 = 16.628925236306479*x2;
    double x144 = x101 + x76;
    double x145 = x116 - x38*(-n2 + x117);
    double x146 = x145*x40;
    double x147 = -1.5*x2 + x43;
    double x148 = x147*x45;
    double x149 = 8.3144626181532395*x1;
    double x150 = x1*x145;
    double x151 = x1*x18;
    double x152 = x147*x151;
    double x153 = 2*n2;
    double x154 = -x125*(x123 + x153);
    double x155 = 1.0*x15;
    double x156 = x1*x155;
    double x157 = 0.5*x92;
    double x158 = x156*x50;
    double x159 = -x147*x158 + x79;
    double x160 = x146 + x148 + x149*x82 + 16.628925236306479*x150*x8 - x150*x90 + 33.257850472612958*x152 + x156*x95 - x157*x96 + x159 + 41.572313090766201*x22 + x34 + x41 + x46 - x49 - x51*x80 - 1.5*x52 + x86*(x122 + x154) + x89*(5.0*x37 + x88);
    double x161 = x20 + 0.5*x9;
    double x162 = x161*x18;
    double x163 = 16.628925236306479*x162;
    double x164 = x1*x163;
    double x165 = x1*x146 + x1*x148 - 0.5*x1*x52 + x164 + 8.3144626181532395*x35;
    double x166 = x165 + x33 + x63 - 24.943387854459719*x9;
    double x167 = x114 + x131*x166 - x132*x166;
    double x168 = -16.628925236306479*x3 + 16.628925236306479*x9;
    double x169 = x1*x168;
    double x170 = x161*x45;
    double x171 = x1*x170 + x109 + 16.628925236306479*x111 + x112 + x169 + x68 - x7*x9 - 5.7631463216439762;
    double x172 = x103*x171;
    double x173 = x137*x172 - x171*x42;
    double x174 = x105*x137 - x42*x73;
    double x175 = -x5;
    double x176 = -x14 + x175;
    double x177 = 1.0/n2;
    double x178 = x24 - x25;
    double x179 = x1*(-x143 + x75) + x135*x177 - x176*x2 + x178 + x54 + 8.3144626181532395*x9;
    double x180 = 4.0*x2;
    double x181 = x103*x141;
    double x182 = -x136*x180 + x138*x140 - x179*x181 + x179*x19;
    double x183 = x1*(-x115 + x75) + x165 + x178 + x2*x26 - 33.257850472612958*x9;
    double x184 = 33.257850472612958*x2;
    double x185 = x114 + x173;
    double x186 = -x141 + x43;
    double x187 = x161*x50;
    double x188 = 2*x146 + 2*x148 - x149*x187 - x149*x51 + 16.628925236306479*x151*x186 + 16.628925236306479*x152 + x157*x95 + x159 + x163 + 16.628925236306479*x22 - x53 + x86*(x154 + x38) + x89*(x140 + x88);
    double x189 = -x184;
    double x190 = 1.0/n3;
    double x191 = x1*x187;
    double x192 = x1*(x189 + x78) + x129 - 0.5*x15*x191 + x164 + x169*x190 + x170 + x186*x89 - x2*(x175 - x6) + x32 - x4 + x63;
    double x193 = x140*x172 - x171*x180 - x181*x192 + x19*x192;
    double x194 = 6.0*x2;
    double x195 = -49.886775708919437*n2*x84;
    double x196 = x134*x177;
    double x197 = x153*x37;
    double x198 = x149*x177;
    double x199 = n2*x77;
    double x200 = x199 - x26*x38;
    double x201 = x103*x107;
    double x202 = x131*x183 - x132*x183;

result[0] = x104*(x101 + x98) + x105*x87 - x106*x107 + x114 + x64*x65 - 6.0*x74;
result[1] = x104*(x115 + 16.628925236306479*x121 + x128 + x56 + x98 + x99*(x122 + x126)) + x133 + x139 + x142;
result[2] = x104*(x143 + x144 + x160) + x142 + x167 + x173;
result[3] = x104*(2*x127 + 24.943387854459719*x2 + x98 + x99*(x126 + x38)) + x133 + x174 + x182;
result[4] = x104*(8.3144626181532395*x121 + x128 + x160 + x184 + 8.3144626181532395*x30 + x76 + x99*(x118*x85 + x122)) - x130*x181 + x130*x19 + x139 - x166*x181 + x166*x19 + x174 - x181*x183 + x183*x19 + x185;
result[5] = x104*(x144 + x188 + 41.572313090766201*x2) + x167 + x174 + x193;
result[6] = x104*(x1*(x195 + 49.886775708919437*x37) + x189 + x196 + x198*(x197 + x36) + x200 + x97 - x135/((n2)*(n2))) + x114 - x136*x194 + x138*x87 - x179*x201 + x179*x65;
result[7] = x104*(x1*(x195 + x77) + x160 + x176*x38 + x196 + x198*(x116 + x197) + x199) + x182 + x185 + x202;
result[8] = x104*(x1*(x195 + 16.628925236306479*x37) + x188 + 49.886775708919437*x2 + x200) + x114 + x139 + x193 + x202;
result[9] = x104*(66.515700945225916*n3*x37 + 16.628925236306479*x1*x190*(x124*x37 + x36) + x1*(-99.773551417838874*n3*x84 + 99.773551417838874*x37) + x144 - x155*x187 + x157*x161*x94 - x158*x186 + 24.943387854459719*x162 + x168*x190 + x18*x186*x80 + 2*x186*x45 - 12.471693927229859*x191 - 66.515700945225916*x2 - x38*x7 + x89*(3.0*x37 + x88) - x169/((n3)*(n3))) + x114 - x171*x194 + x172*x87 - x192*x201 + x192*x65;
}
        
static double coder_dgdp(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    

result = 1.0*(1.0*n1 + 1.0*n2 + 1.0*n3)*(n1*(*endmember[0].dmu0dP)(T, P) + n2*(*endmember[1].dmu0dP)(T, P) + n3*(*endmember[2].dmu0dP)(T, P))/(n1 + n2 + n3);
    return result;
}
        
static void coder_d2gdndp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = (*endmember[0].dmu0dP)(T, P);
    double x1 = 1.0*n1 + 1.0*n2 + 1.0*n3;
    double x2 = n1 + n2 + n3;
    double x3 = 1.0/x2;
    double x4 = x1*x3;
    double x5 = (*endmember[1].dmu0dP)(T, P);
    double x6 = (*endmember[2].dmu0dP)(T, P);
    double x7 = n1*x0 + n2*x5 + n3*x6;
    double x8 = -1.0*x1*x7/((x2)*(x2)) + x3*x7;

result[0] = x0*x4 + x8;
result[1] = x4*x5 + x8;
result[2] = x4*x6 + x8;
}
        
static void coder_d3gdn2dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = (*endmember[0].dmu0dP)(T, P);
    double x1 = n1 + n2 + n3;
    double x2 = 1.0/x1;
    double x3 = x0*x2;
    double x4 = pow(x1, -2);
    double x5 = 1.0*n1 + 1.0*n2 + 1.0*n3;
    double x6 = x4*x5;
    double x7 = x0*x6;
    double x8 = (*endmember[1].dmu0dP)(T, P);
    double x9 = (*endmember[2].dmu0dP)(T, P);
    double x10 = 2.0*n1*x0 + 2.0*n2*x8 + 2.0*n3*x9;
    double x11 = -x10*x4 + x10*x5/((x1)*(x1)*(x1));
    double x12 = x11 + 1.0*x3 - 1.0*x7;
    double x13 = 1.0*x2;
    double x14 = 1.0*x6;
    double x15 = x13*x8 - x14*x8;
    double x16 = x13*x9 - x14*x9;
    double x17 = 2.0*x2;
    double x18 = 2.0*x6;

result[0] = x11 + 2.0*x3 - 2.0*x7;
result[1] = x12 + x15;
result[2] = x12 + x16;
result[3] = x11 + x17*x8 - x18*x8;
result[4] = x11 + x15 + x16;
result[5] = x11 + x17*x9 - x18*x9;
}
        
static void coder_d4gdn3dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = (*endmember[0].dmu0dP)(T, P);
    double x1 = n1 + n2 + n3;
    double x2 = pow(x1, -2);
    double x3 = x0*x2;
    double x4 = pow(x1, -3);
    double x5 = 6.0*x4;
    double x6 = 1.0*n1 + 1.0*n2 + 1.0*n3;
    double x7 = x0*x6;
    double x8 = (*endmember[1].dmu0dP)(T, P);
    double x9 = (*endmember[2].dmu0dP)(T, P);
    double x10 = n1*x0 + n2*x8 + n3*x9;
    double x11 = x10*x5 - 6.0*x10*x6/((x1)*(x1)*(x1)*(x1));
    double x12 = 4.0*x4;
    double x13 = x11 + x12*x7 - 4.0*x3;
    double x14 = 2.0*x2;
    double x15 = 2.0*x4;
    double x16 = x6*x8;
    double x17 = -x14*x8 + x15*x16;
    double x18 = x6*x9;
    double x19 = -x14*x9 + x15*x18;
    double x20 = x11 + x15*x7 - 2.0*x3;
    double x21 = 4.0*x2;
    double x22 = x12*x16 - x21*x8;
    double x23 = x12*x18 - x21*x9;
    double x24 = 6.0*x2;

result[0] = x11 - 6.0*x3 + x5*x7;
result[1] = x13 + x17;
result[2] = x13 + x19;
result[3] = x20 + x22;
result[4] = x17 + x19 + x20;
result[5] = x20 + x23;
result[6] = x11 + x16*x5 - x24*x8;
result[7] = x11 + x19 + x22;
result[8] = x11 + x17 + x23;
result[9] = x11 + x18*x5 - x24*x9;
}
        
static double coder_d2gdt2(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    

result = 1.0*(n1*(*endmember[0].d2mu0dT2)(T, P) + n2*(*endmember[1].d2mu0dT2)(T, P) + n3*(*endmember[2].d2mu0dT2)(T, P));
    return result;
}
        
static void coder_d3gdndt2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 1.0*(*endmember[0].d2mu0dT2)(T, P);
result[1] = 1.0*(*endmember[1].d2mu0dT2)(T, P);
result[2] = 1.0*(*endmember[2].d2mu0dT2)(T, P);
}
        
static void coder_d4gdn2dt2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d5gdn3dt2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d2gdtdp(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    

result = 1.0*n1*(*endmember[0].d2mu0dTdP)(T, P) + 1.0*n2*(*endmember[1].d2mu0dTdP)(T, P) + 1.0*n3*(*endmember[2].d2mu0dTdP)(T, P);
    return result;
}
        
static void coder_d3gdndtdp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 1.0*(*endmember[0].d2mu0dTdP)(T, P);
result[1] = 1.0*(*endmember[1].d2mu0dTdP)(T, P);
result[2] = 1.0*(*endmember[2].d2mu0dTdP)(T, P);
}
        
static void coder_d4gdn2dtdp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d5gdn3dtdp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d2gdp2(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    

result = 1.0*(n1*(*endmember[0].d2mu0dP2)(T, P) + n2*(*endmember[1].d2mu0dP2)(T, P) + n3*(*endmember[2].d2mu0dP2)(T, P));
    return result;
}
        
static void coder_d3gdndp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 1.0*(*endmember[0].d2mu0dP2)(T, P);
result[1] = 1.0*(*endmember[1].d2mu0dP2)(T, P);
result[2] = 1.0*(*endmember[2].d2mu0dP2)(T, P);
}
        
static void coder_d4gdn2dp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d5gdn3dp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d3gdt3(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    

result = 1.0*(n1*(*endmember[0].d3mu0dT3)(T, P) + n2*(*endmember[1].d3mu0dT3)(T, P) + n3*(*endmember[2].d3mu0dT3)(T, P));
    return result;
}
        
static void coder_d4gdndt3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 1.0*(*endmember[0].d3mu0dT3)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dT3)(T, P);
result[2] = 1.0*(*endmember[2].d3mu0dT3)(T, P);
}
        
static void coder_d5gdn2dt3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d6gdn3dt3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d3gdt2dp(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    

result = 1.0*(n1*(*endmember[0].d3mu0dT2dP)(T, P) + n2*(*endmember[1].d3mu0dT2dP)(T, P) + n3*(*endmember[2].d3mu0dT2dP)(T, P));
    return result;
}
        
static void coder_d4gdndt2dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 1.0*(*endmember[0].d3mu0dT2dP)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dT2dP)(T, P);
result[2] = 1.0*(*endmember[2].d3mu0dT2dP)(T, P);
}
        
static void coder_d5gdn2dt2dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d6gdn3dt2dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d3gdtdp2(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    

result = 1.0*n1*(*endmember[0].d3mu0dTdP2)(T, P) + 1.0*n2*(*endmember[1].d3mu0dTdP2)(T, P) + 1.0*n3*(*endmember[2].d3mu0dTdP2)(T, P);
    return result;
}
        
static void coder_d4gdndtdp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 1.0*(*endmember[0].d3mu0dTdP2)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dTdP2)(T, P);
result[2] = 1.0*(*endmember[2].d3mu0dTdP2)(T, P);
}
        
static void coder_d5gdn2dtdp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d6gdn3dtdp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d3gdp3(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    

result = 1.0*(n1*(*endmember[0].d3mu0dP3)(T, P) + n2*(*endmember[1].d3mu0dP3)(T, P) + n3*(*endmember[2].d3mu0dP3)(T, P));
    return result;
}
        
static void coder_d4gdndp3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 1.0*(*endmember[0].d3mu0dP3)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dP3)(T, P);
result[2] = 1.0*(*endmember[2].d3mu0dP3)(T, P);
}
        
static void coder_d5gdn2dp3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d6gdn3dp3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_s(double T, double P, double n[3]) {
    double result = -coder_dgdt(T, P, n);
    return result;
}

static double coder_v(double T, double P, double n[3]) {
    double result = coder_dgdp(T, P, n);
    return result;
}

static double coder_cv(double T, double P, double n[3]) {
    double result = -T*coder_d2gdt2(T, P, n);
    double dvdt = coder_d2gdtdp(T, P, n);
    double dvdp = coder_d2gdp2(T, P, n);
    result += T*dvdt*dvdt/dvdp;
    return result;
}

static double coder_cp(double T, double P, double n[3]) {
    double result = -T*coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdt(double T, double P, double n[3]) {
    double result = -T*coder_d3gdt3(T, P, n) - coder_d2gdt2(T, P, n);
    return result;
}

static double coder_alpha(double T, double P, double n[3]) {
    double result = coder_d2gdtdp(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_beta(double T, double P, double n[3]) {
    double result = -coder_d2gdp2(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_K(double T, double P, double n[3]) {
    double result = -coder_dgdp(T, P, n)/coder_d2gdp2(T, P, n);
    return result;
}

static double coder_Kp(double T, double P, double n[3]) {
    double result = coder_dgdp(T, P, n);
    result *= coder_d3gdp3(T, P, n);
    result /= pow(coder_d2gdp2(T, P, n), 2.0);
    return result - 1.0;
}

