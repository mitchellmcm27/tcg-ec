#include <math.h>


static double coder_dparam_g(double T, double P, double n[6], int index) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double n6 = n[5];


        double x0 = (*endmember[0].mu0)(T, P);
    double x1 = n1*x0;
    double x2 = -x0;
    double x3 = x2 + (*endmember[1].mu0)(T, P);
    double x4 = n1*t;
    double x5 = exp(x3*x4);
    double x6 = x2 + (*endmember[2].mu0)(T, P);
    double x7 = exp(x4*x6);
    double x8 = (*endmember[4].mu0)(T, P);
    double x9 = x2 + x8 + (*endmember[3].mu0)(T, P);
    double x10 = exp(x4*x9);
    double x11 = x2 + 2*x8 + (*endmember[5].mu0)(T, P);
    double x12 = exp(x11*x4);
    double x13 = x10 + x12 + x5 + x7 + exp(0);

    
    double result = 0.0;
    switch (index) {
    case 0:
        result = (x1 + (n1*x10*x9 + n1*x11*x12 + n1*x3*x5 + n1*x6*x7)/x13)/t - (t*x1 + log(x13))/((t)*(t));
        break;

    default:
        break;
    }
        return result;
}

static double coder_dparam_dgdt(double T, double P, double n[6], int index) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double n6 = n[5];


        double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[0].dmu0dT)(T, P);
    double x2 = n1*x1;
    double x3 = (*endmember[1].mu0)(T, P);
    double x4 = -x0;
    double x5 = x3 + x4;
    double x6 = n1*t;
    double x7 = exp(x5*x6);
    double x8 = (*endmember[2].mu0)(T, P);
    double x9 = x4 + x8;
    double x10 = exp(x6*x9);
    double x11 = (*endmember[3].mu0)(T, P);
    double x12 = (*endmember[4].mu0)(T, P);
    double x13 = x11 + x12 + x4;
    double x14 = exp(x13*x6);
    double x15 = (*endmember[5].mu0)(T, P);
    double x16 = 2*x12 + x15 + x4;
    double x17 = exp(x16*x6);
    double x18 = x10 + x14 + x17 + x7 + exp(0);
    double x19 = 1.0/x18;
    double x20 = -x1;
    double x21 = x20 + (*endmember[1].dmu0dT)(T, P);
    double x22 = x21*x7;
    double x23 = x20 + (*endmember[2].dmu0dT)(T, P);
    double x24 = x10*x23;
    double x25 = (*endmember[4].dmu0dT)(T, P);
    double x26 = x20 + x25 + (*endmember[3].dmu0dT)(T, P);
    double x27 = x14*x26;
    double x28 = x20 + 2*x25 + (*endmember[5].dmu0dT)(T, P);
    double x29 = x17*x28;
    double x30 = x22*x6 + x24*x6 + x27*x6 + x29*x6;
    double x31 = n1*x7;
    double x32 = n1*x10;
    double x33 = n1*x14;
    double x34 = n1*x17;
    double x35 = ((n1)*(n1))*t;

    
    double result = 0.0;
    switch (index) {
    case 0:
        result = (x19*(x13*x27*x35 + x16*x29*x35 + x21*x31 + x22*x35*x5 + x23*x32 + x24*x35*x9 + x26*x33 + x28*x34) + x2 + x30*(-x13*x33 - x16*x34 - x31*x5 - x32*x9)/((x18)*(x18)))/t - (t*x2 + x19*x30)/((t)*(t));
        break;

    default:
        break;
    }
        return result;
}

static double coder_dparam_dgdp(double T, double P, double n[6], int index) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double n6 = n[5];


        double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[0].dmu0dP)(T, P);
    double x2 = n1*x1;
    double x3 = (*endmember[1].mu0)(T, P);
    double x4 = -x0;
    double x5 = x3 + x4;
    double x6 = n1*t;
    double x7 = exp(x5*x6);
    double x8 = (*endmember[2].mu0)(T, P);
    double x9 = x4 + x8;
    double x10 = exp(x6*x9);
    double x11 = (*endmember[3].mu0)(T, P);
    double x12 = (*endmember[4].mu0)(T, P);
    double x13 = x11 + x12 + x4;
    double x14 = exp(x13*x6);
    double x15 = (*endmember[5].mu0)(T, P);
    double x16 = 2*x12 + x15 + x4;
    double x17 = exp(x16*x6);
    double x18 = x10 + x14 + x17 + x7 + exp(0);
    double x19 = 1.0/x18;
    double x20 = -x1;
    double x21 = x20 + (*endmember[1].dmu0dP)(T, P);
    double x22 = x21*x7;
    double x23 = x20 + (*endmember[2].dmu0dP)(T, P);
    double x24 = x10*x23;
    double x25 = (*endmember[4].dmu0dP)(T, P);
    double x26 = x20 + x25 + (*endmember[3].dmu0dP)(T, P);
    double x27 = x14*x26;
    double x28 = x20 + 2*x25 + (*endmember[5].dmu0dP)(T, P);
    double x29 = x17*x28;
    double x30 = x22*x6 + x24*x6 + x27*x6 + x29*x6;
    double x31 = n1*x7;
    double x32 = n1*x10;
    double x33 = n1*x14;
    double x34 = n1*x17;
    double x35 = ((n1)*(n1))*t;

    
    double result = 0.0;
    switch (index) {
    case 0:
        result = (x19*(x13*x27*x35 + x16*x29*x35 + x21*x31 + x22*x35*x5 + x23*x32 + x24*x35*x9 + x26*x33 + x28*x34) + x2 + x30*(-x13*x33 - x16*x34 - x31*x5 - x32*x9)/((x18)*(x18)))/t - (t*x2 + x19*x30)/((t)*(t));
        break;

    default:
        break;
    }
        return result;
}

static double coder_dparam_d2gdt2(double T, double P, double n[6], int index) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double n6 = n[5];


        double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[1].mu0)(T, P);
    double x2 = x0 - x1;
    double x3 = n1*t;
    double x4 = exp(-x2*x3);
    double x5 = (*endmember[2].mu0)(T, P);
    double x6 = x0 - x5;
    double x7 = exp(-x3*x6);
    double x8 = (*endmember[3].mu0)(T, P);
    double x9 = (*endmember[4].mu0)(T, P);
    double x10 = -x0;
    double x11 = x10 + x8 + x9;
    double x12 = exp(x11*x3);
    double x13 = (*endmember[5].mu0)(T, P);
    double x14 = x10 + x13 + 2*x9;
    double x15 = exp(x14*x3);
    double x16 = x12 + x15 + x4 + x7 + exp(0);
    double x17 = pow(x16, -2);
    double x18 = (*endmember[0].dmu0dT)(T, P);
    double x19 = x18 - (*endmember[1].dmu0dT)(T, P);
    double x20 = x19*x4;
    double x21 = x18 - (*endmember[2].dmu0dT)(T, P);
    double x22 = x21*x7;
    double x23 = (*endmember[3].dmu0dT)(T, P);
    double x24 = (*endmember[4].dmu0dT)(T, P);
    double x25 = -x18;
    double x26 = x23 + x24 + x25;
    double x27 = (*endmember[5].dmu0dT)(T, P);
    double x28 = 2*x24;
    double x29 = x25 + x27 + x28;
    double x30 = -x12*x26 - x15*x29 + x20 + x22;
    double x31 = ((x30)*(x30));
    double x32 = n1*x4;
    double x33 = x2*x32;
    double x34 = n1*x7;
    double x35 = x34*x6;
    double x36 = n1*x12;
    double x37 = x11*x36;
    double x38 = 2*x37;
    double x39 = n1*x15;
    double x40 = x14*x39;
    double x41 = 2*x40;
    double x42 = 2*n1;
    double x43 = (*endmember[0].d2mu0dT2)(T, P);
    double x44 = (*endmember[1].d2mu0dT2)(T, P);
    double x45 = (*endmember[2].d2mu0dT2)(T, P);
    double x46 = ((x19)*(x19));
    double x47 = x4*x46;
    double x48 = ((x21)*(x21));
    double x49 = x48*x7;
    double x50 = (*endmember[4].d2mu0dT2)(T, P);
    double x51 = -x43;
    double x52 = x12*(x50 + x51 + (*endmember[3].d2mu0dT2)(T, P));
    double x53 = x15*(2*x50 + x51 + (*endmember[5].d2mu0dT2)(T, P));
    double x54 = ((x26)*(x26));
    double x55 = x12*x54;
    double x56 = ((x29)*(x29));
    double x57 = x15*x56;
    double x58 = ((n1)*(n1))*t;

    
    double result = 0.0;
    switch (index) {
    case 0:
        result = n1*(-n1*x17*x31 - x17*x3*x30*(-x2*x20*x42 - x22*x42*x6 + x38*(x18 - x23 - x24) + x41*(x18 - x27 - x28)) + x17*(x33 + x35 - x37 - x40)*(x3*x47 + x3*x49 + x3*x55 + x3*x57 - x4*(x43 - x44) + x52 + x53 - x7*(x43 - x45)) + (n1*x11*x52 + n1*x14*x53 + x11*x55*x58 + x14*x57*x58 - x2*x47*x58 + x32*x46 - x33*(x44 + x51) + x34*x48 - x35*(x45 + x51) + x36*x54 + x39*x56 - x49*x58*x6)/x16 - x3*x31*(2*x33 + 2*x35 - x38 - x41)/((x16)*(x16)*(x16)));
        break;

    default:
        break;
    }
        return result;
}

static double coder_dparam_d2gdtdp(double T, double P, double n[6], int index) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double n6 = n[5];


        double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[1].mu0)(T, P);
    double x2 = x0 - x1;
    double x3 = n1*t;
    double x4 = exp(-x2*x3);
    double x5 = (*endmember[0].dmu0dP)(T, P);
    double x6 = (*endmember[1].dmu0dP)(T, P);
    double x7 = x5 - x6;
    double x8 = (*endmember[2].mu0)(T, P);
    double x9 = x0 - x8;
    double x10 = exp(-x3*x9);
    double x11 = (*endmember[2].dmu0dP)(T, P);
    double x12 = -x11 + x5;
    double x13 = (*endmember[3].mu0)(T, P);
    double x14 = (*endmember[4].mu0)(T, P);
    double x15 = -x0;
    double x16 = x13 + x14 + x15;
    double x17 = exp(x16*x3);
    double x18 = (*endmember[4].dmu0dP)(T, P);
    double x19 = -x5;
    double x20 = x18 + x19 + (*endmember[3].dmu0dP)(T, P);
    double x21 = x17*x20;
    double x22 = (*endmember[5].mu0)(T, P);
    double x23 = 2*x14 + x15 + x22;
    double x24 = exp(x23*x3);
    double x25 = 2*x18 + x19 + (*endmember[5].dmu0dP)(T, P);
    double x26 = x24*x25;
    double x27 = -x10*x12 + x21 + x26 - x4*x7;
    double x28 = x10 + x17 + x24 + x4 + exp(0);
    double x29 = pow(x28, -2);
    double x30 = (*endmember[0].dmu0dT)(T, P);
    double x31 = x4*(x30 - (*endmember[1].dmu0dT)(T, P));
    double x32 = x10*(x30 - (*endmember[2].dmu0dT)(T, P));
    double x33 = (*endmember[3].dmu0dT)(T, P);
    double x34 = (*endmember[4].dmu0dT)(T, P);
    double x35 = -x30;
    double x36 = x17*(x33 + x34 + x35);
    double x37 = (*endmember[5].dmu0dT)(T, P);
    double x38 = 2*x34;
    double x39 = x24*(x35 + x37 + x38);
    double x40 = x31 + x32 - x36 - x39;
    double x41 = x29*x40;
    double x42 = n1*x2;
    double x43 = x4*x42;
    double x44 = n1*x9;
    double x45 = x10*x44;
    double x46 = n1*x16;
    double x47 = n1*x23;
    double x48 = x17*x46;
    double x49 = x24*x47;
    double x50 = x27*x3;
    double x51 = (*endmember[0].d2mu0dTdP)(T, P);
    double x52 = (*endmember[1].d2mu0dTdP)(T, P);
    double x53 = (*endmember[2].d2mu0dTdP)(T, P);
    double x54 = (*endmember[4].d2mu0dTdP)(T, P);
    double x55 = -x51;
    double x56 = x17*(x54 + x55 + (*endmember[3].d2mu0dTdP)(T, P));
    double x57 = x31*x7;
    double x58 = x12*x32;
    double x59 = x24*(2*x54 + x55 + (*endmember[5].d2mu0dTdP)(T, P));
    double x60 = x20*x36;
    double x61 = x25*x39;
    double x62 = ((n1)*(n1))*t;

    
    double result = 0.0;
    switch (index) {
    case 0:
        result = n1*(n1*x27*x41 + x29*x50*(-x31*x42 - x32*x44 + x48*(x30 - x33 - x34) + x49*(x30 - x37 - x38)) + x29*(x43 + x45 - x48 - x49)*(-x10*(x51 - x53) + x3*x57 + x3*x58 + x3*x60 + x3*x61 - x4*(x51 - x52) + x56 + x59) + x3*x41*(x21*x46 + x26*x47 - x43*(x19 + x6) - x45*(x11 + x19)) + (n1*x57 + n1*x58 + n1*x60 + n1*x61 + x16*x60*x62 - x2*x57*x62 + x23*x61*x62 - x43*(x52 + x55) - x45*(x53 + x55) + x46*x56 + x47*x59 - x58*x62*x9)/x28 + x40*x50*(2*x43 + 2*x45 - 2*x48 - 2*x49)/((x28)*(x28)*(x28)));
        break;

    default:
        break;
    }
        return result;
}

static double coder_dparam_d2gdp2(double T, double P, double n[6], int index) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double n6 = n[5];


        double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[1].mu0)(T, P);
    double x2 = x0 - x1;
    double x3 = n1*t;
    double x4 = exp(-x2*x3);
    double x5 = (*endmember[2].mu0)(T, P);
    double x6 = x0 - x5;
    double x7 = exp(-x3*x6);
    double x8 = (*endmember[3].mu0)(T, P);
    double x9 = (*endmember[4].mu0)(T, P);
    double x10 = -x0;
    double x11 = x10 + x8 + x9;
    double x12 = exp(x11*x3);
    double x13 = (*endmember[5].mu0)(T, P);
    double x14 = x10 + x13 + 2*x9;
    double x15 = exp(x14*x3);
    double x16 = x12 + x15 + x4 + x7 + exp(0);
    double x17 = pow(x16, -2);
    double x18 = (*endmember[0].dmu0dP)(T, P);
    double x19 = x18 - (*endmember[1].dmu0dP)(T, P);
    double x20 = x19*x4;
    double x21 = x18 - (*endmember[2].dmu0dP)(T, P);
    double x22 = x21*x7;
    double x23 = (*endmember[3].dmu0dP)(T, P);
    double x24 = (*endmember[4].dmu0dP)(T, P);
    double x25 = -x18;
    double x26 = x23 + x24 + x25;
    double x27 = (*endmember[5].dmu0dP)(T, P);
    double x28 = 2*x24;
    double x29 = x25 + x27 + x28;
    double x30 = -x12*x26 - x15*x29 + x20 + x22;
    double x31 = ((x30)*(x30));
    double x32 = n1*x4;
    double x33 = x2*x32;
    double x34 = n1*x7;
    double x35 = x34*x6;
    double x36 = n1*x12;
    double x37 = x11*x36;
    double x38 = 2*x37;
    double x39 = n1*x15;
    double x40 = x14*x39;
    double x41 = 2*x40;
    double x42 = 2*n1;
    double x43 = (*endmember[0].d2mu0dP2)(T, P);
    double x44 = (*endmember[1].d2mu0dP2)(T, P);
    double x45 = (*endmember[2].d2mu0dP2)(T, P);
    double x46 = ((x19)*(x19));
    double x47 = x4*x46;
    double x48 = ((x21)*(x21));
    double x49 = x48*x7;
    double x50 = (*endmember[4].d2mu0dP2)(T, P);
    double x51 = -x43;
    double x52 = x12*(x50 + x51 + (*endmember[3].d2mu0dP2)(T, P));
    double x53 = x15*(2*x50 + x51 + (*endmember[5].d2mu0dP2)(T, P));
    double x54 = ((x26)*(x26));
    double x55 = x12*x54;
    double x56 = ((x29)*(x29));
    double x57 = x15*x56;
    double x58 = ((n1)*(n1))*t;

    
    double result = 0.0;
    switch (index) {
    case 0:
        result = n1*(-n1*x17*x31 - x17*x3*x30*(-x2*x20*x42 - x22*x42*x6 + x38*(x18 - x23 - x24) + x41*(x18 - x27 - x28)) + x17*(x33 + x35 - x37 - x40)*(x3*x47 + x3*x49 + x3*x55 + x3*x57 - x4*(x43 - x44) + x52 + x53 - x7*(x43 - x45)) + (n1*x11*x52 + n1*x14*x53 + x11*x55*x58 + x14*x57*x58 - x2*x47*x58 + x32*x46 - x33*(x44 + x51) + x34*x48 - x35*(x45 + x51) + x36*x54 + x39*x56 - x49*x58*x6)/x16 - x3*x31*(2*x33 + 2*x35 - x38 - x41)/((x16)*(x16)*(x16)));
        break;

    default:
        break;
    }
        return result;
}

static double coder_dparam_d3gdt3(double T, double P, double n[6], int index) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double n6 = n[5];


        double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[1].mu0)(T, P);
    double x2 = x0 - x1;
    double x3 = n1*t;
    double x4 = exp(-x2*x3);
    double x5 = (*endmember[0].dmu0dT)(T, P);
    double x6 = x5 - (*endmember[1].dmu0dT)(T, P);
    double x7 = x4*x6;
    double x8 = (*endmember[2].mu0)(T, P);
    double x9 = x0 - x8;
    double x10 = exp(-x3*x9);
    double x11 = x5 - (*endmember[2].dmu0dT)(T, P);
    double x12 = x10*x11;
    double x13 = (*endmember[3].mu0)(T, P);
    double x14 = (*endmember[4].mu0)(T, P);
    double x15 = -x0;
    double x16 = x13 + x14 + x15;
    double x17 = exp(x16*x3);
    double x18 = (*endmember[3].dmu0dT)(T, P);
    double x19 = (*endmember[4].dmu0dT)(T, P);
    double x20 = -x5;
    double x21 = x18 + x19 + x20;
    double x22 = x17*x21;
    double x23 = (*endmember[5].mu0)(T, P);
    double x24 = 2*x14 + x15 + x23;
    double x25 = exp(x24*x3);
    double x26 = (*endmember[5].dmu0dT)(T, P);
    double x27 = 2*x19;
    double x28 = x20 + x26 + x27;
    double x29 = x25*x28;
    double x30 = x12 - x22 - x29 + x7;
    double x31 = ((x30)*(x30)*(x30));
    double x32 = x10 + x17 + x25 + x4 + exp(0);
    double x33 = pow(x32, -3);
    double x34 = ((n1)*(n1));
    double x35 = t*x34;
    double x36 = n1*x4;
    double x37 = x2*x36;
    double x38 = n1*x10;
    double x39 = x38*x9;
    double x40 = n1*x17;
    double x41 = x16*x40;
    double x42 = 3*x41;
    double x43 = n1*x25;
    double x44 = x24*x43;
    double x45 = 3*x44;
    double x46 = ((t)*(t));
    double x47 = x34*x46;
    double x48 = 2*x47;
    double x49 = n1*x7;
    double x50 = x2*x49;
    double x51 = n1*x12;
    double x52 = x51*x9;
    double x53 = -x18 - x19 + x5;
    double x54 = -x26 - x27 + x5;
    double x55 = (*endmember[0].d2mu0dT2)(T, P);
    double x56 = (*endmember[1].d2mu0dT2)(T, P);
    double x57 = x55 - x56;
    double x58 = (*endmember[2].d2mu0dT2)(T, P);
    double x59 = x55 - x58;
    double x60 = ((x6)*(x6));
    double x61 = x4*x60;
    double x62 = ((x11)*(x11));
    double x63 = x10*x62;
    double x64 = (*endmember[4].d2mu0dT2)(T, P);
    double x65 = -x55;
    double x66 = x64 + x65 + (*endmember[3].d2mu0dT2)(T, P);
    double x67 = x17*x66;
    double x68 = 2*x64 + x65 + (*endmember[5].d2mu0dT2)(T, P);
    double x69 = x25*x68;
    double x70 = ((x21)*(x21));
    double x71 = x17*x70;
    double x72 = ((x28)*(x28));
    double x73 = x25*x72;
    double x74 = -x10*x59 + x3*x61 + x3*x63 + x3*x71 + x3*x73 - x4*x57 + x67 + x69;
    double x75 = 3*n1;
    double x76 = pow(x32, -2);
    double x77 = x30*x76;
    double x78 = 3*x3;
    double x79 = x74*x78;
    double x80 = (*endmember[0].d3mu0dT3)(T, P);
    double x81 = (*endmember[1].d3mu0dT3)(T, P);
    double x82 = (*endmember[2].d3mu0dT3)(T, P);
    double x83 = (*endmember[4].d3mu0dT3)(T, P);
    double x84 = -x80;
    double x85 = x17*(x83 + x84 + (*endmember[3].d3mu0dT3)(T, P));
    double x86 = x4*((x6)*(x6)*(x6));
    double x87 = x10*((x11)*(x11)*(x11));
    double x88 = x25*(2*x83 + x84 + (*endmember[5].d3mu0dT3)(T, P));
    double x89 = x17*((x21)*(x21)*(x21));
    double x90 = 3*x57;
    double x91 = x7*x90;
    double x92 = 3*x59;
    double x93 = x12*x92;
    double x94 = x25*((x28)*(x28)*(x28));
    double x95 = x22*x66;
    double x96 = x29*x68;
    double x97 = x2*x35;
    double x98 = x35*x9;
    double x99 = n1*x16;
    double x100 = x16*x35;
    double x101 = n1*x24;
    double x102 = x24*x35;
    double x103 = 2*x35;
    double x104 = ((n1)*(n1)*(n1))*x46;

    
    double result = 0.0;
    switch (index) {
    case 0:
        result = n1*(-((x30)*(x30))*x33*x48*(x42*x53 + x45*x54 - 3*x50 - 3*x52) + x30*x33*x79*(2*x37 + 2*x39 - 2*x41 - 2*x44) - 4*x31*x33*x35 - x31*x48*(3*x37 + 3*x39 - x42 - x45)/((x32)*(x32)*(x32)*(x32)) + x74*x75*x77 + x76*x79*(x41*x53 + x44*x54 - x50 - x52) + x76*(x37 + x39 - x41 - x44)*(-x10*(x80 - x82) + x3*x91 + x3*x93 - x4*(x80 - x81) - x47*x86 - x47*x87 + x47*x89 + x47*x94 + x78*x95 + x78*x96 + x85 + x88) + x77*x78*(x100*x71 + x101*x69 + x102*x73 + x36*x60 - x37*(x56 + x65) + x38*x62 - x39*(x58 + x65) + x40*x70 + x43*x72 - x61*x97 - x63*x98 + x67*x99) + (3*x100*x95 + x101*x88 + 3*x102*x96 - x103*x86 - x103*x87 + x103*x89 + x103*x94 + x104*x16*x89 + x104*x2*x86 + x104*x24*x94 + x104*x87*x9 - x37*(x81 + x84) - x39*(x82 + x84) + x49*x90 + x51*x92 + x75*x95 + x75*x96 + x85*x99 - x91*x97 - x93*x98)/x32);
        break;

    default:
        break;
    }
        return result;
}

static double coder_dparam_d3gdt2dp(double T, double P, double n[6], int index) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double n6 = n[5];


        double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[1].mu0)(T, P);
    double x2 = x0 - x1;
    double x3 = n1*t;
    double x4 = exp(-x2*x3);
    double x5 = (*endmember[0].dmu0dP)(T, P);
    double x6 = x4*(x5 - (*endmember[1].dmu0dP)(T, P));
    double x7 = (*endmember[2].mu0)(T, P);
    double x8 = x0 - x7;
    double x9 = exp(-x3*x8);
    double x10 = x9*(x5 - (*endmember[2].dmu0dP)(T, P));
    double x11 = (*endmember[3].mu0)(T, P);
    double x12 = (*endmember[4].mu0)(T, P);
    double x13 = -x0;
    double x14 = x11 + x12 + x13;
    double x15 = exp(x14*x3);
    double x16 = (*endmember[3].dmu0dP)(T, P);
    double x17 = (*endmember[4].dmu0dP)(T, P);
    double x18 = -x5;
    double x19 = x15*(x16 + x17 + x18);
    double x20 = (*endmember[5].mu0)(T, P);
    double x21 = 2*x12 + x13 + x20;
    double x22 = exp(x21*x3);
    double x23 = (*endmember[5].dmu0dP)(T, P);
    double x24 = 2*x17;
    double x25 = x22*(x18 + x23 + x24);
    double x26 = x10 - x19 - x25 + x6;
    double x27 = ((n1)*(n1));
    double x28 = t*x27;
    double x29 = (*endmember[0].dmu0dT)(T, P);
    double x30 = x29 - (*endmember[1].dmu0dT)(T, P);
    double x31 = x30*x4;
    double x32 = x29 - (*endmember[2].dmu0dT)(T, P);
    double x33 = x32*x9;
    double x34 = (*endmember[3].dmu0dT)(T, P);
    double x35 = (*endmember[4].dmu0dT)(T, P);
    double x36 = -x29;
    double x37 = x34 + x35 + x36;
    double x38 = x15*x37;
    double x39 = (*endmember[5].dmu0dT)(T, P);
    double x40 = 2*x35;
    double x41 = x36 + x39 + x40;
    double x42 = x22*x41;
    double x43 = x31 + x33 - x38 - x42;
    double x44 = ((x43)*(x43));
    double x45 = x15 + x22 + x4 + x9 + exp(0);
    double x46 = pow(x45, -3);
    double x47 = x44*x46;
    double x48 = n1*x6;
    double x49 = n1*x10;
    double x50 = n1*x15;
    double x51 = x14*x50;
    double x52 = n1*x22;
    double x53 = x21*x52;
    double x54 = -x2*x48 - x49*x8 + x51*(-x16 - x17 + x5) + x53*(-x23 - x24 + x5);
    double x55 = ((t)*(t));
    double x56 = x27*x55;
    double x57 = 2*x56;
    double x58 = n1*x4;
    double x59 = x2*x58;
    double x60 = n1*x9;
    double x61 = x60*x8;
    double x62 = pow(x45, -2);
    double x63 = n1*x62;
    double x64 = (*endmember[0].d2mu0dT2)(T, P);
    double x65 = (*endmember[1].d2mu0dT2)(T, P);
    double x66 = x64 - x65;
    double x67 = (*endmember[2].d2mu0dT2)(T, P);
    double x68 = x64 - x67;
    double x69 = ((x30)*(x30));
    double x70 = x4*x69;
    double x71 = ((x32)*(x32));
    double x72 = x71*x9;
    double x73 = (*endmember[4].d2mu0dT2)(T, P);
    double x74 = -x64;
    double x75 = x73 + x74 + (*endmember[3].d2mu0dT2)(T, P);
    double x76 = x15*x75;
    double x77 = 2*x73 + x74 + (*endmember[5].d2mu0dT2)(T, P);
    double x78 = x22*x77;
    double x79 = ((x37)*(x37));
    double x80 = x15*x79;
    double x81 = ((x41)*(x41));
    double x82 = x22*x81;
    double x83 = x3*x70 + x3*x72 + x3*x80 + x3*x82 - x4*x66 - x68*x9 + x76 + x78;
    double x84 = x26*x83;
    double x85 = n1*x31;
    double x86 = x2*x85;
    double x87 = n1*x33;
    double x88 = x8*x87;
    double x89 = x51*(x29 - x34 - x35);
    double x90 = x53*(x29 - x39 - x40);
    double x91 = 2*x43;
    double x92 = x3*x62;
    double x93 = (*endmember[0].d2mu0dTdP)(T, P);
    double x94 = (*endmember[1].d2mu0dTdP)(T, P);
    double x95 = x93 - x94;
    double x96 = (*endmember[2].d2mu0dTdP)(T, P);
    double x97 = x93 - x96;
    double x98 = (*endmember[4].d2mu0dTdP)(T, P);
    double x99 = -x93;
    double x100 = x98 + x99 + (*endmember[3].d2mu0dTdP)(T, P);
    double x101 = x100*x15;
    double x102 = x3*x6;
    double x103 = x10*x3;
    double x104 = 2*x98 + x99 + (*endmember[5].d2mu0dTdP)(T, P);
    double x105 = x104*x22;
    double x106 = x19*x3;
    double x107 = x25*x3;
    double x108 = x101 + x102*x30 + x103*x32 + x105 + x106*x37 + x107*x41 - x4*x95 - x9*x97;
    double x109 = x108*x91;
    double x110 = x3*x46*(-2*x51 - 2*x53 + 2*x59 + 2*x61);
    double x111 = x2*x28;
    double x112 = x28*x8;
    double x113 = n1*x14;
    double x114 = x14*x28;
    double x115 = n1*x21;
    double x116 = x21*x28;
    double x117 = x111*x6;
    double x118 = x10*x112;
    double x119 = n1*x19;
    double x120 = n1*x25;
    double x121 = x114*x19;
    double x122 = x116*x25;
    double x123 = (*endmember[0].d3mu0dT2dP)(T, P);
    double x124 = (*endmember[1].d3mu0dT2dP)(T, P);
    double x125 = (*endmember[2].d3mu0dT2dP)(T, P);
    double x126 = (*endmember[4].d3mu0dT2dP)(T, P);
    double x127 = -x123;
    double x128 = x15*(x126 + x127 + (*endmember[3].d3mu0dT2dP)(T, P));
    double x129 = x22*(2*x126 + x127 + (*endmember[5].d3mu0dT2dP)(T, P));
    double x130 = 2*x95;
    double x131 = x130*x31;
    double x132 = 2*x97;
    double x133 = x132*x33;
    double x134 = x6*x69;
    double x135 = x10*x71;
    double x136 = x19*x79;
    double x137 = x100*x38;
    double x138 = 2*x3;
    double x139 = x25*x81;
    double x140 = x104*x42;
    double x141 = 2*x28;
    double x142 = ((n1)*(n1)*(n1))*x55;
    double x143 = 2*n1;

    
    double result = 0.0;
    switch (index) {
    case 0:
        result = n1*(2*x108*x92*(-x86 - x88 + x89 + x90) + x109*x110 + x109*x63 + x110*x84 - 4*x26*x28*x47 - x26*x44*x57*(-3*x51 - 3*x53 + 3*x59 + 3*x61)/((x45)*(x45)*(x45)*(x45)) - x26*x46*x56*x91*(-2*x86 - 2*x88 + 2*x89 + 2*x90) + x26*x92*(-x111*x70 - x112*x72 + x113*x76 + x114*x80 + x115*x78 + x116*x82 + x50*x79 + x52*x81 + x58*x69 - x59*(x65 + x74) + x60*x71 - x61*(x67 + x74)) - x47*x54*x57 + x54*x83*x92 + x62*(-x51 - x53 + x59 + x61)*(x102*x66 + x103*x68 + x106*x75 + x107*x77 + x128 + x129 + x131*x3 + x133*x3 - x134*x56 - x135*x56 + x136*x56 + x137*x138 + x138*x140 + x139*x56 - x4*(x123 - x124) - x9*(x123 - x125)) + x63*x84 + x91*x92*(x101*x113 + x105*x115 - x117*x30 - x118*x32 + x119*x37 + x120*x41 + x121*x37 + x122*x41 + x30*x48 + x32*x49 - x59*(x94 + x99) - x61*(x96 + x99)) + (-x111*x131 - x112*x133 + x113*x128 + 2*x114*x137 + x115*x129 + 2*x116*x140 - x117*x66 - x118*x68 + x119*x75 + x120*x77 + x121*x75 + x122*x77 + x130*x85 + x132*x87 - x134*x141 + x134*x142*x2 - x135*x141 + x135*x142*x8 + x136*x14*x142 + x136*x141 + x137*x143 + x139*x141 + x139*x142*x21 + x140*x143 + x48*x66 + x49*x68 - x59*(x124 + x127) - x61*(x125 + x127))/x45);
        break;

    default:
        break;
    }
        return result;
}

static double coder_dparam_d3gdtdp2(double T, double P, double n[6], int index) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double n6 = n[5];


        double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[1].mu0)(T, P);
    double x2 = x0 - x1;
    double x3 = n1*t;
    double x4 = exp(-x2*x3);
    double x5 = (*endmember[0].dmu0dT)(T, P);
    double x6 = x4*(x5 - (*endmember[1].dmu0dT)(T, P));
    double x7 = (*endmember[2].mu0)(T, P);
    double x8 = x0 - x7;
    double x9 = exp(-x3*x8);
    double x10 = x9*(x5 - (*endmember[2].dmu0dT)(T, P));
    double x11 = (*endmember[3].mu0)(T, P);
    double x12 = (*endmember[4].mu0)(T, P);
    double x13 = -x0;
    double x14 = x11 + x12 + x13;
    double x15 = exp(x14*x3);
    double x16 = (*endmember[3].dmu0dT)(T, P);
    double x17 = (*endmember[4].dmu0dT)(T, P);
    double x18 = -x5;
    double x19 = x15*(x16 + x17 + x18);
    double x20 = (*endmember[5].mu0)(T, P);
    double x21 = 2*x12 + x13 + x20;
    double x22 = exp(x21*x3);
    double x23 = (*endmember[5].dmu0dT)(T, P);
    double x24 = 2*x17;
    double x25 = x22*(x18 + x23 + x24);
    double x26 = x10 - x19 - x25 + x6;
    double x27 = ((n1)*(n1));
    double x28 = t*x27;
    double x29 = (*endmember[0].dmu0dP)(T, P);
    double x30 = x29 - (*endmember[1].dmu0dP)(T, P);
    double x31 = x30*x4;
    double x32 = x29 - (*endmember[2].dmu0dP)(T, P);
    double x33 = x32*x9;
    double x34 = (*endmember[3].dmu0dP)(T, P);
    double x35 = (*endmember[4].dmu0dP)(T, P);
    double x36 = -x29;
    double x37 = x34 + x35 + x36;
    double x38 = x15*x37;
    double x39 = (*endmember[5].dmu0dP)(T, P);
    double x40 = 2*x35;
    double x41 = x36 + x39 + x40;
    double x42 = x22*x41;
    double x43 = x31 + x33 - x38 - x42;
    double x44 = ((x43)*(x43));
    double x45 = x15 + x22 + x4 + x9 + exp(0);
    double x46 = pow(x45, -3);
    double x47 = x44*x46;
    double x48 = n1*x6;
    double x49 = n1*x10;
    double x50 = n1*x15;
    double x51 = x14*x50;
    double x52 = n1*x22;
    double x53 = x21*x52;
    double x54 = -x2*x48 - x49*x8 + x51*(-x16 - x17 + x5) + x53*(-x23 - x24 + x5);
    double x55 = ((t)*(t));
    double x56 = x27*x55;
    double x57 = 2*x56;
    double x58 = n1*x4;
    double x59 = x2*x58;
    double x60 = n1*x9;
    double x61 = x60*x8;
    double x62 = pow(x45, -2);
    double x63 = n1*x62;
    double x64 = (*endmember[0].d2mu0dP2)(T, P);
    double x65 = (*endmember[1].d2mu0dP2)(T, P);
    double x66 = x64 - x65;
    double x67 = (*endmember[2].d2mu0dP2)(T, P);
    double x68 = x64 - x67;
    double x69 = ((x30)*(x30));
    double x70 = x4*x69;
    double x71 = ((x32)*(x32));
    double x72 = x71*x9;
    double x73 = (*endmember[4].d2mu0dP2)(T, P);
    double x74 = -x64;
    double x75 = x73 + x74 + (*endmember[3].d2mu0dP2)(T, P);
    double x76 = x15*x75;
    double x77 = 2*x73 + x74 + (*endmember[5].d2mu0dP2)(T, P);
    double x78 = x22*x77;
    double x79 = ((x37)*(x37));
    double x80 = x15*x79;
    double x81 = ((x41)*(x41));
    double x82 = x22*x81;
    double x83 = x3*x70 + x3*x72 + x3*x80 + x3*x82 - x4*x66 - x68*x9 + x76 + x78;
    double x84 = x26*x83;
    double x85 = n1*x31;
    double x86 = x2*x85;
    double x87 = n1*x33;
    double x88 = x8*x87;
    double x89 = x51*(x29 - x34 - x35);
    double x90 = x53*(x29 - x39 - x40);
    double x91 = 2*x43;
    double x92 = x3*x62;
    double x93 = (*endmember[0].d2mu0dTdP)(T, P);
    double x94 = (*endmember[1].d2mu0dTdP)(T, P);
    double x95 = x93 - x94;
    double x96 = (*endmember[2].d2mu0dTdP)(T, P);
    double x97 = x93 - x96;
    double x98 = (*endmember[4].d2mu0dTdP)(T, P);
    double x99 = -x93;
    double x100 = x98 + x99 + (*endmember[3].d2mu0dTdP)(T, P);
    double x101 = x100*x15;
    double x102 = x3*x6;
    double x103 = x10*x3;
    double x104 = 2*x98 + x99 + (*endmember[5].d2mu0dTdP)(T, P);
    double x105 = x104*x22;
    double x106 = x19*x3;
    double x107 = x25*x3;
    double x108 = x101 + x102*x30 + x103*x32 + x105 + x106*x37 + x107*x41 - x4*x95 - x9*x97;
    double x109 = x108*x91;
    double x110 = x3*x46*(-2*x51 - 2*x53 + 2*x59 + 2*x61);
    double x111 = x2*x28;
    double x112 = x28*x8;
    double x113 = n1*x14;
    double x114 = x14*x28;
    double x115 = n1*x21;
    double x116 = x21*x28;
    double x117 = x111*x6;
    double x118 = x10*x112;
    double x119 = n1*x19;
    double x120 = n1*x25;
    double x121 = x114*x19;
    double x122 = x116*x25;
    double x123 = (*endmember[0].d3mu0dTdP2)(T, P);
    double x124 = (*endmember[1].d3mu0dTdP2)(T, P);
    double x125 = (*endmember[2].d3mu0dTdP2)(T, P);
    double x126 = (*endmember[4].d3mu0dTdP2)(T, P);
    double x127 = -x123;
    double x128 = x15*(x126 + x127 + (*endmember[3].d3mu0dTdP2)(T, P));
    double x129 = x22*(2*x126 + x127 + (*endmember[5].d3mu0dTdP2)(T, P));
    double x130 = 2*x95;
    double x131 = x130*x31;
    double x132 = 2*x97;
    double x133 = x132*x33;
    double x134 = x6*x69;
    double x135 = x10*x71;
    double x136 = x19*x79;
    double x137 = x100*x38;
    double x138 = 2*x3;
    double x139 = x25*x81;
    double x140 = x104*x42;
    double x141 = 2*x28;
    double x142 = ((n1)*(n1)*(n1))*x55;
    double x143 = 2*n1;

    
    double result = 0.0;
    switch (index) {
    case 0:
        result = n1*(2*x108*x92*(-x86 - x88 + x89 + x90) + x109*x110 + x109*x63 + x110*x84 - 4*x26*x28*x47 - x26*x44*x57*(-3*x51 - 3*x53 + 3*x59 + 3*x61)/((x45)*(x45)*(x45)*(x45)) - x26*x46*x56*x91*(-2*x86 - 2*x88 + 2*x89 + 2*x90) + x26*x92*(-x111*x70 - x112*x72 + x113*x76 + x114*x80 + x115*x78 + x116*x82 + x50*x79 + x52*x81 + x58*x69 - x59*(x65 + x74) + x60*x71 - x61*(x67 + x74)) - x47*x54*x57 + x54*x83*x92 + x62*(-x51 - x53 + x59 + x61)*(x102*x66 + x103*x68 + x106*x75 + x107*x77 + x128 + x129 + x131*x3 + x133*x3 - x134*x56 - x135*x56 + x136*x56 + x137*x138 + x138*x140 + x139*x56 - x4*(x123 - x124) - x9*(x123 - x125)) + x63*x84 + x91*x92*(x101*x113 + x105*x115 - x117*x30 - x118*x32 + x119*x37 + x120*x41 + x121*x37 + x122*x41 + x30*x48 + x32*x49 - x59*(x94 + x99) - x61*(x96 + x99)) + (-x111*x131 - x112*x133 + x113*x128 + 2*x114*x137 + x115*x129 + 2*x116*x140 - x117*x66 - x118*x68 + x119*x75 + x120*x77 + x121*x75 + x122*x77 + x130*x85 + x132*x87 - x134*x141 + x134*x142*x2 - x135*x141 + x135*x142*x8 + x136*x14*x142 + x136*x141 + x137*x143 + x139*x141 + x139*x142*x21 + x140*x143 + x48*x66 + x49*x68 - x59*(x124 + x127) - x61*(x125 + x127))/x45);
        break;

    default:
        break;
    }
        return result;
}

static double coder_dparam_d3gdp3(double T, double P, double n[6], int index) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double n6 = n[5];


        double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[1].mu0)(T, P);
    double x2 = x0 - x1;
    double x3 = n1*t;
    double x4 = exp(-x2*x3);
    double x5 = (*endmember[0].dmu0dP)(T, P);
    double x6 = x5 - (*endmember[1].dmu0dP)(T, P);
    double x7 = x4*x6;
    double x8 = (*endmember[2].mu0)(T, P);
    double x9 = x0 - x8;
    double x10 = exp(-x3*x9);
    double x11 = x5 - (*endmember[2].dmu0dP)(T, P);
    double x12 = x10*x11;
    double x13 = (*endmember[3].mu0)(T, P);
    double x14 = (*endmember[4].mu0)(T, P);
    double x15 = -x0;
    double x16 = x13 + x14 + x15;
    double x17 = exp(x16*x3);
    double x18 = (*endmember[3].dmu0dP)(T, P);
    double x19 = (*endmember[4].dmu0dP)(T, P);
    double x20 = -x5;
    double x21 = x18 + x19 + x20;
    double x22 = x17*x21;
    double x23 = (*endmember[5].mu0)(T, P);
    double x24 = 2*x14 + x15 + x23;
    double x25 = exp(x24*x3);
    double x26 = (*endmember[5].dmu0dP)(T, P);
    double x27 = 2*x19;
    double x28 = x20 + x26 + x27;
    double x29 = x25*x28;
    double x30 = x12 - x22 - x29 + x7;
    double x31 = ((x30)*(x30)*(x30));
    double x32 = x10 + x17 + x25 + x4 + exp(0);
    double x33 = pow(x32, -3);
    double x34 = ((n1)*(n1));
    double x35 = t*x34;
    double x36 = n1*x4;
    double x37 = x2*x36;
    double x38 = n1*x10;
    double x39 = x38*x9;
    double x40 = n1*x17;
    double x41 = x16*x40;
    double x42 = 3*x41;
    double x43 = n1*x25;
    double x44 = x24*x43;
    double x45 = 3*x44;
    double x46 = ((t)*(t));
    double x47 = x34*x46;
    double x48 = 2*x47;
    double x49 = n1*x7;
    double x50 = x2*x49;
    double x51 = n1*x12;
    double x52 = x51*x9;
    double x53 = -x18 - x19 + x5;
    double x54 = -x26 - x27 + x5;
    double x55 = (*endmember[0].d2mu0dP2)(T, P);
    double x56 = (*endmember[1].d2mu0dP2)(T, P);
    double x57 = x55 - x56;
    double x58 = (*endmember[2].d2mu0dP2)(T, P);
    double x59 = x55 - x58;
    double x60 = ((x6)*(x6));
    double x61 = x4*x60;
    double x62 = ((x11)*(x11));
    double x63 = x10*x62;
    double x64 = (*endmember[4].d2mu0dP2)(T, P);
    double x65 = -x55;
    double x66 = x64 + x65 + (*endmember[3].d2mu0dP2)(T, P);
    double x67 = x17*x66;
    double x68 = 2*x64 + x65 + (*endmember[5].d2mu0dP2)(T, P);
    double x69 = x25*x68;
    double x70 = ((x21)*(x21));
    double x71 = x17*x70;
    double x72 = ((x28)*(x28));
    double x73 = x25*x72;
    double x74 = -x10*x59 + x3*x61 + x3*x63 + x3*x71 + x3*x73 - x4*x57 + x67 + x69;
    double x75 = 3*n1;
    double x76 = pow(x32, -2);
    double x77 = x30*x76;
    double x78 = 3*x3;
    double x79 = x74*x78;
    double x80 = (*endmember[0].d3mu0dP3)(T, P);
    double x81 = (*endmember[1].d3mu0dP3)(T, P);
    double x82 = (*endmember[2].d3mu0dP3)(T, P);
    double x83 = (*endmember[4].d3mu0dP3)(T, P);
    double x84 = -x80;
    double x85 = x17*(x83 + x84 + (*endmember[3].d3mu0dP3)(T, P));
    double x86 = x4*((x6)*(x6)*(x6));
    double x87 = x10*((x11)*(x11)*(x11));
    double x88 = x25*(2*x83 + x84 + (*endmember[5].d3mu0dP3)(T, P));
    double x89 = x17*((x21)*(x21)*(x21));
    double x90 = 3*x57;
    double x91 = x7*x90;
    double x92 = 3*x59;
    double x93 = x12*x92;
    double x94 = x25*((x28)*(x28)*(x28));
    double x95 = x22*x66;
    double x96 = x29*x68;
    double x97 = x2*x35;
    double x98 = x35*x9;
    double x99 = n1*x16;
    double x100 = x16*x35;
    double x101 = n1*x24;
    double x102 = x24*x35;
    double x103 = 2*x35;
    double x104 = ((n1)*(n1)*(n1))*x46;

    
    double result = 0.0;
    switch (index) {
    case 0:
        result = n1*(-((x30)*(x30))*x33*x48*(x42*x53 + x45*x54 - 3*x50 - 3*x52) + x30*x33*x79*(2*x37 + 2*x39 - 2*x41 - 2*x44) - 4*x31*x33*x35 - x31*x48*(3*x37 + 3*x39 - x42 - x45)/((x32)*(x32)*(x32)*(x32)) + x74*x75*x77 + x76*x79*(x41*x53 + x44*x54 - x50 - x52) + x76*(x37 + x39 - x41 - x44)*(-x10*(x80 - x82) + x3*x91 + x3*x93 - x4*(x80 - x81) - x47*x86 - x47*x87 + x47*x89 + x47*x94 + x78*x95 + x78*x96 + x85 + x88) + x77*x78*(x100*x71 + x101*x69 + x102*x73 + x36*x60 - x37*(x56 + x65) + x38*x62 - x39*(x58 + x65) + x40*x70 + x43*x72 - x61*x97 - x63*x98 + x67*x99) + (3*x100*x95 + x101*x88 + 3*x102*x96 - x103*x86 - x103*x87 + x103*x89 + x103*x94 + x104*x16*x89 + x104*x2*x86 + x104*x24*x94 + x104*x87*x9 - x37*(x81 + x84) - x39*(x82 + x84) + x49*x90 + x51*x92 + x75*x95 + x75*x96 + x85*x99 - x91*x97 - x93*x98)/x32);
        break;

    default:
        break;
    }
        return result;
}
static void coder_dparam_dgdn(double T, double P, double n[6], int index, double result[6]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double n6 = n[5];

    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = -x0;
    double x2 = x1 + (*endmember[1].mu0)(T, P);
    double x3 = n1*t;
    double x4 = exp(x2*x3);
    double x5 = x1 + (*endmember[2].mu0)(T, P);
    double x6 = exp(x3*x5);
    double x7 = (*endmember[4].mu0)(T, P);
    double x8 = x1 + x7 + (*endmember[3].mu0)(T, P);
    double x9 = exp(x3*x8);
    double x10 = x1 + 2*x7 + (*endmember[5].mu0)(T, P);
    double x11 = exp(x10*x3);
    double x12 = x11 + x4 + x6 + x9 + exp(0);
    double x13 = 1.0/x12;
    double x14 = x2*x4;
    double x15 = t*x14;
    double x16 = x5*x6;
    double x17 = t*x16;
    double x18 = x8*x9;
    double x19 = t*x18;
    double x20 = x10*x11;
    double x21 = t*x20;

    switch (index) {
    case 0:
    result[0] = (x0 + x13*(((x10)*(x10))*x11*x3 + x14 + x16 + x18 + ((x2)*(x2))*x3*x4 + x20 + x3*((x5)*(x5))*x6 + x3*((x8)*(x8))*x9) + (-x15 - x17 - x19 - x21)*(n1*x14 + n1*x16 + n1*x18 + n1*x20)/((x12)*(x12)))/t - (t*x0 + x13*(x15 + x17 + x19 + x21))/((t)*(t));
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
        break;
    default:
        break;
    }
}

static int coder_get_param_number(void) {
    return 1;
}

static const char *paramNames[1] = {"t"};
static const char *paramUnits[1] = {"'None'"};

static const char **coder_get_param_names(void) {
    return paramNames;
}

static const char **coder_get_param_units(void) {
    return paramUnits;
}

static void coder_get_param_values(double **values) {
    (*values)[0] = t;

}

static int coder_set_param_values(double *values) {
    t = values[0];

    return 1;
}

static double coder_get_param_value(int index) {
    double result = 0.0;
    switch (index) {
    case 0:
        result = t;
        break;

    default:
        break;
    }
    return result;
}

static int coder_set_param_value(int index, double value) {
    int result = 1;
    switch (index) {
    case 0:
        t = value;
        break;

    default:
        result = 0;
        break;
    }
    return result;
}

