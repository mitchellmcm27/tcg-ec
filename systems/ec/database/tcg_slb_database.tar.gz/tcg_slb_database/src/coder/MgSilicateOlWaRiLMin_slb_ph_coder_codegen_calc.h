#include <math.h>

#include "coder_external_functions.h"


static double coder_g(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = n1*(*endmember[0].mu0)(T, P);
    double x1 = n1*(*endmember[1].mu0)(T, P);
    double x2 = n1*(*endmember[2].mu0)(T, P);

result = LMin(3, x0, x1, x2, x0, x1, x2);
    return result;
}
        
static void coder_dgdn(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[1].mu0)(T, P);
    double x2 = (*endmember[2].mu0)(T, P);

result[0] = LMin(3, x0, x1, x2, n1*x0, n1*x1, n1*x2);
result[1] = 0;
result[2] = 0;
}
        
static void coder_d2gdn2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = LMin(3, 0, 0, 0, n1*(*endmember[0].mu0)(T, P), n1*(*endmember[1].mu0)(T, P), n1*(*endmember[2].mu0)(T, P));
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d3gdn3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = LMin(3, 0, 0, 0, n1*(*endmember[0].mu0)(T, P), n1*(*endmember[1].mu0)(T, P), n1*(*endmember[2].mu0)(T, P));
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_dgdt(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[1].mu0)(T, P);
    double x2 = (*endmember[2].mu0)(T, P);

result = LMin(3, n1*(*endmember[0].dmu0dT)(T, P), n1*(*endmember[1].dmu0dT)(T, P), n1*(*endmember[2].dmu0dT)(T, P), n1*x0, n1*x1, n1*x2);
    return result;
}
        
static void coder_d2gdndt(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[1].mu0)(T, P);
    double x2 = (*endmember[2].mu0)(T, P);

result[0] = LMin(3, (*endmember[0].dmu0dT)(T, P), (*endmember[1].dmu0dT)(T, P), (*endmember[2].dmu0dT)(T, P), n1*x0, n1*x1, n1*x2);
result[1] = 0;
result[2] = 0;
}
        
static void coder_d3gdn2dt(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = LMin(3, 0, 0, 0, n1*(*endmember[0].mu0)(T, P), n1*(*endmember[1].mu0)(T, P), n1*(*endmember[2].mu0)(T, P));
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d4gdn3dt(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = LMin(3, 0, 0, 0, n1*(*endmember[0].mu0)(T, P), n1*(*endmember[1].mu0)(T, P), n1*(*endmember[2].mu0)(T, P));
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_dgdp(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[1].mu0)(T, P);
    double x2 = (*endmember[2].mu0)(T, P);

result = LMin(3, n1*(*endmember[0].dmu0dP)(T, P), n1*(*endmember[1].dmu0dP)(T, P), n1*(*endmember[2].dmu0dP)(T, P), n1*x0, n1*x1, n1*x2);
    return result;
}
        
static void coder_d2gdndp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[1].mu0)(T, P);
    double x2 = (*endmember[2].mu0)(T, P);

result[0] = LMin(3, (*endmember[0].dmu0dP)(T, P), (*endmember[1].dmu0dP)(T, P), (*endmember[2].dmu0dP)(T, P), n1*x0, n1*x1, n1*x2);
result[1] = 0;
result[2] = 0;
}
        
static void coder_d3gdn2dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = LMin(3, 0, 0, 0, n1*(*endmember[0].mu0)(T, P), n1*(*endmember[1].mu0)(T, P), n1*(*endmember[2].mu0)(T, P));
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d4gdn3dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = LMin(3, 0, 0, 0, n1*(*endmember[0].mu0)(T, P), n1*(*endmember[1].mu0)(T, P), n1*(*endmember[2].mu0)(T, P));
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d2gdt2(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[1].mu0)(T, P);
    double x2 = (*endmember[2].mu0)(T, P);

result = LMin(3, n1*(*endmember[0].d2mu0dT2)(T, P), n1*(*endmember[1].d2mu0dT2)(T, P), n1*(*endmember[2].d2mu0dT2)(T, P), n1*x0, n1*x1, n1*x2);
    return result;
}
        
static void coder_d3gdndt2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[1].mu0)(T, P);
    double x2 = (*endmember[2].mu0)(T, P);

result[0] = LMin(3, (*endmember[0].d2mu0dT2)(T, P), (*endmember[1].d2mu0dT2)(T, P), (*endmember[2].d2mu0dT2)(T, P), n1*x0, n1*x1, n1*x2);
result[1] = 0;
result[2] = 0;
}
        
static void coder_d4gdn2dt2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = LMin(3, 0, 0, 0, n1*(*endmember[0].mu0)(T, P), n1*(*endmember[1].mu0)(T, P), n1*(*endmember[2].mu0)(T, P));
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d5gdn3dt2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = LMin(3, 0, 0, 0, n1*(*endmember[0].mu0)(T, P), n1*(*endmember[1].mu0)(T, P), n1*(*endmember[2].mu0)(T, P));
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d2gdtdp(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[1].mu0)(T, P);
    double x2 = (*endmember[2].mu0)(T, P);

result = LMin(3, n1*(*endmember[0].d2mu0dTdP)(T, P), n1*(*endmember[1].d2mu0dTdP)(T, P), n1*(*endmember[2].d2mu0dTdP)(T, P), n1*x0, n1*x1, n1*x2);
    return result;
}
        
static void coder_d3gdndtdp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[1].mu0)(T, P);
    double x2 = (*endmember[2].mu0)(T, P);

result[0] = LMin(3, (*endmember[0].d2mu0dTdP)(T, P), (*endmember[1].d2mu0dTdP)(T, P), (*endmember[2].d2mu0dTdP)(T, P), n1*x0, n1*x1, n1*x2);
result[1] = 0;
result[2] = 0;
}
        
static void coder_d4gdn2dtdp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = LMin(3, 0, 0, 0, n1*(*endmember[0].mu0)(T, P), n1*(*endmember[1].mu0)(T, P), n1*(*endmember[2].mu0)(T, P));
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d5gdn3dtdp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = LMin(3, 0, 0, 0, n1*(*endmember[0].mu0)(T, P), n1*(*endmember[1].mu0)(T, P), n1*(*endmember[2].mu0)(T, P));
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d2gdp2(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[1].mu0)(T, P);
    double x2 = (*endmember[2].mu0)(T, P);

result = LMin(3, n1*(*endmember[0].d2mu0dP2)(T, P), n1*(*endmember[1].d2mu0dP2)(T, P), n1*(*endmember[2].d2mu0dP2)(T, P), n1*x0, n1*x1, n1*x2);
    return result;
}
        
static void coder_d3gdndp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[1].mu0)(T, P);
    double x2 = (*endmember[2].mu0)(T, P);

result[0] = LMin(3, (*endmember[0].d2mu0dP2)(T, P), (*endmember[1].d2mu0dP2)(T, P), (*endmember[2].d2mu0dP2)(T, P), n1*x0, n1*x1, n1*x2);
result[1] = 0;
result[2] = 0;
}
        
static void coder_d4gdn2dp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = LMin(3, 0, 0, 0, n1*(*endmember[0].mu0)(T, P), n1*(*endmember[1].mu0)(T, P), n1*(*endmember[2].mu0)(T, P));
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d5gdn3dp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = LMin(3, 0, 0, 0, n1*(*endmember[0].mu0)(T, P), n1*(*endmember[1].mu0)(T, P), n1*(*endmember[2].mu0)(T, P));
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d3gdt3(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[1].mu0)(T, P);
    double x2 = (*endmember[2].mu0)(T, P);

result = LMin(3, n1*(*endmember[0].d3mu0dT3)(T, P), n1*(*endmember[1].d3mu0dT3)(T, P), n1*(*endmember[2].d3mu0dT3)(T, P), n1*x0, n1*x1, n1*x2);
    return result;
}
        
static void coder_d4gdndt3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[1].mu0)(T, P);
    double x2 = (*endmember[2].mu0)(T, P);

result[0] = LMin(3, (*endmember[0].d3mu0dT3)(T, P), (*endmember[1].d3mu0dT3)(T, P), (*endmember[2].d3mu0dT3)(T, P), n1*x0, n1*x1, n1*x2);
result[1] = 0;
result[2] = 0;
}
        
static void coder_d5gdn2dt3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = LMin(3, 0, 0, 0, n1*(*endmember[0].mu0)(T, P), n1*(*endmember[1].mu0)(T, P), n1*(*endmember[2].mu0)(T, P));
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d6gdn3dt3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = LMin(3, 0, 0, 0, n1*(*endmember[0].mu0)(T, P), n1*(*endmember[1].mu0)(T, P), n1*(*endmember[2].mu0)(T, P));
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d3gdt2dp(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[1].mu0)(T, P);
    double x2 = (*endmember[2].mu0)(T, P);

result = LMin(3, n1*(*endmember[0].d3mu0dT2dP)(T, P), n1*(*endmember[1].d3mu0dT2dP)(T, P), n1*(*endmember[2].d3mu0dT2dP)(T, P), n1*x0, n1*x1, n1*x2);
    return result;
}
        
static void coder_d4gdndt2dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[1].mu0)(T, P);
    double x2 = (*endmember[2].mu0)(T, P);

result[0] = LMin(3, (*endmember[0].d3mu0dT2dP)(T, P), (*endmember[1].d3mu0dT2dP)(T, P), (*endmember[2].d3mu0dT2dP)(T, P), n1*x0, n1*x1, n1*x2);
result[1] = 0;
result[2] = 0;
}
        
static void coder_d5gdn2dt2dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = LMin(3, 0, 0, 0, n1*(*endmember[0].mu0)(T, P), n1*(*endmember[1].mu0)(T, P), n1*(*endmember[2].mu0)(T, P));
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d6gdn3dt2dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = LMin(3, 0, 0, 0, n1*(*endmember[0].mu0)(T, P), n1*(*endmember[1].mu0)(T, P), n1*(*endmember[2].mu0)(T, P));
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d3gdtdp2(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[1].mu0)(T, P);
    double x2 = (*endmember[2].mu0)(T, P);

result = LMin(3, n1*(*endmember[0].d3mu0dTdP2)(T, P), n1*(*endmember[1].d3mu0dTdP2)(T, P), n1*(*endmember[2].d3mu0dTdP2)(T, P), n1*x0, n1*x1, n1*x2);
    return result;
}
        
static void coder_d4gdndtdp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[1].mu0)(T, P);
    double x2 = (*endmember[2].mu0)(T, P);

result[0] = LMin(3, (*endmember[0].d3mu0dTdP2)(T, P), (*endmember[1].d3mu0dTdP2)(T, P), (*endmember[2].d3mu0dTdP2)(T, P), n1*x0, n1*x1, n1*x2);
result[1] = 0;
result[2] = 0;
}
        
static void coder_d5gdn2dtdp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = LMin(3, 0, 0, 0, n1*(*endmember[0].mu0)(T, P), n1*(*endmember[1].mu0)(T, P), n1*(*endmember[2].mu0)(T, P));
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d6gdn3dtdp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = LMin(3, 0, 0, 0, n1*(*endmember[0].mu0)(T, P), n1*(*endmember[1].mu0)(T, P), n1*(*endmember[2].mu0)(T, P));
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d3gdp3(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[1].mu0)(T, P);
    double x2 = (*endmember[2].mu0)(T, P);

result = LMin(3, n1*(*endmember[0].d3mu0dP3)(T, P), n1*(*endmember[1].d3mu0dP3)(T, P), n1*(*endmember[2].d3mu0dP3)(T, P), n1*x0, n1*x1, n1*x2);
    return result;
}
        
static void coder_d4gdndp3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[1].mu0)(T, P);
    double x2 = (*endmember[2].mu0)(T, P);

result[0] = LMin(3, (*endmember[0].d3mu0dP3)(T, P), (*endmember[1].d3mu0dP3)(T, P), (*endmember[2].d3mu0dP3)(T, P), n1*x0, n1*x1, n1*x2);
result[1] = 0;
result[2] = 0;
}
        
static void coder_d5gdn2dp3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = LMin(3, 0, 0, 0, n1*(*endmember[0].mu0)(T, P), n1*(*endmember[1].mu0)(T, P), n1*(*endmember[2].mu0)(T, P));
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d6gdn3dp3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = LMin(3, 0, 0, 0, n1*(*endmember[0].mu0)(T, P), n1*(*endmember[1].mu0)(T, P), n1*(*endmember[2].mu0)(T, P));
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_s(double T, double P, double n[3]) {
    double result = -coder_dgdt(T, P, n);
    return result;
}

static double coder_v(double T, double P, double n[3]) {
    double result = coder_dgdp(T, P, n);
    return result;
}

static double coder_cv(double T, double P, double n[3]) {
    double result = -T*coder_d2gdt2(T, P, n);
    double dvdt = coder_d2gdtdp(T, P, n);
    double dvdp = coder_d2gdp2(T, P, n);
    result += T*dvdt*dvdt/dvdp;
    return result;
}

static double coder_cp(double T, double P, double n[3]) {
    double result = -T*coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdt(double T, double P, double n[3]) {
    double result = -T*coder_d3gdt3(T, P, n) - coder_d2gdt2(T, P, n);
    return result;
}

static double coder_alpha(double T, double P, double n[3]) {
    double result = coder_d2gdtdp(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_beta(double T, double P, double n[3]) {
    double result = -coder_d2gdp2(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_K(double T, double P, double n[3]) {
    double result = -coder_dgdp(T, P, n)/coder_d2gdp2(T, P, n);
    return result;
}

static double coder_Kp(double T, double P, double n[3]) {
    double result = coder_dgdp(T, P, n);
    result *= coder_d3gdp3(T, P, n);
    result /= pow(coder_d2gdp2(T, P, n), 2.0);
    return result - 1.0;
}

