#include <math.h>

#include "coder_external_functions.h"


static double coder_dparam_g(double T, double P, double n[6], int index) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double n6 = n[5];


        double x0 = n1*(*endmember[0].mu0)(T, P);
    double x1 = n1*(*endmember[1].mu0)(T, P);
    double x2 = n1*(*endmember[2].mu0)(T, P);
    double x3 = (*endmember[4].mu0)(T, P);
    double x4 = n1*(x3 + (*endmember[3].mu0)(T, P));
    double x5 = n1*(2*x3 + (*endmember[5].mu0)(T, P));
    double x6 = LAbsMax(5, x0, x1, x2, x4, x5, x0, x1, x2, x4, x5);
    double x7 = -x6;
    double x8 = x0 + x7;
    double x9 = exp(t*x8);
    double x10 = x1 + x7;
    double x11 = exp(t*x10);
    double x12 = x2 + x7;
    double x13 = exp(t*x12);
    double x14 = x4 + x7;
    double x15 = exp(t*x14);
    double x16 = x5 + x7;
    double x17 = exp(t*x16);
    double x18 = x11 + x13 + x15 + x17 + x9;

    
    double result = 0.0;
    switch (index) {
    case 0:
        result = (x6 + (x10*x11 + x12*x13 + x14*x15 + x16*x17 + x8*x9)/x18)/t - (t*x6 + log(x18))/((t)*(t));
        break;

    default:
        break;
    }
        return result;
}

static double coder_dparam_dgdt(double T, double P, double n[6], int index) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double n6 = n[5];


        double x0 = (*endmember[0].mu0)(T, P);
    double x1 = n1*(*endmember[0].dmu0dT)(T, P);
    double x2 = (*endmember[1].mu0)(T, P);
    double x3 = n1*(*endmember[1].dmu0dT)(T, P);
    double x4 = (*endmember[2].mu0)(T, P);
    double x5 = n1*(*endmember[2].dmu0dT)(T, P);
    double x6 = (*endmember[3].mu0)(T, P);
    double x7 = (*endmember[4].mu0)(T, P);
    double x8 = (*endmember[4].dmu0dT)(T, P);
    double x9 = n1*(x8 + (*endmember[3].dmu0dT)(T, P));
    double x10 = (*endmember[5].mu0)(T, P);
    double x11 = n1*(2*x8 + (*endmember[5].dmu0dT)(T, P));
    double x12 = n1*x0;
    double x13 = n1*x2;
    double x14 = n1*x4;
    double x15 = n1*(x6 + x7);
    double x16 = n1*(x10 + 2*x7);
    double x17 = LAbsMax(5, x1, x3, x5, x9, x11, x12, x13, x14, x15, x16);
    double x18 = -LAbsMax(5, x12, x13, x14, x15, x16, x12, x13, x14, x15, x16);
    double x19 = x12 + x18;
    double x20 = t*x19;
    double x21 = exp(x20);
    double x22 = x13 + x18;
    double x23 = t*x22;
    double x24 = exp(x23);
    double x25 = x14 + x18;
    double x26 = t*x25;
    double x27 = exp(x26);
    double x28 = x15 + x18;
    double x29 = t*x28;
    double x30 = exp(x29);
    double x31 = x16 + x18;
    double x32 = t*x31;
    double x33 = exp(x32);
    double x34 = x21 + x24 + x27 + x30 + x33;
    double x35 = 1.0/x34;
    double x36 = -x17;
    double x37 = x21*(x1 + x36);
    double x38 = x24*(x3 + x36);
    double x39 = x27*(x36 + x5);
    double x40 = x30*(x36 + x9);
    double x41 = x33*(x11 + x36);
    double x42 = t*x37 + t*x38 + t*x39 + t*x40 + t*x41;

    
    double result = 0.0;
    switch (index) {
    case 0:
        result = (x17 + x35*(x20*x37 + x23*x38 + x26*x39 + x29*x40 + x32*x41 + x37 + x38 + x39 + x40 + x41) + x42*(-x19*x21 - x22*x24 - x25*x27 - x28*x30 - x31*x33)/((x34)*(x34)))/t - (t*x17 + x35*x42)/((t)*(t));
        break;

    default:
        break;
    }
        return result;
}

static double coder_dparam_dgdp(double T, double P, double n[6], int index) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double n6 = n[5];


        double x0 = (*endmember[0].mu0)(T, P);
    double x1 = n1*(*endmember[0].dmu0dP)(T, P);
    double x2 = (*endmember[1].mu0)(T, P);
    double x3 = n1*(*endmember[1].dmu0dP)(T, P);
    double x4 = (*endmember[2].mu0)(T, P);
    double x5 = n1*(*endmember[2].dmu0dP)(T, P);
    double x6 = (*endmember[3].mu0)(T, P);
    double x7 = (*endmember[4].mu0)(T, P);
    double x8 = (*endmember[4].dmu0dP)(T, P);
    double x9 = n1*(x8 + (*endmember[3].dmu0dP)(T, P));
    double x10 = (*endmember[5].mu0)(T, P);
    double x11 = n1*(2*x8 + (*endmember[5].dmu0dP)(T, P));
    double x12 = n1*x0;
    double x13 = n1*x2;
    double x14 = n1*x4;
    double x15 = n1*(x6 + x7);
    double x16 = n1*(x10 + 2*x7);
    double x17 = LAbsMax(5, x1, x3, x5, x9, x11, x12, x13, x14, x15, x16);
    double x18 = -LAbsMax(5, x12, x13, x14, x15, x16, x12, x13, x14, x15, x16);
    double x19 = x12 + x18;
    double x20 = t*x19;
    double x21 = exp(x20);
    double x22 = x13 + x18;
    double x23 = t*x22;
    double x24 = exp(x23);
    double x25 = x14 + x18;
    double x26 = t*x25;
    double x27 = exp(x26);
    double x28 = x15 + x18;
    double x29 = t*x28;
    double x30 = exp(x29);
    double x31 = x16 + x18;
    double x32 = t*x31;
    double x33 = exp(x32);
    double x34 = x21 + x24 + x27 + x30 + x33;
    double x35 = 1.0/x34;
    double x36 = -x17;
    double x37 = x21*(x1 + x36);
    double x38 = x24*(x3 + x36);
    double x39 = x27*(x36 + x5);
    double x40 = x30*(x36 + x9);
    double x41 = x33*(x11 + x36);
    double x42 = t*x37 + t*x38 + t*x39 + t*x40 + t*x41;

    
    double result = 0.0;
    switch (index) {
    case 0:
        result = (x17 + x35*(x20*x37 + x23*x38 + x26*x39 + x29*x40 + x32*x41 + x37 + x38 + x39 + x40 + x41) + x42*(-x19*x21 - x22*x24 - x25*x27 - x28*x30 - x31*x33)/((x34)*(x34)))/t - (t*x17 + x35*x42)/((t)*(t));
        break;

    default:
        break;
    }
        return result;
}

static double coder_dparam_d2gdt2(double T, double P, double n[6], int index) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double n6 = n[5];


        double x0 = (*endmember[0].mu0)(T, P);
    double x1 = n1*x0;
    double x2 = (*endmember[1].mu0)(T, P);
    double x3 = n1*x2;
    double x4 = (*endmember[2].mu0)(T, P);
    double x5 = n1*x4;
    double x6 = (*endmember[3].mu0)(T, P);
    double x7 = (*endmember[4].mu0)(T, P);
    double x8 = n1*(x6 + x7);
    double x9 = (*endmember[5].mu0)(T, P);
    double x10 = n1*(2*x7 + x9);
    double x11 = -LAbsMax(5, x1, x3, x5, x8, x10, x1, x3, x5, x8, x10);
    double x12 = x1 + x11;
    double x13 = t*x12;
    double x14 = exp(x13);
    double x15 = x11 + x3;
    double x16 = t*x15;
    double x17 = exp(x16);
    double x18 = x11 + x5;
    double x19 = t*x18;
    double x20 = exp(x19);
    double x21 = x11 + x8;
    double x22 = t*x21;
    double x23 = exp(x22);
    double x24 = x10 + x11;
    double x25 = t*x24;
    double x26 = exp(x25);
    double x27 = x14 + x17 + x20 + x23 + x26;
    double x28 = pow(x27, -2);
    double x29 = n1*(*endmember[0].dmu0dT)(T, P);
    double x30 = n1*(*endmember[1].dmu0dT)(T, P);
    double x31 = n1*(*endmember[2].dmu0dT)(T, P);
    double x32 = (*endmember[4].dmu0dT)(T, P);
    double x33 = n1*(x32 + (*endmember[3].dmu0dT)(T, P));
    double x34 = n1*(2*x32 + (*endmember[5].dmu0dT)(T, P));
    double x35 = -LAbsMax(5, x29, x30, x31, x33, x34, x1, x3, x5, x8, x10);
    double x36 = x29 + x35;
    double x37 = x14*x36;
    double x38 = x30 + x35;
    double x39 = x17*x38;
    double x40 = x31 + x35;
    double x41 = x20*x40;
    double x42 = x33 + x35;
    double x43 = x23*x42;
    double x44 = x34 + x35;
    double x45 = x26*x44;
    double x46 = x37 + x39 + x41 + x43 + x45;
    double x47 = ((x46)*(x46));
    double x48 = x12*x14;
    double x49 = x15*x17;
    double x50 = x18*x20;
    double x51 = x21*x23;
    double x52 = x24*x26;
    double x53 = n1*(*endmember[0].d2mu0dT2)(T, P);
    double x54 = n1*(*endmember[1].d2mu0dT2)(T, P);
    double x55 = n1*(*endmember[2].d2mu0dT2)(T, P);
    double x56 = (*endmember[4].d2mu0dT2)(T, P);
    double x57 = n1*(x56 + (*endmember[3].d2mu0dT2)(T, P));
    double x58 = n1*(2*x56 + (*endmember[5].d2mu0dT2)(T, P));
    double x59 = -LAbsMax(5, x53, x54, x55, x57, x58, x1, x3, x5, x8, x10);
    double x60 = x53 + x59;
    double x61 = x54 + x59;
    double x62 = x55 + x59;
    double x63 = x14*((x36)*(x36));
    double x64 = x17*((x38)*(x38));
    double x65 = x20*((x40)*(x40));
    double x66 = x57 + x59;
    double x67 = x23*((x42)*(x42));
    double x68 = x58 + x59;
    double x69 = x26*((x44)*(x44));

    
    double result = 0.0;
    switch (index) {
    case 0:
        result = -t*x28*x46*(2*x12*x37 + 2*x15*x39 + 2*x18*x41 + 2*x21*x43 + 2*x24*x45) - t*x47*(-2*x48 - 2*x49 - 2*x50 - 2*x51 - 2*x52)/((x27)*(x27)*(x27)) - x28*x47 + x28*(-x48 - x49 - x50 - x51 - x52)*(t*x63 + t*x64 + t*x65 + t*x67 + t*x69 + x14*x60 + x17*x61 + x20*x62 + x23*x66 + x26*x68) + (x13*x63 + x16*x64 + x19*x65 + x22*x67 + x25*x69 + x48*x60 + x49*x61 + x50*x62 + x51*x66 + x52*x68 + x63 + x64 + x65 + x67 + x69)/x27;
        break;

    default:
        break;
    }
        return result;
}

static double coder_dparam_d2gdtdp(double T, double P, double n[6], int index) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double n6 = n[5];


        double x0 = (*endmember[0].mu0)(T, P);
    double x1 = n1*x0;
    double x2 = (*endmember[1].mu0)(T, P);
    double x3 = n1*x2;
    double x4 = (*endmember[2].mu0)(T, P);
    double x5 = n1*x4;
    double x6 = (*endmember[3].mu0)(T, P);
    double x7 = (*endmember[4].mu0)(T, P);
    double x8 = n1*(x6 + x7);
    double x9 = (*endmember[5].mu0)(T, P);
    double x10 = n1*(2*x7 + x9);
    double x11 = -LAbsMax(5, x1, x3, x5, x8, x10, x1, x3, x5, x8, x10);
    double x12 = x1 + x11;
    double x13 = t*x12;
    double x14 = exp(x13);
    double x15 = n1*(*endmember[0].dmu0dT)(T, P);
    double x16 = n1*(*endmember[1].dmu0dT)(T, P);
    double x17 = n1*(*endmember[2].dmu0dT)(T, P);
    double x18 = (*endmember[4].dmu0dT)(T, P);
    double x19 = n1*(x18 + (*endmember[3].dmu0dT)(T, P));
    double x20 = n1*(2*x18 + (*endmember[5].dmu0dT)(T, P));
    double x21 = -LAbsMax(5, x15, x16, x17, x19, x20, x1, x3, x5, x8, x10);
    double x22 = x15 + x21;
    double x23 = x11 + x3;
    double x24 = t*x23;
    double x25 = exp(x24);
    double x26 = x16 + x21;
    double x27 = x11 + x5;
    double x28 = t*x27;
    double x29 = exp(x28);
    double x30 = x17 + x21;
    double x31 = x11 + x8;
    double x32 = t*x31;
    double x33 = exp(x32);
    double x34 = x19 + x21;
    double x35 = x10 + x11;
    double x36 = t*x35;
    double x37 = exp(x36);
    double x38 = x20 + x21;
    double x39 = x14*x22 + x25*x26 + x29*x30 + x33*x34 + x37*x38;
    double x40 = x14 + x25 + x29 + x33 + x37;
    double x41 = pow(x40, -2);
    double x42 = n1*(*endmember[0].dmu0dP)(T, P);
    double x43 = n1*(*endmember[1].dmu0dP)(T, P);
    double x44 = n1*(*endmember[2].dmu0dP)(T, P);
    double x45 = (*endmember[4].dmu0dP)(T, P);
    double x46 = n1*(x45 + (*endmember[3].dmu0dP)(T, P));
    double x47 = n1*(2*x45 + (*endmember[5].dmu0dP)(T, P));
    double x48 = -LAbsMax(5, x42, x43, x44, x46, x47, x1, x3, x5, x8, x10);
    double x49 = x42 + x48;
    double x50 = x14*x49;
    double x51 = x43 + x48;
    double x52 = x25*x51;
    double x53 = x44 + x48;
    double x54 = x29*x53;
    double x55 = x46 + x48;
    double x56 = x33*x55;
    double x57 = x47 + x48;
    double x58 = x37*x57;
    double x59 = x50 + x52 + x54 + x56 + x58;
    double x60 = x41*x59;
    double x61 = x12*x14;
    double x62 = x23*x25;
    double x63 = x27*x29;
    double x64 = x31*x33;
    double x65 = x35*x37;
    double x66 = t*x39;
    double x67 = n1*(*endmember[0].d2mu0dTdP)(T, P);
    double x68 = n1*(*endmember[1].d2mu0dTdP)(T, P);
    double x69 = n1*(*endmember[2].d2mu0dTdP)(T, P);
    double x70 = (*endmember[4].d2mu0dTdP)(T, P);
    double x71 = n1*(x70 + (*endmember[3].d2mu0dTdP)(T, P));
    double x72 = n1*(2*x70 + (*endmember[5].d2mu0dTdP)(T, P));
    double x73 = -LAbsMax(5, x67, x68, x69, x71, x72, x1, x3, x5, x8, x10);
    double x74 = x67 + x73;
    double x75 = x68 + x73;
    double x76 = x69 + x73;
    double x77 = x71 + x73;
    double x78 = x72 + x73;
    double x79 = x22*x50;
    double x80 = x26*x52;
    double x81 = x30*x54;
    double x82 = x34*x56;
    double x83 = x38*x58;

    
    double result = 0.0;
    switch (index) {
    case 0:
        result = -t*x60*(x22*x61 + x26*x62 + x30*x63 + x34*x64 + x38*x65) - x39*x60 - x41*x66*(x49*x61 + x51*x62 + x53*x63 + x55*x64 + x57*x65) + x41*(-x61 - x62 - x63 - x64 - x65)*(t*x79 + t*x80 + t*x81 + t*x82 + t*x83 + x14*x74 + x25*x75 + x29*x76 + x33*x77 + x37*x78) + (x13*x79 + x24*x80 + x28*x81 + x32*x82 + x36*x83 + x61*x74 + x62*x75 + x63*x76 + x64*x77 + x65*x78 + x79 + x80 + x81 + x82 + x83)/x40 - x59*x66*(-2*x61 - 2*x62 - 2*x63 - 2*x64 - 2*x65)/((x40)*(x40)*(x40));
        break;

    default:
        break;
    }
        return result;
}

static double coder_dparam_d2gdp2(double T, double P, double n[6], int index) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double n6 = n[5];


        double x0 = (*endmember[0].mu0)(T, P);
    double x1 = n1*x0;
    double x2 = (*endmember[1].mu0)(T, P);
    double x3 = n1*x2;
    double x4 = (*endmember[2].mu0)(T, P);
    double x5 = n1*x4;
    double x6 = (*endmember[3].mu0)(T, P);
    double x7 = (*endmember[4].mu0)(T, P);
    double x8 = n1*(x6 + x7);
    double x9 = (*endmember[5].mu0)(T, P);
    double x10 = n1*(2*x7 + x9);
    double x11 = -LAbsMax(5, x1, x3, x5, x8, x10, x1, x3, x5, x8, x10);
    double x12 = x1 + x11;
    double x13 = t*x12;
    double x14 = exp(x13);
    double x15 = x11 + x3;
    double x16 = t*x15;
    double x17 = exp(x16);
    double x18 = x11 + x5;
    double x19 = t*x18;
    double x20 = exp(x19);
    double x21 = x11 + x8;
    double x22 = t*x21;
    double x23 = exp(x22);
    double x24 = x10 + x11;
    double x25 = t*x24;
    double x26 = exp(x25);
    double x27 = x14 + x17 + x20 + x23 + x26;
    double x28 = pow(x27, -2);
    double x29 = n1*(*endmember[0].dmu0dP)(T, P);
    double x30 = n1*(*endmember[1].dmu0dP)(T, P);
    double x31 = n1*(*endmember[2].dmu0dP)(T, P);
    double x32 = (*endmember[4].dmu0dP)(T, P);
    double x33 = n1*(x32 + (*endmember[3].dmu0dP)(T, P));
    double x34 = n1*(2*x32 + (*endmember[5].dmu0dP)(T, P));
    double x35 = -LAbsMax(5, x29, x30, x31, x33, x34, x1, x3, x5, x8, x10);
    double x36 = x29 + x35;
    double x37 = x14*x36;
    double x38 = x30 + x35;
    double x39 = x17*x38;
    double x40 = x31 + x35;
    double x41 = x20*x40;
    double x42 = x33 + x35;
    double x43 = x23*x42;
    double x44 = x34 + x35;
    double x45 = x26*x44;
    double x46 = x37 + x39 + x41 + x43 + x45;
    double x47 = ((x46)*(x46));
    double x48 = x12*x14;
    double x49 = x15*x17;
    double x50 = x18*x20;
    double x51 = x21*x23;
    double x52 = x24*x26;
    double x53 = n1*(*endmember[0].d2mu0dP2)(T, P);
    double x54 = n1*(*endmember[1].d2mu0dP2)(T, P);
    double x55 = n1*(*endmember[2].d2mu0dP2)(T, P);
    double x56 = (*endmember[4].d2mu0dP2)(T, P);
    double x57 = n1*(x56 + (*endmember[3].d2mu0dP2)(T, P));
    double x58 = n1*(2*x56 + (*endmember[5].d2mu0dP2)(T, P));
    double x59 = -LAbsMax(5, x53, x54, x55, x57, x58, x1, x3, x5, x8, x10);
    double x60 = x53 + x59;
    double x61 = x54 + x59;
    double x62 = x55 + x59;
    double x63 = x14*((x36)*(x36));
    double x64 = x17*((x38)*(x38));
    double x65 = x20*((x40)*(x40));
    double x66 = x57 + x59;
    double x67 = x23*((x42)*(x42));
    double x68 = x58 + x59;
    double x69 = x26*((x44)*(x44));

    
    double result = 0.0;
    switch (index) {
    case 0:
        result = -t*x28*x46*(2*x12*x37 + 2*x15*x39 + 2*x18*x41 + 2*x21*x43 + 2*x24*x45) - t*x47*(-2*x48 - 2*x49 - 2*x50 - 2*x51 - 2*x52)/((x27)*(x27)*(x27)) - x28*x47 + x28*(-x48 - x49 - x50 - x51 - x52)*(t*x63 + t*x64 + t*x65 + t*x67 + t*x69 + x14*x60 + x17*x61 + x20*x62 + x23*x66 + x26*x68) + (x13*x63 + x16*x64 + x19*x65 + x22*x67 + x25*x69 + x48*x60 + x49*x61 + x50*x62 + x51*x66 + x52*x68 + x63 + x64 + x65 + x67 + x69)/x27;
        break;

    default:
        break;
    }
        return result;
}

static double coder_dparam_d3gdt3(double T, double P, double n[6], int index) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double n6 = n[5];


        double x0 = (*endmember[0].mu0)(T, P);
    double x1 = n1*x0;
    double x2 = (*endmember[1].mu0)(T, P);
    double x3 = n1*x2;
    double x4 = (*endmember[2].mu0)(T, P);
    double x5 = n1*x4;
    double x6 = (*endmember[3].mu0)(T, P);
    double x7 = (*endmember[4].mu0)(T, P);
    double x8 = n1*(x6 + x7);
    double x9 = (*endmember[5].mu0)(T, P);
    double x10 = n1*(2*x7 + x9);
    double x11 = -LAbsMax(5, x1, x3, x5, x8, x10, x1, x3, x5, x8, x10);
    double x12 = x1 + x11;
    double x13 = t*x12;
    double x14 = exp(x13);
    double x15 = n1*(*endmember[0].dmu0dT)(T, P);
    double x16 = n1*(*endmember[1].dmu0dT)(T, P);
    double x17 = n1*(*endmember[2].dmu0dT)(T, P);
    double x18 = (*endmember[4].dmu0dT)(T, P);
    double x19 = n1*(x18 + (*endmember[3].dmu0dT)(T, P));
    double x20 = n1*(2*x18 + (*endmember[5].dmu0dT)(T, P));
    double x21 = LAbsMax(5, x15, x16, x17, x19, x20, x1, x3, x5, x8, x10);
    double x22 = -x21;
    double x23 = x15 + x22;
    double x24 = x14*x23;
    double x25 = x11 + x3;
    double x26 = t*x25;
    double x27 = exp(x26);
    double x28 = x16 + x22;
    double x29 = x27*x28;
    double x30 = x11 + x5;
    double x31 = t*x30;
    double x32 = exp(x31);
    double x33 = x17 + x22;
    double x34 = x32*x33;
    double x35 = x11 + x8;
    double x36 = t*x35;
    double x37 = exp(x36);
    double x38 = x19 + x22;
    double x39 = x37*x38;
    double x40 = x10 + x11;
    double x41 = t*x40;
    double x42 = exp(x41);
    double x43 = x20 + x22;
    double x44 = x42*x43;
    double x45 = x24 + x29 + x34 + x39 + x44;
    double x46 = ((x45)*(x45)*(x45));
    double x47 = x14 + x27 + x32 + x37 + x42;
    double x48 = pow(x47, -3);
    double x49 = t*x48;
    double x50 = x12*x14;
    double x51 = x25*x27;
    double x52 = x30*x32;
    double x53 = x35*x37;
    double x54 = x40*x42;
    double x55 = ((t)*(t));
    double x56 = 2*x55;
    double x57 = x23*x50;
    double x58 = x28*x51;
    double x59 = x33*x52;
    double x60 = x38*x53;
    double x61 = x43*x54;
    double x62 = n1*(*endmember[0].d2mu0dT2)(T, P);
    double x63 = n1*(*endmember[1].d2mu0dT2)(T, P);
    double x64 = n1*(*endmember[2].d2mu0dT2)(T, P);
    double x65 = (*endmember[4].d2mu0dT2)(T, P);
    double x66 = n1*(x65 + (*endmember[3].d2mu0dT2)(T, P));
    double x67 = n1*(2*x65 + (*endmember[5].d2mu0dT2)(T, P));
    double x68 = -LAbsMax(5, x62, x63, x64, x66, x67, x1, x3, x5, x8, x10);
    double x69 = x62 + x68;
    double x70 = x14*x69;
    double x71 = x63 + x68;
    double x72 = x27*x71;
    double x73 = x64 + x68;
    double x74 = x32*x73;
    double x75 = x14*((x23)*(x23));
    double x76 = x27*((x28)*(x28));
    double x77 = x32*((x33)*(x33));
    double x78 = x66 + x68;
    double x79 = x37*x78;
    double x80 = x37*((x38)*(x38));
    double x81 = x67 + x68;
    double x82 = x42*x81;
    double x83 = x42*((x43)*(x43));
    double x84 = t*x75 + t*x76 + t*x77 + t*x80 + t*x83 + x70 + x72 + x74 + x79 + x82;
    double x85 = pow(x47, -2);
    double x86 = 3*x45*x85;
    double x87 = 3*t;
    double x88 = n1*(*endmember[0].d3mu0dT3)(T, P);
    double x89 = n1*(*endmember[1].d3mu0dT3)(T, P);
    double x90 = n1*(*endmember[2].d3mu0dT3)(T, P);
    double x91 = (*endmember[4].d3mu0dT3)(T, P);
    double x92 = n1*(x91 + (*endmember[3].d3mu0dT3)(T, P));
    double x93 = n1*(2*x91 + (*endmember[5].d3mu0dT3)(T, P));
    double x94 = -LAbsMax(5, x88, x89, x90, x92, x93, x1, x3, x5, x8, x10);
    double x95 = x88 + x94;
    double x96 = x89 + x94;
    double x97 = x90 + x94;
    double x98 = ((x23)*(x23)*(x23));
    double x99 = x14*x98;
    double x100 = ((x28)*(x28)*(x28));
    double x101 = x100*x27;
    double x102 = ((x33)*(x33)*(x33));
    double x103 = x102*x32;
    double x104 = x92 + x94;
    double x105 = x93 + x94;
    double x106 = ((x38)*(x38)*(x38));
    double x107 = x106*x37;
    double x108 = ((x43)*(x43)*(x43));
    double x109 = x108*x42;
    double x110 = x24*x69;
    double x111 = x29*x71;
    double x112 = x34*x73;
    double x113 = x39*x78;
    double x114 = x44*x81;
    double x115 = 2*t;
    double x116 = -3*x21;

    
    double result = 0.0;
    switch (index) {
    case 0:
        result = -t*x86*(x13*x75 + x26*x76 + x31*x77 + x36*x80 + x41*x83 + x50*x69 + x51*x71 + x52*x73 + x53*x78 + x54*x81 + x75 + x76 + x77 + x80 + x83) + ((x45)*(x45))*x48*x56*(3*x57 + 3*x58 + 3*x59 + 3*x60 + 3*x61) - 3*x45*x49*x84*(-2*x50 - 2*x51 - 2*x52 - 2*x53 - 2*x54) + 4*x46*x49 + x46*x56*(-3*x50 - 3*x51 - 3*x52 - 3*x53 - 3*x54)/((x47)*(x47)*(x47)*(x47)) - x84*x85*x87*(x57 + x58 + x59 + x60 + x61) - x84*x86 + x85*(-x50 - x51 - x52 - x53 - x54)*(x101*x55 + x103*x55 + x104*x37 + x105*x42 + x107*x55 + x109*x55 + x110*x87 + x111*x87 + x112*x87 + x113*x87 + x114*x87 + x14*x95 + x27*x96 + x32*x97 + x55*x99) + (x100*x51*x55 + x101*x115 + x102*x52*x55 + x103*x115 + x104*x53 + x105*x54 + x106*x53*x55 + x107*x115 + x108*x54*x55 + x109*x115 + 3*x110*x13 + 3*x111*x26 + 3*x112*x31 + 3*x113*x36 + 3*x114*x41 + x115*x99 + x50*x55*x98 + x50*x95 + x51*x96 + x52*x97 + x70*(x116 + 3*x15) + x72*(x116 + 3*x16) + x74*(x116 + 3*x17) + x79*(x116 + 3*x19) + x82*(x116 + 3*x20))/x47;
        break;

    default:
        break;
    }
        return result;
}

static double coder_dparam_d3gdt2dp(double T, double P, double n[6], int index) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double n6 = n[5];


        double x0 = (*endmember[0].mu0)(T, P);
    double x1 = n1*x0;
    double x2 = (*endmember[1].mu0)(T, P);
    double x3 = n1*x2;
    double x4 = (*endmember[2].mu0)(T, P);
    double x5 = n1*x4;
    double x6 = (*endmember[3].mu0)(T, P);
    double x7 = (*endmember[4].mu0)(T, P);
    double x8 = n1*(x6 + x7);
    double x9 = (*endmember[5].mu0)(T, P);
    double x10 = n1*(2*x7 + x9);
    double x11 = -LAbsMax(5, x1, x3, x5, x8, x10, x1, x3, x5, x8, x10);
    double x12 = x1 + x11;
    double x13 = t*x12;
    double x14 = exp(x13);
    double x15 = n1*(*endmember[0].dmu0dT)(T, P);
    double x16 = n1*(*endmember[1].dmu0dT)(T, P);
    double x17 = n1*(*endmember[2].dmu0dT)(T, P);
    double x18 = (*endmember[4].dmu0dT)(T, P);
    double x19 = n1*(x18 + (*endmember[3].dmu0dT)(T, P));
    double x20 = n1*(2*x18 + (*endmember[5].dmu0dT)(T, P));
    double x21 = LAbsMax(5, x15, x16, x17, x19, x20, x1, x3, x5, x8, x10);
    double x22 = -x21;
    double x23 = x15 + x22;
    double x24 = x14*x23;
    double x25 = x11 + x3;
    double x26 = t*x25;
    double x27 = exp(x26);
    double x28 = x16 + x22;
    double x29 = x27*x28;
    double x30 = x11 + x5;
    double x31 = t*x30;
    double x32 = exp(x31);
    double x33 = x17 + x22;
    double x34 = x32*x33;
    double x35 = x11 + x8;
    double x36 = t*x35;
    double x37 = exp(x36);
    double x38 = x19 + x22;
    double x39 = x37*x38;
    double x40 = x10 + x11;
    double x41 = t*x40;
    double x42 = exp(x41);
    double x43 = x20 + x22;
    double x44 = x42*x43;
    double x45 = x24 + x29 + x34 + x39 + x44;
    double x46 = ((x45)*(x45));
    double x47 = x14 + x27 + x32 + x37 + x42;
    double x48 = pow(x47, -3);
    double x49 = x46*x48;
    double x50 = n1*(*endmember[0].dmu0dP)(T, P);
    double x51 = n1*(*endmember[1].dmu0dP)(T, P);
    double x52 = n1*(*endmember[2].dmu0dP)(T, P);
    double x53 = (*endmember[4].dmu0dP)(T, P);
    double x54 = n1*(x53 + (*endmember[3].dmu0dP)(T, P));
    double x55 = n1*(2*x53 + (*endmember[5].dmu0dP)(T, P));
    double x56 = -LAbsMax(5, x50, x51, x52, x54, x55, x1, x3, x5, x8, x10);
    double x57 = x50 + x56;
    double x58 = x14*x57;
    double x59 = x51 + x56;
    double x60 = x27*x59;
    double x61 = x52 + x56;
    double x62 = x32*x61;
    double x63 = x54 + x56;
    double x64 = x37*x63;
    double x65 = x55 + x56;
    double x66 = x42*x65;
    double x67 = x58 + x60 + x62 + x64 + x66;
    double x68 = t*x67;
    double x69 = x12*x14;
    double x70 = x57*x69;
    double x71 = x25*x27;
    double x72 = x59*x71;
    double x73 = x30*x32;
    double x74 = x61*x73;
    double x75 = x35*x37;
    double x76 = x63*x75;
    double x77 = x40*x42;
    double x78 = x65*x77;
    double x79 = x70 + x72 + x74 + x76 + x78;
    double x80 = ((t)*(t));
    double x81 = 2*x80;
    double x82 = n1*(*endmember[0].d2mu0dT2)(T, P);
    double x83 = n1*(*endmember[1].d2mu0dT2)(T, P);
    double x84 = n1*(*endmember[2].d2mu0dT2)(T, P);
    double x85 = (*endmember[4].d2mu0dT2)(T, P);
    double x86 = n1*(x85 + (*endmember[3].d2mu0dT2)(T, P));
    double x87 = n1*(2*x85 + (*endmember[5].d2mu0dT2)(T, P));
    double x88 = -LAbsMax(5, x82, x83, x84, x86, x87, x1, x3, x5, x8, x10);
    double x89 = x82 + x88;
    double x90 = x83 + x88;
    double x91 = x84 + x88;
    double x92 = ((x23)*(x23));
    double x93 = x14*x92;
    double x94 = ((x28)*(x28));
    double x95 = x27*x94;
    double x96 = ((x33)*(x33));
    double x97 = x32*x96;
    double x98 = x86 + x88;
    double x99 = ((x38)*(x38));
    double x100 = x37*x99;
    double x101 = x87 + x88;
    double x102 = ((x43)*(x43));
    double x103 = x102*x42;
    double x104 = t*x100 + t*x103 + t*x93 + t*x95 + t*x97 + x101*x42 + x14*x89 + x27*x90 + x32*x91 + x37*x98;
    double x105 = pow(x47, -2);
    double x106 = x105*x67;
    double x107 = x23*x69;
    double x108 = x28*x71;
    double x109 = x33*x73;
    double x110 = x38*x75;
    double x111 = x43*x77;
    double x112 = 2*x45;
    double x113 = t*x105;
    double x114 = n1*(*endmember[0].d2mu0dTdP)(T, P);
    double x115 = n1*(*endmember[1].d2mu0dTdP)(T, P);
    double x116 = n1*(*endmember[2].d2mu0dTdP)(T, P);
    double x117 = (*endmember[4].d2mu0dTdP)(T, P);
    double x118 = n1*(x117 + (*endmember[3].d2mu0dTdP)(T, P));
    double x119 = n1*(2*x117 + (*endmember[5].d2mu0dTdP)(T, P));
    double x120 = -LAbsMax(5, x114, x115, x116, x118, x119, x1, x3, x5, x8, x10);
    double x121 = x114 + x120;
    double x122 = x121*x14;
    double x123 = x115 + x120;
    double x124 = x123*x27;
    double x125 = x116 + x120;
    double x126 = x125*x32;
    double x127 = x118 + x120;
    double x128 = x127*x37;
    double x129 = x119 + x120;
    double x130 = x129*x42;
    double x131 = x23*x58;
    double x132 = x28*x60;
    double x133 = x33*x62;
    double x134 = x38*x64;
    double x135 = x43*x66;
    double x136 = t*x131 + t*x132 + t*x133 + t*x134 + t*x135 + x122 + x124 + x126 + x128 + x130;
    double x137 = x105*x112;
    double x138 = x48*(-2*x69 - 2*x71 - 2*x73 - 2*x75 - 2*x77);
    double x139 = n1*(*endmember[0].d3mu0dT2dP)(T, P);
    double x140 = n1*(*endmember[1].d3mu0dT2dP)(T, P);
    double x141 = n1*(*endmember[2].d3mu0dT2dP)(T, P);
    double x142 = (*endmember[4].d3mu0dT2dP)(T, P);
    double x143 = n1*(x142 + (*endmember[3].d3mu0dT2dP)(T, P));
    double x144 = n1*(2*x142 + (*endmember[5].d3mu0dT2dP)(T, P));
    double x145 = -LAbsMax(5, x139, x140, x141, x143, x144, x1, x3, x5, x8, x10);
    double x146 = x139 + x145;
    double x147 = x140 + x145;
    double x148 = x141 + x145;
    double x149 = x143 + x145;
    double x150 = x144 + x145;
    double x151 = x58*x89;
    double x152 = x60*x90;
    double x153 = x62*x91;
    double x154 = x58*x92;
    double x155 = x60*x94;
    double x156 = x62*x96;
    double x157 = x64*x98;
    double x158 = x64*x99;
    double x159 = 2*t;
    double x160 = x121*x24;
    double x161 = x123*x29;
    double x162 = x125*x34;
    double x163 = x101*x66;
    double x164 = x102*x66;
    double x165 = x127*x39;
    double x166 = x129*x44;
    double x167 = -2*x21;

    
    double result = 0.0;
    switch (index) {
    case 0:
        result = -t*x106*(x100*x36 + x100 + x101*x77 + x103*x41 + x103 + x13*x93 + x26*x95 + x31*x97 + x69*x89 + x71*x90 + x73*x91 + x75*x98 + x93 + x95 + x97) - t*x112*x136*x138 - t*x137*(x121*x69 + x123*x71 + x125*x73 + x127*x75 + x129*x77 + x13*x131 + x131 + x132*x26 + x132 + x133*x31 + x133 + x134*x36 + x134 + x135*x41 + x135) - x104*x106 - x104*x113*x79 - x104*x138*x68 + x105*(-x69 - x71 - x73 - x75 - x77)*(t*x151 + t*x152 + t*x153 + t*x157 + t*x163 + x14*x146 + x147*x27 + x148*x32 + x149*x37 + x150*x42 + x154*x80 + x155*x80 + x156*x80 + x158*x80 + x159*x160 + x159*x161 + x159*x162 + x159*x165 + x159*x166 + x164*x80) + x112*x48*x67*x80*(2*x107 + 2*x108 + 2*x109 + 2*x110 + 2*x111) - 2*x113*x136*(x107 + x108 + x109 + x110 + x111) - x136*x137 + x46*x67*x81*(-3*x69 - 3*x71 - 3*x73 - 3*x75 - 3*x77)/((x47)*(x47)*(x47)*(x47)) + 4*x49*x68 + x49*x79*x81 + (x102*x78*x80 + x122*(2*x15 + x167) + x124*(2*x16 + x167) + x126*(x167 + 2*x17) + x128*(x167 + 2*x19) + x13*x151 + 2*x13*x160 + x130*(x167 + 2*x20) + x146*x69 + x147*x71 + x148*x73 + x149*x75 + x150*x77 + x151 + x152*x26 + x152 + x153*x31 + x153 + x154*x159 + x155*x159 + x156*x159 + x157*x36 + x157 + x158*x159 + x159*x164 + 2*x161*x26 + 2*x162*x31 + x163*x41 + x163 + 2*x165*x36 + 2*x166*x41 + x70*x80*x92 + x72*x80*x94 + x74*x80*x96 + x76*x80*x99)/x47;
        break;

    default:
        break;
    }
        return result;
}

static double coder_dparam_d3gdtdp2(double T, double P, double n[6], int index) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double n6 = n[5];


        double x0 = (*endmember[0].mu0)(T, P);
    double x1 = n1*x0;
    double x2 = (*endmember[1].mu0)(T, P);
    double x3 = n1*x2;
    double x4 = (*endmember[2].mu0)(T, P);
    double x5 = n1*x4;
    double x6 = (*endmember[3].mu0)(T, P);
    double x7 = (*endmember[4].mu0)(T, P);
    double x8 = n1*(x6 + x7);
    double x9 = (*endmember[5].mu0)(T, P);
    double x10 = n1*(2*x7 + x9);
    double x11 = -LAbsMax(5, x1, x3, x5, x8, x10, x1, x3, x5, x8, x10);
    double x12 = x1 + x11;
    double x13 = t*x12;
    double x14 = exp(x13);
    double x15 = n1*(*endmember[0].dmu0dP)(T, P);
    double x16 = n1*(*endmember[1].dmu0dP)(T, P);
    double x17 = n1*(*endmember[2].dmu0dP)(T, P);
    double x18 = (*endmember[4].dmu0dP)(T, P);
    double x19 = n1*(x18 + (*endmember[3].dmu0dP)(T, P));
    double x20 = n1*(2*x18 + (*endmember[5].dmu0dP)(T, P));
    double x21 = LAbsMax(5, x15, x16, x17, x19, x20, x1, x3, x5, x8, x10);
    double x22 = -x21;
    double x23 = x15 + x22;
    double x24 = x14*x23;
    double x25 = x11 + x3;
    double x26 = t*x25;
    double x27 = exp(x26);
    double x28 = x16 + x22;
    double x29 = x27*x28;
    double x30 = x11 + x5;
    double x31 = t*x30;
    double x32 = exp(x31);
    double x33 = x17 + x22;
    double x34 = x32*x33;
    double x35 = x11 + x8;
    double x36 = t*x35;
    double x37 = exp(x36);
    double x38 = x19 + x22;
    double x39 = x37*x38;
    double x40 = x10 + x11;
    double x41 = t*x40;
    double x42 = exp(x41);
    double x43 = x20 + x22;
    double x44 = x42*x43;
    double x45 = x24 + x29 + x34 + x39 + x44;
    double x46 = ((x45)*(x45));
    double x47 = x14 + x27 + x32 + x37 + x42;
    double x48 = pow(x47, -3);
    double x49 = x46*x48;
    double x50 = n1*(*endmember[0].dmu0dT)(T, P);
    double x51 = n1*(*endmember[1].dmu0dT)(T, P);
    double x52 = n1*(*endmember[2].dmu0dT)(T, P);
    double x53 = (*endmember[4].dmu0dT)(T, P);
    double x54 = n1*(x53 + (*endmember[3].dmu0dT)(T, P));
    double x55 = n1*(2*x53 + (*endmember[5].dmu0dT)(T, P));
    double x56 = -LAbsMax(5, x50, x51, x52, x54, x55, x1, x3, x5, x8, x10);
    double x57 = x50 + x56;
    double x58 = x14*x57;
    double x59 = x51 + x56;
    double x60 = x27*x59;
    double x61 = x52 + x56;
    double x62 = x32*x61;
    double x63 = x54 + x56;
    double x64 = x37*x63;
    double x65 = x55 + x56;
    double x66 = x42*x65;
    double x67 = x58 + x60 + x62 + x64 + x66;
    double x68 = t*x67;
    double x69 = x12*x14;
    double x70 = x57*x69;
    double x71 = x25*x27;
    double x72 = x59*x71;
    double x73 = x30*x32;
    double x74 = x61*x73;
    double x75 = x35*x37;
    double x76 = x63*x75;
    double x77 = x40*x42;
    double x78 = x65*x77;
    double x79 = x70 + x72 + x74 + x76 + x78;
    double x80 = ((t)*(t));
    double x81 = 2*x80;
    double x82 = n1*(*endmember[0].d2mu0dP2)(T, P);
    double x83 = n1*(*endmember[1].d2mu0dP2)(T, P);
    double x84 = n1*(*endmember[2].d2mu0dP2)(T, P);
    double x85 = (*endmember[4].d2mu0dP2)(T, P);
    double x86 = n1*(x85 + (*endmember[3].d2mu0dP2)(T, P));
    double x87 = n1*(2*x85 + (*endmember[5].d2mu0dP2)(T, P));
    double x88 = -LAbsMax(5, x82, x83, x84, x86, x87, x1, x3, x5, x8, x10);
    double x89 = x82 + x88;
    double x90 = x83 + x88;
    double x91 = x84 + x88;
    double x92 = ((x23)*(x23));
    double x93 = x14*x92;
    double x94 = ((x28)*(x28));
    double x95 = x27*x94;
    double x96 = ((x33)*(x33));
    double x97 = x32*x96;
    double x98 = x86 + x88;
    double x99 = ((x38)*(x38));
    double x100 = x37*x99;
    double x101 = x87 + x88;
    double x102 = ((x43)*(x43));
    double x103 = x102*x42;
    double x104 = t*x100 + t*x103 + t*x93 + t*x95 + t*x97 + x101*x42 + x14*x89 + x27*x90 + x32*x91 + x37*x98;
    double x105 = pow(x47, -2);
    double x106 = x105*x67;
    double x107 = x23*x69;
    double x108 = x28*x71;
    double x109 = x33*x73;
    double x110 = x38*x75;
    double x111 = x43*x77;
    double x112 = 2*x45;
    double x113 = t*x105;
    double x114 = n1*(*endmember[0].d2mu0dTdP)(T, P);
    double x115 = n1*(*endmember[1].d2mu0dTdP)(T, P);
    double x116 = n1*(*endmember[2].d2mu0dTdP)(T, P);
    double x117 = (*endmember[4].d2mu0dTdP)(T, P);
    double x118 = n1*(x117 + (*endmember[3].d2mu0dTdP)(T, P));
    double x119 = n1*(2*x117 + (*endmember[5].d2mu0dTdP)(T, P));
    double x120 = -LAbsMax(5, x114, x115, x116, x118, x119, x1, x3, x5, x8, x10);
    double x121 = x114 + x120;
    double x122 = x121*x14;
    double x123 = x115 + x120;
    double x124 = x123*x27;
    double x125 = x116 + x120;
    double x126 = x125*x32;
    double x127 = x118 + x120;
    double x128 = x127*x37;
    double x129 = x119 + x120;
    double x130 = x129*x42;
    double x131 = x23*x58;
    double x132 = x28*x60;
    double x133 = x33*x62;
    double x134 = x38*x64;
    double x135 = x43*x66;
    double x136 = t*x131 + t*x132 + t*x133 + t*x134 + t*x135 + x122 + x124 + x126 + x128 + x130;
    double x137 = x105*x112;
    double x138 = x48*(-2*x69 - 2*x71 - 2*x73 - 2*x75 - 2*x77);
    double x139 = n1*(*endmember[0].d3mu0dTdP2)(T, P);
    double x140 = n1*(*endmember[1].d3mu0dTdP2)(T, P);
    double x141 = n1*(*endmember[2].d3mu0dTdP2)(T, P);
    double x142 = (*endmember[4].d3mu0dTdP2)(T, P);
    double x143 = n1*(x142 + (*endmember[3].d3mu0dTdP2)(T, P));
    double x144 = n1*(2*x142 + (*endmember[5].d3mu0dTdP2)(T, P));
    double x145 = -LAbsMax(5, x139, x140, x141, x143, x144, x1, x3, x5, x8, x10);
    double x146 = x139 + x145;
    double x147 = x140 + x145;
    double x148 = x141 + x145;
    double x149 = x143 + x145;
    double x150 = x144 + x145;
    double x151 = x58*x89;
    double x152 = x60*x90;
    double x153 = x62*x91;
    double x154 = x58*x92;
    double x155 = x60*x94;
    double x156 = x62*x96;
    double x157 = x64*x98;
    double x158 = x64*x99;
    double x159 = 2*t;
    double x160 = x121*x24;
    double x161 = x123*x29;
    double x162 = x125*x34;
    double x163 = x101*x66;
    double x164 = x102*x66;
    double x165 = x127*x39;
    double x166 = x129*x44;
    double x167 = -2*x21;

    
    double result = 0.0;
    switch (index) {
    case 0:
        result = -t*x106*(x100*x36 + x100 + x101*x77 + x103*x41 + x103 + x13*x93 + x26*x95 + x31*x97 + x69*x89 + x71*x90 + x73*x91 + x75*x98 + x93 + x95 + x97) - t*x112*x136*x138 - t*x137*(x121*x69 + x123*x71 + x125*x73 + x127*x75 + x129*x77 + x13*x131 + x131 + x132*x26 + x132 + x133*x31 + x133 + x134*x36 + x134 + x135*x41 + x135) - x104*x106 - x104*x113*x79 - x104*x138*x68 + x105*(-x69 - x71 - x73 - x75 - x77)*(t*x151 + t*x152 + t*x153 + t*x157 + t*x163 + x14*x146 + x147*x27 + x148*x32 + x149*x37 + x150*x42 + x154*x80 + x155*x80 + x156*x80 + x158*x80 + x159*x160 + x159*x161 + x159*x162 + x159*x165 + x159*x166 + x164*x80) + x112*x48*x67*x80*(2*x107 + 2*x108 + 2*x109 + 2*x110 + 2*x111) - 2*x113*x136*(x107 + x108 + x109 + x110 + x111) - x136*x137 + x46*x67*x81*(-3*x69 - 3*x71 - 3*x73 - 3*x75 - 3*x77)/((x47)*(x47)*(x47)*(x47)) + 4*x49*x68 + x49*x79*x81 + (x102*x78*x80 + x122*(2*x15 + x167) + x124*(2*x16 + x167) + x126*(x167 + 2*x17) + x128*(x167 + 2*x19) + x13*x151 + 2*x13*x160 + x130*(x167 + 2*x20) + x146*x69 + x147*x71 + x148*x73 + x149*x75 + x150*x77 + x151 + x152*x26 + x152 + x153*x31 + x153 + x154*x159 + x155*x159 + x156*x159 + x157*x36 + x157 + x158*x159 + x159*x164 + 2*x161*x26 + 2*x162*x31 + x163*x41 + x163 + 2*x165*x36 + 2*x166*x41 + x70*x80*x92 + x72*x80*x94 + x74*x80*x96 + x76*x80*x99)/x47;
        break;

    default:
        break;
    }
        return result;
}

static double coder_dparam_d3gdp3(double T, double P, double n[6], int index) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double n6 = n[5];


        double x0 = (*endmember[0].mu0)(T, P);
    double x1 = n1*x0;
    double x2 = (*endmember[1].mu0)(T, P);
    double x3 = n1*x2;
    double x4 = (*endmember[2].mu0)(T, P);
    double x5 = n1*x4;
    double x6 = (*endmember[3].mu0)(T, P);
    double x7 = (*endmember[4].mu0)(T, P);
    double x8 = n1*(x6 + x7);
    double x9 = (*endmember[5].mu0)(T, P);
    double x10 = n1*(2*x7 + x9);
    double x11 = -LAbsMax(5, x1, x3, x5, x8, x10, x1, x3, x5, x8, x10);
    double x12 = x1 + x11;
    double x13 = t*x12;
    double x14 = exp(x13);
    double x15 = n1*(*endmember[0].dmu0dP)(T, P);
    double x16 = n1*(*endmember[1].dmu0dP)(T, P);
    double x17 = n1*(*endmember[2].dmu0dP)(T, P);
    double x18 = (*endmember[4].dmu0dP)(T, P);
    double x19 = n1*(x18 + (*endmember[3].dmu0dP)(T, P));
    double x20 = n1*(2*x18 + (*endmember[5].dmu0dP)(T, P));
    double x21 = LAbsMax(5, x15, x16, x17, x19, x20, x1, x3, x5, x8, x10);
    double x22 = -x21;
    double x23 = x15 + x22;
    double x24 = x14*x23;
    double x25 = x11 + x3;
    double x26 = t*x25;
    double x27 = exp(x26);
    double x28 = x16 + x22;
    double x29 = x27*x28;
    double x30 = x11 + x5;
    double x31 = t*x30;
    double x32 = exp(x31);
    double x33 = x17 + x22;
    double x34 = x32*x33;
    double x35 = x11 + x8;
    double x36 = t*x35;
    double x37 = exp(x36);
    double x38 = x19 + x22;
    double x39 = x37*x38;
    double x40 = x10 + x11;
    double x41 = t*x40;
    double x42 = exp(x41);
    double x43 = x20 + x22;
    double x44 = x42*x43;
    double x45 = x24 + x29 + x34 + x39 + x44;
    double x46 = ((x45)*(x45)*(x45));
    double x47 = x14 + x27 + x32 + x37 + x42;
    double x48 = pow(x47, -3);
    double x49 = t*x48;
    double x50 = x12*x14;
    double x51 = x25*x27;
    double x52 = x30*x32;
    double x53 = x35*x37;
    double x54 = x40*x42;
    double x55 = ((t)*(t));
    double x56 = 2*x55;
    double x57 = x23*x50;
    double x58 = x28*x51;
    double x59 = x33*x52;
    double x60 = x38*x53;
    double x61 = x43*x54;
    double x62 = n1*(*endmember[0].d2mu0dP2)(T, P);
    double x63 = n1*(*endmember[1].d2mu0dP2)(T, P);
    double x64 = n1*(*endmember[2].d2mu0dP2)(T, P);
    double x65 = (*endmember[4].d2mu0dP2)(T, P);
    double x66 = n1*(x65 + (*endmember[3].d2mu0dP2)(T, P));
    double x67 = n1*(2*x65 + (*endmember[5].d2mu0dP2)(T, P));
    double x68 = -LAbsMax(5, x62, x63, x64, x66, x67, x1, x3, x5, x8, x10);
    double x69 = x62 + x68;
    double x70 = x14*x69;
    double x71 = x63 + x68;
    double x72 = x27*x71;
    double x73 = x64 + x68;
    double x74 = x32*x73;
    double x75 = x14*((x23)*(x23));
    double x76 = x27*((x28)*(x28));
    double x77 = x32*((x33)*(x33));
    double x78 = x66 + x68;
    double x79 = x37*x78;
    double x80 = x37*((x38)*(x38));
    double x81 = x67 + x68;
    double x82 = x42*x81;
    double x83 = x42*((x43)*(x43));
    double x84 = t*x75 + t*x76 + t*x77 + t*x80 + t*x83 + x70 + x72 + x74 + x79 + x82;
    double x85 = pow(x47, -2);
    double x86 = 3*x45*x85;
    double x87 = 3*t;
    double x88 = n1*(*endmember[0].d3mu0dP3)(T, P);
    double x89 = n1*(*endmember[1].d3mu0dP3)(T, P);
    double x90 = n1*(*endmember[2].d3mu0dP3)(T, P);
    double x91 = (*endmember[4].d3mu0dP3)(T, P);
    double x92 = n1*(x91 + (*endmember[3].d3mu0dP3)(T, P));
    double x93 = n1*(2*x91 + (*endmember[5].d3mu0dP3)(T, P));
    double x94 = -LAbsMax(5, x88, x89, x90, x92, x93, x1, x3, x5, x8, x10);
    double x95 = x88 + x94;
    double x96 = x89 + x94;
    double x97 = x90 + x94;
    double x98 = ((x23)*(x23)*(x23));
    double x99 = x14*x98;
    double x100 = ((x28)*(x28)*(x28));
    double x101 = x100*x27;
    double x102 = ((x33)*(x33)*(x33));
    double x103 = x102*x32;
    double x104 = x92 + x94;
    double x105 = x93 + x94;
    double x106 = ((x38)*(x38)*(x38));
    double x107 = x106*x37;
    double x108 = ((x43)*(x43)*(x43));
    double x109 = x108*x42;
    double x110 = x24*x69;
    double x111 = x29*x71;
    double x112 = x34*x73;
    double x113 = x39*x78;
    double x114 = x44*x81;
    double x115 = 2*t;
    double x116 = -3*x21;

    
    double result = 0.0;
    switch (index) {
    case 0:
        result = -t*x86*(x13*x75 + x26*x76 + x31*x77 + x36*x80 + x41*x83 + x50*x69 + x51*x71 + x52*x73 + x53*x78 + x54*x81 + x75 + x76 + x77 + x80 + x83) + ((x45)*(x45))*x48*x56*(3*x57 + 3*x58 + 3*x59 + 3*x60 + 3*x61) - 3*x45*x49*x84*(-2*x50 - 2*x51 - 2*x52 - 2*x53 - 2*x54) + 4*x46*x49 + x46*x56*(-3*x50 - 3*x51 - 3*x52 - 3*x53 - 3*x54)/((x47)*(x47)*(x47)*(x47)) - x84*x85*x87*(x57 + x58 + x59 + x60 + x61) - x84*x86 + x85*(-x50 - x51 - x52 - x53 - x54)*(x101*x55 + x103*x55 + x104*x37 + x105*x42 + x107*x55 + x109*x55 + x110*x87 + x111*x87 + x112*x87 + x113*x87 + x114*x87 + x14*x95 + x27*x96 + x32*x97 + x55*x99) + (x100*x51*x55 + x101*x115 + x102*x52*x55 + x103*x115 + x104*x53 + x105*x54 + x106*x53*x55 + x107*x115 + x108*x54*x55 + x109*x115 + 3*x110*x13 + 3*x111*x26 + 3*x112*x31 + 3*x113*x36 + 3*x114*x41 + x115*x99 + x50*x55*x98 + x50*x95 + x51*x96 + x52*x97 + x70*(x116 + 3*x15) + x72*(x116 + 3*x16) + x74*(x116 + 3*x17) + x79*(x116 + 3*x19) + x82*(x116 + 3*x20))/x47;
        break;

    default:
        break;
    }
        return result;
}
static void coder_dparam_dgdn(double T, double P, double n[6], int index, double result[6]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double n6 = n[5];

    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[1].mu0)(T, P);
    double x2 = (*endmember[2].mu0)(T, P);
    double x3 = (*endmember[4].mu0)(T, P);
    double x4 = x3 + (*endmember[3].mu0)(T, P);
    double x5 = 2*x3 + (*endmember[5].mu0)(T, P);
    double x6 = n1*x0;
    double x7 = n1*x1;
    double x8 = n1*x2;
    double x9 = n1*x4;
    double x10 = n1*x5;
    double x11 = LAbsMax(5, x0, x1, x2, x4, x5, x6, x7, x8, x9, x10);
    double x12 = -LAbsMax(5, x6, x7, x8, x9, x10, x6, x7, x8, x9, x10);
    double x13 = x12 + x6;
    double x14 = t*x13;
    double x15 = exp(x14);
    double x16 = x12 + x7;
    double x17 = t*x16;
    double x18 = exp(x17);
    double x19 = x12 + x8;
    double x20 = t*x19;
    double x21 = exp(x20);
    double x22 = x12 + x9;
    double x23 = t*x22;
    double x24 = exp(x23);
    double x25 = x10 + x12;
    double x26 = t*x25;
    double x27 = exp(x26);
    double x28 = x15 + x18 + x21 + x24 + x27;
    double x29 = 1.0/x28;
    double x30 = -x11;
    double x31 = x15*(x0 + x30);
    double x32 = t*x31;
    double x33 = x18*(x1 + x30);
    double x34 = t*x33;
    double x35 = x21*(x2 + x30);
    double x36 = t*x35;
    double x37 = x24*(x30 + x4);
    double x38 = t*x37;
    double x39 = x27*(x30 + x5);
    double x40 = t*x39;

    switch (index) {
    case 0:
    result[0] = (x11 + x29*(x14*x31 + x17*x33 + x20*x35 + x23*x37 + x26*x39 + x31 + x33 + x35 + x37 + x39) + (-x32 - x34 - x36 - x38 - x40)*(x13*x15 + x16*x18 + x19*x21 + x22*x24 + x25*x27)/((x28)*(x28)))/t - (t*x11 + x29*(x32 + x34 + x36 + x38 + x40))/((t)*(t));
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
        break;
    default:
        break;
    }
}

static int coder_get_param_number(void) {
    return 1;
}

static const char *paramNames[1] = {"t"};
static const char *paramUnits[1] = {"'None'"};

static const char **coder_get_param_names(void) {
    return paramNames;
}

static const char **coder_get_param_units(void) {
    return paramUnits;
}

static void coder_get_param_values(double **values) {
    (*values)[0] = t;

}

static int coder_set_param_values(double *values) {
    t = values[0];

    return 1;
}

static double coder_get_param_value(int index) {
    double result = 0.0;
    switch (index) {
    case 0:
        result = t;
        break;

    default:
        break;
    }
    return result;
}

static int coder_set_param_value(int index, double value) {
    int result = 1;
    switch (index) {
    case 0:
        t = value;
        break;

    default:
        result = 0;
        break;
    }
    return result;
}

