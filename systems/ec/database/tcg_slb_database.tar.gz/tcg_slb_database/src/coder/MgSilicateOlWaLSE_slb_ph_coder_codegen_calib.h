#include <math.h>

#include "coder_external_functions.h"


static double coder_dparam_g(double T, double P, double n[2], int index) {
    double n1 = n[0];
    double n2 = n[1];


        double x0 = n1*(*endmember[0].mu0)(T, P);
    double x1 = n1*(*endmember[1].mu0)(T, P);
    double x2 = LAbsMax(2, x0, x1, x0, x1);
    double x3 = -x2;
    double x4 = x0 + x3;
    double x5 = exp(t*x4);
    double x6 = x1 + x3;
    double x7 = exp(t*x6);
    double x8 = x5 + x7;

    
    double result = 0.0;
    switch (index) {
    case 0:
        result = (x2 + (x4*x5 + x6*x7)/x8)/t - (t*x2 + log(x8))/((t)*(t));
        break;

    default:
        break;
    }
        return result;
}

static double coder_dparam_dgdt(double T, double P, double n[2], int index) {
    double n1 = n[0];
    double n2 = n[1];


        double x0 = (*endmember[0].mu0)(T, P);
    double x1 = n1*(*endmember[0].dmu0dT)(T, P);
    double x2 = (*endmember[1].mu0)(T, P);
    double x3 = n1*(*endmember[1].dmu0dT)(T, P);
    double x4 = n1*x0;
    double x5 = n1*x2;
    double x6 = LAbsMax(2, x1, x3, x4, x5);
    double x7 = -LAbsMax(2, x4, x5, x4, x5);
    double x8 = x4 + x7;
    double x9 = t*x8;
    double x10 = exp(x9);
    double x11 = x5 + x7;
    double x12 = t*x11;
    double x13 = exp(x12);
    double x14 = x10 + x13;
    double x15 = 1.0/x14;
    double x16 = -x6;
    double x17 = x10*(x1 + x16);
    double x18 = x13*(x16 + x3);
    double x19 = t*x17 + t*x18;

    
    double result = 0.0;
    switch (index) {
    case 0:
        result = (x15*(x12*x18 + x17*x9 + x17 + x18) + x6 + x19*(-x10*x8 - x11*x13)/((x14)*(x14)))/t - (t*x6 + x15*x19)/((t)*(t));
        break;

    default:
        break;
    }
        return result;
}

static double coder_dparam_dgdp(double T, double P, double n[2], int index) {
    double n1 = n[0];
    double n2 = n[1];


        double x0 = (*endmember[0].mu0)(T, P);
    double x1 = n1*(*endmember[0].dmu0dP)(T, P);
    double x2 = (*endmember[1].mu0)(T, P);
    double x3 = n1*(*endmember[1].dmu0dP)(T, P);
    double x4 = n1*x0;
    double x5 = n1*x2;
    double x6 = LAbsMax(2, x1, x3, x4, x5);
    double x7 = -LAbsMax(2, x4, x5, x4, x5);
    double x8 = x4 + x7;
    double x9 = t*x8;
    double x10 = exp(x9);
    double x11 = x5 + x7;
    double x12 = t*x11;
    double x13 = exp(x12);
    double x14 = x10 + x13;
    double x15 = 1.0/x14;
    double x16 = -x6;
    double x17 = x10*(x1 + x16);
    double x18 = x13*(x16 + x3);
    double x19 = t*x17 + t*x18;

    
    double result = 0.0;
    switch (index) {
    case 0:
        result = (x15*(x12*x18 + x17*x9 + x17 + x18) + x6 + x19*(-x10*x8 - x11*x13)/((x14)*(x14)))/t - (t*x6 + x15*x19)/((t)*(t));
        break;

    default:
        break;
    }
        return result;
}

static double coder_dparam_d2gdt2(double T, double P, double n[2], int index) {
    double n1 = n[0];
    double n2 = n[1];


        double x0 = (*endmember[0].mu0)(T, P);
    double x1 = n1*x0;
    double x2 = (*endmember[1].mu0)(T, P);
    double x3 = n1*x2;
    double x4 = -LAbsMax(2, x1, x3, x1, x3);
    double x5 = x1 + x4;
    double x6 = t*x5;
    double x7 = exp(x6);
    double x8 = x3 + x4;
    double x9 = t*x8;
    double x10 = exp(x9);
    double x11 = x10 + x7;
    double x12 = pow(x11, -2);
    double x13 = n1*(*endmember[0].dmu0dT)(T, P);
    double x14 = n1*(*endmember[1].dmu0dT)(T, P);
    double x15 = -LAbsMax(2, x13, x14, x1, x3);
    double x16 = x13 + x15;
    double x17 = x16*x7;
    double x18 = x14 + x15;
    double x19 = x10*x18;
    double x20 = x17 + x19;
    double x21 = ((x20)*(x20));
    double x22 = x5*x7;
    double x23 = x10*x8;
    double x24 = n1*(*endmember[0].d2mu0dT2)(T, P);
    double x25 = n1*(*endmember[1].d2mu0dT2)(T, P);
    double x26 = -LAbsMax(2, x24, x25, x1, x3);
    double x27 = x24 + x26;
    double x28 = x25 + x26;
    double x29 = ((x16)*(x16))*x7;
    double x30 = x10*((x18)*(x18));

    
    double result = 0.0;
    switch (index) {
    case 0:
        result = -t*x12*x20*(2*x17*x5 + 2*x19*x8) - t*x21*(-2*x22 - 2*x23)/((x11)*(x11)*(x11)) - x12*x21 + x12*(-x22 - x23)*(t*x29 + t*x30 + x10*x28 + x27*x7) + (x22*x27 + x23*x28 + x29*x6 + x29 + x30*x9 + x30)/x11;
        break;

    default:
        break;
    }
        return result;
}

static double coder_dparam_d2gdtdp(double T, double P, double n[2], int index) {
    double n1 = n[0];
    double n2 = n[1];


        double x0 = (*endmember[0].mu0)(T, P);
    double x1 = n1*x0;
    double x2 = (*endmember[1].mu0)(T, P);
    double x3 = n1*x2;
    double x4 = -LAbsMax(2, x1, x3, x1, x3);
    double x5 = x1 + x4;
    double x6 = t*x5;
    double x7 = exp(x6);
    double x8 = n1*(*endmember[0].dmu0dT)(T, P);
    double x9 = n1*(*endmember[1].dmu0dT)(T, P);
    double x10 = -LAbsMax(2, x8, x9, x1, x3);
    double x11 = x10 + x8;
    double x12 = x3 + x4;
    double x13 = t*x12;
    double x14 = exp(x13);
    double x15 = x10 + x9;
    double x16 = x11*x7 + x14*x15;
    double x17 = x14 + x7;
    double x18 = pow(x17, -2);
    double x19 = n1*(*endmember[0].dmu0dP)(T, P);
    double x20 = n1*(*endmember[1].dmu0dP)(T, P);
    double x21 = -LAbsMax(2, x19, x20, x1, x3);
    double x22 = x19 + x21;
    double x23 = x22*x7;
    double x24 = x20 + x21;
    double x25 = x14*x24;
    double x26 = x23 + x25;
    double x27 = x18*x26;
    double x28 = x5*x7;
    double x29 = x12*x14;
    double x30 = t*x16;
    double x31 = n1*(*endmember[0].d2mu0dTdP)(T, P);
    double x32 = n1*(*endmember[1].d2mu0dTdP)(T, P);
    double x33 = -LAbsMax(2, x31, x32, x1, x3);
    double x34 = x31 + x33;
    double x35 = x32 + x33;
    double x36 = x11*x23;
    double x37 = x15*x25;

    
    double result = 0.0;
    switch (index) {
    case 0:
        result = -t*x27*(x11*x28 + x15*x29) - x16*x27 - x18*x30*(x22*x28 + x24*x29) + x18*(-x28 - x29)*(t*x36 + t*x37 + x14*x35 + x34*x7) + (x13*x37 + x28*x34 + x29*x35 + x36*x6 + x36 + x37)/x17 - x26*x30*(-2*x28 - 2*x29)/((x17)*(x17)*(x17));
        break;

    default:
        break;
    }
        return result;
}

static double coder_dparam_d2gdp2(double T, double P, double n[2], int index) {
    double n1 = n[0];
    double n2 = n[1];


        double x0 = (*endmember[0].mu0)(T, P);
    double x1 = n1*x0;
    double x2 = (*endmember[1].mu0)(T, P);
    double x3 = n1*x2;
    double x4 = -LAbsMax(2, x1, x3, x1, x3);
    double x5 = x1 + x4;
    double x6 = t*x5;
    double x7 = exp(x6);
    double x8 = x3 + x4;
    double x9 = t*x8;
    double x10 = exp(x9);
    double x11 = x10 + x7;
    double x12 = pow(x11, -2);
    double x13 = n1*(*endmember[0].dmu0dP)(T, P);
    double x14 = n1*(*endmember[1].dmu0dP)(T, P);
    double x15 = -LAbsMax(2, x13, x14, x1, x3);
    double x16 = x13 + x15;
    double x17 = x16*x7;
    double x18 = x14 + x15;
    double x19 = x10*x18;
    double x20 = x17 + x19;
    double x21 = ((x20)*(x20));
    double x22 = x5*x7;
    double x23 = x10*x8;
    double x24 = n1*(*endmember[0].d2mu0dP2)(T, P);
    double x25 = n1*(*endmember[1].d2mu0dP2)(T, P);
    double x26 = -LAbsMax(2, x24, x25, x1, x3);
    double x27 = x24 + x26;
    double x28 = x25 + x26;
    double x29 = ((x16)*(x16))*x7;
    double x30 = x10*((x18)*(x18));

    
    double result = 0.0;
    switch (index) {
    case 0:
        result = -t*x12*x20*(2*x17*x5 + 2*x19*x8) - t*x21*(-2*x22 - 2*x23)/((x11)*(x11)*(x11)) - x12*x21 + x12*(-x22 - x23)*(t*x29 + t*x30 + x10*x28 + x27*x7) + (x22*x27 + x23*x28 + x29*x6 + x29 + x30*x9 + x30)/x11;
        break;

    default:
        break;
    }
        return result;
}

static double coder_dparam_d3gdt3(double T, double P, double n[2], int index) {
    double n1 = n[0];
    double n2 = n[1];


        double x0 = (*endmember[0].mu0)(T, P);
    double x1 = n1*x0;
    double x2 = (*endmember[1].mu0)(T, P);
    double x3 = n1*x2;
    double x4 = -LAbsMax(2, x1, x3, x1, x3);
    double x5 = x1 + x4;
    double x6 = t*x5;
    double x7 = exp(x6);
    double x8 = n1*(*endmember[0].dmu0dT)(T, P);
    double x9 = n1*(*endmember[1].dmu0dT)(T, P);
    double x10 = LAbsMax(2, x8, x9, x1, x3);
    double x11 = -x10;
    double x12 = x11 + x8;
    double x13 = x12*x7;
    double x14 = x3 + x4;
    double x15 = t*x14;
    double x16 = exp(x15);
    double x17 = x11 + x9;
    double x18 = x16*x17;
    double x19 = x13 + x18;
    double x20 = ((x19)*(x19)*(x19));
    double x21 = x16 + x7;
    double x22 = pow(x21, -3);
    double x23 = t*x22;
    double x24 = x5*x7;
    double x25 = x14*x16;
    double x26 = ((t)*(t));
    double x27 = 2*x26;
    double x28 = x12*x24;
    double x29 = x17*x25;
    double x30 = n1*(*endmember[0].d2mu0dT2)(T, P);
    double x31 = n1*(*endmember[1].d2mu0dT2)(T, P);
    double x32 = -LAbsMax(2, x30, x31, x1, x3);
    double x33 = x30 + x32;
    double x34 = x33*x7;
    double x35 = x31 + x32;
    double x36 = x16*x35;
    double x37 = ((x12)*(x12))*x7;
    double x38 = x16*((x17)*(x17));
    double x39 = t*x37 + t*x38 + x34 + x36;
    double x40 = pow(x21, -2);
    double x41 = 3*x19*x40;
    double x42 = 3*t;
    double x43 = n1*(*endmember[0].d3mu0dT3)(T, P);
    double x44 = n1*(*endmember[1].d3mu0dT3)(T, P);
    double x45 = -LAbsMax(2, x43, x44, x1, x3);
    double x46 = x43 + x45;
    double x47 = x44 + x45;
    double x48 = ((x12)*(x12)*(x12));
    double x49 = x48*x7;
    double x50 = ((x17)*(x17)*(x17));
    double x51 = x16*x50;
    double x52 = x13*x33;
    double x53 = x18*x35;
    double x54 = 2*t;
    double x55 = -3*x10;

    
    double result = 0.0;
    switch (index) {
    case 0:
        result = -t*x41*(x15*x38 + x24*x33 + x25*x35 + x37*x6 + x37 + x38) + ((x19)*(x19))*x22*x27*(3*x28 + 3*x29) - 3*x19*x23*x39*(-2*x24 - 2*x25) + 4*x20*x23 + x20*x27*(-3*x24 - 3*x25)/((x21)*(x21)*(x21)*(x21)) - x39*x40*x42*(x28 + x29) - x39*x41 + x40*(-x24 - x25)*(x16*x47 + x26*x49 + x26*x51 + x42*x52 + x42*x53 + x46*x7) + (3*x15*x53 + x24*x26*x48 + x24*x46 + x25*x26*x50 + x25*x47 + x34*(x55 + 3*x8) + x36*(x55 + 3*x9) + x49*x54 + x51*x54 + 3*x52*x6)/x21;
        break;

    default:
        break;
    }
        return result;
}

static double coder_dparam_d3gdt2dp(double T, double P, double n[2], int index) {
    double n1 = n[0];
    double n2 = n[1];


        double x0 = (*endmember[0].mu0)(T, P);
    double x1 = n1*x0;
    double x2 = (*endmember[1].mu0)(T, P);
    double x3 = n1*x2;
    double x4 = -LAbsMax(2, x1, x3, x1, x3);
    double x5 = x1 + x4;
    double x6 = t*x5;
    double x7 = exp(x6);
    double x8 = n1*(*endmember[0].dmu0dT)(T, P);
    double x9 = n1*(*endmember[1].dmu0dT)(T, P);
    double x10 = LAbsMax(2, x8, x9, x1, x3);
    double x11 = -x10;
    double x12 = x11 + x8;
    double x13 = x12*x7;
    double x14 = x3 + x4;
    double x15 = t*x14;
    double x16 = exp(x15);
    double x17 = x11 + x9;
    double x18 = x16*x17;
    double x19 = x13 + x18;
    double x20 = ((x19)*(x19));
    double x21 = x16 + x7;
    double x22 = pow(x21, -3);
    double x23 = x20*x22;
    double x24 = n1*(*endmember[0].dmu0dP)(T, P);
    double x25 = n1*(*endmember[1].dmu0dP)(T, P);
    double x26 = -LAbsMax(2, x24, x25, x1, x3);
    double x27 = x24 + x26;
    double x28 = x27*x7;
    double x29 = x25 + x26;
    double x30 = x16*x29;
    double x31 = x28 + x30;
    double x32 = t*x31;
    double x33 = x5*x7;
    double x34 = x27*x33;
    double x35 = x14*x16;
    double x36 = x29*x35;
    double x37 = x34 + x36;
    double x38 = ((t)*(t));
    double x39 = 2*x38;
    double x40 = n1*(*endmember[0].d2mu0dT2)(T, P);
    double x41 = n1*(*endmember[1].d2mu0dT2)(T, P);
    double x42 = -LAbsMax(2, x40, x41, x1, x3);
    double x43 = x40 + x42;
    double x44 = x41 + x42;
    double x45 = ((x12)*(x12));
    double x46 = x45*x7;
    double x47 = ((x17)*(x17));
    double x48 = x16*x47;
    double x49 = t*x46 + t*x48 + x16*x44 + x43*x7;
    double x50 = pow(x21, -2);
    double x51 = x31*x50;
    double x52 = x12*x33;
    double x53 = x17*x35;
    double x54 = 2*x19;
    double x55 = t*x50;
    double x56 = n1*(*endmember[0].d2mu0dTdP)(T, P);
    double x57 = n1*(*endmember[1].d2mu0dTdP)(T, P);
    double x58 = -LAbsMax(2, x56, x57, x1, x3);
    double x59 = x56 + x58;
    double x60 = x59*x7;
    double x61 = x57 + x58;
    double x62 = x16*x61;
    double x63 = x12*x28;
    double x64 = x17*x30;
    double x65 = t*x63 + t*x64 + x60 + x62;
    double x66 = x50*x54;
    double x67 = x22*(-2*x33 - 2*x35);
    double x68 = n1*(*endmember[0].d3mu0dT2dP)(T, P);
    double x69 = n1*(*endmember[1].d3mu0dT2dP)(T, P);
    double x70 = -LAbsMax(2, x68, x69, x1, x3);
    double x71 = x68 + x70;
    double x72 = x69 + x70;
    double x73 = x28*x43;
    double x74 = x30*x44;
    double x75 = x28*x45;
    double x76 = x30*x47;
    double x77 = 2*t;
    double x78 = x13*x59;
    double x79 = x18*x61;
    double x80 = -2*x10;

    
    double result = 0.0;
    switch (index) {
    case 0:
        result = -t*x51*(x15*x48 + x33*x43 + x35*x44 + x46*x6 + x46 + x48) - t*x54*x65*x67 - t*x66*(x15*x64 + x33*x59 + x35*x61 + x6*x63 + x63 + x64) + x20*x31*x39*(-3*x33 - 3*x35)/((x21)*(x21)*(x21)*(x21)) + x22*x31*x38*x54*(2*x52 + 2*x53) + 4*x23*x32 + x23*x37*x39 - x32*x49*x67 - x37*x49*x55 - x49*x51 + x50*(-x33 - x35)*(t*x73 + t*x74 + x16*x72 + x38*x75 + x38*x76 + x7*x71 + x77*x78 + x77*x79) - 2*x55*x65*(x52 + x53) - x65*x66 + (x15*x74 + 2*x15*x79 + x33*x71 + x34*x38*x45 + x35*x72 + x36*x38*x47 + x6*x73 + 2*x6*x78 + x60*(2*x8 + x80) + x62*(x80 + 2*x9) + x73 + x74 + x75*x77 + x76*x77)/x21;
        break;

    default:
        break;
    }
        return result;
}

static double coder_dparam_d3gdtdp2(double T, double P, double n[2], int index) {
    double n1 = n[0];
    double n2 = n[1];


        double x0 = (*endmember[0].mu0)(T, P);
    double x1 = n1*x0;
    double x2 = (*endmember[1].mu0)(T, P);
    double x3 = n1*x2;
    double x4 = -LAbsMax(2, x1, x3, x1, x3);
    double x5 = x1 + x4;
    double x6 = t*x5;
    double x7 = exp(x6);
    double x8 = n1*(*endmember[0].dmu0dP)(T, P);
    double x9 = n1*(*endmember[1].dmu0dP)(T, P);
    double x10 = LAbsMax(2, x8, x9, x1, x3);
    double x11 = -x10;
    double x12 = x11 + x8;
    double x13 = x12*x7;
    double x14 = x3 + x4;
    double x15 = t*x14;
    double x16 = exp(x15);
    double x17 = x11 + x9;
    double x18 = x16*x17;
    double x19 = x13 + x18;
    double x20 = ((x19)*(x19));
    double x21 = x16 + x7;
    double x22 = pow(x21, -3);
    double x23 = x20*x22;
    double x24 = n1*(*endmember[0].dmu0dT)(T, P);
    double x25 = n1*(*endmember[1].dmu0dT)(T, P);
    double x26 = -LAbsMax(2, x24, x25, x1, x3);
    double x27 = x24 + x26;
    double x28 = x27*x7;
    double x29 = x25 + x26;
    double x30 = x16*x29;
    double x31 = x28 + x30;
    double x32 = t*x31;
    double x33 = x5*x7;
    double x34 = x27*x33;
    double x35 = x14*x16;
    double x36 = x29*x35;
    double x37 = x34 + x36;
    double x38 = ((t)*(t));
    double x39 = 2*x38;
    double x40 = n1*(*endmember[0].d2mu0dP2)(T, P);
    double x41 = n1*(*endmember[1].d2mu0dP2)(T, P);
    double x42 = -LAbsMax(2, x40, x41, x1, x3);
    double x43 = x40 + x42;
    double x44 = x41 + x42;
    double x45 = ((x12)*(x12));
    double x46 = x45*x7;
    double x47 = ((x17)*(x17));
    double x48 = x16*x47;
    double x49 = t*x46 + t*x48 + x16*x44 + x43*x7;
    double x50 = pow(x21, -2);
    double x51 = x31*x50;
    double x52 = x12*x33;
    double x53 = x17*x35;
    double x54 = 2*x19;
    double x55 = t*x50;
    double x56 = n1*(*endmember[0].d2mu0dTdP)(T, P);
    double x57 = n1*(*endmember[1].d2mu0dTdP)(T, P);
    double x58 = -LAbsMax(2, x56, x57, x1, x3);
    double x59 = x56 + x58;
    double x60 = x59*x7;
    double x61 = x57 + x58;
    double x62 = x16*x61;
    double x63 = x12*x28;
    double x64 = x17*x30;
    double x65 = t*x63 + t*x64 + x60 + x62;
    double x66 = x50*x54;
    double x67 = x22*(-2*x33 - 2*x35);
    double x68 = n1*(*endmember[0].d3mu0dTdP2)(T, P);
    double x69 = n1*(*endmember[1].d3mu0dTdP2)(T, P);
    double x70 = -LAbsMax(2, x68, x69, x1, x3);
    double x71 = x68 + x70;
    double x72 = x69 + x70;
    double x73 = x28*x43;
    double x74 = x30*x44;
    double x75 = x28*x45;
    double x76 = x30*x47;
    double x77 = 2*t;
    double x78 = x13*x59;
    double x79 = x18*x61;
    double x80 = -2*x10;

    
    double result = 0.0;
    switch (index) {
    case 0:
        result = -t*x51*(x15*x48 + x33*x43 + x35*x44 + x46*x6 + x46 + x48) - t*x54*x65*x67 - t*x66*(x15*x64 + x33*x59 + x35*x61 + x6*x63 + x63 + x64) + x20*x31*x39*(-3*x33 - 3*x35)/((x21)*(x21)*(x21)*(x21)) + x22*x31*x38*x54*(2*x52 + 2*x53) + 4*x23*x32 + x23*x37*x39 - x32*x49*x67 - x37*x49*x55 - x49*x51 + x50*(-x33 - x35)*(t*x73 + t*x74 + x16*x72 + x38*x75 + x38*x76 + x7*x71 + x77*x78 + x77*x79) - 2*x55*x65*(x52 + x53) - x65*x66 + (x15*x74 + 2*x15*x79 + x33*x71 + x34*x38*x45 + x35*x72 + x36*x38*x47 + x6*x73 + 2*x6*x78 + x60*(2*x8 + x80) + x62*(x80 + 2*x9) + x73 + x74 + x75*x77 + x76*x77)/x21;
        break;

    default:
        break;
    }
        return result;
}

static double coder_dparam_d3gdp3(double T, double P, double n[2], int index) {
    double n1 = n[0];
    double n2 = n[1];


        double x0 = (*endmember[0].mu0)(T, P);
    double x1 = n1*x0;
    double x2 = (*endmember[1].mu0)(T, P);
    double x3 = n1*x2;
    double x4 = -LAbsMax(2, x1, x3, x1, x3);
    double x5 = x1 + x4;
    double x6 = t*x5;
    double x7 = exp(x6);
    double x8 = n1*(*endmember[0].dmu0dP)(T, P);
    double x9 = n1*(*endmember[1].dmu0dP)(T, P);
    double x10 = LAbsMax(2, x8, x9, x1, x3);
    double x11 = -x10;
    double x12 = x11 + x8;
    double x13 = x12*x7;
    double x14 = x3 + x4;
    double x15 = t*x14;
    double x16 = exp(x15);
    double x17 = x11 + x9;
    double x18 = x16*x17;
    double x19 = x13 + x18;
    double x20 = ((x19)*(x19)*(x19));
    double x21 = x16 + x7;
    double x22 = pow(x21, -3);
    double x23 = t*x22;
    double x24 = x5*x7;
    double x25 = x14*x16;
    double x26 = ((t)*(t));
    double x27 = 2*x26;
    double x28 = x12*x24;
    double x29 = x17*x25;
    double x30 = n1*(*endmember[0].d2mu0dP2)(T, P);
    double x31 = n1*(*endmember[1].d2mu0dP2)(T, P);
    double x32 = -LAbsMax(2, x30, x31, x1, x3);
    double x33 = x30 + x32;
    double x34 = x33*x7;
    double x35 = x31 + x32;
    double x36 = x16*x35;
    double x37 = ((x12)*(x12))*x7;
    double x38 = x16*((x17)*(x17));
    double x39 = t*x37 + t*x38 + x34 + x36;
    double x40 = pow(x21, -2);
    double x41 = 3*x19*x40;
    double x42 = 3*t;
    double x43 = n1*(*endmember[0].d3mu0dP3)(T, P);
    double x44 = n1*(*endmember[1].d3mu0dP3)(T, P);
    double x45 = -LAbsMax(2, x43, x44, x1, x3);
    double x46 = x43 + x45;
    double x47 = x44 + x45;
    double x48 = ((x12)*(x12)*(x12));
    double x49 = x48*x7;
    double x50 = ((x17)*(x17)*(x17));
    double x51 = x16*x50;
    double x52 = x13*x33;
    double x53 = x18*x35;
    double x54 = 2*t;
    double x55 = -3*x10;

    
    double result = 0.0;
    switch (index) {
    case 0:
        result = -t*x41*(x15*x38 + x24*x33 + x25*x35 + x37*x6 + x37 + x38) + ((x19)*(x19))*x22*x27*(3*x28 + 3*x29) - 3*x19*x23*x39*(-2*x24 - 2*x25) + 4*x20*x23 + x20*x27*(-3*x24 - 3*x25)/((x21)*(x21)*(x21)*(x21)) - x39*x40*x42*(x28 + x29) - x39*x41 + x40*(-x24 - x25)*(x16*x47 + x26*x49 + x26*x51 + x42*x52 + x42*x53 + x46*x7) + (3*x15*x53 + x24*x26*x48 + x24*x46 + x25*x26*x50 + x25*x47 + x34*(x55 + 3*x8) + x36*(x55 + 3*x9) + x49*x54 + x51*x54 + 3*x52*x6)/x21;
        break;

    default:
        break;
    }
        return result;
}
static void coder_dparam_dgdn(double T, double P, double n[2], int index, double result[2]) {
    double n1 = n[0];
    double n2 = n[1];

    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[1].mu0)(T, P);
    double x2 = n1*x0;
    double x3 = n1*x1;
    double x4 = LAbsMax(2, x0, x1, x2, x3);
    double x5 = -LAbsMax(2, x2, x3, x2, x3);
    double x6 = x2 + x5;
    double x7 = t*x6;
    double x8 = exp(x7);
    double x9 = x3 + x5;
    double x10 = t*x9;
    double x11 = exp(x10);
    double x12 = x11 + x8;
    double x13 = 1.0/x12;
    double x14 = -x4;
    double x15 = x8*(x0 + x14);
    double x16 = t*x15;
    double x17 = x11*(x1 + x14);
    double x18 = t*x17;

    switch (index) {
    case 0:
    result[0] = (x13*(x10*x17 + x15*x7 + x15 + x17) + x4 + (-x16 - x18)*(x11*x9 + x6*x8)/((x12)*(x12)))/t - (t*x4 + x13*(x16 + x18))/((t)*(t));
result[1] = 0;
        break;
    default:
        break;
    }
}

static int coder_get_param_number(void) {
    return 1;
}

static const char *paramNames[1] = {"t"};
static const char *paramUnits[1] = {"'None'"};

static const char **coder_get_param_names(void) {
    return paramNames;
}

static const char **coder_get_param_units(void) {
    return paramUnits;
}

static void coder_get_param_values(double **values) {
    (*values)[0] = t;

}

static int coder_set_param_values(double *values) {
    t = values[0];

    return 1;
}

static double coder_get_param_value(int index) {
    double result = 0.0;
    switch (index) {
    case 0:
        result = t;
        break;

    default:
        break;
    }
    return result;
}

static int coder_set_param_value(int index, double value) {
    int result = 1;
    switch (index) {
    case 0:
        t = value;
        break;

    default:
        result = 0;
        break;
    }
    return result;
}

