#include <math.h>


static double coder_g(double T, double P, double n[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double result;
    
    double x0 = 1.0*n1;
    double x1 = 1.0*n2;
    double x2 = 1.0*n3 + x0 + x1;
    double x3 = 3.5*n4 + x2;
    double x4 = n1 + n3;
    double x5 = n2 + n4;
    double x6 = 1.0/(x4 + x5);
    double x7 = 1.0*n4;
    double x8 = n3 + n4;

result = (0.055555555555555552*n1*(222300.0*n3 + 364000.0*n4) + 7777.7777777777774*n2*n4 + 0.055555555555555552*n3*(222300.0*n1 + 345800.0*n4) + 0.038408779149519887*n4*(526500.0*n1 + 202500.0*n2 + 500175.0*n3) + x3*(8.3144626181532395*T*(x0*log(n1*x6) + x1*log(n2*x6) + 1.0*x4*log(x4*x6) + 1.0*x5*log(x5*x6) + x7*(log(n4*x6) - 0.69314718055994495) + 1.0*x8*log(x6*x8) + (2.0*n1 + 2.0*n2 + 2.0*n3 + x7)*log(x6*(0.5*n4 + x2))) + n1*(*endmember[0].mu0)(T, P) + n2*(*endmember[1].mu0)(T, P) + n3*(*endmember[2].mu0)(T, P) + n4*(*endmember[3].mu0)(T, P)))/x3;
    return result;
}
        
static void coder_dgdn(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];

    double x0 = 3.5*n4;
    double x1 = 1.0*n2;
    double x2 = 1.0*n1;
    double x3 = 1.0*n3;
    double x4 = x2 + x3;
    double x5 = x1 + x4;
    double x6 = x0 + x5;
    double x7 = (*endmember[0].mu0)(T, P);
    double x8 = n1*x7;
    double x9 = (*endmember[1].mu0)(T, P);
    double x10 = n2*x9;
    double x11 = (*endmember[2].mu0)(T, P);
    double x12 = n3*x11;
    double x13 = (*endmember[3].mu0)(T, P);
    double x14 = n1 + n3;
    double x15 = n2 + n4;
    double x16 = x14 + x15;
    double x17 = 1.0/x16;
    double x18 = log(n1*x17);
    double x19 = log(n2*x17);
    double x20 = log(n4*x17);
    double x21 = 1.0*n4;
    double x22 = 1.0*log(x14*x17);
    double x23 = 1.0*log(x15*x17);
    double x24 = n3 + n4;
    double x25 = 1.0*log(x17*x24);
    double x26 = 2.0*n1 + 2.0*n2 + 2.0*n3 + x21;
    double x27 = 0.5*n4 + x5;
    double x28 = log(x17*x27);
    double x29 = x1*x19 + x14*x22 + x15*x23 + x18*x2 + x21*(x20 - 0.69314718055994495) + x24*x25 + x26*x28;
    double x30 = 8.3144626181532395*T;
    double x31 = x29*x30;
    double x32 = (0.055555555555555552*n1*(222300.0*n3 + 364000.0*n4) + 7777.7777777777774*n2*n4 + 0.055555555555555552*n3*(222300.0*n1 + 345800.0*n4) + 0.038408779149519887*n4*(526500.0*n1 + 202500.0*n2 + 500175.0*n3) + x6*(n4*x13 + x10 + x12 + x31 + x8))/((x6)*(x6));
    double x33 = -1.0*x32;
    double x34 = 1.0/x6;
    double x35 = pow(x16, -2);
    double x36 = 1.0*x16;
    double x37 = 2.0*x28;
    double x38 = x21 + x3;
    double x39 = -x17*x21;
    double x40 = -x27*x35;
    double x41 = x16*x26/x27;
    double x42 = x41*(1.0*x17 + x40);
    double x43 = -x17*x38 + x37 + x39 + x42;
    double x44 = x1 + x21;
    double x45 = -x1*x17;
    double x46 = -x17*x44 + x22 + x45 + x16*x4*(-x14*x35 + x17)/x14;
    double x47 = x1*x9 + x11*x3 + x13*x21 + x2*x7 + x31;
    double x48 = -x17*x2;
    double x49 = -x17*x4 + x23 + x48 + x16*x44*(-x15*x35 + x17)/x15;
    double x50 = x16*x38*(x17 - x24*x35)/x24 + x25;

result[0] = x33 + x34*(24700.0*n3 + 40444.444444444438*n4 + x47 + x6*(x30*(1.0*x18 + x36*(-n1*x35 + x17) + x43 + x46) + x7));
result[1] = x33 + x34*(15555.555555555555*n4 + x47 + x6*(x30*(1.0*x19 + x36*(-n2*x35 + x17) + x43 + x49) + x9));
result[2] = x33 + x34*(24700.0*n1 + 38422.222222222219*n4 + x47 + x6*(x11 + x30*(x37 + x39 + x42 + x46 + x48 + x50)));
result[3] = -3.5*x32 + x34*(29.100619163536336*T*x29 + 40444.444444444438*n1 + 15555.555555555555*n2 + 38422.222222222219*n3 + x0*x13 + 3.5*x10 + 3.5*x12 + x6*(x13 + x30*(1.0*x20 + 1.0*x28 + x36*(-n4*x35 + x17) + x41*(0.5*x17 + x40) + x45 + x49 + x50 - 0.69314718055994495)) + 3.5*x8);
}
        
static void coder_d2gdn2(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];

    double x0 = 3.5*n4;
    double x1 = 1.0*n2;
    double x2 = 1.0*n1;
    double x3 = 1.0*n3;
    double x4 = x2 + x3;
    double x5 = x1 + x4;
    double x6 = x0 + x5;
    double x7 = (*endmember[0].mu0)(T, P);
    double x8 = n1*x7;
    double x9 = (*endmember[1].mu0)(T, P);
    double x10 = n2*x9;
    double x11 = (*endmember[2].mu0)(T, P);
    double x12 = n3*x11;
    double x13 = (*endmember[3].mu0)(T, P);
    double x14 = n1 + n3;
    double x15 = n2 + n4;
    double x16 = x14 + x15;
    double x17 = 1.0/x16;
    double x18 = log(n1*x17);
    double x19 = log(n2*x17);
    double x20 = log(n4*x17);
    double x21 = 1.0*n4;
    double x22 = 1.0*log(x14*x17);
    double x23 = 1.0*log(x15*x17);
    double x24 = n3 + n4;
    double x25 = 1.0*log(x17*x24);
    double x26 = 2.0*n1;
    double x27 = 2.0*n2;
    double x28 = 2.0*n3 + x21 + x26 + x27;
    double x29 = 0.5*n4 + x5;
    double x30 = log(x17*x29);
    double x31 = x1*x19 + x14*x22 + x15*x23 + x18*x2 + x21*(x20 - 0.69314718055994495) + x24*x25 + x28*x30;
    double x32 = 8.3144626181532395*T;
    double x33 = x31*x32;
    double x34 = (0.055555555555555552*n1*(222300.0*n3 + 364000.0*n4) + 7777.7777777777774*n2*n4 + 0.055555555555555552*n3*(222300.0*n1 + 345800.0*n4) + 0.038408779149519887*n4*(526500.0*n1 + 202500.0*n2 + 500175.0*n3) + x6*(n4*x13 + x10 + x12 + x33 + x8))/((x6)*(x6)*(x6));
    double x35 = 2.0*x34;
    double x36 = pow(x6, -2);
    double x37 = pow(x16, -2);
    double x38 = 1.0*x16;
    double x39 = x38*(-n1*x37 + x17);
    double x40 = 2.0*x30;
    double x41 = x21 + x3;
    double x42 = -x17*x21;
    double x43 = 1.0*x17;
    double x44 = -x29*x37;
    double x45 = x43 + x44;
    double x46 = 1.0/x29;
    double x47 = x28*x46;
    double x48 = x45*x47;
    double x49 = x16*x48;
    double x50 = -x17*x41 + x40 + x42 + x49;
    double x51 = x1 + x21;
    double x52 = -x1*x17;
    double x53 = 1.0/x14;
    double x54 = -x14*x37 + x17;
    double x55 = x53*x54;
    double x56 = x4*x55;
    double x57 = x16*x56 - x17*x51 + x22 + x52;
    double x58 = T*(1.0*x18 + x39 + x50 + x57);
    double x59 = 8.3144626181532395*x58;
    double x60 = x1*x9 + x11*x3 + x13*x21 + x2*x7 + x33;
    double x61 = x36*(24700.0*n3 + 40444.444444444438*n4 + x6*(x59 + x7) + x60);
    double x62 = 1.0/x6;
    double x63 = -2.0*x37;
    double x64 = pow(x16, -3);
    double x65 = x26*x64;
    double x66 = x2*x37;
    double x67 = -x66;
    double x68 = -x21;
    double x69 = 2.0*x16;
    double x70 = -2*x37;
    double x71 = 2*x64;
    double x72 = x16*x4;
    double x73 = x53*x72;
    double x74 = x1*x37;
    double x75 = x56 + x74;
    double x76 = x45*x46;
    double x77 = 4.0*x16*x76;
    double x78 = x29*x71;
    double x79 = x16*x47;
    double x80 = x79*(x63 + x78);
    double x81 = x28/((x29)*(x29));
    double x82 = x45*x81;
    double x83 = -x38*x82;
    double x84 = x77 + x80 + x83;
    double x85 = -x37*(-x1 + x68) + x55*x69 + x73*(x14*x71 + x70) + x75 + x84 - x54*x72/((x14)*(x14));
    double x86 = x67 + x85;
    double x87 = -x3;
    double x88 = -x37*(x68 + x87);
    double x89 = x21*x37;
    double x90 = x48 + x89;
    double x91 = x43 + x88 + x90;
    double x92 = x32*x6;
    double x93 = -3.0*x17;
    double x94 = x77 + x80 + x83 + x90 + x93;
    double x95 = -1.0*x37;
    double x96 = x16*(x65 + x95);
    double x97 = -x37;
    double x98 = x37*x51 + x73*(-x71*(-n1 - n3) + x97) + x75;
    double x99 = x67 + x96 + x98;
    double x100 = x38*(-n2*x37 + x17);
    double x101 = -x17*x2;
    double x102 = 1.0/x15;
    double x103 = -x15*x37 + x17;
    double x104 = x102*x103;
    double x105 = x104*x51;
    double x106 = x101 + x105*x16 - x17*x4 + x23;
    double x107 = x100 + x106 + 1.0*x19 + x50;
    double x108 = x107*x32;
    double x109 = x108 + 1.0*x9;
    double x110 = x59 + 1.0*x7;
    double x111 = 15555.555555555555*n4 + x6*(x108 + x9) + x60;
    double x112 = 1.0*x36;
    double x113 = -x111*x112;
    double x114 = x35 - 1.0*x61;
    double x115 = x37*x41;
    double x116 = x115 + x90;
    double x117 = 1.0/x24;
    double x118 = x17 - x24*x37;
    double x119 = x117*x118;
    double x120 = x119*x41;
    double x121 = x120*x16 + x25;
    double x122 = x101 + x121 + x40 + x42 + x49 + x57;
    double x123 = x122*x32;
    double x124 = 1.0*x11 + x123;
    double x125 = 24700.0*n1 + 38422.222222222219*n4 + x6*(x11 + x123) + x60;
    double x126 = -x112*x125;
    double x127 = 0.5*x17 + x44;
    double x128 = x127*x46*x69;
    double x129 = 0.5*x16;
    double x130 = x128 - x129*x82 + x38*x76 + x79*(-1.5*x37 + x78);
    double x131 = x38*(-n4*x37 + x17);
    double x132 = x127*x47;
    double x133 = x106 + x121 + x131 + x132*x16 + 1.0*x20 + 1.0*x30 + x52 - 0.69314718055994495;
    double x134 = x133*x32;
    double x135 = 1.0*x13 + x134;
    double x136 = 29.100619163536336*T;
    double x137 = 40444.444444444438*n1 + 15555.555555555555*n2 + 38422.222222222219*n3 + x0*x13 + 3.5*x10 + 3.5*x12 + x136*x31 + x6*(x13 + x134) + 3.5*x8;
    double x138 = -x112*x137 + 7.0*x34;
    double x139 = x111*x36;
    double x140 = 16.628925236306479*T;
    double x141 = x27*x64;
    double x142 = x105 + x66;
    double x143 = x142 - x74;
    double x144 = x16*x51;
    double x145 = x102*x144;
    double x146 = -x103*x144/((x15)*(x15)) + x104*x69 + x145*(x15*x71 + x70) - x37*(-x2 + x87);
    double x147 = x115 + x143 + x16*(x141 + x95);
    double x148 = x130 + x90;
    double x149 = x125*x36;
    double x150 = x16*x41;
    double x151 = x117*x150*(x24*x71 + x70) - x118*x150/((x24)*(x24)) + x119*x69 + x120;
    double x152 = x151 + x66;

result[0] = x35 - 2.0*x61 + x62*(16.628925236306479*x58 + 2.0*x7 + x92*(x16*(x63 + x65) + x86 + x91 + x39/n1));
result[1] = x113 + x114 + x62*(x109 + x110 + x92*(x88 + x94 + x99));
result[2] = x114 + x126 + x62*(x110 + x124 + x92*(x116 - x43 + x86 + x96) + 24700.0);
result[3] = x138 - 3.5*x61 + x62*(x135 + 29.100619163536336*x58 + 3.5*x7 + x92*(x116 + x130 - 4.0*x17 + x99) + 40444.444444444438);
result[4] = -2.0*x139 + x35 + x62*(x107*x140 + 2.0*x9 + x92*(x143 + x146 + x16*(x141 + x63) + x84 + x91 + x100/n2));
result[5] = x113 + x126 + x35 + x62*(x109 + x124 + x92*(x145*(-x71*(-n2 - n4) + x97) + x147 + x37*x4 + x94));
result[6] = x138 - 3.5*x139 + x62*(x107*x136 + x135 + 3.5*x9 + x92*(x146 + x147 + x148 - 2.0*x17) + 15555.555555555555);
result[7] = -2.0*x149 + x35 + x62*(2.0*x11 + x122*x140 + x92*(x152 + x85 + x90));
result[8] = x138 - 3.5*x149 + x62*(3.5*x11 + x122*x136 + x135 + x92*(x148 + x152 + x93 + x98) + 38422.222222222219);
result[9] = -7.0*x137*x36 + 24.5*x34 + x62*(58.201238327072673*T*x133 + 7.0*x13 + x92*(-x127*x129*x81 + x128 + x132 + x142 + x146 + x151 + x16*(2.0*n4*x64 + x63) + x43 + x74 + x79*(x78 + x95) - x89 + x131/n4));
}
        
static void coder_d3gdn3(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];

    double x0 = 3.5*n4;
    double x1 = 1.0*n2;
    double x2 = 1.0*n1;
    double x3 = 1.0*n3;
    double x4 = x2 + x3;
    double x5 = x1 + x4;
    double x6 = x0 + x5;
    double x7 = (*endmember[0].mu0)(T, P);
    double x8 = n1*x7;
    double x9 = (*endmember[1].mu0)(T, P);
    double x10 = n2*x9;
    double x11 = (*endmember[2].mu0)(T, P);
    double x12 = n3*x11;
    double x13 = (*endmember[3].mu0)(T, P);
    double x14 = n1 + n3;
    double x15 = n2 + n4;
    double x16 = x14 + x15;
    double x17 = 1.0/x16;
    double x18 = log(n1*x17);
    double x19 = log(n2*x17);
    double x20 = log(n4*x17);
    double x21 = 1.0*n4;
    double x22 = 1.0*log(x14*x17);
    double x23 = 1.0*log(x15*x17);
    double x24 = n3 + n4;
    double x25 = 1.0*log(x17*x24);
    double x26 = 2.0*n1;
    double x27 = 2.0*n2;
    double x28 = 2.0*n3 + x21 + x26 + x27;
    double x29 = 0.5*n4 + x5;
    double x30 = log(x17*x29);
    double x31 = x1*x19 + x14*x22 + x15*x23 + x18*x2 + x21*(x20 - 0.69314718055994495) + x24*x25 + x28*x30;
    double x32 = 8.3144626181532395*T;
    double x33 = x31*x32;
    double x34 = (0.055555555555555552*n1*(222300.0*n3 + 364000.0*n4) + 7777.7777777777774*n2*n4 + 0.055555555555555552*n3*(222300.0*n1 + 345800.0*n4) + 0.038408779149519887*n4*(526500.0*n1 + 202500.0*n2 + 500175.0*n3) + x6*(n4*x13 + x10 + x12 + x33 + x8))/((x6)*(x6)*(x6)*(x6));
    double x35 = -6.0*x34;
    double x36 = pow(x6, -3);
    double x37 = pow(x16, -2);
    double x38 = -1.0*n1*x37 + 1.0*x17;
    double x39 = x16*x38;
    double x40 = 2.0*x30;
    double x41 = x21 + x3;
    double x42 = 1.0*x17;
    double x43 = -n4*x42;
    double x44 = 1.0/x29;
    double x45 = -x29*x37;
    double x46 = x42 + x45;
    double x47 = x44*x46;
    double x48 = x28*x47;
    double x49 = x16*x48;
    double x50 = -x17*x41 + x40 + x43 + x49;
    double x51 = x1 + x21;
    double x52 = -x1*x17;
    double x53 = 1.0/x14;
    double x54 = -x14*x37 + x17;
    double x55 = x53*x54;
    double x56 = x4*x55;
    double x57 = x16*x56 - x17*x51 + x22 + x52;
    double x58 = 1.0*x18 + x39 + x50 + x57;
    double x59 = x32*x58;
    double x60 = x1*x9 + x11*x3 + x13*x21 + x2*x7 + x33;
    double x61 = x36*(24700.0*n3 + 40444.444444444438*n4 + x6*(x59 + x7) + x60);
    double x62 = pow(x6, -2);
    double x63 = 16.628925236306479*T;
    double x64 = 2.0*x37;
    double x65 = -x64;
    double x66 = pow(x16, -3);
    double x67 = x26*x66;
    double x68 = 1.0/n1;
    double x69 = x38*x68;
    double x70 = x2*x37;
    double x71 = -x70;
    double x72 = -x21;
    double x73 = -x1 + x72;
    double x74 = 2.0*x55;
    double x75 = -2*x37;
    double x76 = 2*x66;
    double x77 = x14*x76 + x75;
    double x78 = x4*x53;
    double x79 = x77*x78;
    double x80 = pow(x14, -2);
    double x81 = x54*x80;
    double x82 = x4*x81;
    double x83 = x1*x37;
    double x84 = x56 + x83;
    double x85 = 4.0*x16;
    double x86 = x47*x85;
    double x87 = x29*x76;
    double x88 = x65 + x87;
    double x89 = x28*x44;
    double x90 = x88*x89;
    double x91 = x16*x90;
    double x92 = 1.0*x16;
    double x93 = pow(x29, -2);
    double x94 = x46*x93;
    double x95 = x28*x94;
    double x96 = -x92*x95;
    double x97 = x86 + x91 + x96;
    double x98 = x16*x74 + x16*x79 - x16*x82 - x37*x73 + x84 + x97;
    double x99 = x71 + x98;
    double x100 = -x3;
    double x101 = x100 + x72;
    double x102 = -x101*x37;
    double x103 = x21*x37;
    double x104 = x103 + x48;
    double x105 = x102 + x104 + x42;
    double x106 = T*(x105 + x16*x69 + x16*(x65 + x67) + x99);
    double x107 = 8.3144626181532395*x106;
    double x108 = x62*(x107*x6 + x58*x63 + 2.0*x7);
    double x109 = 1.0/x6;
    double x110 = -x51*x76;
    double x111 = 4.0*x37;
    double x112 = -x111;
    double x113 = 6.0*x66;
    double x114 = pow(x16, -4);
    double x115 = 6.0*x114;
    double x116 = -n1*x115;
    double x117 = 2*n1;
    double x118 = x117*x66;
    double x119 = x68*x92;
    double x120 = 2.0*x66;
    double x121 = n4*x120;
    double x122 = -x121;
    double x123 = x122 - x41*x76;
    double x124 = 6.0*x16;
    double x125 = x44*x88;
    double x126 = 6*x114;
    double x127 = -x126*x29;
    double x128 = x16*x89;
    double x129 = 2.0*x16;
    double x130 = x129*x28;
    double x131 = pow(x29, -3);
    double x132 = x131*x46;
    double x133 = x88*x93;
    double x134 = x124*x125 - x124*x94 + x128*(x113 + x127) + x130*x132 - x130*x133 + 6.0*x47 + 2*x90 - 2.0*x95;
    double x135 = x123 + x134;
    double x136 = 3.0*x16;
    double x137 = 6*x66;
    double x138 = x16*x78;
    double x139 = x4*x80;
    double x140 = 2*x16;
    double x141 = x136*x53*x77 - x136*x81 + x138*(-x126*x14 + x137) - x139*x140*x77 + 3.0*x55 + 2*x79 - 2*x82 + x140*x4*x54/((x14)*(x14)*(x14));
    double x142 = x135 + x141;
    double x143 = 4.0*x66;
    double x144 = x27*x66;
    double x145 = -x144;
    double x146 = n1*x143 + x145;
    double x147 = x146 + x69;
    double x148 = x32*x6;
    double x149 = -3.0*x17;
    double x150 = x104 + x149 + x86 + x91 + x96;
    double x151 = 1.0*x37;
    double x152 = -x151;
    double x153 = x16*(x152 + x67);
    double x154 = -x37;
    double x155 = -n1 - n3;
    double x156 = x154 - x155*x76;
    double x157 = x156*x78;
    double x158 = x157*x16 + x37*x51 + x84;
    double x159 = x153 + x158 + x71;
    double x160 = x102 + x150 + x159;
    double x161 = x160*x63;
    double x162 = x119*(x118 + x154) + x147 + x16*(x116 + x143);
    double x163 = x156*x16;
    double x164 = -x139*x163 + x157 + x79 - x82;
    double x165 = 4*x66;
    double x166 = 3*x114;
    double x167 = -x166*(2*n3 + x117);
    double x168 = x138*(x165 + x167) + 2.0*x163*x53 + x73*x76 + x74;
    double x169 = x164 + x168;
    double x170 = x162 + x169;
    double x171 = -n2*x37 + x17;
    double x172 = x171*x92;
    double x173 = -x17*x2;
    double x174 = 1.0/x15;
    double x175 = -x15*x37 + x17;
    double x176 = x174*x175;
    double x177 = x176*x51;
    double x178 = x16*x177 - x17*x4 + x173 + x23;
    double x179 = x172 + x178 + 1.0*x19 + x50;
    double x180 = x179*x32;
    double x181 = 15555.555555555555*n4 + x6*(x180 + x9) + x60;
    double x182 = 2.0*x36;
    double x183 = x181*x182;
    double x184 = x160*x32;
    double x185 = x180 + 1.0*x9;
    double x186 = x59 + 1.0*x7;
    double x187 = x184*x6 + x185 + x186;
    double x188 = 2.0*x62;
    double x189 = -x187*x188 + x35;
    double x190 = -1.0*x108 + 4.0*x61;
    double x191 = x37*x41;
    double x192 = x104 + x191;
    double x193 = x153 + x192 - x42 + x99;
    double x194 = x193*x63;
    double x195 = x101*x76 + x122;
    double x196 = x134 + x195;
    double x197 = x110 + x141;
    double x198 = 1.0/x24;
    double x199 = x17 - x24*x37;
    double x200 = x198*x199;
    double x201 = x200*x41;
    double x202 = x16*x201 + x25;
    double x203 = x173 + x202 + x40 + x43 + x49 + x57;
    double x204 = x203*x32;
    double x205 = 24700.0*n1 + 38422.222222222219*n4 + x6*(x11 + x204) + x60;
    double x206 = x182*x205;
    double x207 = x193*x32;
    double x208 = 1.0*x11 + x204;
    double x209 = x186 + x207*x6 + x208 + 24700.0;
    double x210 = -x188*x209 + x35;
    double x211 = 0.5*x17 + x45;
    double x212 = x211*x44;
    double x213 = 2.0*x212;
    double x214 = x16*x213;
    double x215 = -1.5*x37 + x87;
    double x216 = x215*x89;
    double x217 = 0.5*x16;
    double x218 = x16*x216 + x214 - x217*x95 + x47*x92;
    double x219 = x159 - 4.0*x17 + x192 + x218;
    double x220 = x28*x92;
    double x221 = x220*x93;
    double x222 = -x215*x221;
    double x223 = x215*x44;
    double x224 = x217*x28;
    double x225 = x125*x92 + x128*(x127 + 5.0*x66) + x132*x220 - x133*x224 - x136*x94 + x216 + x223*x85 + 5.0*x47 + x90 - 1.5*x95;
    double x226 = x195 + x225;
    double x227 = x222 + x226;
    double x228 = 29.100619163536336*T;
    double x229 = x219*x32;
    double x230 = -n4*x37 + x17;
    double x231 = x230*x92;
    double x232 = x211*x89;
    double x233 = x16*x232 + x178 + 1.0*x20 + x202 + x231 + 1.0*x30 + x52 - 0.69314718055994495;
    double x234 = x233*x32;
    double x235 = 1.0*x13 + x234;
    double x236 = x228*x58 + x229*x6 + x235 + 3.5*x7 + 40444.444444444438;
    double x237 = 40444.444444444438*n1 + 15555.555555555555*n2 + 38422.222222222219*n3 + x0*x13 + 3.5*x10 + 3.5*x12 + x228*x31 + x6*(x13 + x234) + 3.5*x8;
    double x238 = x182*x237 - 21.0*x34;
    double x239 = 1.0/n2;
    double x240 = x177 + x70;
    double x241 = x240 - x83;
    double x242 = x100 - x2;
    double x243 = 2.0*x176;
    double x244 = x15*x76 + x75;
    double x245 = x174*x51;
    double x246 = x244*x245;
    double x247 = pow(x15, -2);
    double x248 = x175*x247;
    double x249 = x248*x51;
    double x250 = x16*x243 + x16*x246 - x16*x249 - x242*x37;
    double x251 = x105 + x16*(x144 + x65) + x172*x239 + x241 + x250 + x97;
    double x252 = x251*x32;
    double x253 = x146 + x16*(x116 + x120);
    double x254 = x110 + x138*(x167 + x76) + 2*x157;
    double x255 = x253 + x254;
    double x256 = x111 + x123;
    double x257 = x134 + x256;
    double x258 = 2.0*x61;
    double x259 = x181*x36;
    double x260 = x179*x63 + x252*x6 + 2.0*x9;
    double x261 = 1.0*x62;
    double x262 = 4.0*x259 - x260*x261;
    double x263 = -n2 - n4;
    double x264 = x154 - x263*x76;
    double x265 = x245*x264;
    double x266 = x16*(x144 + x152) + x191 + x241;
    double x267 = x150 + x16*x265 + x266 + x37*x4;
    double x268 = x267*x32;
    double x269 = x185 + x208 + x268*x6;
    double x270 = x110 + x253;
    double x271 = 3.0*x37;
    double x272 = x164 + x271;
    double x273 = x104 + x218;
    double x274 = -2.0*x17 + x250 + x266 + x273;
    double x275 = x274*x32;
    double x276 = 5.0*x37;
    double x277 = x222 + x255;
    double x278 = 3.5*x62;
    double x279 = -x236*x261 + x238 + 7.0*x61;
    double x280 = x179*x228 + x235 + x275*x6 + 3.5*x9 + 15555.555555555555;
    double x281 = 7.0*x259 - x261*x280;
    double x282 = x16*x41;
    double x283 = x24*x76 + x75;
    double x284 = x198*x283;
    double x285 = pow(x24, -2);
    double x286 = x199*x285;
    double x287 = x129*x200 + x201 + x282*x284 - x282*x286;
    double x288 = x287 + x70;
    double x289 = x104 + x288 + x98;
    double x290 = x289*x32;
    double x291 = x205*x36;
    double x292 = 2.0*x11 + x203*x63 + x290*x6;
    double x293 = -x261*x292 + 4.0*x291;
    double x294 = x149 + x158 + x273 + x288;
    double x295 = x294*x32;
    double x296 = x222 + x225;
    double x297 = 3.5*x11 + x203*x228 + x235 + x295*x6 + 38422.222222222219;
    double x298 = -x261*x297 + 7.0*x291;
    double x299 = 58.201238327072673*T;
    double x300 = 1.0/n4;
    double x301 = x152 + x87;
    double x302 = x211*x93;
    double x303 = x28*x302;
    double x304 = -x103 + x128*x301 + x16*(x121 + x65) + x214 - x217*x303 + x231*x300 + x232 + x240 + x250 + x287 + x42 + x83;
    double x305 = x304*x32;
    double x306 = x301*x44;
    double x307 = x128*(x127 + x143) + x129*x223 + x129*x306 + x132*x224 + x213 + 2*x216 - x302*x92 + 2.0*x47 - x92*x94 - 1.0*x95;
    double x308 = x123 + x307;
    double x309 = 7.0*x62;
    double x310 = x237*x36;
    double x311 = 7.0*x13 + x233*x299 + x305*x6;
    double x312 = -x261*x311 + 14.0*x310 - 73.5*x34;
    double x313 = 3.0*x62;
    double x314 = 24.943387854459719*T;
    double x315 = 1.0*x171*x239;
    double x316 = -n2*x115;
    double x317 = n2*x76;
    double x318 = x239*x92;
    double x319 = -x4*x76;
    double x320 = -x67;
    double x321 = n2*x143 + x320;
    double x322 = x319 + x321;
    double x323 = x16*x245;
    double x324 = x16*x51;
    double x325 = x247*x324;
    double x326 = x136*x174*x244 - x136*x248 + 3.0*x176 - 2*x244*x325 + 2*x246 - 2*x249 + x323*(-x126*x15 + x137) + 2*x175*x324/((x15)*(x15)*(x15));
    double x327 = x322 + x326;
    double x328 = x267*x63;
    double x329 = x174*x264;
    double x330 = -x166*(2*n2 + 2*n4);
    double x331 = x246 - x249 - x264*x325 + x265;
    double x332 = x152 + x16*(x143 + x316) + x315 + x318*(x154 + x317);
    double x333 = -x188*x269 + x35;
    double x334 = x16*(x120 + x316) + x322;
    double x335 = 2*x41;
    double x336 = 2*x282;
    double x337 = x136*x284 - x136*x286 + x145 + x198*x282*(-x126*x24 + x137) + x199*x336/((x24)*(x24)*(x24)) + 3.0*x200 - x283*x285*x336 + x284*x335 - x286*x335 + x320;
    double x338 = x122 + x337;

result[0] = -3.0*x108 + x109*(24.943387854459719*x106 + x148*(x110 + x112 + x119*(x118 + x75) + x142 + x147 + x16*(x113 + x116) - x39/((n1)*(n1)))) + x35 + 6.0*x61;
result[1] = x109*(x107 + x148*(x135 + x152 + x170) + x161) + x183 + x189 + x190;
result[2] = x109*(x107 + x148*(x162 + x196 + x197 + x65) + x194) + x190 + x206 + x210;
result[3] = -3.5*x108 + x109*(29.100619163536336*x106 + x148*(x170 + x227) + x219*x63) - x188*x236 + x238 + 14.0*x61;
result[4] = x109*(x148*(x255 + x257) + x161 + x252) + x189 + x258 + x262;
result[5] = x109*(x148*(x138*(x126*x155 + x165) + x156*x53*x92 + x196 + x270 + x272 + 1.0*x55) + x184 + x207 + x268) + x183 - x187*x261 + x206 - x209*x261 + x258 - x261*x269 + x35;
result[6] = x109*(x148*(x226 + x276 + x277) + x160*x228 + x229 + x275) - x187*x278 + x279 + x281;
result[7] = x109*(x148*(x142 + x151 + x270) + x194 + x290) + x210 + x258 + x293;
result[8] = x109*(x148*(x123 + x168 + x253 + x272 + x296) + x193*x228 + x229 + x295) - x209*x278 + x279 + x298;
result[9] = x109*(x148*(x277 + x308 + 6.0*x37) + x219*x299 + x305) - x236*x309 + x312 + 24.5*x61;
result[10] = x109*(x148*(x112 + x135 + x16*(x113 + x316) + x315 + x318*(x317 + x75) + x327 - x172/((n2)*(n2))) + x251*x314) + 6.0*x259 - x260*x313 + x35;
result[11] = x109*(x148*(x129*x329 + x196 + x242*x76 + x243 + x321 + x323*(x165 + x330) + x331 + x332) + x252 + x328) + x206 + x262 + x333;
result[12] = x109*(x148*(x227 + x327 + x332) + x228*x251 + x274*x63) - x188*x280 + x238 + 14.0*x259 - x260*x278;
result[13] = x109*(x148*(x257 + 2*x265 + x323*(x330 + x76) + x334) + x290 + x328) + x183 + x293 + x333;
result[14] = x109*(x148*(1.0*x176 + x256 + x296 + x323*(x126*x263 + x165) + x329*x92 + x331 + x334) + x228*x267 + x275 + x295) + x238 - x269*x278 + x281 + x298;
result[15] = x109*(x148*(x222 + x271 + x308 + x326 + x334) + x274*x299 + x305) + 24.5*x259 - x280*x309 + x312;
result[16] = x109*(x148*(x134 + x197 + x338) + x289*x314) + 6.0*x291 - x292*x313 + x35;
result[17] = x109*(x148*(x169 + x296 + x338 + x64) + x228*x289 + x294*x63) - x188*x297 + x238 - x278*x292 + 14.0*x291;
result[18] = x109*(x148*(x222 + x254 + x276 + x307 + x338) + x294*x299 + x305) + 24.5*x291 - x297*x309 + x312;
result[19] = x109*(87.301857490609009*T*x304 + x148*(n4*x143 + x112 + x128*(x127 + 3.0*x66) + x131*x211*x224 + x136*x306 - 1.5*x16*x302 + x16*(-n4*x115 + x113) + 3.0*x212 - x221*x301 + 1.0*x230*x300 + x300*x92*(n4*x76 + x75) + 2*x301*x89 - 1.0*x303 + x319 + x326 + x337 - x231/((n4)*(n4)))) + 73.5*x310 - 10.5*x311*x62 - 257.25*x34;
}
        
static double coder_dgdt(double T, double P, double n[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double result;
    
    double x0 = n1 + n3;
    double x1 = n2 + n4;
    double x2 = 1.0/(x0 + x1);
    double x3 = n3 + n4;

result = 8.3144626181532395*n1*log(n1*x2) + n1*(*endmember[0].dmu0dT)(T, P) + 8.3144626181532395*n2*log(n2*x2) + n2*(*endmember[1].dmu0dT)(T, P) + n3*(*endmember[2].dmu0dT)(T, P) + 8.3144626181532395*n4*(log(n4*x2) - 0.69314718055994495) + n4*(*endmember[3].dmu0dT)(T, P) + 8.3144626181532395*x0*log(x0*x2) + 8.3144626181532395*x1*log(x1*x2) + 8.3144626181532395*x3*log(x2*x3) + 8.3144626181532395*(2.0*n1 + 2.0*n2 + 2.0*n3 + 1.0*n4)*log(x2*(1.0*n1 + 1.0*n2 + 1.0*n3 + 0.5*n4));
    return result;
}
        
static void coder_d2gdndt(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];

    double x0 = n1 + n3;
    double x1 = n2 + n4;
    double x2 = x0 + x1;
    double x3 = 1.0/x2;
    double x4 = n1*x3;
    double x5 = pow(x2, -2);
    double x6 = 8.3144626181532395*x2;
    double x7 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 0.5*n4;
    double x8 = log(x3*x7);
    double x9 = 16.628925236306479*x8;
    double x10 = 8.3144626181532395*n3;
    double x11 = 8.3144626181532395*n4;
    double x12 = x10 + x11;
    double x13 = -x11*x3;
    double x14 = -x5*x7;
    double x15 = x2*(16.628925236306479*n1 + 16.628925236306479*n2 + 16.628925236306479*n3 + x11)/x7;
    double x16 = x15*(x14 + 1.0*x3);
    double x17 = -x12*x3 + x13 + x16 + x9;
    double x18 = 8.3144626181532395*n2;
    double x19 = x11 + x18;
    double x20 = -x18*x3;
    double x21 = 8.3144626181532395*n1 + x10;
    double x22 = -x19*x3 + x20 + 8.3144626181532395*log(x0*x3) + x2*x21*(-x0*x5 + x3)/x0;
    double x23 = -8.3144626181532395*x4;
    double x24 = -x21*x3 + x23 + 8.3144626181532395*log(x1*x3) + x19*x2*(-x1*x5 + x3)/x1;
    double x25 = n3 + n4;
    double x26 = x12*x2*(-x25*x5 + x3)/x25 + 8.3144626181532395*log(x25*x3);

result[0] = x17 + x22 + x6*(-n1*x5 + x3) + 8.3144626181532395*log(x4) + (*endmember[0].dmu0dT)(T, P);
result[1] = x17 + x24 + x6*(-n2*x5 + x3) + 8.3144626181532395*log(n2*x3) + (*endmember[1].dmu0dT)(T, P);
result[2] = x13 + x16 + x22 + x23 + x26 + x9 + (*endmember[2].dmu0dT)(T, P);
result[3] = x15*(x14 + 0.5*x3) + x20 + x24 + x26 + x6*(-n4*x5 + x3) + 8.3144626181532395*x8 + 8.3144626181532395*log(n4*x3) + (*endmember[3].dmu0dT)(T, P) - 5.7631463216439762;
}
        
static void coder_d3gdn2dt(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];

    double x0 = n1 + n3;
    double x1 = n2 + n4;
    double x2 = x0 + x1;
    double x3 = pow(x2, -2);
    double x4 = -16.628925236306479*x3;
    double x5 = pow(x2, -3);
    double x6 = 16.628925236306479*n1;
    double x7 = x5*x6;
    double x8 = 1.0/x2;
    double x9 = 8.3144626181532395*x2;
    double x10 = 8.3144626181532395*n1;
    double x11 = x10*x3;
    double x12 = -x11;
    double x13 = 8.3144626181532395*n2;
    double x14 = 8.3144626181532395*n4;
    double x15 = -x14;
    double x16 = 1.0/x0;
    double x17 = -x0*x3 + x8;
    double x18 = x16*x17;
    double x19 = 16.628925236306479*x2;
    double x20 = -2*x3;
    double x21 = 2*x5;
    double x22 = 8.3144626181532395*n3;
    double x23 = x10 + x22;
    double x24 = x2*x23;
    double x25 = x16*x24;
    double x26 = x13*x3;
    double x27 = x18*x23 + x26;
    double x28 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 0.5*n4;
    double x29 = 1.0/x28;
    double x30 = -x28*x3;
    double x31 = x30 + 1.0*x8;
    double x32 = x29*x31;
    double x33 = 33.257850472612958*x2*x32;
    double x34 = x21*x28;
    double x35 = 16.628925236306479*n2;
    double x36 = 16.628925236306479*n3 + x14 + x35 + x6;
    double x37 = x29*x36;
    double x38 = x2*x37;
    double x39 = x38*(-2.0*x3 + x34);
    double x40 = x2*x36/((x28)*(x28));
    double x41 = x31*x40;
    double x42 = -1.0*x41;
    double x43 = x33 + x39 + x42;
    double x44 = x18*x19 + x25*(x0*x21 + x20) + x27 - x3*(-x13 + x15) + x43 - x17*x24/((x0)*(x0));
    double x45 = x12 + x44;
    double x46 = -x22;
    double x47 = -x3*(x15 + x46);
    double x48 = 8.3144626181532395*x8;
    double x49 = x14*x3;
    double x50 = x31*x37 + x49;
    double x51 = x47 + x48 + x50;
    double x52 = -24.943387854459719*x8;
    double x53 = x33 + x39 + x42 + x50 + x52;
    double x54 = -8.3144626181532395*x3;
    double x55 = x2*(x54 + x7);
    double x56 = x13 + x14;
    double x57 = -x3;
    double x58 = x25*(-x21*(-n1 - n3) + x57) + x27 + x3*x56;
    double x59 = x12 + x55 + x58;
    double x60 = x14 + x22;
    double x61 = x3*x60;
    double x62 = x50 + x61;
    double x63 = x30 + 0.5*x8;
    double x64 = x19*x29*x63;
    double x65 = x32*x9 + x38*(-1.5*x3 + x34) - 0.5*x41 + x64;
    double x66 = x35*x5;
    double x67 = 1.0/x1;
    double x68 = -x1*x3 + x8;
    double x69 = x67*x68;
    double x70 = x11 + x56*x69;
    double x71 = -x26 + x70;
    double x72 = x2*x56;
    double x73 = x67*x72;
    double x74 = x19*x69 - x3*(-x10 + x46) + x73*(x1*x21 + x20) - x68*x72/((x1)*(x1));
    double x75 = x2*(x54 + x66) + x61 + x71;
    double x76 = x50 + x65;
    double x77 = n3 + n4;
    double x78 = 1.0/x77;
    double x79 = -x3*x77 + x8;
    double x80 = x78*x79;
    double x81 = x2*x60;
    double x82 = x19*x80 + x60*x80 + x78*x81*(x20 + x21*x77) - x79*x81/((x77)*(x77));
    double x83 = x11 + x82;

result[0] = x2*(x4 + x7) + x45 + x51 + x9*(-n1*x3 + x8)/n1;
result[1] = x47 + x53 + x59;
result[2] = x45 - x48 + x55 + x62;
result[3] = x59 + x62 + x65 - 33.257850472612958*x8;
result[4] = x2*(x4 + x66) + x43 + x51 + x71 + x74 + x9*(-n2*x3 + x8)/n2;
result[5] = x23*x3 + x53 + x73*(-x21*(-n2 - n4) + x57) + x75;
result[6] = x74 + x75 + x76 - 16.628925236306479*x8;
result[7] = x44 + x50 + x83;
result[8] = x52 + x58 + x76 + x83;
result[9] = x2*(16.628925236306479*n4*x5 + x4) + x26 + x37*x63 + x38*(-1.0*x3 + x34) - 0.5*x40*x63 + x48 - x49 + x64 + x70 + x74 + x82 + x9*(-n4*x3 + x8)/n4;
}
        
static void coder_d4gdn3dt(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];

    double x0 = 8.3144626181532395*n2;
    double x1 = 8.3144626181532395*n4;
    double x2 = x0 + x1;
    double x3 = n1 + n3;
    double x4 = n2 + n4;
    double x5 = x3 + x4;
    double x6 = pow(x5, -3);
    double x7 = 2*x6;
    double x8 = -x2*x7;
    double x9 = pow(x5, -2);
    double x10 = 33.257850472612958*x9;
    double x11 = -x10;
    double x12 = 49.886775708919437*x6;
    double x13 = pow(x5, -4);
    double x14 = 49.886775708919437*x13;
    double x15 = -n1*x14;
    double x16 = -2*x9;
    double x17 = 2*n1;
    double x18 = x17*x6;
    double x19 = 8.3144626181532395/n1;
    double x20 = x19*x5;
    double x21 = 1.0/x5;
    double x22 = -n1*x9 + x21;
    double x23 = 8.3144626181532395*x5;
    double x24 = 8.3144626181532395*n3;
    double x25 = x1 + x24;
    double x26 = 16.628925236306479*x6;
    double x27 = -n4*x26;
    double x28 = -x25*x7 + x27;
    double x29 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 0.5*n4;
    double x30 = 1.0/x29;
    double x31 = -x29*x9;
    double x32 = 1.0*x21 + x31;
    double x33 = x30*x32;
    double x34 = x29*x7;
    double x35 = x34 - 2.0*x9;
    double x36 = 16.628925236306479*n1;
    double x37 = 16.628925236306479*n2;
    double x38 = 16.628925236306479*n3 + x1 + x36 + x37;
    double x39 = x30*x38;
    double x40 = x35*x39;
    double x41 = 49.886775708919437*x5;
    double x42 = x30*x35;
    double x43 = pow(x29, -2);
    double x44 = x32*x43;
    double x45 = x38*x44;
    double x46 = 6*x13;
    double x47 = -x29*x46;
    double x48 = x39*x5;
    double x49 = x38*x5;
    double x50 = 2.0*x49;
    double x51 = pow(x29, -3);
    double x52 = x32*x51;
    double x53 = x35*x43;
    double x54 = 49.886775708919437*x33 + 2*x40 + x41*x42 - x41*x44 - 2.0*x45 + x48*(x47 + 6.0*x6) + x50*x52 - x50*x53;
    double x55 = x28 + x54;
    double x56 = 1.0/x3;
    double x57 = x21 - x3*x9;
    double x58 = x56*x57;
    double x59 = 8.3144626181532395*n1;
    double x60 = x24 + x59;
    double x61 = pow(x3, -2);
    double x62 = x57*x61;
    double x63 = x60*x62;
    double x64 = x16 + x3*x7;
    double x65 = x56*x60;
    double x66 = x64*x65;
    double x67 = 24.943387854459719*x5;
    double x68 = 6*x6;
    double x69 = x5*x65;
    double x70 = x60*x61;
    double x71 = 2*x5;
    double x72 = x56*x64*x67 + 24.943387854459719*x58 - x62*x67 - 2*x63 - x64*x70*x71 + 2*x66 + x69*(-x3*x46 + x68) + x57*x60*x71/((x3)*(x3)*(x3));
    double x73 = x55 + x72;
    double x74 = 33.257850472612958*x6;
    double x75 = -x37*x6;
    double x76 = n1*x74 + x75;
    double x77 = x19*x22 + x76;
    double x78 = 8.3144626181532395*x9;
    double x79 = -x78;
    double x80 = -x9;
    double x81 = x20*(x18 + x80) + x5*(x15 + x74) + x77;
    double x82 = -n1 - n3;
    double x83 = -x7*x82 + x80;
    double x84 = x65*x83;
    double x85 = x5*x83;
    double x86 = -x63 + x66 - x70*x85 + x84;
    double x87 = -x1;
    double x88 = 4*x6;
    double x89 = 3*x13;
    double x90 = -x89*(2*n3 + x17);
    double x91 = 16.628925236306479*x56*x85 + 16.628925236306479*x58 + x69*(x88 + x90) + x7*(-x0 + x87);
    double x92 = x86 + x91;
    double x93 = x81 + x92;
    double x94 = 16.628925236306479*x9;
    double x95 = -x24;
    double x96 = x27 + x7*(x87 + x95);
    double x97 = x54 + x96;
    double x98 = x72 + x8;
    double x99 = x34 - 1.5*x9;
    double x100 = 1.0*x38;
    double x101 = x100*x5;
    double x102 = x101*x43;
    double x103 = -x102*x99;
    double x104 = x39*x99;
    double x105 = x30*x5;
    double x106 = x105*x99;
    double x107 = 0.5*x49;
    double x108 = x101*x52 + x104 + 33.257850472612958*x106 - x107*x53 + x23*x42 + 41.572313090766201*x33 + x40 - x44*x67 - 1.5*x45 + x48*(x47 + 5.0*x6);
    double x109 = x108 + x96;
    double x110 = x103 + x109;
    double x111 = x5*(x15 + x26) + x76;
    double x112 = x69*(x7 + x90) + x8 + 2*x84;
    double x113 = x111 + x112;
    double x114 = x10 + x28;
    double x115 = x114 + x54;
    double x116 = x111 + x8;
    double x117 = 24.943387854459719*x9;
    double x118 = x117 + x86;
    double x119 = 41.572313090766201*x9;
    double x120 = x103 + x113;
    double x121 = x103 + x108;
    double x122 = 0.5*x21 + x31;
    double x123 = x122*x30;
    double x124 = x34 - 1.0*x9;
    double x125 = x122*x43;
    double x126 = 2*x104 + 16.628925236306479*x105*x124 + 16.628925236306479*x106 + x107*x52 + 16.628925236306479*x123 - x125*x23 - x23*x44 + 16.628925236306479*x33 - 1.0*x45 + x48*(x47 + 4.0*x6);
    double x127 = x126 + x28;
    double x128 = -n2*x9 + x21;
    double x129 = 8.3144626181532395/n2;
    double x130 = x128*x129;
    double x131 = -n2*x14;
    double x132 = n2*x7;
    double x133 = x129*x5;
    double x134 = -x60*x7;
    double x135 = -x36*x6;
    double x136 = n2*x74 + x135;
    double x137 = x134 + x136;
    double x138 = 1.0/x4;
    double x139 = x21 - x4*x9;
    double x140 = x138*x139;
    double x141 = pow(x4, -2);
    double x142 = x139*x141;
    double x143 = x142*x2;
    double x144 = x16 + x4*x7;
    double x145 = x138*x2;
    double x146 = x144*x145;
    double x147 = x145*x5;
    double x148 = x141*x2;
    double x149 = x138*x144*x67 + x139*x2*x71/((x4)*(x4)*(x4)) + 24.943387854459719*x140 - x142*x67 - 2*x143 - x144*x148*x71 + 2*x146 + x147*(-x4*x46 + x68);
    double x150 = x137 + x149;
    double x151 = -n2 - n4;
    double x152 = -x151*x7 + x80;
    double x153 = x152*x5;
    double x154 = -x89*(2*n2 + 2*n4);
    double x155 = x145*x152;
    double x156 = -x143 + x146 - x148*x153 + x155;
    double x157 = x130 + x133*(x132 + x80) + x5*(x131 + x74) + x79;
    double x158 = x137 + x5*(x131 + x26);
    double x159 = n3 + n4;
    double x160 = -x159*x9 + x21;
    double x161 = 1.0/x159;
    double x162 = 24.943387854459719*x161;
    double x163 = 2*x25;
    double x164 = pow(x159, -2);
    double x165 = x160*x164;
    double x166 = x159*x7 + x16;
    double x167 = x163*x166;
    double x168 = x135 + x160*x162 + x161*x167 + x161*x25*x5*(-x159*x46 + x68) + x162*x166*x5 - x163*x165 - x164*x167*x5 - x165*x67 + x75 + x160*x163*x5/((x159)*(x159)*(x159));
    double x169 = x168 + x27;
    double x170 = -n4*x9 + x21;
    double x171 = 8.3144626181532395/n4;

result[0] = x11 + x20*(x16 + x18) + x5*(x12 + x15) + x73 + x77 + x8 - x22*x23/((n1)*(n1));
result[1] = x55 + x79 + x93;
result[2] = x81 - x94 + x97 + x98;
result[3] = x110 + x93;
result[4] = x113 + x115;
result[5] = x116 + x118 + x23*x56*x83 + 8.3144626181532395*x58 + x69*(x46*x82 + x88) + x97;
result[6] = x109 + x119 + x120;
result[7] = x116 + x73 + x78;
result[8] = x111 + x118 + x121 + x28 + x91;
result[9] = x120 + x127 + 49.886775708919444*x9;
result[10] = x11 + x130 + x133*(x132 + x16) + x150 + x5*(x12 + x131) + x55 - x128*x23/((n2)*(n2));
result[11] = x136 + 16.628925236306479*x138*x153 + 16.628925236306479*x140 + x147*(x154 + x88) + x156 + x157 + x7*(-x59 + x95) + x97;
result[12] = x110 + x150 + x157;
result[13] = x115 + x147*(x154 + x7) + 2*x155 + x158;
result[14] = x114 + x121 + x138*x152*x23 + 8.3144626181532395*x140 + x147*(x151*x46 + x88) + x156 + x158;
result[15] = x103 + x117 + x127 + x149 + x158;
result[16] = x169 + x54 + x98;
result[17] = x121 + x169 + x92 + x94;
result[18] = x103 + x112 + x119 + x126 + x169;
result[19] = n4*x74 - x100*x125 - x102*x124 + x107*x122*x51 + x11 + 24.943387854459719*x123 + x124*x30*x67 + 2*x124*x39 - 12.471693927229859*x125*x5 + x134 + x149 + x168 + x170*x171 + x171*x5*(n4*x7 + x16) + x48*(x47 + 3.0*x6) + x5*(-n4*x14 + x12) - x170*x23/((n4)*(n4));
}
        
static double coder_dgdp(double T, double P, double n[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double result;
    

result = n1*(*endmember[0].dmu0dP)(T, P) + n2*(*endmember[1].dmu0dP)(T, P) + n3*(*endmember[2].dmu0dP)(T, P) + n4*(*endmember[3].dmu0dP)(T, P);
    return result;
}
        
static void coder_d2gdndp(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = (*endmember[0].dmu0dP)(T, P);
result[1] = (*endmember[1].dmu0dP)(T, P);
result[2] = (*endmember[2].dmu0dP)(T, P);
result[3] = (*endmember[3].dmu0dP)(T, P);
}
        
static void coder_d3gdn2dp(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static void coder_d4gdn3dp(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
}
        
static double coder_d2gdt2(double T, double P, double n[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double result;
    

result = n1*(*endmember[0].d2mu0dT2)(T, P) + n2*(*endmember[1].d2mu0dT2)(T, P) + n3*(*endmember[2].d2mu0dT2)(T, P) + n4*(*endmember[3].d2mu0dT2)(T, P);
    return result;
}
        
static void coder_d3gdndt2(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = (*endmember[0].d2mu0dT2)(T, P);
result[1] = (*endmember[1].d2mu0dT2)(T, P);
result[2] = (*endmember[2].d2mu0dT2)(T, P);
result[3] = (*endmember[3].d2mu0dT2)(T, P);
}
        
static void coder_d4gdn2dt2(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static void coder_d5gdn3dt2(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
}
        
static double coder_d2gdtdp(double T, double P, double n[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double result;
    

result = n1*(*endmember[0].d2mu0dTdP)(T, P) + n2*(*endmember[1].d2mu0dTdP)(T, P) + n3*(*endmember[2].d2mu0dTdP)(T, P) + n4*(*endmember[3].d2mu0dTdP)(T, P);
    return result;
}
        
static void coder_d3gdndtdp(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = (*endmember[0].d2mu0dTdP)(T, P);
result[1] = (*endmember[1].d2mu0dTdP)(T, P);
result[2] = (*endmember[2].d2mu0dTdP)(T, P);
result[3] = (*endmember[3].d2mu0dTdP)(T, P);
}
        
static void coder_d4gdn2dtdp(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static void coder_d5gdn3dtdp(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
}
        
static double coder_d2gdp2(double T, double P, double n[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double result;
    

result = n1*(*endmember[0].d2mu0dP2)(T, P) + n2*(*endmember[1].d2mu0dP2)(T, P) + n3*(*endmember[2].d2mu0dP2)(T, P) + n4*(*endmember[3].d2mu0dP2)(T, P);
    return result;
}
        
static void coder_d3gdndp2(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = (*endmember[0].d2mu0dP2)(T, P);
result[1] = (*endmember[1].d2mu0dP2)(T, P);
result[2] = (*endmember[2].d2mu0dP2)(T, P);
result[3] = (*endmember[3].d2mu0dP2)(T, P);
}
        
static void coder_d4gdn2dp2(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static void coder_d5gdn3dp2(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
}
        
static double coder_d3gdt3(double T, double P, double n[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double result;
    

result = n1*(*endmember[0].d3mu0dT3)(T, P) + n2*(*endmember[1].d3mu0dT3)(T, P) + n3*(*endmember[2].d3mu0dT3)(T, P) + n4*(*endmember[3].d3mu0dT3)(T, P);
    return result;
}
        
static void coder_d4gdndt3(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = (*endmember[0].d3mu0dT3)(T, P);
result[1] = (*endmember[1].d3mu0dT3)(T, P);
result[2] = (*endmember[2].d3mu0dT3)(T, P);
result[3] = (*endmember[3].d3mu0dT3)(T, P);
}
        
static void coder_d5gdn2dt3(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static void coder_d6gdn3dt3(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
}
        
static double coder_d3gdt2dp(double T, double P, double n[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double result;
    

result = n1*(*endmember[0].d3mu0dT2dP)(T, P) + n2*(*endmember[1].d3mu0dT2dP)(T, P) + n3*(*endmember[2].d3mu0dT2dP)(T, P) + n4*(*endmember[3].d3mu0dT2dP)(T, P);
    return result;
}
        
static void coder_d4gdndt2dp(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = (*endmember[0].d3mu0dT2dP)(T, P);
result[1] = (*endmember[1].d3mu0dT2dP)(T, P);
result[2] = (*endmember[2].d3mu0dT2dP)(T, P);
result[3] = (*endmember[3].d3mu0dT2dP)(T, P);
}
        
static void coder_d5gdn2dt2dp(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static void coder_d6gdn3dt2dp(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
}
        
static double coder_d3gdtdp2(double T, double P, double n[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double result;
    

result = n1*(*endmember[0].d3mu0dTdP2)(T, P) + n2*(*endmember[1].d3mu0dTdP2)(T, P) + n3*(*endmember[2].d3mu0dTdP2)(T, P) + n4*(*endmember[3].d3mu0dTdP2)(T, P);
    return result;
}
        
static void coder_d4gdndtdp2(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = (*endmember[0].d3mu0dTdP2)(T, P);
result[1] = (*endmember[1].d3mu0dTdP2)(T, P);
result[2] = (*endmember[2].d3mu0dTdP2)(T, P);
result[3] = (*endmember[3].d3mu0dTdP2)(T, P);
}
        
static void coder_d5gdn2dtdp2(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static void coder_d6gdn3dtdp2(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
}
        
static double coder_d3gdp3(double T, double P, double n[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double result;
    

result = n1*(*endmember[0].d3mu0dP3)(T, P) + n2*(*endmember[1].d3mu0dP3)(T, P) + n3*(*endmember[2].d3mu0dP3)(T, P) + n4*(*endmember[3].d3mu0dP3)(T, P);
    return result;
}
        
static void coder_d4gdndp3(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = (*endmember[0].d3mu0dP3)(T, P);
result[1] = (*endmember[1].d3mu0dP3)(T, P);
result[2] = (*endmember[2].d3mu0dP3)(T, P);
result[3] = (*endmember[3].d3mu0dP3)(T, P);
}
        
static void coder_d5gdn2dp3(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static void coder_d6gdn3dp3(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
}
        
static double coder_s(double T, double P, double n[4]) {
    double result = -coder_dgdt(T, P, n);
    return result;
}

static double coder_v(double T, double P, double n[4]) {
    double result = coder_dgdp(T, P, n);
    return result;
}

static double coder_cv(double T, double P, double n[4]) {
    double result = -T*coder_d2gdt2(T, P, n);
    double dvdt = coder_d2gdtdp(T, P, n);
    double dvdp = coder_d2gdp2(T, P, n);
    result += T*dvdt*dvdt/dvdp;
    return result;
}

static double coder_cp(double T, double P, double n[4]) {
    double result = -T*coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdt(double T, double P, double n[4]) {
    double result = -T*coder_d3gdt3(T, P, n) - coder_d2gdt2(T, P, n);
    return result;
}

static double coder_alpha(double T, double P, double n[4]) {
    double result = coder_d2gdtdp(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_beta(double T, double P, double n[4]) {
    double result = -coder_d2gdp2(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_K(double T, double P, double n[4]) {
    double result = -coder_dgdp(T, P, n)/coder_d2gdp2(T, P, n);
    return result;
}

static double coder_Kp(double T, double P, double n[4]) {
    double result = coder_dgdp(T, P, n);
    result *= coder_d3gdp3(T, P, n);
    result /= pow(coder_d2gdp2(T, P, n), 2.0);
    return result - 1.0;
}

