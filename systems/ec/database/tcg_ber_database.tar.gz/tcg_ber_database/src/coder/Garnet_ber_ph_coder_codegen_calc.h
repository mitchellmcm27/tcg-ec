#include <math.h>


static double coder_g(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = 1.0/(n1 + n2 + n3);

result = 8.3144626181532395*T*(n1*log(n1*x0) + n2*log(n2*x0) + n3*log(n3*x0)) + n1*(*endmember[0].mu0)(T, P) + n2*(*endmember[1].mu0)(T, P) + n3*(*endmember[2].mu0)(T, P);
    return result;
}
        
static void coder_dgdn(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = n1 + n2 + n3;
    double x1 = 1.0/x0;
    double x2 = n2*x1;
    double x3 = -x2;
    double x4 = n3*x1;
    double x5 = -x4;
    double x6 = n1*x1;
    double x7 = pow(x0, -2);
    double x8 = 8.3144626181532395*T;
    double x9 = -x6;

result[0] = x8*(x0*(-n1*x7 + x1) + x3 + x5 + log(x6)) + (*endmember[0].mu0)(T, P);
result[1] = x8*(x0*(-n2*x7 + x1) + x5 + x9 + log(x2)) + (*endmember[1].mu0)(T, P);
result[2] = x8*(x0*(-n3*x7 + x1) + x3 + x9 + log(x4)) + (*endmember[2].mu0)(T, P);
}
        
static void coder_d2gdn2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = n1 + n2 + n3;
    double x1 = pow(x0, -2);
    double x2 = n2*x1;
    double x3 = n3*x1;
    double x4 = -2*x1;
    double x5 = 2/((x0)*(x0)*(x0));
    double x6 = n1*x5;
    double x7 = 1.0/x0;
    double x8 = n1*x1;
    double x9 = -x8;
    double x10 = x7 + x9;
    double x11 = 8.3144626181532395*T;
    double x12 = -x1;
    double x13 = x3 - x7;
    double x14 = x11*(x0*(x12 + x6) + x13 + x2 + x9);
    double x15 = n2*x5;
    double x16 = -x2;
    double x17 = x16 + x7;
    double x18 = -x3 + x7;

result[0] = x11*(x0*(x4 + x6) + x10 + x2 + x3 + x0*x10/n1);
result[1] = x14;
result[2] = x14;
result[3] = x11*(x0*(x15 + x4) + x17 + x3 + x8 + x0*x17/n2);
result[4] = x11*(x0*(x12 + x15) + x13 + x16 + x8);
result[5] = x11*(x0*(n3*x5 + x4) + x18 + x2 + x8 + x0*x18/n3);
}
        
static void coder_d3gdn3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = n1 + n2 + n3;
    double x1 = pow(x0, -3);
    double x2 = 6*x1;
    double x3 = 6/((x0)*(x0)*(x0)*(x0));
    double x4 = -n1*x3;
    double x5 = pow(x0, -2);
    double x6 = -2*x5;
    double x7 = 2*x1;
    double x8 = n1*x7;
    double x9 = 1.0/n1;
    double x10 = x0*x9;
    double x11 = 1.0/x0;
    double x12 = -n1*x5 + x11;
    double x13 = n2*x7;
    double x14 = -x13;
    double x15 = 4*x1;
    double x16 = n1*x15 + x14;
    double x17 = x12*x9 + x16;
    double x18 = n3*x7;
    double x19 = -x18;
    double x20 = -4*x5;
    double x21 = x19 + x20;
    double x22 = 8.3144626181532395*T;
    double x23 = -x5;
    double x24 = x19 + x6;
    double x25 = x22*(x0*(x15 + x4) + x10*(x23 + x8) + x17 + x24);
    double x26 = x19 + x5;
    double x27 = x22*(x0*(x4 + x7) + x16 + x26);
    double x28 = -n2*x3;
    double x29 = 1.0/n2;
    double x30 = x0*x29;
    double x31 = -n2*x5 + x11;
    double x32 = -x8;
    double x33 = n2*x15 + x32;
    double x34 = x29*x31 + x33;
    double x35 = 1.0/n3;
    double x36 = -n3*x5 + x11;

result[0] = x22*(x0*(x2 + x4) + x10*(x6 + x8) + x17 + x21 - x0*x12/((n1)*(n1)));
result[1] = x25;
result[2] = x25;
result[3] = x27;
result[4] = x27;
result[5] = x27;
result[6] = x22*(x0*(x2 + x28) + x21 + x30*(x13 + x6) + x34 - x0*x31/((n2)*(n2)));
result[7] = x22*(x0*(x15 + x28) + x24 + x30*(x13 + x23) + x34);
result[8] = x22*(x0*(x28 + x7) + x26 + x33);
result[9] = x22*(n3*x15 + x0*x35*(x18 + x6) + x0*(-n3*x3 + x2) + x14 + x20 + x32 + x35*x36 - x0*x36/((n3)*(n3)));
}
        
static double coder_dgdt(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = 1.0/(n1 + n2 + n3);

result = 8.3144626181532395*n1*log(n1*x0) + n1*(*endmember[0].dmu0dT)(T, P) + 8.3144626181532395*n2*log(n2*x0) + n2*(*endmember[1].dmu0dT)(T, P) + 8.3144626181532395*n3*log(n3*x0) + n3*(*endmember[2].dmu0dT)(T, P);
    return result;
}
        
static void coder_d2gdndt(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = n1 + n2 + n3;
    double x1 = 1.0/x0;
    double x2 = n2*x1;
    double x3 = -8.3144626181532395*x2;
    double x4 = n3*x1;
    double x5 = -8.3144626181532395*x4;
    double x6 = n1*x1;
    double x7 = pow(x0, -2);
    double x8 = 8.3144626181532395*x0;
    double x9 = -8.3144626181532395*x6;

result[0] = x3 + x5 + x8*(-n1*x7 + x1) + 8.3144626181532395*log(x6) + (*endmember[0].dmu0dT)(T, P);
result[1] = x5 + x8*(-n2*x7 + x1) + x9 + 8.3144626181532395*log(x2) + (*endmember[1].dmu0dT)(T, P);
result[2] = x3 + x8*(-n3*x7 + x1) + x9 + 8.3144626181532395*log(x4) + (*endmember[2].dmu0dT)(T, P);
}
        
static void coder_d3gdn2dt(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = n1 + n2 + n3;
    double x1 = pow(x0, -2);
    double x2 = -16.628925236306479*x1;
    double x3 = 16.628925236306479/((x0)*(x0)*(x0));
    double x4 = n1*x3;
    double x5 = 1.0/x0;
    double x6 = n1*x1;
    double x7 = 8.3144626181532395*x0;
    double x8 = 8.3144626181532395*x1;
    double x9 = n2*x8;
    double x10 = 8.3144626181532395*x6;
    double x11 = -x10 + x9;
    double x12 = n3*x8;
    double x13 = 8.3144626181532395*x5;
    double x14 = x12 + x13;
    double x15 = -x8;
    double x16 = x12 - x13;
    double x17 = x0*(x15 + x4) + x11 + x16;
    double x18 = n2*x3;
    double x19 = x10 - x9;

result[0] = x0*(x2 + x4) + x11 + x14 + x7*(x5 - x6)/n1;
result[1] = x17;
result[2] = x17;
result[3] = x0*(x18 + x2) + x14 + x19 + x7*(-n2*x1 + x5)/n2;
result[4] = x0*(x15 + x18) + x16 + x19;
result[5] = x0*(n3*x3 + x2) + x10 - x12 + x13 + x9 + x7*(-n3*x1 + x5)/n3;
}
        
static void coder_d4gdn3dt(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = n1 + n2 + n3;
    double x1 = pow(x0, -3);
    double x2 = 49.886775708919437*x1;
    double x3 = 49.886775708919437/((x0)*(x0)*(x0)*(x0));
    double x4 = -n1*x3;
    double x5 = pow(x0, -2);
    double x6 = -2*x5;
    double x7 = 2*x1;
    double x8 = n1*x7;
    double x9 = 8.3144626181532395/n1;
    double x10 = x0*x9;
    double x11 = 1.0/x0;
    double x12 = -n1*x5 + x11;
    double x13 = 8.3144626181532395*x0;
    double x14 = 33.257850472612958*x1;
    double x15 = 16.628925236306479*x1;
    double x16 = -n2*x15;
    double x17 = n1*x14 + x16;
    double x18 = x12*x9 + x17;
    double x19 = -n3*x15;
    double x20 = -33.257850472612958*x5;
    double x21 = x19 + x20;
    double x22 = -x5;
    double x23 = x19 - 16.628925236306479*x5;
    double x24 = x0*(x14 + x4) + x10*(x22 + x8) + x18 + x23;
    double x25 = x19 + 8.3144626181532395*x5;
    double x26 = x0*(x15 + x4) + x17 + x25;
    double x27 = -n2*x3;
    double x28 = n2*x7;
    double x29 = 8.3144626181532395/n2;
    double x30 = x0*x29;
    double x31 = -n2*x5 + x11;
    double x32 = -n1*x15;
    double x33 = n2*x14 + x32;
    double x34 = x29*x31 + x33;
    double x35 = -n3*x5 + x11;
    double x36 = 8.3144626181532395/n3;

result[0] = x0*(x2 + x4) + x10*(x6 + x8) + x18 + x21 - x12*x13/((n1)*(n1));
result[1] = x24;
result[2] = x24;
result[3] = x26;
result[4] = x26;
result[5] = x26;
result[6] = x0*(x2 + x27) + x21 + x30*(x28 + x6) + x34 - x13*x31/((n2)*(n2));
result[7] = x0*(x14 + x27) + x23 + x30*(x22 + x28) + x34;
result[8] = x0*(x15 + x27) + x25 + x33;
result[9] = n3*x14 + x0*x36*(n3*x7 + x6) + x0*(-n3*x3 + x2) + x16 + x20 + x32 + x35*x36 - x13*x35/((n3)*(n3));
}
        
static double coder_dgdp(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    

result = n1*(*endmember[0].dmu0dP)(T, P) + n2*(*endmember[1].dmu0dP)(T, P) + n3*(*endmember[2].dmu0dP)(T, P);
    return result;
}
        
static void coder_d2gdndp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = (*endmember[0].dmu0dP)(T, P);
result[1] = (*endmember[1].dmu0dP)(T, P);
result[2] = (*endmember[2].dmu0dP)(T, P);
}
        
static void coder_d3gdn2dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d4gdn3dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d2gdt2(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    

result = n1*(*endmember[0].d2mu0dT2)(T, P) + n2*(*endmember[1].d2mu0dT2)(T, P) + n3*(*endmember[2].d2mu0dT2)(T, P);
    return result;
}
        
static void coder_d3gdndt2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = (*endmember[0].d2mu0dT2)(T, P);
result[1] = (*endmember[1].d2mu0dT2)(T, P);
result[2] = (*endmember[2].d2mu0dT2)(T, P);
}
        
static void coder_d4gdn2dt2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d5gdn3dt2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d2gdtdp(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    

result = n1*(*endmember[0].d2mu0dTdP)(T, P) + n2*(*endmember[1].d2mu0dTdP)(T, P) + n3*(*endmember[2].d2mu0dTdP)(T, P);
    return result;
}
        
static void coder_d3gdndtdp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = (*endmember[0].d2mu0dTdP)(T, P);
result[1] = (*endmember[1].d2mu0dTdP)(T, P);
result[2] = (*endmember[2].d2mu0dTdP)(T, P);
}
        
static void coder_d4gdn2dtdp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d5gdn3dtdp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d2gdp2(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    

result = n1*(*endmember[0].d2mu0dP2)(T, P) + n2*(*endmember[1].d2mu0dP2)(T, P) + n3*(*endmember[2].d2mu0dP2)(T, P);
    return result;
}
        
static void coder_d3gdndp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = (*endmember[0].d2mu0dP2)(T, P);
result[1] = (*endmember[1].d2mu0dP2)(T, P);
result[2] = (*endmember[2].d2mu0dP2)(T, P);
}
        
static void coder_d4gdn2dp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d5gdn3dp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d3gdt3(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    

result = n1*(*endmember[0].d3mu0dT3)(T, P) + n2*(*endmember[1].d3mu0dT3)(T, P) + n3*(*endmember[2].d3mu0dT3)(T, P);
    return result;
}
        
static void coder_d4gdndt3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = (*endmember[0].d3mu0dT3)(T, P);
result[1] = (*endmember[1].d3mu0dT3)(T, P);
result[2] = (*endmember[2].d3mu0dT3)(T, P);
}
        
static void coder_d5gdn2dt3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d6gdn3dt3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d3gdt2dp(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    

result = n1*(*endmember[0].d3mu0dT2dP)(T, P) + n2*(*endmember[1].d3mu0dT2dP)(T, P) + n3*(*endmember[2].d3mu0dT2dP)(T, P);
    return result;
}
        
static void coder_d4gdndt2dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = (*endmember[0].d3mu0dT2dP)(T, P);
result[1] = (*endmember[1].d3mu0dT2dP)(T, P);
result[2] = (*endmember[2].d3mu0dT2dP)(T, P);
}
        
static void coder_d5gdn2dt2dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d6gdn3dt2dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d3gdtdp2(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    

result = n1*(*endmember[0].d3mu0dTdP2)(T, P) + n2*(*endmember[1].d3mu0dTdP2)(T, P) + n3*(*endmember[2].d3mu0dTdP2)(T, P);
    return result;
}
        
static void coder_d4gdndtdp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = (*endmember[0].d3mu0dTdP2)(T, P);
result[1] = (*endmember[1].d3mu0dTdP2)(T, P);
result[2] = (*endmember[2].d3mu0dTdP2)(T, P);
}
        
static void coder_d5gdn2dtdp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d6gdn3dtdp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d3gdp3(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    

result = n1*(*endmember[0].d3mu0dP3)(T, P) + n2*(*endmember[1].d3mu0dP3)(T, P) + n3*(*endmember[2].d3mu0dP3)(T, P);
    return result;
}
        
static void coder_d4gdndp3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = (*endmember[0].d3mu0dP3)(T, P);
result[1] = (*endmember[1].d3mu0dP3)(T, P);
result[2] = (*endmember[2].d3mu0dP3)(T, P);
}
        
static void coder_d5gdn2dp3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d6gdn3dp3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_s(double T, double P, double n[3]) {
    double result = -coder_dgdt(T, P, n);
    return result;
}

static double coder_v(double T, double P, double n[3]) {
    double result = coder_dgdp(T, P, n);
    return result;
}

static double coder_cv(double T, double P, double n[3]) {
    double result = -T*coder_d2gdt2(T, P, n);
    double dvdt = coder_d2gdtdp(T, P, n);
    double dvdp = coder_d2gdp2(T, P, n);
    result += T*dvdt*dvdt/dvdp;
    return result;
}

static double coder_cp(double T, double P, double n[3]) {
    double result = -T*coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdt(double T, double P, double n[3]) {
    double result = -T*coder_d3gdt3(T, P, n) - coder_d2gdt2(T, P, n);
    return result;
}

static double coder_alpha(double T, double P, double n[3]) {
    double result = coder_d2gdtdp(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_beta(double T, double P, double n[3]) {
    double result = -coder_d2gdp2(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_K(double T, double P, double n[3]) {
    double result = -coder_dgdp(T, P, n)/coder_d2gdp2(T, P, n);
    return result;
}

static double coder_Kp(double T, double P, double n[3]) {
    double result = coder_dgdp(T, P, n);
    result *= coder_d3gdp3(T, P, n);
    result /= pow(coder_d2gdp2(T, P, n), 2.0);
    return result - 1.0;
}

