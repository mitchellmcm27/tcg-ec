#include <math.h>


static double coder_g(double T, double P, double n[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double result;
    
    double x0 = 1.0/(n1 + n2 + n3 + n4);

result = 8.3144626181532395*T*(n1*log(n1*x0) + n2*log(n2*x0) + n3*log(n3*x0) + n4*log(n4*x0)) + n1*(*endmember[0].mu0)(T, P) + n2*(*endmember[1].mu0)(T, P) + n3*(*endmember[2].mu0)(T, P) + n4*(*endmember[3].mu0)(T, P);
    return result;
}
        
static void coder_dgdn(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];

    double x0 = n1 + n2 + n3 + n4;
    double x1 = 1.0/x0;
    double x2 = pow(x0, -2);
    double x3 = n2*x1;
    double x4 = -x3;
    double x5 = n1*x1;
    double x6 = n3*x1;
    double x7 = -x6;
    double x8 = n4*x1;
    double x9 = -x8;
    double x10 = x7 + x9;
    double x11 = 8.3144626181532395*T;
    double x12 = -x5;
    double x13 = x12 + x4;

result[0] = x11*(x0*(-n1*x2 + x1) + x10 + x4 + log(x5)) + (*endmember[0].mu0)(T, P);
result[1] = x11*(x0*(-n2*x2 + x1) + x10 + x12 + log(x3)) + (*endmember[1].mu0)(T, P);
result[2] = x11*(x0*(-n3*x2 + x1) + x13 + x9 + log(x6)) + (*endmember[2].mu0)(T, P);
result[3] = x11*(x0*(-n4*x2 + x1) + x13 + x7 + log(x8)) + (*endmember[3].mu0)(T, P);
}
        
static void coder_d2gdn2(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];

    double x0 = n1 + n2 + n3 + n4;
    double x1 = pow(x0, -2);
    double x2 = n2*x1;
    double x3 = -2*x1;
    double x4 = 2/((x0)*(x0)*(x0));
    double x5 = n1*x4;
    double x6 = 1.0/x0;
    double x7 = n1*x1;
    double x8 = -x7;
    double x9 = x6 + x8;
    double x10 = n3*x1;
    double x11 = n4*x1;
    double x12 = x10 + x11;
    double x13 = 8.3144626181532395*T;
    double x14 = -x1;
    double x15 = -x6;
    double x16 = x12 + x15;
    double x17 = x13*(x0*(x14 + x5) + x16 + x2 + x8);
    double x18 = n2*x4;
    double x19 = -x2;
    double x20 = x19 + x6;
    double x21 = x13*(x0*(x14 + x18) + x16 + x19 + x7);
    double x22 = n3*x4;
    double x23 = -x10;
    double x24 = x23 + x6;
    double x25 = x2 + x7;
    double x26 = x11 + x25;
    double x27 = -x11 + x6;

result[0] = x13*(x0*(x3 + x5) + x12 + x2 + x9 + x0*x9/n1);
result[1] = x17;
result[2] = x17;
result[3] = x17;
result[4] = x13*(x0*(x18 + x3) + x12 + x20 + x7 + x0*x20/n2);
result[5] = x21;
result[6] = x21;
result[7] = x13*(x0*(x22 + x3) + x24 + x26 + x0*x24/n3);
result[8] = x13*(x0*(x14 + x22) + x15 + x23 + x26);
result[9] = x13*(x0*(n4*x4 + x3) + x10 + x25 + x27 + x0*x27/n4);
}
        
static void coder_d3gdn3(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];

    double x0 = n1 + n2 + n3 + n4;
    double x1 = pow(x0, -3);
    double x2 = 6*x1;
    double x3 = 6/((x0)*(x0)*(x0)*(x0));
    double x4 = -n1*x3;
    double x5 = pow(x0, -2);
    double x6 = -2*x5;
    double x7 = 2*x1;
    double x8 = n1*x7;
    double x9 = 1.0/n1;
    double x10 = x0*x9;
    double x11 = 1.0/x0;
    double x12 = -n1*x5 + x11;
    double x13 = n2*x7;
    double x14 = -x13;
    double x15 = 4*x1;
    double x16 = n1*x15 + x14;
    double x17 = x12*x9 + x16;
    double x18 = -4*x5;
    double x19 = n3*x7;
    double x20 = -x19;
    double x21 = n4*x7;
    double x22 = -x21;
    double x23 = x20 + x22;
    double x24 = x18 + x23;
    double x25 = 8.3144626181532395*T;
    double x26 = -x5;
    double x27 = x23 + x6;
    double x28 = x25*(x0*(x15 + x4) + x10*(x26 + x8) + x17 + x27);
    double x29 = x23 + x5;
    double x30 = x25*(x0*(x4 + x7) + x16 + x29);
    double x31 = -n2*x3;
    double x32 = 1.0/n2;
    double x33 = x0*x32;
    double x34 = -n2*x5 + x11;
    double x35 = -x8;
    double x36 = n2*x15 + x35;
    double x37 = x32*x34 + x36;
    double x38 = x25*(x0*(x15 + x31) + x27 + x33*(x13 + x26) + x37);
    double x39 = x25*(x0*(x31 + x7) + x29 + x36);
    double x40 = -n3*x3;
    double x41 = 1.0/n3;
    double x42 = x0*x41;
    double x43 = -n3*x5 + x11;
    double x44 = x14 + x35;
    double x45 = n3*x15 + x22 + x44;
    double x46 = x41*x43 + x45;
    double x47 = 1.0/n4;
    double x48 = -n4*x5 + x11;

result[0] = x25*(x0*(x2 + x4) + x10*(x6 + x8) + x17 + x24 - x0*x12/((n1)*(n1)));
result[1] = x28;
result[2] = x28;
result[3] = x28;
result[4] = x30;
result[5] = x30;
result[6] = x30;
result[7] = x30;
result[8] = x30;
result[9] = x30;
result[10] = x25*(x0*(x2 + x31) + x24 + x33*(x13 + x6) + x37 - x0*x34/((n2)*(n2)));
result[11] = x38;
result[12] = x38;
result[13] = x39;
result[14] = x39;
result[15] = x39;
result[16] = x25*(x0*(x2 + x40) + x18 + x42*(x19 + x6) + x46 - x0*x43/((n3)*(n3)));
result[17] = x25*(x0*(x15 + x40) + x42*(x19 + x26) + x46 + x6);
result[18] = x25*(x0*(x40 + x7) + x45 + x5);
result[19] = x25*(n4*x15 + x0*x47*(x21 + x6) + x0*(-n4*x3 + x2) + x18 + x20 + x44 + x47*x48 - x0*x48/((n4)*(n4)));
}
        
static double coder_dgdt(double T, double P, double n[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double result;
    
    double x0 = 1.0/(n1 + n2 + n3 + n4);

result = 8.3144626181532395*n1*log(n1*x0) + n1*(*endmember[0].dmu0dT)(T, P) + 8.3144626181532395*n2*log(n2*x0) + n2*(*endmember[1].dmu0dT)(T, P) + 8.3144626181532395*n3*log(n3*x0) + n3*(*endmember[2].dmu0dT)(T, P) + 8.3144626181532395*n4*log(n4*x0) + n4*(*endmember[3].dmu0dT)(T, P);
    return result;
}
        
static void coder_d2gdndt(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];

    double x0 = n1 + n2 + n3 + n4;
    double x1 = 1.0/x0;
    double x2 = n1*x1;
    double x3 = pow(x0, -2);
    double x4 = 8.3144626181532395*x0;
    double x5 = n2*x1;
    double x6 = -8.3144626181532395*x5;
    double x7 = n3*x1;
    double x8 = -8.3144626181532395*x7;
    double x9 = n4*x1;
    double x10 = -8.3144626181532395*x9;
    double x11 = x10 + x8;
    double x12 = -8.3144626181532395*x2;
    double x13 = x12 + x6;

result[0] = x11 + x4*(-n1*x3 + x1) + x6 + 8.3144626181532395*log(x2) + (*endmember[0].dmu0dT)(T, P);
result[1] = x11 + x12 + x4*(-n2*x3 + x1) + 8.3144626181532395*log(x5) + (*endmember[1].dmu0dT)(T, P);
result[2] = x10 + x13 + x4*(-n3*x3 + x1) + 8.3144626181532395*log(x7) + (*endmember[2].dmu0dT)(T, P);
result[3] = x13 + x4*(-n4*x3 + x1) + x8 + 8.3144626181532395*log(x9) + (*endmember[3].dmu0dT)(T, P);
}
        
static void coder_d3gdn2dt(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];

    double x0 = n1 + n2 + n3 + n4;
    double x1 = pow(x0, -2);
    double x2 = -16.628925236306479*x1;
    double x3 = 16.628925236306479/((x0)*(x0)*(x0));
    double x4 = n1*x3;
    double x5 = 1.0/x0;
    double x6 = n1*x1;
    double x7 = 8.3144626181532395*x0;
    double x8 = 8.3144626181532395*x1;
    double x9 = n2*x8;
    double x10 = 8.3144626181532395*x6;
    double x11 = -x10 + x9;
    double x12 = 8.3144626181532395*x5;
    double x13 = n3*x8;
    double x14 = n4*x8;
    double x15 = x13 + x14;
    double x16 = x12 + x15;
    double x17 = -x8;
    double x18 = -x12;
    double x19 = x15 + x18;
    double x20 = x0*(x17 + x4) + x11 + x19;
    double x21 = n2*x3;
    double x22 = x10 - x9;
    double x23 = x0*(x17 + x21) + x19 + x22;
    double x24 = n3*x3;
    double x25 = x10 + x9;
    double x26 = -x13 + x14 + x25;

result[0] = x0*(x2 + x4) + x11 + x16 + x7*(x5 - x6)/n1;
result[1] = x20;
result[2] = x20;
result[3] = x20;
result[4] = x0*(x2 + x21) + x16 + x22 + x7*(-n2*x1 + x5)/n2;
result[5] = x23;
result[6] = x23;
result[7] = x0*(x2 + x24) + x12 + x26 + x7*(-n3*x1 + x5)/n3;
result[8] = x0*(x17 + x24) + x18 + x26;
result[9] = x0*(n4*x3 + x2) + x12 + x13 - x14 + x25 + x7*(-n4*x1 + x5)/n4;
}
        
static void coder_d4gdn3dt(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];

    double x0 = n1 + n2 + n3 + n4;
    double x1 = pow(x0, -3);
    double x2 = 49.886775708919437*x1;
    double x3 = 49.886775708919437/((x0)*(x0)*(x0)*(x0));
    double x4 = -n1*x3;
    double x5 = pow(x0, -2);
    double x6 = -2*x5;
    double x7 = 2*x1;
    double x8 = n1*x7;
    double x9 = 8.3144626181532395/n1;
    double x10 = x0*x9;
    double x11 = 1.0/x0;
    double x12 = -n1*x5 + x11;
    double x13 = 8.3144626181532395*x0;
    double x14 = 33.257850472612958*x1;
    double x15 = 16.628925236306479*x1;
    double x16 = -n2*x15;
    double x17 = n1*x14 + x16;
    double x18 = x12*x9 + x17;
    double x19 = -33.257850472612958*x5;
    double x20 = -n3*x15;
    double x21 = -n4*x15;
    double x22 = x20 + x21;
    double x23 = x19 + x22;
    double x24 = -x5;
    double x25 = -16.628925236306479*x5;
    double x26 = x22 + x25;
    double x27 = x0*(x14 + x4) + x10*(x24 + x8) + x18 + x26;
    double x28 = 8.3144626181532395*x5;
    double x29 = x22 + x28;
    double x30 = x0*(x15 + x4) + x17 + x29;
    double x31 = -n2*x3;
    double x32 = n2*x7;
    double x33 = 8.3144626181532395/n2;
    double x34 = x0*x33;
    double x35 = -n2*x5 + x11;
    double x36 = -n1*x15;
    double x37 = n2*x14 + x36;
    double x38 = x33*x35 + x37;
    double x39 = x0*(x14 + x31) + x26 + x34*(x24 + x32) + x38;
    double x40 = x0*(x15 + x31) + x29 + x37;
    double x41 = -n3*x3;
    double x42 = n3*x7;
    double x43 = 8.3144626181532395/n3;
    double x44 = x0*x43;
    double x45 = -n3*x5 + x11;
    double x46 = x16 + x36;
    double x47 = n3*x14 + x21 + x46;
    double x48 = x43*x45 + x47;
    double x49 = -n4*x5 + x11;
    double x50 = 8.3144626181532395/n4;

result[0] = x0*(x2 + x4) + x10*(x6 + x8) + x18 + x23 - x12*x13/((n1)*(n1));
result[1] = x27;
result[2] = x27;
result[3] = x27;
result[4] = x30;
result[5] = x30;
result[6] = x30;
result[7] = x30;
result[8] = x30;
result[9] = x30;
result[10] = x0*(x2 + x31) + x23 + x34*(x32 + x6) + x38 - x13*x35/((n2)*(n2));
result[11] = x39;
result[12] = x39;
result[13] = x40;
result[14] = x40;
result[15] = x40;
result[16] = x0*(x2 + x41) + x19 + x44*(x42 + x6) + x48 - x13*x45/((n3)*(n3));
result[17] = x0*(x14 + x41) + x25 + x44*(x24 + x42) + x48;
result[18] = x0*(x15 + x41) + x28 + x47;
result[19] = n4*x14 + x0*x50*(n4*x7 + x6) + x0*(-n4*x3 + x2) + x19 + x20 + x46 + x49*x50 - x13*x49/((n4)*(n4));
}
        
static double coder_dgdp(double T, double P, double n[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double result;
    

result = n1*(*endmember[0].dmu0dP)(T, P) + n2*(*endmember[1].dmu0dP)(T, P) + n3*(*endmember[2].dmu0dP)(T, P) + n4*(*endmember[3].dmu0dP)(T, P);
    return result;
}
        
static void coder_d2gdndp(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = (*endmember[0].dmu0dP)(T, P);
result[1] = (*endmember[1].dmu0dP)(T, P);
result[2] = (*endmember[2].dmu0dP)(T, P);
result[3] = (*endmember[3].dmu0dP)(T, P);
}
        
static void coder_d3gdn2dp(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static void coder_d4gdn3dp(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
}
        
static double coder_d2gdt2(double T, double P, double n[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double result;
    

result = n1*(*endmember[0].d2mu0dT2)(T, P) + n2*(*endmember[1].d2mu0dT2)(T, P) + n3*(*endmember[2].d2mu0dT2)(T, P) + n4*(*endmember[3].d2mu0dT2)(T, P);
    return result;
}
        
static void coder_d3gdndt2(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = (*endmember[0].d2mu0dT2)(T, P);
result[1] = (*endmember[1].d2mu0dT2)(T, P);
result[2] = (*endmember[2].d2mu0dT2)(T, P);
result[3] = (*endmember[3].d2mu0dT2)(T, P);
}
        
static void coder_d4gdn2dt2(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static void coder_d5gdn3dt2(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
}
        
static double coder_d2gdtdp(double T, double P, double n[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double result;
    

result = n1*(*endmember[0].d2mu0dTdP)(T, P) + n2*(*endmember[1].d2mu0dTdP)(T, P) + n3*(*endmember[2].d2mu0dTdP)(T, P) + n4*(*endmember[3].d2mu0dTdP)(T, P);
    return result;
}
        
static void coder_d3gdndtdp(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = (*endmember[0].d2mu0dTdP)(T, P);
result[1] = (*endmember[1].d2mu0dTdP)(T, P);
result[2] = (*endmember[2].d2mu0dTdP)(T, P);
result[3] = (*endmember[3].d2mu0dTdP)(T, P);
}
        
static void coder_d4gdn2dtdp(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static void coder_d5gdn3dtdp(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
}
        
static double coder_d2gdp2(double T, double P, double n[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double result;
    

result = n1*(*endmember[0].d2mu0dP2)(T, P) + n2*(*endmember[1].d2mu0dP2)(T, P) + n3*(*endmember[2].d2mu0dP2)(T, P) + n4*(*endmember[3].d2mu0dP2)(T, P);
    return result;
}
        
static void coder_d3gdndp2(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = (*endmember[0].d2mu0dP2)(T, P);
result[1] = (*endmember[1].d2mu0dP2)(T, P);
result[2] = (*endmember[2].d2mu0dP2)(T, P);
result[3] = (*endmember[3].d2mu0dP2)(T, P);
}
        
static void coder_d4gdn2dp2(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static void coder_d5gdn3dp2(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
}
        
static double coder_d3gdt3(double T, double P, double n[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double result;
    

result = n1*(*endmember[0].d3mu0dT3)(T, P) + n2*(*endmember[1].d3mu0dT3)(T, P) + n3*(*endmember[2].d3mu0dT3)(T, P) + n4*(*endmember[3].d3mu0dT3)(T, P);
    return result;
}
        
static void coder_d4gdndt3(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = (*endmember[0].d3mu0dT3)(T, P);
result[1] = (*endmember[1].d3mu0dT3)(T, P);
result[2] = (*endmember[2].d3mu0dT3)(T, P);
result[3] = (*endmember[3].d3mu0dT3)(T, P);
}
        
static void coder_d5gdn2dt3(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static void coder_d6gdn3dt3(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
}
        
static double coder_d3gdt2dp(double T, double P, double n[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double result;
    

result = n1*(*endmember[0].d3mu0dT2dP)(T, P) + n2*(*endmember[1].d3mu0dT2dP)(T, P) + n3*(*endmember[2].d3mu0dT2dP)(T, P) + n4*(*endmember[3].d3mu0dT2dP)(T, P);
    return result;
}
        
static void coder_d4gdndt2dp(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = (*endmember[0].d3mu0dT2dP)(T, P);
result[1] = (*endmember[1].d3mu0dT2dP)(T, P);
result[2] = (*endmember[2].d3mu0dT2dP)(T, P);
result[3] = (*endmember[3].d3mu0dT2dP)(T, P);
}
        
static void coder_d5gdn2dt2dp(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static void coder_d6gdn3dt2dp(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
}
        
static double coder_d3gdtdp2(double T, double P, double n[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double result;
    

result = n1*(*endmember[0].d3mu0dTdP2)(T, P) + n2*(*endmember[1].d3mu0dTdP2)(T, P) + n3*(*endmember[2].d3mu0dTdP2)(T, P) + n4*(*endmember[3].d3mu0dTdP2)(T, P);
    return result;
}
        
static void coder_d4gdndtdp2(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = (*endmember[0].d3mu0dTdP2)(T, P);
result[1] = (*endmember[1].d3mu0dTdP2)(T, P);
result[2] = (*endmember[2].d3mu0dTdP2)(T, P);
result[3] = (*endmember[3].d3mu0dTdP2)(T, P);
}
        
static void coder_d5gdn2dtdp2(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static void coder_d6gdn3dtdp2(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
}
        
static double coder_d3gdp3(double T, double P, double n[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double result;
    

result = n1*(*endmember[0].d3mu0dP3)(T, P) + n2*(*endmember[1].d3mu0dP3)(T, P) + n3*(*endmember[2].d3mu0dP3)(T, P) + n4*(*endmember[3].d3mu0dP3)(T, P);
    return result;
}
        
static void coder_d4gdndp3(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = (*endmember[0].d3mu0dP3)(T, P);
result[1] = (*endmember[1].d3mu0dP3)(T, P);
result[2] = (*endmember[2].d3mu0dP3)(T, P);
result[3] = (*endmember[3].d3mu0dP3)(T, P);
}
        
static void coder_d5gdn2dp3(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static void coder_d6gdn3dp3(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
}
        
static double coder_s(double T, double P, double n[4]) {
    double result = -coder_dgdt(T, P, n);
    return result;
}

static double coder_v(double T, double P, double n[4]) {
    double result = coder_dgdp(T, P, n);
    return result;
}

static double coder_cv(double T, double P, double n[4]) {
    double result = -T*coder_d2gdt2(T, P, n);
    double dvdt = coder_d2gdtdp(T, P, n);
    double dvdp = coder_d2gdp2(T, P, n);
    result += T*dvdt*dvdt/dvdp;
    return result;
}

static double coder_cp(double T, double P, double n[4]) {
    double result = -T*coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdt(double T, double P, double n[4]) {
    double result = -T*coder_d3gdt3(T, P, n) - coder_d2gdt2(T, P, n);
    return result;
}

static double coder_alpha(double T, double P, double n[4]) {
    double result = coder_d2gdtdp(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_beta(double T, double P, double n[4]) {
    double result = -coder_d2gdp2(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_K(double T, double P, double n[4]) {
    double result = -coder_dgdp(T, P, n)/coder_d2gdp2(T, P, n);
    return result;
}

static double coder_Kp(double T, double P, double n[4]) {
    double result = coder_dgdp(T, P, n);
    result *= coder_d3gdp3(T, P, n);
    result /= pow(coder_d2gdp2(T, P, n), 2.0);
    return result - 1.0;
}

