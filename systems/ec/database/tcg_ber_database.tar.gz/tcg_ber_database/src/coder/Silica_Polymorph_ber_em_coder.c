
static char *identifier = "Silica_Polymorph_ber_em.emml:155843f8c17af60246145f75637d4f0296c4f456:Tue Nov 15 19:46:06 2022";



#include <math.h>

#include <float.h>
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

static double chebvalat(double x) {
    double c[17] = {
        2.707737068327440945 / 2.0, 0.340068135211091751, -0.12945150184440869e-01, 0.7963755380173816e-03,
        -0.546360009590824e-04, 0.39243019598805e-05, -0.2894032823539e-06, 0.217317613962e-07, -0.16542099950e-08,
        0.1272796189e-09, -0.987963460e-11, 0.7725074e-12, -0.607797e-13, 0.48076e-14, -0.3820e-15, 0.305e-16, -0.24e-17
    };
    double x2 = 2 * x;
    double c0 = c[17-2];
    double c1 = c[17-1];
    for (int i=3; i<18; i++) {
        double tmp = c0;
        c0 = c[17-i] - c1;
        c1 = tmp + c1 * x2;
    }
    return c0 + c1 * x;
}

static double Debye(double x) {
    //
    // returns D_3(x) = 3/x^3\int_0^x t^3/(e^t - 1) dt
    //
    
    double val_infinity = 19.4818182068004875;
    double sqrt_eps = sqrt(DBL_EPSILON);
    double log_eps = log(DBL_EPSILON);
    double xcut = -log_eps;

    //Check for negative x (was returning zero)
    assert(x >= 0.);

    if (x < (2.0*sqrt(2.0)*sqrt_eps)) return 1.0 - 3.0*x/8.0 + x*x/20.0;
    else if (x <= 4.0) {
        double t = x*x/8.0 - 1.0;
        double c = chebvalat(t);
        return c - 0.375*x;
    } else if (x < -(log(2.0)+log_eps)) {
        int nexp = (int)(floor(xcut / x));
        double ex = exp(-x);
        double xk = nexp * x;
        double rk = nexp;
        double sum = 0.0;
        for (int i=nexp; i>0; i--) {
            double xk_inv = 1.0/xk;
            sum *= ex;
            sum += (((6.0*xk_inv + 6.0)*xk_inv + 3.0)*xk_inv + 1.0)/rk;
            rk -= 1.0;
            xk -= x;
        }
        return val_infinity / (x * x * x) - 3.0 * sum * ex;
    } else if (x < xcut) {
        double x3 = x*x*x;
        double sum = 6.0 + 6.0*x + 3.0*x*x + x3;
        return (val_infinity - 3.0*sum*exp(-x))/x3;
    } else return ((val_infinity/x)/x)/x;
}

double born_B(double t, double p);
double born_Q(double t, double p);
double born_N(double t, double p);
double born_U(double t, double p);
double born_Y(double t, double p);
double born_X(double t, double p);
double born_dUdT(double t, double p);
double born_dUdP(double t, double p);
double born_dNdT(double t, double p);
double born_dNdP(double t, double p);
double born_dXdT(double t, double p);
double gSolvent(double t, double p);
double DgSolventDt(double t, double p);
double DgSolventDp(double t, double p);
double D2gSolventDt2(double t, double p);
double D2gSolventDtDp(double t, double p);
double D2gSolventDp2(double t, double p);
double D3gSolventDt3(double t, double p);
double D3gSolventDt2Dp(double t, double p);
double D3gSolventDtDp2(double t, double p);
double D3gSolventDp3(double t, double p);
double D4gSolventDt4(double t, double p);

static double coder_g(double T, double P) {
    double result = 0.0;
    double x0 = ((P)*(P));
    double x1 = pow(T, -2);
    double x2 = 1.0/T;
    double x3 = sqrt(T);
    double x4 = T*log(T);

    result += fmin(2.3700029347710001*P + 533.27833159792306*T - 1.4673855e-6*x0 - 81928064.0*x1 + 1773342.0*x2 - 961.10400000000004*x3 - 80.011989999999997*x4 - 933317.71882692084, 8.7065159999999992e-6*P*T + 2.7274071544355998*P + 566.99949837708004*T - 1.5010905e-6*x0 - 46678698.666666672*x1 + 1227680.0*x2 - 1498.7719999999999*x3 - 83.513599999999997*x4 - 924999.86581459211);
    return result;
}

static double coder_dgdt(double T, double P) {
    double result = 0.0;
    double x0 = log(T);
    double x1 = pow(T, -3);
    double x2 = pow(T, -2);
    double x3 = sqrt(T);
    double x4 = 1.0/x3;
    double x5 = 0.35740421966459968*P;
    double x6 = 33.721166779156988*T;
    double x7 = 8.7065159999999992e-6*P;
    double x8 = T*x7;
    double x9 = 3.3704999999999917e-8*((P)*(P));
    double x10 = 35249365.333333328*x2;
    double x11 = 545662.0/T;
    double x12 = 537.66799999999989*x3;
    double x13 = 3.5016099999999994*T*x0;

    result += (-80.011989999999997*x0 + 163856128.0*x1 - 1773342.0*x2 - 480.55200000000002*x4 + 453.26634159792309)*(x10 - x11 - x12 - x13 + x5 + x6 + x8 - x9 + 8317.8530123287346 >= 0. ? 1. : 0.) + (-83.513599999999997*x0 + 93357397.333333343*x1 - 1227680.0*x2 - 749.38599999999997*x4 + x7 + 483.48589837708005)*(-x10 + x11 + x12 + x13 - x5 - x6 - x8 + x9 - 8317.8530123287346 >= 0. ? 1. : 0.);
    return result;
}

static double coder_dgdp(double T, double P) {
    double result = 0.0;
    double x0 = 0.35740421966459968*P;
    double x1 = 33.721166779156988*T;
    double x2 = 8.7065159999999992e-6*T;
    double x3 = P*x2;
    double x4 = 3.3704999999999917e-8*((P)*(P));
    double x5 = 35249365.333333328/((T)*(T));
    double x6 = 545662.0/T;
    double x7 = 537.66799999999989*sqrt(T);
    double x8 = 3.5016099999999994*T*log(T);

    result += (-2.9347710000000001e-6*P + 2.3700029347710001)*(x0 + x1 + x3 - x4 + x5 - x6 - x7 - x8 + 8317.8530123287346 >= 0. ? 1. : 0.) + (-3.0021809999999999e-6*P + x2 + 2.7274071544355998)*(-x0 - x1 - x3 + x4 - x5 + x6 + x7 + x8 - 8317.8530123287346 >= 0. ? 1. : 0.);
    return result;
}

static double coder_d2gdt2(double T, double P) {
    double result = 0.0;
    double x0 = pow(T, -4);
    double x1 = pow(T, -3);
    double x2 = pow(T, -3.0/2.0);
    double x3 = 1.0/T;
    double x4 = 0.35740421966459968*P;
    double x5 = 33.721166779156988*T;
    double x6 = 8.7065159999999992e-6*P;
    double x7 = T*x6;
    double x8 = 3.3704999999999917e-8*((P)*(P));
    double x9 = pow(T, -2);
    double x10 = 35249365.333333328*x9;
    double x11 = 545662.0*x3;
    double x12 = sqrt(T);
    double x13 = 537.66799999999989*x12;
    double x14 = log(T);
    double x15 = 3.5016099999999994*x14;
    double x16 = T*x15;
    double x17 = x10 - x11 - x13 - x16 + x4 + x5 + x7 - x8 + 8317.8530123287346;
    double x18 = 1.0/x12;
    double x19 = (-70498730.666666657*x1 - x15 - 268.83399999999995*x18 + x6 + 545662.0*x9 + 30.219556779156989)*0;

    result += -x19*(-163856128.0*x1 + 80.011989999999997*x14 + 480.55200000000002*x18 + 1773342.0*x9 - 453.26634159792309) - x19*(93357397.333333343*x1 - 83.513599999999997*x14 - 749.38599999999997*x18 + x6 - 1227680.0*x9 + 483.48589837708005) - (280072192.0*x0 - 2455360.0*x1 - 374.69299999999998*x2 + 83.513599999999997*x3)*(-x10 + x11 + x13 + x16 - x4 - x5 - x7 + x8 - 8317.8530123287346 >= 0. ? 1. : 0.) - (491568384.0*x0 - 3546684.0*x1 - 240.27600000000001*x2 + 80.011989999999997*x3)*(x17 >= 0. ? 1. : 0.);
    return result;
}

static double coder_d2gdtdp(double T, double P) {
    double result = 0.0;
    double x0 = 0.35740421966459968*P;
    double x1 = 33.721166779156988*T;
    double x2 = 8.7065159999999992e-6*T;
    double x3 = P*x2;
    double x4 = 3.3704999999999917e-8*((P)*(P));
    double x5 = pow(T, -2);
    double x6 = 35249365.333333328*x5;
    double x7 = 545662.0/T;
    double x8 = sqrt(T);
    double x9 = 537.66799999999989*x8;
    double x10 = log(T);
    double x11 = 3.5016099999999994*T*x10;
    double x12 = pow(T, -3);
    double x13 = 1.0/x8;
    double x14 = (-6.7409999999999834e-8*P + x2 + 0.35740421966459968)*0;

    result += -x14*(80.011989999999997*x10 - 163856128.0*x12 + 480.55200000000002*x13 + 1773342.0*x5 - 453.26634159792309) - x14*(8.7065159999999992e-6*P - 83.513599999999997*x10 + 93357397.333333343*x12 - 749.38599999999997*x13 - 1227680.0*x5 + 483.48589837708005) + 8.7065159999999992e-6*(-x0 - x1 + x11 - x3 + x4 - x6 + x7 + x9 - 8317.8530123287346 >= 0. ? 1. : 0.);
    return result;
}

static double coder_d2gdp2(double T, double P) {
    double result = 0.0;
    double x0 = 0.35740421966459968*P;
    double x1 = 33.721166779156988*T;
    double x2 = 8.7065159999999992e-6*T;
    double x3 = P*x2;
    double x4 = 3.3704999999999917e-8*((P)*(P));
    double x5 = 35249365.333333328/((T)*(T));
    double x6 = 545662.0/T;
    double x7 = 537.66799999999989*sqrt(T);
    double x8 = 3.5016099999999994*T*log(T);
    double x9 = x0 + x1 + x3 - x4 + x5 - x6 - x7 - x8 + 8317.8530123287346;
    double x10 = (-6.7409999999999834e-8*P + x2 + 0.35740421966459968)*0;

    result += -x10*(2.9347710000000001e-6*P - 2.3700029347710001) - x10*(-3.0021809999999999e-6*P + x2 + 2.7274071544355998) - 2.9347710000000001e-6*(x9 >= 0. ? 1. : 0.) - 3.0021809999999999e-6*(-x0 - x1 - x3 + x4 - x5 + x6 + x7 + x8 - 8317.8530123287346 >= 0. ? 1. : 0.);
    return result;
}

static double coder_d3gdt3(double T, double P) {
    double result = 0.0;
    double x0 = pow(T, -5);
    double x1 = pow(T, -4);
    double x2 = pow(T, -5.0/2.0);
    double x3 = pow(T, -2);
    double x4 = 0.35740421966459968*P;
    double x5 = 33.721166779156988*T;
    double x6 = 8.7065159999999992e-6*P;
    double x7 = T*x6;
    double x8 = 3.3704999999999917e-8*((P)*(P));
    double x9 = 35249365.333333328*x3;
    double x10 = 1.0/T;
    double x11 = 545662.0*x10;
    double x12 = sqrt(T);
    double x13 = 537.66799999999989*x12;
    double x14 = log(T);
    double x15 = 3.5016099999999994*x14;
    double x16 = T*x15;
    double x17 = -x11 - x13 - x16 + x4 + x5 + x7 - x8 + x9 + 8317.8530123287346;
    double x18 = pow(T, -3);
    double x19 = 1.0/x12;
    double x20 = 80.011989999999997*x14 - 163856128.0*x18 + 480.55200000000002*x19 + 1773342.0*x3 - 453.26634159792309;
    double x21 = pow(T, -3.0/2.0);
    double x22 = 0;
    double x23 = x22*(-211496191.99999997*x1 + 3.5016099999999994*x10 + 1091324.0*x18 - 134.41699999999997*x21);
    double x24 = -83.513599999999997*x14 + 93357397.333333343*x18 - 749.38599999999997*x19 - 1227680.0*x3 + x6 + 483.48589837708005;
    double x25 = -x15 - 70498730.666666657*x18 - 268.83399999999995*x19 + 545662.0*x3 + x6 + 30.219556779156989;
    double x26 = 2*x22*x25;
    double x27 = ((x25)*(x25))*0;

    result += x20*x23 - x20*x27 + x23*x24 - x24*x27 + x26*(280072192.0*x1 + 83.513599999999997*x10 - 2455360.0*x18 - 374.69299999999998*x21) - x26*(491568384.0*x1 + 80.011989999999997*x10 - 3546684.0*x18 - 240.27600000000001*x21) + (1120288768.0*x0 - 7366080.0*x1 - 562.03949999999998*x2 + 83.513599999999997*x3)*(x11 + x13 + x16 - x4 - x5 - x7 + x8 - x9 - 8317.8530123287346 >= 0. ? 1. : 0.) + (1966273536.0*x0 - 10640052.0*x1 - 360.41399999999999*x2 + 80.011989999999997*x3)*(x17 >= 0. ? 1. : 0.);
    return result;
}

static double coder_d3gdt2dp(double T, double P) {
    double result = 0.0;
    double x0 = log(T);
    double x1 = pow(T, -3);
    double x2 = pow(T, -2);
    double x3 = sqrt(T);
    double x4 = 1.0/x3;
    double x5 = 8.7065159999999992e-6*T;
    double x6 = 1.0/T;
    double x7 = 3.5016099999999994*x0;
    double x8 = -3.3704999999999917e-8*((P)*(P)) + P*x5 + 0.35740421966459968*P - T*x7 + 33.721166779156988*T + 35249365.333333328*x2 - 537.66799999999989*x3 - 545662.0*x6 + 8317.8530123287346;
    double x9 = 0;
    double x10 = 7.5803420858255988e-11*P;
    double x11 = pow(T, -4);
    double x12 = pow(T, -3.0/2.0);
    double x13 = -6.7409999999999834e-8*P + x5 + 0.35740421966459968;
    double x14 = x13*x9;
    double x15 = 8.7065159999999992e-6*P;
    double x16 = x13*(-70498730.666666657*x1 + x15 + 545662.0*x2 - 268.83399999999995*x4 - x7 + 30.219556779156989)*0;

    result += -x14*(-3546684.0*x1 + 491568384.0*x11 - 240.27600000000001*x12 + 80.011989999999997*x6) + x14*(-2455360.0*x1 + 280072192.0*x11 - 374.69299999999998*x12 + 83.513599999999997*x6) - x16*(80.011989999999997*x0 - 163856128.0*x1 + 1773342.0*x2 + 480.55200000000002*x4 - 453.26634159792309) - x16*(-83.513599999999997*x0 + 93357397.333333343*x1 + x15 - 1227680.0*x2 - 749.38599999999997*x4 + 483.48589837708005) - x9*(0.00069662567112683995*x0 - 1426.616000130048*x1 + 15.439630496471999*x2 + 0.0041839336768320001*x4 - 0.0039463706553837822) - x9*(-0.00072711249461759994*x0 + 812.81767360102401*x1 + x10 - 10.688815562879999*x2 - 0.0065245411991759995*x4 + 0.0042094777099944214) - x9*(-3.0486823490759994e-5*x0 - 613.79832652902383*x1 + x10 + 4.7508149335919994*x2 - 0.0023406075223439994*x4 + 0.00026310705461063877);
    return result;
}

static double coder_d3gdtdp2(double T, double P) {
    double result = 0.0;
    double x0 = 8.7065159999999992e-6*T;
    double x1 = -6.7409999999999834e-8*P + x0 + 0.35740421966459968;
    double x2 = pow(T, -2);
    double x3 = sqrt(T);
    double x4 = log(T);
    double x5 = -3.3704999999999917e-8*((P)*(P)) + P*x0 + 0.35740421966459968*P - 3.5016099999999994*T*x4 + 33.721166779156988*T + 35249365.333333328*x2 - 537.66799999999989*x3 + 8317.8530123287346 - 545662.0/T;
    double x6 = 0;
    double x7 = 5.8690624355999849e-13*P;
    double x8 = pow(T, -3);
    double x9 = 1.0/x3;
    double x10 = ((x1)*(x1))*0;

    result += -8.7065159999999992e-6*x1*x6 - x10*(1773342.0*x2 + 80.011989999999997*x4 - 163856128.0*x8 + 480.55200000000002*x9 - 453.26634159792309) - x10*(8.7065159999999992e-6*P - 1227680.0*x2 - 83.513599999999997*x4 + 93357397.333333343*x8 - 749.38599999999997*x9 + 483.48589837708005) - x6*(7.5803420858255988e-11*T - x7 + 3.1117455569773514e-6) + x6*(0.1195409842199997*x2 + 5.3936082458999865e-6*x4 - 11.045541588479972*x8 + 3.2394010319999922e-5*x9 - 3.0554684087115919e-5) + x6*(-0.082757908799999794*x2 - 5.6296517759999857e-6*x4 + x7 + 6.2932221542399853*x8 - 5.0516110259999877e-5*x9 + 3.2591784409598887e-5);
    return result;
}

static double coder_d3gdp3(double T, double P) {
    double result = 0.0;
    double x0 = 1.9783291310999952e-13*P;
    double x1 = 8.7065159999999992e-6*T;
    double x2 = -3.3704999999999917e-8*((P)*(P)) + P*x1 + 0.35740421966459968*P - 537.66799999999989*sqrt(T) - 3.5016099999999994*T*log(T) + 33.721166779156988*T + 8317.8530123287346 - 545662.0/T + 35249365.333333328/((T)*(T));
    double x3 = 0;
    double x4 = -2.0237702120999949e-13*P;
    double x5 = -6.7409999999999834e-8*P + x1 + 0.35740421966459968;
    double x6 = ((x5)*(x5))*0;

    result += 6.7409999999999834e-8*x3*x5 + x3*(x0 - 1.5976189783291272e-7) + x3*(5.8690624355999849e-13*T + x4 + 1.8385451628050332e-7) - x3*(2.5551630667835999e-11*T - x0 + 1.0488995391492969e-6) + x3*(2.6138536911395998e-11*T + x4 + 1.0729921575968876e-6) - x6*(2.9347710000000001e-6*P - 2.3700029347710001) - x6*(-3.0021809999999999e-6*P + x1 + 2.7274071544355998);
    return result;
}


static double coder_s(double T, double P) {
    double result = -coder_dgdt(T, P);
    return result;
}

static double coder_v(double T, double P) {
    double result = coder_dgdp(T, P);
    return result;
}

static double coder_cv(double T, double P) {
    double result = -T*coder_d2gdt2(T, P);
    double dvdt = coder_d2gdtdp(T, P);
    double dvdp = coder_d2gdp2(T, P);
    result += T*dvdt*dvdt/dvdp;
    return result;
}

static double coder_cp(double T, double P) {
    double result = -T*coder_d2gdt2(T, P);
    return result;
}

static double coder_dcpdt(double T, double P) {
    double result = -T*coder_d3gdt3(T, P) - coder_d2gdt2(T, P);
    return result;
}

static double coder_alpha(double T, double P) {
    double result = coder_d2gdtdp(T, P)/coder_dgdp(T, P);
    return result;
}

static double coder_beta(double T, double P) {
    double result = -coder_d2gdp2(T, P)/coder_dgdp(T, P);
    return result;
}

static double coder_K(double T, double P) {
    double result = -coder_dgdp(T, P)/coder_d2gdp2(T, P);
    return result;
}

static double coder_Kp(double T, double P) {
    double result = coder_dgdp(T, P);
    result *= coder_d3gdp3(T, P);
    result /= pow(coder_d2gdp2(T, P), 2.0);
    return result - 1.0;
}


#include <math.h>

static double coder_dparam_g(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_dgdt(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_dgdp(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d2gdt2(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d2gdtdp(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d2gdp2(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d3gdt3(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d3gdt2dp(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d3gdtdp2(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d3gdp3(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static int coder_get_param_number(void) {
    return 0;
}

static const char *paramNames[0] = {  };

static const char *paramUnits[0] = {  };

static const char **coder_get_param_names(void) {
    return paramNames;
}

static const char **coder_get_param_units(void) {
    return paramUnits;
}

static void coder_get_param_values(double **values) {
}

static int coder_set_param_values(double *values) {
    return 1;
}

static double coder_get_param_value(int index) {
    double result = 0.0;
    switch (index) {
     default:
         break;
    }
    return result;
}

static int coder_set_param_value(int index, double value) {
    int result = 1;
    switch (index) {
     default:
         break;
    }
    return result;
}



const char *Silica_Polymorph_ber_em_coder_calib_identifier(void) {
    return identifier;
}

const char *Silica_Polymorph_ber_em_coder_calib_name(void) {
    return "Silica_Polymorph_ber_em";
}

const char *Silica_Polymorph_ber_em_coder_calib_formula(void) {
    return "SiO2";
}

const double Silica_Polymorph_ber_em_coder_calib_mw(void) {
    return 60.0843;
}

static const double elmformula[106] = {
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,2.0,0.0,0.0,0.0,
        0.0,0.0,1.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0
    };

const double *Silica_Polymorph_ber_em_coder_calib_elements(void) {
    return elmformula;
}

double Silica_Polymorph_ber_em_coder_calib_g(double T, double P) {
    return coder_g(T, P);
}

double Silica_Polymorph_ber_em_coder_calib_dgdt(double T, double P) {
    return coder_dgdt(T, P);
}

double Silica_Polymorph_ber_em_coder_calib_dgdp(double T, double P) {
    return coder_dgdp(T, P);
}

double Silica_Polymorph_ber_em_coder_calib_d2gdt2(double T, double P) {
    return coder_d2gdt2(T, P);
}

double Silica_Polymorph_ber_em_coder_calib_d2gdtdp(double T, double P) {
    return coder_d2gdtdp(T, P);
}

double Silica_Polymorph_ber_em_coder_calib_d2gdp2(double T, double P) {
    return coder_d2gdp2(T, P);
}

double Silica_Polymorph_ber_em_coder_calib_d3gdt3(double T, double P) {
    return coder_d3gdt3(T, P);
}

double Silica_Polymorph_ber_em_coder_calib_d3gdt2dp(double T, double P) {
    return coder_d3gdt2dp(T, P);
}

double Silica_Polymorph_ber_em_coder_calib_d3gdtdp2(double T, double P) {
    return coder_d3gdtdp2(T, P);
}

double Silica_Polymorph_ber_em_coder_calib_d3gdp3(double T, double P) {
    return coder_d3gdp3(T, P);
}

double Silica_Polymorph_ber_em_coder_calib_s(double T, double P) {
    return coder_s(T, P);
}

double Silica_Polymorph_ber_em_coder_calib_v(double T, double P) {
    return coder_v(T, P);
}

double Silica_Polymorph_ber_em_coder_calib_cv(double T, double P) {
    return coder_cv(T, P);
}

double Silica_Polymorph_ber_em_coder_calib_cp(double T, double P) {
    return coder_cp(T, P);
}

double Silica_Polymorph_ber_em_coder_calib_dcpdt(double T, double P) {
    return coder_dcpdt(T, P);
}

double Silica_Polymorph_ber_em_coder_calib_alpha(double T, double P) {
    return coder_alpha(T, P);
}

double Silica_Polymorph_ber_em_coder_calib_beta(double T, double P) {
    return coder_beta(T, P);
}

double Silica_Polymorph_ber_em_coder_calib_K(double T, double P) {
    return coder_K(T, P);
}

double Silica_Polymorph_ber_em_coder_calib_Kp(double T, double P) {
    return coder_Kp(T, P);
}

int Silica_Polymorph_ber_em_coder_get_param_number(void) {
    return coder_get_param_number();
}

const char **Silica_Polymorph_ber_em_coder_get_param_names(void) {
    return coder_get_param_names();
}

const char **Silica_Polymorph_ber_em_coder_get_param_units(void) {
    return coder_get_param_units();
}

void Silica_Polymorph_ber_em_coder_get_param_values(double **values) {
    coder_get_param_values(values);
}

int Silica_Polymorph_ber_em_coder_set_param_values(double *values) {
    return coder_set_param_values(values);
}

double Silica_Polymorph_ber_em_coder_get_param_value(int index) {
    return coder_get_param_value(index);
}

int Silica_Polymorph_ber_em_coder_set_param_value(int index, double value) {
    return coder_set_param_value(index, value);
}

double Silica_Polymorph_ber_em_coder_dparam_g(double T, double P, int index) {
    return coder_dparam_g(T, P, index);
}

double Silica_Polymorph_ber_em_coder_dparam_dgdt(double T, double P, int index) {
    return coder_dparam_dgdt(T, P, index);
}

double Silica_Polymorph_ber_em_coder_dparam_dgdp(double T, double P, int index) {
    return coder_dparam_dgdp(T, P, index);
}

double Silica_Polymorph_ber_em_coder_dparam_d2gdt2(double T, double P, int index) {
    return coder_dparam_d2gdt2(T, P, index);
}

double Silica_Polymorph_ber_em_coder_dparam_d2gdtdp(double T, double P, int index) {
    return coder_dparam_d2gdtdp(T, P, index);
}

double Silica_Polymorph_ber_em_coder_dparam_d2gdp2(double T, double P, int index) {
    return coder_dparam_d2gdp2(T, P, index);
}

double Silica_Polymorph_ber_em_coder_dparam_d3gdt3(double T, double P, int index) {
    return coder_dparam_d3gdt3(T, P, index);
}

double Silica_Polymorph_ber_em_coder_dparam_d3gdt2dp(double T, double P, int index) {
    return coder_dparam_d3gdt2dp(T, P, index);
}

double Silica_Polymorph_ber_em_coder_dparam_d3gdtdp2(double T, double P, int index) {
    return coder_dparam_d3gdtdp2(T, P, index);
}

double Silica_Polymorph_ber_em_coder_dparam_d3gdp3(double T, double P, int index) {
    return coder_dparam_d3gdp3(T, P, index);
}

