#include "endmembers/Oxygen_Gas_ber_em.h"
#include "tcgversion.h"

//-----------------------------------------------------------------------------
Oxygen_Gas_ber_em::Oxygen_Gas_ber_em()
{
  // Do Nothing
}
//-----------------------------------------------------------------------------
Oxygen_Gas_ber_em::~Oxygen_Gas_ber_em()
{
  // Do nothing
}
//-----------------------------------------------------------------------------
std::string Oxygen_Gas_ber_em::identifier()
{
    std::string _str(Oxygen_Gas_ber_em_coder_calib_identifier());
    return _str;
}
//-----------------------------------------------------------------------------
std::string Oxygen_Gas_ber_em::name()
{
    std::string _str(Oxygen_Gas_ber_em_coder_calib_name());
    return _str;
}
//-----------------------------------------------------------------------------
std::string Oxygen_Gas_ber_em::tcg_build_version()
{
    return TCG_VERSION;
}
//-----------------------------------------------------------------------------
std::string Oxygen_Gas_ber_em::tcg_build_git_sha()
{
    return TCG_GIT_SHA;
}
//-----------------------------------------------------------------------------
std::string Oxygen_Gas_ber_em::tcg_generation_version()
{
    return "0.6.9";
}
//-----------------------------------------------------------------------------
std::string Oxygen_Gas_ber_em::tcg_generation_git_sha()
{
    return "56dfef7059e95dd8cdde839c4942089d910bdcbd Fri Aug 19 17:22:58 2022 -0400";
}
//-----------------------------------------------------------------------------
std::string Oxygen_Gas_ber_em::formula()
{
    std::string _str(Oxygen_Gas_ber_em_coder_calib_formula());
    return _str;
}
//-----------------------------------------------------------------------------
double Oxygen_Gas_ber_em::molecular_weight()
{
    return Oxygen_Gas_ber_em_coder_calib_mw();
}
//-----------------------------------------------------------------------------
std::vector<double> Oxygen_Gas_ber_em::elements()
{
  std::vector<double> _elements;
  const double *el = Oxygen_Gas_ber_em_coder_calib_elements();
  _elements.assign(el, el + 106);
  return _elements;
}
//-----------------------------------------------------------------------------
double Oxygen_Gas_ber_em::G(const double &T, const double &P)
{
  return Oxygen_Gas_ber_em_coder_calib_g(T,P);
}
//-----------------------------------------------------------------------------
double Oxygen_Gas_ber_em::dGdT(const double &T, const double &P)
{
  return Oxygen_Gas_ber_em_coder_calib_dgdt(T,P);
}
//-----------------------------------------------------------------------------
double Oxygen_Gas_ber_em::dGdP(const double &T, const double &P)
{
  return Oxygen_Gas_ber_em_coder_calib_dgdp(T,P);
}
//-----------------------------------------------------------------------------
double Oxygen_Gas_ber_em::d2GdT2(const double &T, const double &P)
{
  return Oxygen_Gas_ber_em_coder_calib_d2gdt2(T,P);
}
//-----------------------------------------------------------------------------
double Oxygen_Gas_ber_em::d2GdTdP(const double &T, const double &P)
{
  return Oxygen_Gas_ber_em_coder_calib_d2gdtdp(T,P);
}
//-----------------------------------------------------------------------------
double Oxygen_Gas_ber_em::d2GdP2(const double &T, const double &P)
{
  return Oxygen_Gas_ber_em_coder_calib_d2gdp2(T,P);
}
//-----------------------------------------------------------------------------
double Oxygen_Gas_ber_em::d3GdT3(const double &T, const double &P)
{
  return Oxygen_Gas_ber_em_coder_calib_d3gdt3(T,P);
}
//-----------------------------------------------------------------------------
double Oxygen_Gas_ber_em::d3GdT2dP(const double &T, const double &P)
{
  return Oxygen_Gas_ber_em_coder_calib_d3gdt2dp(T,P);
}
//-----------------------------------------------------------------------------
double Oxygen_Gas_ber_em::d3GdTdP2(const double &T, const double &P)
{
  return Oxygen_Gas_ber_em_coder_calib_d3gdtdp2(T,P);
}
//-----------------------------------------------------------------------------
double Oxygen_Gas_ber_em::d3GdP3(const double &T, const double &P)
{
  return Oxygen_Gas_ber_em_coder_calib_d3gdp3(T,P);
}
//**************************************************************************
// Convenience functions of T and P
//**************************************************************************

//-----------------------------------------------------------------------------
double Oxygen_Gas_ber_em::S(const double& T, const double& P)
{
  return Oxygen_Gas_ber_em_coder_calib_s(T,P);
}
//-----------------------------------------------------------------------------
double Oxygen_Gas_ber_em::V(const double& T, const double& P)
{
  return Oxygen_Gas_ber_em_coder_calib_v(T,P);
}
//-----------------------------------------------------------------------------
double Oxygen_Gas_ber_em::dVdT(const double& T, const double& P)
{
  return Oxygen_Gas_ber_em_coder_calib_d2gdtdp(T,P);
}
//-----------------------------------------------------------------------------
double Oxygen_Gas_ber_em::dVdP(const double& T, const double& P)
{
  return Oxygen_Gas_ber_em_coder_calib_d2gdp2(T,P);
}
//-----------------------------------------------------------------------------
double Oxygen_Gas_ber_em::Cv(const double& T, const double& P)
{
  return Oxygen_Gas_ber_em_coder_calib_cv(T,P);
}
//-----------------------------------------------------------------------------
double Oxygen_Gas_ber_em::Cp(const double& T, const double& P)
{
  return Oxygen_Gas_ber_em_coder_calib_cp(T,P);
}
//-----------------------------------------------------------------------------
double Oxygen_Gas_ber_em::dCpdT(const double& T, const double& P)
{
  return Oxygen_Gas_ber_em_coder_calib_dcpdt(T,P);
}
//-----------------------------------------------------------------------------
double Oxygen_Gas_ber_em::alpha(const double& T, const double& P)
{
  return Oxygen_Gas_ber_em_coder_calib_alpha(T,P);
}
//-----------------------------------------------------------------------------
double Oxygen_Gas_ber_em::beta(const double& T, const double& P)
{
  return Oxygen_Gas_ber_em_coder_calib_beta(T,P);
}
//-----------------------------------------------------------------------------
double Oxygen_Gas_ber_em::K(const double& T, const double& P)
{
  return Oxygen_Gas_ber_em_coder_calib_K(T,P);
}
//-----------------------------------------------------------------------------
double Oxygen_Gas_ber_em::Kp(const double& T, const double& P)
{
  return Oxygen_Gas_ber_em_coder_calib_Kp(T,P);
}
//**************************************************************************
// Active parameter functions directly from coder
//**************************************************************************

//-----------------------------------------------------------------------------
int Oxygen_Gas_ber_em::get_param_number()
{
   return Oxygen_Gas_ber_em_coder_get_param_number();
}
//-----------------------------------------------------------------------------
std::vector<std::string> Oxygen_Gas_ber_em::get_param_names()
{
  std::vector<std::string> _param_names;
  const char **p = Oxygen_Gas_ber_em_coder_get_param_names();
  _param_names.assign(p, p + Oxygen_Gas_ber_em_coder_get_param_number());
  return _param_names;
}
//-----------------------------------------------------------------------------
std::vector<std::string> Oxygen_Gas_ber_em::get_param_units()
{
  std::vector<std::string> _param_units;
  const char **p = Oxygen_Gas_ber_em_coder_get_param_units();
  _param_units.assign(p, p + Oxygen_Gas_ber_em_coder_get_param_number());
  return _param_units;
}
//-----------------------------------------------------------------------------
std::vector<double> Oxygen_Gas_ber_em::get_param_values()
{
  std::vector<double> values(Oxygen_Gas_ber_em_coder_get_param_number());
  double* v = values.data();
  double** v_ptr = &v;
  Oxygen_Gas_ber_em_coder_get_param_values(v_ptr);
  return values;
}
//-----------------------------------------------------------------------------
void Oxygen_Gas_ber_em::get_param_values(std::vector<double>& values)
{
  double* v = values.data();
  double** v_ptr = &v;
  Oxygen_Gas_ber_em_coder_get_param_values(v_ptr);
}
//-----------------------------------------------------------------------------
int Oxygen_Gas_ber_em::set_param_values(std::vector<double>& values)
{
  Oxygen_Gas_ber_em_coder_set_param_values(values.data());
  return 1;
}
//-----------------------------------------------------------------------------
double Oxygen_Gas_ber_em::get_param_value(int& index)
{
  return Oxygen_Gas_ber_em_coder_get_param_value(index);
}
//-----------------------------------------------------------------------------
int Oxygen_Gas_ber_em::set_param_value(int& index, double& value)
{
  return Oxygen_Gas_ber_em_coder_set_param_value(index,value);
}
//-----------------------------------------------------------------------------
double Oxygen_Gas_ber_em::dparam_g(double& T, double& P, int& index)
{
  return Oxygen_Gas_ber_em_coder_dparam_g(T,P,index);
}
//-----------------------------------------------------------------------------
double Oxygen_Gas_ber_em::dparam_dgdt(double& T, double& P, int& index)
{
  return Oxygen_Gas_ber_em_coder_dparam_dgdt(T,P,index);
}
//-----------------------------------------------------------------------------
double Oxygen_Gas_ber_em::dparam_dgdp(double& T, double& P, int& index)
{
  return Oxygen_Gas_ber_em_coder_dparam_dgdp(T,P,index);
}
//-----------------------------------------------------------------------------
double Oxygen_Gas_ber_em::dparam_d2gdt2(double& T, double& P, int& index)
{
  return Oxygen_Gas_ber_em_coder_dparam_d2gdt2(T,P,index);
}
//-----------------------------------------------------------------------------
double Oxygen_Gas_ber_em::dparam_d2gdtdp(double& T, double& P, int& index)
{
  return Oxygen_Gas_ber_em_coder_dparam_d2gdtdp(T,P,index);
}
//-----------------------------------------------------------------------------
double Oxygen_Gas_ber_em::dparam_d2gdp2(double& T, double& P, int& index)
{
  return Oxygen_Gas_ber_em_coder_dparam_d2gdp2(T,P,index);
}
//-----------------------------------------------------------------------------
double Oxygen_Gas_ber_em::dparam_d3gdt3(double& T, double& P, int& index)
{
  return Oxygen_Gas_ber_em_coder_dparam_d3gdt3(T,P,index);
}
//-----------------------------------------------------------------------------
double Oxygen_Gas_ber_em::dparam_d3gdt2dp(double& T, double& P, int& index)
{
  return Oxygen_Gas_ber_em_coder_dparam_d3gdt2dp(T,P,index);
}
//-----------------------------------------------------------------------------
double Oxygen_Gas_ber_em::dparam_d3gdtdp2(double& T, double& P, int& index)
{
  return Oxygen_Gas_ber_em_coder_dparam_d3gdtdp2(T,P,index);
}
//-----------------------------------------------------------------------------
double Oxygen_Gas_ber_em::dparam_d3gdp3(double& T, double& P, int& index)
{
  return Oxygen_Gas_ber_em_coder_dparam_d3gdp3(T,P,index);
}
//-----------------------------------------------------------------------------
