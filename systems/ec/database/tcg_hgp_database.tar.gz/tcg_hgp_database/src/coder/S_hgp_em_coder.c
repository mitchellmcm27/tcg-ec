
static char *identifier = "S_hgp_em.emml:72b08e3a37133fcd66ce7084fddbfe8f923a57f3:Mon Nov 21 17:58:45 2022";



#include <math.h>

#include <float.h>
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

static double chebvalat(double x) {
    double c[17] = {
        2.707737068327440945 / 2.0, 0.340068135211091751, -0.12945150184440869e-01, 0.7963755380173816e-03,
        -0.546360009590824e-04, 0.39243019598805e-05, -0.2894032823539e-06, 0.217317613962e-07, -0.16542099950e-08,
        0.1272796189e-09, -0.987963460e-11, 0.7725074e-12, -0.607797e-13, 0.48076e-14, -0.3820e-15, 0.305e-16, -0.24e-17
    };
    double x2 = 2 * x;
    double c0 = c[17-2];
    double c1 = c[17-1];
    for (int i=3; i<18; i++) {
        double tmp = c0;
        c0 = c[17-i] - c1;
        c1 = tmp + c1 * x2;
    }
    return c0 + c1 * x;
}

static double Debye(double x) {
    //
    // returns D_3(x) = 3/x^3\int_0^x t^3/(e^t - 1) dt
    //
    
    double val_infinity = 19.4818182068004875;
    double sqrt_eps = sqrt(DBL_EPSILON);
    double log_eps = log(DBL_EPSILON);
    double xcut = -log_eps;

    //Check for negative x (was returning zero)
    assert(x >= 0.);

    if (x < (2.0*sqrt(2.0)*sqrt_eps)) return 1.0 - 3.0*x/8.0 + x*x/20.0;
    else if (x <= 4.0) {
        double t = x*x/8.0 - 1.0;
        double c = chebvalat(t);
        return c - 0.375*x;
    } else if (x < -(log(2.0)+log_eps)) {
        int nexp = (int)(floor(xcut / x));
        double ex = exp(-x);
        double xk = nexp * x;
        double rk = nexp;
        double sum = 0.0;
        for (int i=nexp; i>0; i--) {
            double xk_inv = 1.0/xk;
            sum *= ex;
            sum += (((6.0*xk_inv + 6.0)*xk_inv + 3.0)*xk_inv + 1.0)/rk;
            rk -= 1.0;
            xk -= x;
        }
        return val_infinity / (x * x * x) - 3.0 * sum * ex;
    } else if (x < xcut) {
        double x3 = x*x*x;
        double sum = 6.0 + 6.0*x + 3.0*x*x + x3;
        return (val_infinity - 3.0*sum*exp(-x))/x3;
    } else return ((val_infinity/x)/x)/x;
}

double born_B(double t, double p);
double born_Q(double t, double p);
double born_N(double t, double p);
double born_U(double t, double p);
double born_Y(double t, double p);
double born_X(double t, double p);
double born_dUdT(double t, double p);
double born_dUdP(double t, double p);
double born_dNdT(double t, double p);
double born_dNdP(double t, double p);
double born_dXdT(double t, double p);
double gSolvent(double t, double p);
double DgSolventDt(double t, double p);
double DgSolventDp(double t, double p);
double D2gSolventDt2(double t, double p);
double D2gSolventDtDp(double t, double p);
double D2gSolventDp2(double t, double p);
double D3gSolventDt3(double t, double p);
double D3gSolventDt2Dp(double t, double p);
double D3gSolventDtDp2(double t, double p);
double D3gSolventDp3(double t, double p);
double D4gSolventDt4(double t, double p);

static double coder_g(double T, double P) {
    double result = 0.0;
    double x0 = pow(T, 1.0);
    double x1 = 276.331514679137/T;
    double x2 = exp(x1) - 1.0;
    double x3 = ((T)*(T))*exp(-x1);
    double x4 = -1.6212430830417474e-6*pow(x2, 1.0)*x3 + 1.0620910597180229e-6*pow(x2, 2.0)*x3;

    result += -1.3493817396023732e-5*P - 2727.1999999999998*sqrt(T) + 0.0022785000000000001*pow(T, 2.0) - 56.600000000000001*x0*log(T) + 421.05809184509116*x0 - 37482.717400706606*pow(x4 + 1.0, 0.85714427754925504) + 37482.717400706606*pow(4.8275922068965514e-5*P + x4 + 0.99995172407793098, 0.85714427754925504) + 9012.4254363194214 - 319000.0/x0;
    return result;
}

static double coder_dgdt(double T, double P) {
    double result = 0.0;
    double x0 = ((T)*(T));
    double x1 = 276.331514679137/T;
    double x2 = exp(x1) - 1.0;
    double x3 = exp(-x1);
    double x4 = pow(x2, 2.0)*x3;
    double x5 = pow(x2, 1.0);
    double x6 = x3*x5;
    double x7 = 1.0620910597180229e-6*x0*x4 - 1.6212430830417474e-6*x0*x6;
    double x8 = 0.068245928599029684*T*x4 - 0.10417490917992737*T*x6 + 9.429250410227052*x4 - 18.858500820454104*x5 - 14.393405222625434*x6 + 14.393405222625434;

    result += 319000.0*pow(T, -2.0) - 1363.5999999999999*pow(T, -0.5) + 0.0045570000000000003*pow(T, 1.0) - x8*pow(x7 + 1.0, -0.14285572245074496) + x8*pow(4.8275922068965514e-5*P + x7 + 0.99995172407793098, -0.14285572245074496) - 56.600000000000001*log(T) + 364.45809184509113;
    return result;
}

static double coder_dgdp(double T, double P) {
    double result = 0.0;
    double x0 = 276.331514679137/T;
    double x1 = exp(x0) - 1.0;
    double x2 = ((T)*(T))*exp(-x0);

    result += 1.5510134938173958*pow(4.8275922068965514e-5*P - 1.6212430830417474e-6*pow(x1, 1.0)*x2 + 1.0620910597180229e-6*pow(x1, 2.0)*x2 + 0.99995172407793098, -0.14285572245074496) - 1.3493817396023732e-5;
    return result;
}

static double coder_d2gdt2(double T, double P) {
    double result = 0.0;
    double x0 = 1.0/T;
    double x1 = ((T)*(T));
    double x2 = 276.331514679137*x0;
    double x3 = exp(x2);
    double x4 = x3 - 1.0;
    double x5 = exp(-x2);
    double x6 = pow(x4, 2.0)*x5;
    double x7 = pow(x4, 1.0);
    double x8 = x5*x7;
    double x9 = 1.0620910597180229e-6*x1*x6 - 1.6212430830417474e-6*x1*x8;
    double x10 = x9 + 1.0;
    double x11 = 1.0/x1;
    double x12 = 0.10611160935956335*x11;
    double x13 = 0.00076800222719999997*x0;
    double x14 = 0.1390293569322589*x11;
    double x15 = 2.7792784622910912e-6*x8;
    double x16 = 1.8207305481470547e-6*x6;
    double x17 = 18.858500820454104*x0*x6 - 37.717001640908208*x0*x7 + 2605.5990481469153*x11*x6 - 37482.717400706606*x12*x8 + 37482.717400706606*x12 - 37482.717400706606*x13*x8 + 37482.717400706606*x13 + 37482.717400706606*x14*x3 - 37482.717400706606*x14*x7 - 37482.717400706606*x15 + 37482.717400706606*x16;
    double x18 = 4.8275922068965514e-5*P + x9 + 0.99995172407793098;
    double x19 = 37482.717400706606*(T*x15 - T*x16 - 0.00025156261509602548*x6 + 0.00050312523019205096*x7 + 0.00038400111359999998*x8 - 0.00038400111359999998)*(-3.0345157128899093e-7*T*x6 + 4.6320770379240388e-7*T*x8 - 4.1926616163025494e-5*x6 + 8.3853232326050987e-5*x7 + 6.3999443199999997e-5*x8 - 6.3999443199999997e-5);

    result += -638000.0*pow(T, -3.0) + 681.79999999999995*pow(T, -1.5) - 56.600000000000001*x0 + pow(x10, -1.142855722450745)*x19 - pow(x10, -0.14285572245074496)*x17 + x17*pow(x18, -0.14285572245074496) - pow(x18, -1.142855722450745)*x19 + 0.0045570000000000003;
    return result;
}

static double coder_d2gdtdp(double T, double P) {
    double result = 0.0;
    double x0 = ((T)*(T));
    double x1 = 276.331514679137/T;
    double x2 = exp(x1) - 1.0;
    double x3 = pow(x2, 1.0);
    double x4 = exp(-x1);
    double x5 = x3*x4;
    double x6 = pow(x2, 2.0)*x4;

    result += 6.8964917241379308e-6*pow(4.8275922068965514e-5*P - 1.6212430830417474e-6*x0*x5 + 1.0620910597180229e-6*x0*x6 + 0.99995172407793098, -1.142855722450745)*(0.10417490917992737*T*x5 - 0.068245928599029684*T*x6 + 18.858500820454104*x3 + 14.393405222625434*x5 - 9.429250410227052*x6 - 14.393405222625434);
    return result;
}

static double coder_d2gdp2(double T, double P) {
    double result = 0.0;
    double x0 = 276.331514679137/T;
    double x1 = exp(x0) - 1.0;
    double x2 = ((T)*(T))*exp(-x0);

    result += -1.0696551724137927e-5*pow(4.8275922068965514e-5*P - 1.6212430830417474e-6*pow(x1, 1.0)*x2 + 1.0620910597180229e-6*pow(x1, 2.0)*x2 + 0.99995172407793098, -1.142855722450745);
    return result;
}

static double coder_d3gdt3(double T, double P) {
    double result = 0.0;
    double x0 = ((T)*(T));
    double x1 = 1.0/x0;
    double x2 = 1.0/T;
    double x3 = 276.331514679137*x2;
    double x4 = exp(-x3);
    double x5 = exp(x3);
    double x6 = x5 - 1.0;
    double x7 = x4*pow(x6, 2.0);
    double x8 = pow(x6, 1.0);
    double x9 = x4*x8;
    double x10 = 1.0620910597180229e-6*x0*x7 - 1.6212430830417474e-6*x0*x9;
    double x11 = x10 + 1.0;
    double x12 = 37482.717400706606*(-19.20909639297874*x7 + 38.41819278595748*x8 + 29.321981739369029*x9 - 29.321981739369029)/((T)*(T)*(T)*(T));
    double x13 = 4.8275922068965514e-5*P + x10 + 0.99995172407793098;
    double x14 = pow(x11, -1.142855722450745);
    double x15 = 4.6320770379240388e-7*x9;
    double x16 = 3.0345157128899093e-7*x7;
    double x17 = T*x15 - T*x16 - 4.1926616163025494e-5*x7 + 8.3853232326050987e-5*x8 + 6.3999443199999997e-5*x9 - 6.3999443199999997e-5;
    double x18 = 0.10611160935956335*x1;
    double x19 = 0.00076800222719999997*x2;
    double x20 = 0.1390293569322589*x1;
    double x21 = x2*x8;
    double x22 = 2.7792784622910912e-6*x9;
    double x23 = 1.8207305481470547e-6*x7;
    double x24 = x1*x7;
    double x25 = x2*x7;
    double x26 = 74965.434801413212*x17*(-x18*x9 + x18 - x19*x9 + x19 + x20*x5 - x20*x8 - 0.0010062504603841019*x21 - x22 + x23 + 0.069514678466129451*x24 + 0.00050312523019205096*x25);
    double x27 = 0.017685063078077393*x1;
    double x28 = 0.00012799888639999999*x2;
    double x29 = 0.023171290699399244*x1;
    double x30 = 37482.717400706606*T*x22 - 37482.717400706606*T*x23 - 9.429250410227052*x7 + 18.858500820454104*x8 + 14.393405222625434*x9 - 14.393405222625434;
    double x31 = x30*(-x15 + x16 - 0.00016770646465210197*x21 + 0.011585645349699622*x24 + 8.3853232326050987e-5*x25 - x27*x9 + x27 - x28*x9 + x28 + x29*x5 - x29*x8);
    double x32 = pow(x13, -1.142855722450745);
    double x33 = x17*x30*(-2.4276336907250368e-6*T*x7 + 3.7056938698758986e-6*T*x9 - 0.00033541584742207651*x7 + 0.00067083169484415301*x8 + 0.00051199999999999998*x9 - 0.00051199999999999998);

    result += 1914000.0*pow(T, -4.0) - 1022.6999999999999*pow(T, -2.5) + 56.600000000000001*x1 + pow(x11, -2.142855722450745)*x33 + pow(x11, -0.14285572245074496)*x12 - x12*pow(x13, -0.14285572245074496) - pow(x13, -2.142855722450745)*x33 - x14*x26 - x14*x31 + x26*x32 + x31*x32;
    return result;
}

static double coder_d3gdt2dp(double T, double P) {
    double result = 0.0;
    double x0 = ((T)*(T));
    double x1 = 1.0/T;
    double x2 = 276.331514679137*x1;
    double x3 = exp(x2);
    double x4 = x3 - 1.0;
    double x5 = pow(x4, 1.0);
    double x6 = exp(-x2);
    double x7 = x5*x6;
    double x8 = pow(x4, 2.0)*x6;
    double x9 = 4.8275922068965514e-5*P - 1.6212430830417474e-6*x0*x7 + 1.0620910597180229e-6*x0*x8 + 0.99995172407793098;
    double x10 = 1.0/x0;
    double x11 = 3977.3514665586872*x10;
    double x12 = 28.786810445250868*x1;
    double x13 = 5211.1980962938305*x10;
    double x14 = T*x7;
    double x15 = T*x8;

    result += 2.0680119945217439*pow(x9, -2.142855722450745)*(4.6320770379240388e-7*x14 - 3.0345157128899093e-7*x15 + 8.3853232326050987e-5*x5 + 6.3999443199999997e-5*x7 - 4.1926616163025494e-5*x8 - 6.3999443199999997e-5)*(2.7792784622910912e-6*x14 - 1.8207305481470547e-6*x15 + 0.00050312523019205096*x5 + 0.00038400111359999998*x7 - 0.00025156261509602548*x8 - 0.00038400111359999998) - 6.8964917241379308e-6*pow(x9, -1.142855722450745)*(-37.717001640908208*x1*x5 + 18.858500820454104*x1*x8 + 2605.5990481469153*x10*x8 - x11*x7 + x11 - x12*x7 + x12 + x13*x3 - x13*x5 - 0.10417490917992737*x7 + 0.068245928599029684*x8);
    return result;
}

static double coder_d3gdtdp2(double T, double P) {
    double result = 0.0;
    double x0 = ((T)*(T));
    double x1 = 276.331514679137/T;
    double x2 = exp(x1) - 1.0;
    double x3 = pow(x2, 1.0);
    double x4 = exp(-x1);
    double x5 = x3*x4;
    double x6 = pow(x2, 2.0)*x4;

    result += -3.8049609512485134e-10*pow(4.8275922068965514e-5*P - 1.6212430830417474e-6*x0*x5 + 1.0620910597180229e-6*x0*x6 + 0.99995172407793098, -2.142855722450745)*(0.10417490917992737*T*x5 - 0.068245928599029684*T*x6 + 18.858500820454104*x3 + 14.393405222625434*x5 - 9.429250410227052*x6 - 14.393405222625434);
    return result;
}

static double coder_d3gdp3(double T, double P) {
    double result = 0.0;
    double x0 = 276.331514679137/T;
    double x1 = exp(x0) - 1.0;
    double x2 = ((T)*(T))*exp(-x0);

    result += 5.9015457788347188e-10*pow(4.8275922068965514e-5*P - 1.6212430830417474e-6*pow(x1, 1.0)*x2 + 1.0620910597180229e-6*pow(x1, 2.0)*x2 + 0.99995172407793098, -2.142855722450745);
    return result;
}


static double coder_s(double T, double P) {
    double result = -coder_dgdt(T, P);
    return result;
}

static double coder_v(double T, double P) {
    double result = coder_dgdp(T, P);
    return result;
}

static double coder_cv(double T, double P) {
    double result = -T*coder_d2gdt2(T, P);
    double dvdt = coder_d2gdtdp(T, P);
    double dvdp = coder_d2gdp2(T, P);
    result += T*dvdt*dvdt/dvdp;
    return result;
}

static double coder_cp(double T, double P) {
    double result = -T*coder_d2gdt2(T, P);
    return result;
}

static double coder_dcpdt(double T, double P) {
    double result = -T*coder_d3gdt3(T, P) - coder_d2gdt2(T, P);
    return result;
}

static double coder_alpha(double T, double P) {
    double result = coder_d2gdtdp(T, P)/coder_dgdp(T, P);
    return result;
}

static double coder_beta(double T, double P) {
    double result = -coder_d2gdp2(T, P)/coder_dgdp(T, P);
    return result;
}

static double coder_K(double T, double P) {
    double result = -coder_dgdp(T, P)/coder_d2gdp2(T, P);
    return result;
}

static double coder_Kp(double T, double P) {
    double result = coder_dgdp(T, P);
    result *= coder_d3gdp3(T, P);
    result /= pow(coder_d2gdp2(T, P), 2.0);
    return result - 1.0;
}


#include <math.h>

static double coder_dparam_g(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_dgdt(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_dgdp(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d2gdt2(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d2gdtdp(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d2gdp2(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d3gdt3(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d3gdt2dp(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d3gdtdp2(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d3gdp3(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static int coder_get_param_number(void) {
    return 0;
}

static const char *paramNames[0] = {  };

static const char *paramUnits[0] = {  };

static const char **coder_get_param_names(void) {
    return paramNames;
}

static const char **coder_get_param_units(void) {
    return paramUnits;
}

static void coder_get_param_values(double **values) {
}

static int coder_set_param_values(double *values) {
    return 1;
}

static double coder_get_param_value(int index) {
    double result = 0.0;
    switch (index) {
     default:
         break;
    }
    return result;
}

static int coder_set_param_value(int index, double value) {
    int result = 1;
    switch (index) {
     default:
         break;
    }
    return result;
}



const char *S_hgp_em_coder_calib_identifier(void) {
    return identifier;
}

const char *S_hgp_em_coder_calib_name(void) {
    return "S_hgp_em";
}

const char *S_hgp_em_coder_calib_formula(void) {
    return "S";
}

const double S_hgp_em_coder_calib_mw(void) {
    return 32.06;
}

static const double elmformula[106] = {
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,1.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0
    };

const double *S_hgp_em_coder_calib_elements(void) {
    return elmformula;
}

double S_hgp_em_coder_calib_g(double T, double P) {
    return coder_g(T, P);
}

double S_hgp_em_coder_calib_dgdt(double T, double P) {
    return coder_dgdt(T, P);
}

double S_hgp_em_coder_calib_dgdp(double T, double P) {
    return coder_dgdp(T, P);
}

double S_hgp_em_coder_calib_d2gdt2(double T, double P) {
    return coder_d2gdt2(T, P);
}

double S_hgp_em_coder_calib_d2gdtdp(double T, double P) {
    return coder_d2gdtdp(T, P);
}

double S_hgp_em_coder_calib_d2gdp2(double T, double P) {
    return coder_d2gdp2(T, P);
}

double S_hgp_em_coder_calib_d3gdt3(double T, double P) {
    return coder_d3gdt3(T, P);
}

double S_hgp_em_coder_calib_d3gdt2dp(double T, double P) {
    return coder_d3gdt2dp(T, P);
}

double S_hgp_em_coder_calib_d3gdtdp2(double T, double P) {
    return coder_d3gdtdp2(T, P);
}

double S_hgp_em_coder_calib_d3gdp3(double T, double P) {
    return coder_d3gdp3(T, P);
}

double S_hgp_em_coder_calib_s(double T, double P) {
    return coder_s(T, P);
}

double S_hgp_em_coder_calib_v(double T, double P) {
    return coder_v(T, P);
}

double S_hgp_em_coder_calib_cv(double T, double P) {
    return coder_cv(T, P);
}

double S_hgp_em_coder_calib_cp(double T, double P) {
    return coder_cp(T, P);
}

double S_hgp_em_coder_calib_dcpdt(double T, double P) {
    return coder_dcpdt(T, P);
}

double S_hgp_em_coder_calib_alpha(double T, double P) {
    return coder_alpha(T, P);
}

double S_hgp_em_coder_calib_beta(double T, double P) {
    return coder_beta(T, P);
}

double S_hgp_em_coder_calib_K(double T, double P) {
    return coder_K(T, P);
}

double S_hgp_em_coder_calib_Kp(double T, double P) {
    return coder_Kp(T, P);
}

int S_hgp_em_coder_get_param_number(void) {
    return coder_get_param_number();
}

const char **S_hgp_em_coder_get_param_names(void) {
    return coder_get_param_names();
}

const char **S_hgp_em_coder_get_param_units(void) {
    return coder_get_param_units();
}

void S_hgp_em_coder_get_param_values(double **values) {
    coder_get_param_values(values);
}

int S_hgp_em_coder_set_param_values(double *values) {
    return coder_set_param_values(values);
}

double S_hgp_em_coder_get_param_value(int index) {
    return coder_get_param_value(index);
}

int S_hgp_em_coder_set_param_value(int index, double value) {
    return coder_set_param_value(index, value);
}

double S_hgp_em_coder_dparam_g(double T, double P, int index) {
    return coder_dparam_g(T, P, index);
}

double S_hgp_em_coder_dparam_dgdt(double T, double P, int index) {
    return coder_dparam_dgdt(T, P, index);
}

double S_hgp_em_coder_dparam_dgdp(double T, double P, int index) {
    return coder_dparam_dgdp(T, P, index);
}

double S_hgp_em_coder_dparam_d2gdt2(double T, double P, int index) {
    return coder_dparam_d2gdt2(T, P, index);
}

double S_hgp_em_coder_dparam_d2gdtdp(double T, double P, int index) {
    return coder_dparam_d2gdtdp(T, P, index);
}

double S_hgp_em_coder_dparam_d2gdp2(double T, double P, int index) {
    return coder_dparam_d2gdp2(T, P, index);
}

double S_hgp_em_coder_dparam_d3gdt3(double T, double P, int index) {
    return coder_dparam_d3gdt3(T, P, index);
}

double S_hgp_em_coder_dparam_d3gdt2dp(double T, double P, int index) {
    return coder_dparam_d3gdt2dp(T, P, index);
}

double S_hgp_em_coder_dparam_d3gdtdp2(double T, double P, int index) {
    return coder_dparam_d3gdtdp2(T, P, index);
}

double S_hgp_em_coder_dparam_d3gdp3(double T, double P, int index) {
    return coder_dparam_d3gdp3(T, P, index);
}

