
static char *identifier = "pxmn_hgp_em.emml:8417f6955a581c7b51378a6acb64cfd3d343e977:Mon Nov 21 18:02:32 2022";



#include <math.h>

#include <float.h>
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

static double chebvalat(double x) {
    double c[17] = {
        2.707737068327440945 / 2.0, 0.340068135211091751, -0.12945150184440869e-01, 0.7963755380173816e-03,
        -0.546360009590824e-04, 0.39243019598805e-05, -0.2894032823539e-06, 0.217317613962e-07, -0.16542099950e-08,
        0.1272796189e-09, -0.987963460e-11, 0.7725074e-12, -0.607797e-13, 0.48076e-14, -0.3820e-15, 0.305e-16, -0.24e-17
    };
    double x2 = 2 * x;
    double c0 = c[17-2];
    double c1 = c[17-1];
    for (int i=3; i<18; i++) {
        double tmp = c0;
        c0 = c[17-i] - c1;
        c1 = tmp + c1 * x2;
    }
    return c0 + c1 * x;
}

static double Debye(double x) {
    //
    // returns D_3(x) = 3/x^3\int_0^x t^3/(e^t - 1) dt
    //
    
    double val_infinity = 19.4818182068004875;
    double sqrt_eps = sqrt(DBL_EPSILON);
    double log_eps = log(DBL_EPSILON);
    double xcut = -log_eps;

    //Check for negative x (was returning zero)
    assert(x >= 0.);

    if (x < (2.0*sqrt(2.0)*sqrt_eps)) return 1.0 - 3.0*x/8.0 + x*x/20.0;
    else if (x <= 4.0) {
        double t = x*x/8.0 - 1.0;
        double c = chebvalat(t);
        return c - 0.375*x;
    } else if (x < -(log(2.0)+log_eps)) {
        int nexp = (int)(floor(xcut / x));
        double ex = exp(-x);
        double xk = nexp * x;
        double rk = nexp;
        double sum = 0.0;
        for (int i=nexp; i>0; i--) {
            double xk_inv = 1.0/xk;
            sum *= ex;
            sum += (((6.0*xk_inv + 6.0)*xk_inv + 3.0)*xk_inv + 1.0)/rk;
            rk -= 1.0;
            xk -= x;
        }
        return val_infinity / (x * x * x) - 3.0 * sum * ex;
    } else if (x < xcut) {
        double x3 = x*x*x;
        double sum = 6.0 + 6.0*x + 3.0*x*x + x3;
        return (val_infinity - 3.0*sum*exp(-x))/x3;
    } else return ((val_infinity/x)/x)/x;
}

double born_B(double t, double p);
double born_Q(double t, double p);
double born_N(double t, double p);
double born_U(double t, double p);
double born_Y(double t, double p);
double born_X(double t, double p);
double born_dUdT(double t, double p);
double born_dUdP(double t, double p);
double born_dNdT(double t, double p);
double born_dNdP(double t, double p);
double born_dXdT(double t, double p);
double gSolvent(double t, double p);
double DgSolventDt(double t, double p);
double DgSolventDp(double t, double p);
double D2gSolventDt2(double t, double p);
double D2gSolventDtDp(double t, double p);
double D2gSolventDp2(double t, double p);
double D3gSolventDt3(double t, double p);
double D3gSolventDt2Dp(double t, double p);
double D3gSolventDtDp2(double t, double p);
double D3gSolventDp3(double t, double p);
double D4gSolventDt4(double t, double p);

static double coder_g(double T, double P) {
    double result = 0.0;
    double x0 = pow(T, 1.0);
    double x1 = 404.41064638783303/T;
    double x2 = exp(x1) - 1.0;
    double x3 = ((T)*(T))*exp(-x1);
    double x4 = -2.7694677870718295e-7*pow(x2, 1.0)*x3 + 9.6088940054363675e-8*pow(x2, 2.0)*x3;

    result += -2.7998433779380605e-5*P - 2155.5999999999999*sqrt(T) - 0.0020439999999999998*pow(T, 2.0) - 138.40000000000001*x0*log(T) + 902.1752372211854*x0 - 972162.61321524985*pow(x4 + 1.0, 0.75000251999491963) + 972162.61321524985*pow(4.7619143619047616e-6*P + x4 + 0.99999523808563806, 0.75000251999491963) - 1352458.639154963 + 968000.0/x0;
    return result;
}

static double coder_dgdt(double T, double P) {
    double result = 0.0;
    double x0 = ((T)*(T));
    double x1 = 404.41064638783303/T;
    double x2 = exp(x1) - 1.0;
    double x3 = exp(-x1);
    double x4 = pow(x2, 2.0)*x3;
    double x5 = pow(x2, 1.0);
    double x6 = x3*x5;
    double x7 = 9.6088940054363675e-8*x0*x4 - 2.7694677870718295e-7*x0*x6;
    double x8 = 0.14012158340248967*T*x4 - 0.40385731311755779*T*x6 + 28.333330058343755*x4 - 56.66666011668751*x5 - 81.662098523162513*x6 + 81.662098523162513;

    result += -968000.0*pow(T, -2.0) - 1077.8*pow(T, -0.5) - 0.0040879999999999996*pow(T, 1.0) - x8*pow(x7 + 1.0, -0.24999748000508037) + x8*pow(4.7619143619047616e-6*P + x7 + 0.99999523808563806, -0.24999748000508037) - 138.40000000000001*log(T) + 763.77523722118542;
    return result;
}

static double coder_dgdp(double T, double P) {
    double result = 0.0;
    double x0 = 404.41064638783303/T;
    double x1 = exp(x0) - 1.0;
    double x2 = ((T)*(T))*exp(-x0);

    result += 3.4720279984337794*pow(4.7619143619047616e-6*P - 2.7694677870718295e-7*pow(x1, 1.0)*x2 + 9.6088940054363675e-8*pow(x1, 2.0)*x2 + 0.99999523808563806, -0.24999748000508037) - 2.7998433779380605e-5;
    return result;
}

static double coder_d2gdt2(double T, double P) {
    double result = 0.0;
    double x0 = 1.0/T;
    double x1 = ((T)*(T));
    double x2 = 404.41064638783303*x0;
    double x3 = exp(x2);
    double x4 = x3 - 1.0;
    double x5 = exp(-x2);
    double x6 = pow(x4, 2.0)*x5;
    double x7 = pow(x4, 1.0);
    double x8 = x5*x7;
    double x9 = 9.6088940054363675e-8*x1*x6 - 2.7694677870718295e-7*x1*x8;
    double x10 = x9 + 1.0;
    double x11 = 1.0/x1;
    double x12 = 0.033970676921955309*x11;
    double x13 = 0.00016800090316799999*x0;
    double x14 = 0.023572805963640971*x11;
    double x15 = 4.1542156386972512e-7*x8;
    double x16 = 1.4413389436882705e-7*x6;
    double x17 = 56.66666011668751*x0*x6 - 113.33332023337502*x0*x7 + 11458.300323214617*x11*x6 - 972162.61321524985*x12*x8 + 972162.61321524985*x12 - 972162.61321524985*x13*x8 + 972162.61321524985*x13 + 972162.61321524985*x14*x3 - 972162.61321524985*x14*x7 - 972162.61321524985*x15 + 972162.61321524985*x16;
    double x18 = 4.7619143619047616e-6*P + x9 + 0.99999523808563806;
    double x19 = 972162.61321524985*(T*x15 - T*x16 - 2.9144640694046496e-5*x6 + 5.8289281388092992e-5*x7 + 8.4000451583999994e-5*x8 - 8.4000451583999994e-5)*(-4.8043985739900301e-8*T*x6 + 1.3847199354464078e-7*T*x8 - 9.7147496640604554e-6*x6 + 1.9429499328120911e-5*x7 + 2.7999774208000007e-5*x8 - 2.7999774208000007e-5);

    result += 1936000.0*pow(T, -3.0) + 538.89999999999998*pow(T, -1.5) - 138.40000000000001*x0 + pow(x10, -1.2499974800050804)*x19 - pow(x10, -0.24999748000508037)*x17 + x17*pow(x18, -0.24999748000508037) - pow(x18, -1.2499974800050804)*x19 - 0.0040879999999999996;
    return result;
}

static double coder_d2gdtdp(double T, double P) {
    double result = 0.0;
    double x0 = ((T)*(T));
    double x1 = 404.41064638783303/T;
    double x2 = exp(x1) - 1.0;
    double x3 = pow(x2, 1.0);
    double x4 = exp(-x1);
    double x5 = x3*x4;
    double x6 = pow(x2, 2.0)*x4;

    result += 1.1904665904761907e-6*pow(4.7619143619047616e-6*P - 2.7694677870718295e-7*x0*x5 + 9.6088940054363675e-8*x0*x6 + 0.99999523808563806, -1.2499974800050804)*(0.40385731311755779*T*x5 - 0.14012158340248967*T*x6 + 56.66666011668751*x3 + 81.662098523162513*x5 - 28.333330058343755*x6 - 81.662098523162513);
    return result;
}

static double coder_d2gdp2(double T, double P) {
    double result = 0.0;
    double x0 = 404.41064638783303/T;
    double x1 = exp(x0) - 1.0;
    double x2 = ((T)*(T))*exp(-x0);

    result += -4.1333333333333341e-6*pow(4.7619143619047616e-6*P - 2.7694677870718295e-7*pow(x1, 1.0)*x2 + 9.6088940054363675e-8*pow(x1, 2.0)*x2 + 0.99999523808563806, -1.2499974800050804);
    return result;
}

static double coder_d3gdt3(double T, double P) {
    double result = 0.0;
    double x0 = ((T)*(T));
    double x1 = 1.0/x0;
    double x2 = 1.0/T;
    double x3 = 404.41064638783303*x2;
    double x4 = exp(-x3);
    double x5 = exp(x3);
    double x6 = x5 - 1.0;
    double x7 = x4*pow(x6, 2.0);
    double x8 = pow(x6, 1.0);
    double x9 = x4*x8;
    double x10 = 9.6088940054363675e-8*x0*x7 - 2.7694677870718295e-7*x0*x9;
    double x11 = x10 + 1.0;
    double x12 = 972162.61321524985*(-4.7665468484655049*x7 + 9.5330936969310098*x8 + 13.738103412240189*x9 - 13.738103412240189)/((T)*(T)*(T)*(T));
    double x13 = 4.7619143619047616e-6*P + x10 + 0.99999523808563806;
    double x14 = pow(x11, -1.2499974800050804);
    double x15 = 1.3847199354464078e-7*x9;
    double x16 = 4.8043985739900301e-8*x7;
    double x17 = T*x15 - T*x16 - 9.7147496640604554e-6*x7 + 1.9429499328120911e-5*x8 + 2.7999774208000007e-5*x9 - 2.7999774208000007e-5;
    double x18 = 0.033970676921955309*x1;
    double x19 = 0.00016800090316799999*x2;
    double x20 = 0.023572805963640971*x1;
    double x21 = x2*x8;
    double x22 = 4.1542156386972512e-7*x9;
    double x23 = 1.4413389436882705e-7*x7;
    double x24 = x1*x7;
    double x25 = x2*x7;
    double x26 = 1944325.2264304997*x17*(-x18*x9 + x18 - x19*x9 + x19 + x20*x5 - x20*x8 - 0.00011657856277618598*x21 - x22 + x23 + 0.011786402981820486*x24 + 5.8289281388092992e-5*x25);
    double x27 = 0.011323406786170659*x1;
    double x28 = 5.5999548416000021e-5*x2;
    double x29 = 0.0078574963822773455*x1;
    double x30 = 972162.61321524985*T*x22 - 972162.61321524985*T*x23 - 28.333330058343755*x7 + 56.66666011668751*x8 + 81.662098523162513*x9 - 81.662098523162513;
    double x31 = x30*(-x15 + x16 - 3.8858998656241828e-5*x21 + 0.0039287481911386727*x24 + 1.9429499328120914e-5*x25 - x27*x9 + x27 - x28*x9 + x28 + x29*x5 - x29*x8);
    double x32 = pow(x13, -1.2499974800050804);
    double x33 = x17*x30*(-2.4022186584862765e-7*T*x7 + 6.9236555095900668e-7*T*x9 - 4.857414002216741e-5*x7 + 9.7148280044334821e-5*x8 + 0.00014000000000000001*x9 - 0.00014000000000000001);

    result += -5808000.0*pow(T, -4.0) - 808.34999999999991*pow(T, -2.5) + 138.40000000000001*x1 + pow(x11, -2.2499974800050806)*x33 + pow(x11, -0.24999748000508037)*x12 - x12*pow(x13, -0.24999748000508037) - pow(x13, -2.2499974800050806)*x33 - x14*x26 - x14*x31 + x26*x32 + x31*x32;
    return result;
}

static double coder_d3gdt2dp(double T, double P) {
    double result = 0.0;
    double x0 = ((T)*(T));
    double x1 = 1.0/T;
    double x2 = 404.41064638783303*x1;
    double x3 = exp(x2);
    double x4 = x3 - 1.0;
    double x5 = pow(x4, 1.0);
    double x6 = exp(-x2);
    double x7 = x5*x6;
    double x8 = pow(x4, 2.0)*x6;
    double x9 = 4.7619143619047616e-6*P - 2.7694677870718295e-7*x0*x7 + 9.6088940054363675e-8*x0*x8 + 0.99999523808563806;
    double x10 = 1.0/x0;
    double x11 = 33025.02204913905*x10;
    double x12 = 163.32419704632503*x1;
    double x13 = 22916.600646429233*x10;
    double x14 = T*x7;
    double x15 = T*x8;

    result += 5.7866822215193441*pow(x9, -2.2499974800050806)*(1.3847199354464078e-7*x14 - 4.8043985739900301e-8*x15 + 1.9429499328120911e-5*x5 + 2.7999774208000007e-5*x7 - 9.7147496640604554e-6*x8 - 2.7999774208000007e-5)*(4.1542156386972512e-7*x14 - 1.4413389436882705e-7*x15 + 5.8289281388092992e-5*x5 + 8.4000451583999994e-5*x7 - 2.9144640694046496e-5*x8 - 8.4000451583999994e-5) - 1.1904665904761907e-6*pow(x9, -1.2499974800050804)*(-113.33332023337502*x1*x5 + 56.66666011668751*x1*x8 + 11458.300323214617*x10*x8 - x11*x7 + x11 - x12*x7 + x12 + x13*x3 - x13*x5 - 0.40385731311755779*x7 + 0.14012158340248967*x8);
    return result;
}

static double coder_d3gdtdp2(double T, double P) {
    double result = 0.0;
    double x0 = ((T)*(T));
    double x1 = 404.41064638783303/T;
    double x2 = exp(x1) - 1.0;
    double x3 = pow(x2, 1.0);
    double x4 = exp(-x1);
    double x5 = x3*x4;
    double x6 = pow(x2, 2.0)*x4;

    result += -7.0861106575963731e-12*pow(4.7619143619047616e-6*P - 2.7694677870718295e-7*x0*x5 + 9.6088940054363675e-8*x0*x6 + 0.99999523808563806, -2.2499974800050806)*(0.40385731311755779*T*x5 - 0.14012158340248967*T*x6 + 56.66666011668751*x3 + 81.662098523162513*x5 - 28.333330058343755*x6 - 81.662098523162513);
    return result;
}

static double coder_d3gdp3(double T, double P) {
    double result = 0.0;
    double x0 = 404.41064638783303/T;
    double x1 = exp(x0) - 1.0;
    double x2 = ((T)*(T))*exp(-x0);

    result += 2.4603174603174608e-11*pow(4.7619143619047616e-6*P - 2.7694677870718295e-7*pow(x1, 1.0)*x2 + 9.6088940054363675e-8*pow(x1, 2.0)*x2 + 0.99999523808563806, -2.2499974800050806);
    return result;
}


static double coder_s(double T, double P) {
    double result = -coder_dgdt(T, P);
    return result;
}

static double coder_v(double T, double P) {
    double result = coder_dgdp(T, P);
    return result;
}

static double coder_cv(double T, double P) {
    double result = -T*coder_d2gdt2(T, P);
    double dvdt = coder_d2gdtdp(T, P);
    double dvdp = coder_d2gdp2(T, P);
    result += T*dvdt*dvdt/dvdp;
    return result;
}

static double coder_cp(double T, double P) {
    double result = -T*coder_d2gdt2(T, P);
    return result;
}

static double coder_dcpdt(double T, double P) {
    double result = -T*coder_d3gdt3(T, P) - coder_d2gdt2(T, P);
    return result;
}

static double coder_alpha(double T, double P) {
    double result = coder_d2gdtdp(T, P)/coder_dgdp(T, P);
    return result;
}

static double coder_beta(double T, double P) {
    double result = -coder_d2gdp2(T, P)/coder_dgdp(T, P);
    return result;
}

static double coder_K(double T, double P) {
    double result = -coder_dgdp(T, P)/coder_d2gdp2(T, P);
    return result;
}

static double coder_Kp(double T, double P) {
    double result = coder_dgdp(T, P);
    result *= coder_d3gdp3(T, P);
    result /= pow(coder_d2gdp2(T, P), 2.0);
    return result - 1.0;
}


#include <math.h>

static double coder_dparam_g(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_dgdt(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_dgdp(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d2gdt2(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d2gdtdp(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d2gdp2(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d3gdt3(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d3gdt2dp(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d3gdtdp2(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d3gdp3(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static int coder_get_param_number(void) {
    return 0;
}

static const char *paramNames[0] = {  };

static const char *paramUnits[0] = {  };

static const char **coder_get_param_names(void) {
    return paramNames;
}

static const char **coder_get_param_units(void) {
    return paramUnits;
}

static void coder_get_param_values(double **values) {
}

static int coder_set_param_values(double *values) {
    return 1;
}

static double coder_get_param_value(int index) {
    double result = 0.0;
    switch (index) {
     default:
         break;
    }
    return result;
}

static int coder_set_param_value(int index, double value) {
    int result = 1;
    switch (index) {
     default:
         break;
    }
    return result;
}



const char *pxmn_hgp_em_coder_calib_identifier(void) {
    return identifier;
}

const char *pxmn_hgp_em_coder_calib_name(void) {
    return "pxmn_hgp_em";
}

const char *pxmn_hgp_em_coder_calib_formula(void) {
    return "MnO3Si";
}

const double pxmn_hgp_em_coder_calib_mw(void) {
    return 131.0217;
}

static const double elmformula[106] = {
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,3.0,0.0,0.0,0.0,
        0.0,0.0,1.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,1.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0
    };

const double *pxmn_hgp_em_coder_calib_elements(void) {
    return elmformula;
}

double pxmn_hgp_em_coder_calib_g(double T, double P) {
    return coder_g(T, P);
}

double pxmn_hgp_em_coder_calib_dgdt(double T, double P) {
    return coder_dgdt(T, P);
}

double pxmn_hgp_em_coder_calib_dgdp(double T, double P) {
    return coder_dgdp(T, P);
}

double pxmn_hgp_em_coder_calib_d2gdt2(double T, double P) {
    return coder_d2gdt2(T, P);
}

double pxmn_hgp_em_coder_calib_d2gdtdp(double T, double P) {
    return coder_d2gdtdp(T, P);
}

double pxmn_hgp_em_coder_calib_d2gdp2(double T, double P) {
    return coder_d2gdp2(T, P);
}

double pxmn_hgp_em_coder_calib_d3gdt3(double T, double P) {
    return coder_d3gdt3(T, P);
}

double pxmn_hgp_em_coder_calib_d3gdt2dp(double T, double P) {
    return coder_d3gdt2dp(T, P);
}

double pxmn_hgp_em_coder_calib_d3gdtdp2(double T, double P) {
    return coder_d3gdtdp2(T, P);
}

double pxmn_hgp_em_coder_calib_d3gdp3(double T, double P) {
    return coder_d3gdp3(T, P);
}

double pxmn_hgp_em_coder_calib_s(double T, double P) {
    return coder_s(T, P);
}

double pxmn_hgp_em_coder_calib_v(double T, double P) {
    return coder_v(T, P);
}

double pxmn_hgp_em_coder_calib_cv(double T, double P) {
    return coder_cv(T, P);
}

double pxmn_hgp_em_coder_calib_cp(double T, double P) {
    return coder_cp(T, P);
}

double pxmn_hgp_em_coder_calib_dcpdt(double T, double P) {
    return coder_dcpdt(T, P);
}

double pxmn_hgp_em_coder_calib_alpha(double T, double P) {
    return coder_alpha(T, P);
}

double pxmn_hgp_em_coder_calib_beta(double T, double P) {
    return coder_beta(T, P);
}

double pxmn_hgp_em_coder_calib_K(double T, double P) {
    return coder_K(T, P);
}

double pxmn_hgp_em_coder_calib_Kp(double T, double P) {
    return coder_Kp(T, P);
}

int pxmn_hgp_em_coder_get_param_number(void) {
    return coder_get_param_number();
}

const char **pxmn_hgp_em_coder_get_param_names(void) {
    return coder_get_param_names();
}

const char **pxmn_hgp_em_coder_get_param_units(void) {
    return coder_get_param_units();
}

void pxmn_hgp_em_coder_get_param_values(double **values) {
    coder_get_param_values(values);
}

int pxmn_hgp_em_coder_set_param_values(double *values) {
    return coder_set_param_values(values);
}

double pxmn_hgp_em_coder_get_param_value(int index) {
    return coder_get_param_value(index);
}

int pxmn_hgp_em_coder_set_param_value(int index, double value) {
    return coder_set_param_value(index, value);
}

double pxmn_hgp_em_coder_dparam_g(double T, double P, int index) {
    return coder_dparam_g(T, P, index);
}

double pxmn_hgp_em_coder_dparam_dgdt(double T, double P, int index) {
    return coder_dparam_dgdt(T, P, index);
}

double pxmn_hgp_em_coder_dparam_dgdp(double T, double P, int index) {
    return coder_dparam_dgdp(T, P, index);
}

double pxmn_hgp_em_coder_dparam_d2gdt2(double T, double P, int index) {
    return coder_dparam_d2gdt2(T, P, index);
}

double pxmn_hgp_em_coder_dparam_d2gdtdp(double T, double P, int index) {
    return coder_dparam_d2gdtdp(T, P, index);
}

double pxmn_hgp_em_coder_dparam_d2gdp2(double T, double P, int index) {
    return coder_dparam_d2gdp2(T, P, index);
}

double pxmn_hgp_em_coder_dparam_d3gdt3(double T, double P, int index) {
    return coder_dparam_d3gdt3(T, P, index);
}

double pxmn_hgp_em_coder_dparam_d3gdt2dp(double T, double P, int index) {
    return coder_dparam_d3gdt2dp(T, P, index);
}

double pxmn_hgp_em_coder_dparam_d3gdtdp2(double T, double P, int index) {
    return coder_dparam_d3gdtdp2(T, P, index);
}

double pxmn_hgp_em_coder_dparam_d3gdp3(double T, double P, int index) {
    return coder_dparam_d3gdp3(T, P, index);
}

