
static char *identifier = "pre_hgp_em.emml:b676b5e90188d46cfbafce965e486ddf678f24f6:Mon Nov 21 18:02:27 2022";



#include <math.h>

#include <float.h>
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

static double chebvalat(double x) {
    double c[17] = {
        2.707737068327440945 / 2.0, 0.340068135211091751, -0.12945150184440869e-01, 0.7963755380173816e-03,
        -0.546360009590824e-04, 0.39243019598805e-05, -0.2894032823539e-06, 0.217317613962e-07, -0.16542099950e-08,
        0.1272796189e-09, -0.987963460e-11, 0.7725074e-12, -0.607797e-13, 0.48076e-14, -0.3820e-15, 0.305e-16, -0.24e-17
    };
    double x2 = 2 * x;
    double c0 = c[17-2];
    double c1 = c[17-1];
    for (int i=3; i<18; i++) {
        double tmp = c0;
        c0 = c[17-i] - c1;
        c1 = tmp + c1 * x2;
    }
    return c0 + c1 * x;
}

static double Debye(double x) {
    //
    // returns D_3(x) = 3/x^3\int_0^x t^3/(e^t - 1) dt
    //
    
    double val_infinity = 19.4818182068004875;
    double sqrt_eps = sqrt(DBL_EPSILON);
    double log_eps = log(DBL_EPSILON);
    double xcut = -log_eps;

    //Check for negative x (was returning zero)
    assert(x >= 0.);

    if (x < (2.0*sqrt(2.0)*sqrt_eps)) return 1.0 - 3.0*x/8.0 + x*x/20.0;
    else if (x <= 4.0) {
        double t = x*x/8.0 - 1.0;
        double c = chebvalat(t);
        return c - 0.375*x;
    } else if (x < -(log(2.0)+log_eps)) {
        int nexp = (int)(floor(xcut / x));
        double ex = exp(-x);
        double xk = nexp * x;
        double rk = nexp;
        double sum = 0.0;
        for (int i=nexp; i>0; i--) {
            double xk_inv = 1.0/xk;
            sum *= ex;
            sum += (((6.0*xk_inv + 6.0)*xk_inv + 3.0)*xk_inv + 1.0)/rk;
            rk -= 1.0;
            xk -= x;
        }
        return val_infinity / (x * x * x) - 3.0 * sum * ex;
    } else if (x < xcut) {
        double x3 = x*x*x;
        double sum = 6.0 + 6.0*x + 3.0*x*x + x3;
        return (val_infinity - 3.0*sum*exp(-x))/x3;
    } else return ((val_infinity/x)/x)/x;
}

double born_B(double t, double p);
double born_Q(double t, double p);
double born_N(double t, double p);
double born_U(double t, double p);
double born_Y(double t, double p);
double born_X(double t, double p);
double born_dUdT(double t, double p);
double born_dUdP(double t, double p);
double born_dNdT(double t, double p);
double born_dNdP(double t, double p);
double born_dXdT(double t, double p);
double gSolvent(double t, double p);
double DgSolventDt(double t, double p);
double DgSolventDp(double t, double p);
double D2gSolventDt2(double t, double p);
double D2gSolventDtDp(double t, double p);
double D2gSolventDp2(double t, double p);
double D3gSolventDt3(double t, double p);
double D3gSolventDt2Dp(double t, double p);
double D3gSolventDtDp2(double t, double p);
double D3gSolventDp3(double t, double p);
double D4gSolventDt4(double t, double p);

static double coder_g(double T, double P) {
    double result = 0.0;
    double x0 = pow(T, 1.0);
    double x1 = 521.811045696664/T;
    double x2 = exp(x1) - 1.0;
    double x3 = ((T)*(T))*exp(-x1);
    double x4 = -1.2141967492063015e-7*pow(x2, 1.0)*x3 + 2.5532259575926023e-8*pow(x2, 2.0)*x3;

    result += -0.00011321956980410474*P - 25295.599999999999*sqrt(T) + 0.0069325000000000003*pow(T, 2.0) - 724.89999999999998*x0*log(T) + 5302.2183491862252*x0 - 5093175.9216572819*pow(x4 + 1.0, 0.75062595636336793) + 5093175.9216572819*pow(3.6688088490904739e-6*P + x4 + 0.99999633119115094, 0.75062595636336793) - 6206098.7780764243 + 1029500.0/x0;
    return result;
}

static double coder_dgdt(double T, double P) {
    double result = 0.0;
    double x0 = ((T)*(T));
    double x1 = 521.811045696664/T;
    double x2 = exp(x1) - 1.0;
    double x3 = exp(-x1);
    double x4 = pow(x2, 2.0)*x3;
    double x5 = pow(x2, 1.0);
    double x6 = x3*x5;
    double x7 = 2.5532259575926023e-8*x0*x4 - 1.2141967492063015e-7*x0*x6;
    double x8 = 0.19522323364007582*T*x4 - 0.92839184464042968*T*x6 + 50.934819845006061*x4 - 101.86963969001212*x5 - 242.22255963403873*x6 + 242.22255963403873;

    result += -1029500.0*pow(T, -2.0) - 12647.799999999999*pow(T, -0.5) + 0.013865000000000001*pow(T, 1.0) - x8*pow(x7 + 1.0, -0.24937404363663207) + x8*pow(3.6688088490904739e-6*P + x7 + 0.99999633119115094, -0.24937404363663207) - 724.89999999999998*log(T) + 4577.3183491862255;
    return result;
}

static double coder_dgdp(double T, double P) {
    double result = 0.0;
    double x0 = 521.811045696664/T;
    double x1 = exp(x0) - 1.0;
    double x2 = ((T)*(T))*exp(-x0);

    result += 14.026113219569801*pow(3.6688088490904739e-6*P - 1.2141967492063015e-7*pow(x1, 1.0)*x2 + 2.5532259575926023e-8*pow(x1, 2.0)*x2 + 0.99999633119115094, -0.24937404363663207) - 0.00011321956980410474;
    return result;
}

static double coder_d2gdt2(double T, double P) {
    double result = 0.0;
    double x0 = 1.0/T;
    double x1 = ((T)*(T));
    double x2 = 521.811045696664*x0;
    double x3 = exp(x2);
    double x4 = x3 - 1.0;
    double x5 = exp(-x2);
    double x6 = pow(x4, 2.0)*x5;
    double x7 = pow(x4, 1.0);
    double x8 = x5*x7;
    double x9 = 2.5532259575926023e-8*x1*x6 - 1.2141967492063015e-7*x1*x8;
    double x10 = x9 + 1.0;
    double x11 = 1.0/x1;
    double x12 = 0.024816422813220339*x11;
    double x13 = 9.5116510153932121e-5*x0;
    double x14 = 0.010436848054934418*x11;
    double x15 = 1.8228151921725449e-7*x8;
    double x16 = 3.833035352459446e-8*x6;
    double x17 = 101.86963969001212*x0*x6 - 203.73927938002424*x0*x7 + 26578.35160569381*x11*x6 - 5093175.9216572819*x12*x8 + 5093175.9216572819*x12 - 5093175.9216572819*x13*x8 + 5093175.9216572819*x13 + 5093175.9216572819*x14*x3 - 5093175.9216572819*x14*x7 - 5093175.9216572819*x15 + 5093175.9216572819*x16;
    double x18 = 3.6688088490904739e-6*P + x9 + 0.99999633119115094;
    double x19 = 5093175.9216572819*(T*x15 - T*x16 - 1.0000600927295723e-5*x6 + 2.0001201854591446e-5*x7 + 4.7558255076966061e-5*x8 - 4.7558255076966061e-5)*(-1.2734165627257586e-8*T*x6 + 6.0557830624005808e-8*T*x8 - 3.3224141410168984e-6*x6 + 6.6448282820337968e-6*x7 + 1.5799872461516968e-5*x8 - 1.5799872461516968e-5);

    result += 2059000.0*pow(T, -3.0) + 6323.8999999999996*pow(T, -1.5) - 724.89999999999998*x0 + pow(x10, -1.2493740436366321)*x19 - pow(x10, -0.24937404363663207)*x17 + x17*pow(x18, -0.24937404363663207) - pow(x18, -1.2493740436366321)*x19 + 0.013865000000000001;
    return result;
}

static double coder_d2gdtdp(double T, double P) {
    double result = 0.0;
    double x0 = ((T)*(T));
    double x1 = 521.811045696664/T;
    double x2 = exp(x1) - 1.0;
    double x3 = pow(x2, 1.0);
    double x4 = exp(-x1);
    double x5 = x3*x4;
    double x6 = pow(x2, 2.0)*x4;

    result += 9.1490569802754968e-7*pow(3.6688088490904739e-6*P - 1.2141967492063015e-7*x0*x5 + 2.5532259575926023e-8*x0*x6 + 0.99999633119115094, -1.2493740436366321)*(0.92839184464042968*T*x5 - 0.19522323364007582*T*x6 + 101.86963969001212*x3 + 242.22255963403873*x5 - 50.934819845006061*x6 - 242.22255963403873);
    return result;
}

static double coder_d2gdp2(double T, double P) {
    double result = 0.0;
    double x0 = 521.811045696664/T;
    double x1 = exp(x0) - 1.0;
    double x2 = ((T)*(T))*exp(-x0);

    result += -1.2832570905763951e-5*pow(3.6688088490904739e-6*P - 1.2141967492063015e-7*pow(x1, 1.0)*x2 + 2.5532259575926023e-8*pow(x1, 2.0)*x2 + 0.99999633119115094, -1.2493740436366321);
    return result;
}

static double coder_d3gdt3(double T, double P) {
    double result = 0.0;
    double x0 = ((T)*(T));
    double x1 = 1.0/x0;
    double x2 = 1.0/T;
    double x3 = 521.811045696664*x2;
    double x4 = exp(-x3);
    double x5 = exp(x3);
    double x6 = x5 - 1.0;
    double x7 = x4*pow(x6, 2.0);
    double x8 = pow(x6, 1.0);
    double x9 = x4*x8;
    double x10 = 2.5532259575926023e-8*x0*x7 - 1.2141967492063015e-7*x0*x9;
    double x11 = x10 + 1.0;
    double x12 = 5093175.9216572819*(-2.7230312986612613*x7 + 5.4460625973225225*x8 + 12.949483538617054*x9 - 12.949483538617054)/((T)*(T)*(T)*(T));
    double x13 = 3.6688088490904739e-6*P + x10 + 0.99999633119115094;
    double x14 = pow(x11, -1.2493740436366321);
    double x15 = 6.0557830624005808e-8*x9;
    double x16 = 1.2734165627257586e-8*x7;
    double x17 = T*x15 - T*x16 - 3.3224141410168984e-6*x7 + 6.6448282820337968e-6*x8 + 1.5799872461516968e-5*x9 - 1.5799872461516968e-5;
    double x18 = 0.024816422813220339*x1;
    double x19 = 9.5116510153932121e-5*x2;
    double x20 = 0.010436848054934418*x1;
    double x21 = x2*x8;
    double x22 = 1.8228151921725449e-7*x9;
    double x23 = 3.833035352459446e-8*x7;
    double x24 = x1*x7;
    double x25 = x2*x7;
    double x26 = 10186351.843314564*x17*(-x18*x9 + x18 - x19*x9 + x19 + x20*x5 - x20*x8 - 4.0002403709182892e-5*x21 - x22 + x23 + 0.0052184240274672092*x24 + 2.0001201854591446e-5*x25);
    double x27 = 0.0082445479710180937*x1;
    double x28 = 3.1599744923033936e-5*x2;
    double x29 = 0.003467344794322823*x1;
    double x30 = 5093175.9216572819*T*x22 - 5093175.9216572819*T*x23 - 50.934819845006061*x7 + 101.86963969001212*x8 + 242.22255963403873*x9 - 242.22255963403873;
    double x31 = x30*(-x15 + x16 - 1.3289656564067592e-5*x21 + 0.0017336723971614115*x24 + 6.644828282033796e-6*x25 - x27*x9 + x27 - x28*x9 + x28 + x29*x5 - x29*x8);
    double x32 = pow(x13, -1.2493740436366321);
    double x33 = x17*x30*(-6.3798684779109633e-8*T*x7 + 3.0339718046526611e-7*T*x9 - 1.664542920932952e-5*x7 + 3.329085841865904e-5*x8 + 7.915799999999999e-5*x9 - 7.915799999999999e-5);

    result += -6177000.0*pow(T, -4.0) - 9485.8499999999985*pow(T, -2.5) + 724.89999999999998*x1 + pow(x11, -2.2493740436366321)*x33 + pow(x11, -0.24937404363663207)*x12 - x12*pow(x13, -0.24937404363663207) - pow(x13, -2.2493740436366321)*x33 - x14*x26 - x14*x31 + x26*x32 + x31*x32;
    return result;
}

static double coder_d3gdt2dp(double T, double P) {
    double result = 0.0;
    double x0 = ((T)*(T));
    double x1 = 1.0/T;
    double x2 = 521.811045696664*x1;
    double x3 = exp(x2);
    double x4 = x3 - 1.0;
    double x5 = pow(x4, 1.0);
    double x6 = exp(-x2);
    double x7 = x5*x6;
    double x8 = pow(x4, 2.0)*x6;
    double x9 = 3.6688088490904739e-6*P - 1.2141967492063015e-7*x0*x7 + 2.5532259575926023e-8*x0*x8 + 0.99999633119115094;
    double x10 = 1.0/x0;
    double x11 = 126394.4071339603*x10;
    double x12 = 484.44511926807746*x1;
    double x13 = 53156.703211387619*x10;
    double x14 = T*x7;
    double x15 = T*x8;

    result += 23.345664563131727*pow(x9, -2.2493740436366321)*(6.0557830624005808e-8*x14 - 1.2734165627257586e-8*x15 + 6.6448282820337968e-6*x5 + 1.5799872461516968e-5*x7 - 3.3224141410168984e-6*x8 - 1.5799872461516968e-5)*(1.8228151921725449e-7*x14 - 3.833035352459446e-8*x15 + 2.0001201854591446e-5*x5 + 4.7558255076966061e-5*x7 - 1.0000600927295723e-5*x8 - 4.7558255076966061e-5) - 9.1490569802754968e-7*pow(x9, -1.2493740436366321)*(-203.73927938002424*x1*x5 + 101.86963969001212*x1*x8 + 26578.35160569381*x10*x8 - x11*x7 + x11 - x12*x7 + x12 + x13*x3 - x13*x5 - 0.92839184464042968*x7 + 0.19522323364007582*x8);
    return result;
}

static double coder_d3gdtdp2(double T, double P) {
    double result = 0.0;
    double x0 = ((T)*(T));
    double x1 = 521.811045696664/T;
    double x2 = exp(x1) - 1.0;
    double x3 = pow(x2, 1.0);
    double x4 = exp(-x1);
    double x5 = x3*x4;
    double x6 = pow(x2, 2.0)*x4;

    result += -4.1936665572900484e-12*pow(3.6688088490904739e-6*P - 1.2141967492063015e-7*x0*x5 + 2.5532259575926023e-8*x0*x6 + 0.99999633119115094, -2.2493740436366321)*(0.92839184464042968*T*x5 - 0.19522323364007582*T*x6 + 101.86963969001212*x3 + 242.22255963403873*x5 - 50.934819845006061*x6 - 242.22255963403873);
    return result;
}

static double coder_d3gdp3(double T, double P) {
    double result = 0.0;
    double x0 = 521.811045696664/T;
    double x1 = exp(x0) - 1.0;
    double x2 = ((T)*(T))*exp(-x0);

    result += 5.8820841937673729e-11*pow(3.6688088490904739e-6*P - 1.2141967492063015e-7*pow(x1, 1.0)*x2 + 2.5532259575926023e-8*pow(x1, 2.0)*x2 + 0.99999633119115094, -2.2493740436366321);
    return result;
}


static double coder_s(double T, double P) {
    double result = -coder_dgdt(T, P);
    return result;
}

static double coder_v(double T, double P) {
    double result = coder_dgdp(T, P);
    return result;
}

static double coder_cv(double T, double P) {
    double result = -T*coder_d2gdt2(T, P);
    double dvdt = coder_d2gdtdp(T, P);
    double dvdp = coder_d2gdp2(T, P);
    result += T*dvdt*dvdt/dvdp;
    return result;
}

static double coder_cp(double T, double P) {
    double result = -T*coder_d2gdt2(T, P);
    return result;
}

static double coder_dcpdt(double T, double P) {
    double result = -T*coder_d3gdt3(T, P) - coder_d2gdt2(T, P);
    return result;
}

static double coder_alpha(double T, double P) {
    double result = coder_d2gdtdp(T, P)/coder_dgdp(T, P);
    return result;
}

static double coder_beta(double T, double P) {
    double result = -coder_d2gdp2(T, P)/coder_dgdp(T, P);
    return result;
}

static double coder_K(double T, double P) {
    double result = -coder_dgdp(T, P)/coder_d2gdp2(T, P);
    return result;
}

static double coder_Kp(double T, double P) {
    double result = coder_dgdp(T, P);
    result *= coder_d3gdp3(T, P);
    result /= pow(coder_d2gdp2(T, P), 2.0);
    return result - 1.0;
}


#include <math.h>

static double coder_dparam_g(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_dgdt(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_dgdp(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d2gdt2(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d2gdtdp(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d2gdp2(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d3gdt3(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d3gdt2dp(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d3gdtdp2(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d3gdp3(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static int coder_get_param_number(void) {
    return 0;
}

static const char *paramNames[0] = {  };

static const char *paramUnits[0] = {  };

static const char **coder_get_param_names(void) {
    return paramNames;
}

static const char **coder_get_param_units(void) {
    return paramUnits;
}

static void coder_get_param_values(double **values) {
}

static int coder_set_param_values(double *values) {
    return 1;
}

static double coder_get_param_value(int index) {
    double result = 0.0;
    switch (index) {
     default:
         break;
    }
    return result;
}

static int coder_set_param_value(int index, double value) {
    int result = 1;
    switch (index) {
     default:
         break;
    }
    return result;
}



const char *pre_hgp_em_coder_calib_identifier(void) {
    return identifier;
}

const char *pre_hgp_em_coder_calib_name(void) {
    return "pre_hgp_em";
}

const char *pre_hgp_em_coder_calib_formula(void) {
    return "Al2Ca2H2O12Si3";
}

const double pre_hgp_em_coder_calib_mw(void) {
    return 412.38818;
}

static const double elmformula[106] = {
        0.0,2.0,0.0,0.0,0.0,0.0,
        0.0,0.0,12.0,0.0,0.0,0.0,
        0.0,2.0,3.0,0.0,0.0,0.0,
        0.0,0.0,2.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0
    };

const double *pre_hgp_em_coder_calib_elements(void) {
    return elmformula;
}

double pre_hgp_em_coder_calib_g(double T, double P) {
    return coder_g(T, P);
}

double pre_hgp_em_coder_calib_dgdt(double T, double P) {
    return coder_dgdt(T, P);
}

double pre_hgp_em_coder_calib_dgdp(double T, double P) {
    return coder_dgdp(T, P);
}

double pre_hgp_em_coder_calib_d2gdt2(double T, double P) {
    return coder_d2gdt2(T, P);
}

double pre_hgp_em_coder_calib_d2gdtdp(double T, double P) {
    return coder_d2gdtdp(T, P);
}

double pre_hgp_em_coder_calib_d2gdp2(double T, double P) {
    return coder_d2gdp2(T, P);
}

double pre_hgp_em_coder_calib_d3gdt3(double T, double P) {
    return coder_d3gdt3(T, P);
}

double pre_hgp_em_coder_calib_d3gdt2dp(double T, double P) {
    return coder_d3gdt2dp(T, P);
}

double pre_hgp_em_coder_calib_d3gdtdp2(double T, double P) {
    return coder_d3gdtdp2(T, P);
}

double pre_hgp_em_coder_calib_d3gdp3(double T, double P) {
    return coder_d3gdp3(T, P);
}

double pre_hgp_em_coder_calib_s(double T, double P) {
    return coder_s(T, P);
}

double pre_hgp_em_coder_calib_v(double T, double P) {
    return coder_v(T, P);
}

double pre_hgp_em_coder_calib_cv(double T, double P) {
    return coder_cv(T, P);
}

double pre_hgp_em_coder_calib_cp(double T, double P) {
    return coder_cp(T, P);
}

double pre_hgp_em_coder_calib_dcpdt(double T, double P) {
    return coder_dcpdt(T, P);
}

double pre_hgp_em_coder_calib_alpha(double T, double P) {
    return coder_alpha(T, P);
}

double pre_hgp_em_coder_calib_beta(double T, double P) {
    return coder_beta(T, P);
}

double pre_hgp_em_coder_calib_K(double T, double P) {
    return coder_K(T, P);
}

double pre_hgp_em_coder_calib_Kp(double T, double P) {
    return coder_Kp(T, P);
}

int pre_hgp_em_coder_get_param_number(void) {
    return coder_get_param_number();
}

const char **pre_hgp_em_coder_get_param_names(void) {
    return coder_get_param_names();
}

const char **pre_hgp_em_coder_get_param_units(void) {
    return coder_get_param_units();
}

void pre_hgp_em_coder_get_param_values(double **values) {
    coder_get_param_values(values);
}

int pre_hgp_em_coder_set_param_values(double *values) {
    return coder_set_param_values(values);
}

double pre_hgp_em_coder_get_param_value(int index) {
    return coder_get_param_value(index);
}

int pre_hgp_em_coder_set_param_value(int index, double value) {
    return coder_set_param_value(index, value);
}

double pre_hgp_em_coder_dparam_g(double T, double P, int index) {
    return coder_dparam_g(T, P, index);
}

double pre_hgp_em_coder_dparam_dgdt(double T, double P, int index) {
    return coder_dparam_dgdt(T, P, index);
}

double pre_hgp_em_coder_dparam_dgdp(double T, double P, int index) {
    return coder_dparam_dgdp(T, P, index);
}

double pre_hgp_em_coder_dparam_d2gdt2(double T, double P, int index) {
    return coder_dparam_d2gdt2(T, P, index);
}

double pre_hgp_em_coder_dparam_d2gdtdp(double T, double P, int index) {
    return coder_dparam_d2gdtdp(T, P, index);
}

double pre_hgp_em_coder_dparam_d2gdp2(double T, double P, int index) {
    return coder_dparam_d2gdp2(T, P, index);
}

double pre_hgp_em_coder_dparam_d3gdt3(double T, double P, int index) {
    return coder_dparam_d3gdt3(T, P, index);
}

double pre_hgp_em_coder_dparam_d3gdt2dp(double T, double P, int index) {
    return coder_dparam_d3gdt2dp(T, P, index);
}

double pre_hgp_em_coder_dparam_d3gdtdp2(double T, double P, int index) {
    return coder_dparam_d3gdtdp2(T, P, index);
}

double pre_hgp_em_coder_dparam_d3gdp3(double T, double P, int index) {
    return coder_dparam_d3gdp3(T, P, index);
}

