
static char *identifier = "mscf_hgp_em.emml:4d96a4134e108614c145791956e2e68a45460dbf:Mon Nov 21 18:01:53 2022";



#include <math.h>

#include <float.h>
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

static double chebvalat(double x) {
    double c[17] = {
        2.707737068327440945 / 2.0, 0.340068135211091751, -0.12945150184440869e-01, 0.7963755380173816e-03,
        -0.546360009590824e-04, 0.39243019598805e-05, -0.2894032823539e-06, 0.217317613962e-07, -0.16542099950e-08,
        0.1272796189e-09, -0.987963460e-11, 0.7725074e-12, -0.607797e-13, 0.48076e-14, -0.3820e-15, 0.305e-16, -0.24e-17
    };
    double x2 = 2 * x;
    double c0 = c[17-2];
    double c1 = c[17-1];
    for (int i=3; i<18; i++) {
        double tmp = c0;
        c0 = c[17-i] - c1;
        c1 = tmp + c1 * x2;
    }
    return c0 + c1 * x;
}

static double Debye(double x) {
    //
    // returns D_3(x) = 3/x^3\int_0^x t^3/(e^t - 1) dt
    //
    
    double val_infinity = 19.4818182068004875;
    double sqrt_eps = sqrt(DBL_EPSILON);
    double log_eps = log(DBL_EPSILON);
    double xcut = -log_eps;

    //Check for negative x (was returning zero)
    assert(x >= 0.);

    if (x < (2.0*sqrt(2.0)*sqrt_eps)) return 1.0 - 3.0*x/8.0 + x*x/20.0;
    else if (x <= 4.0) {
        double t = x*x/8.0 - 1.0;
        double c = chebvalat(t);
        return c - 0.375*x;
    } else if (x < -(log(2.0)+log_eps)) {
        int nexp = (int)(floor(xcut / x));
        double ex = exp(-x);
        double xk = nexp * x;
        double rk = nexp;
        double sum = 0.0;
        for (int i=nexp; i>0; i--) {
            double xk_inv = 1.0/xk;
            sum *= ex;
            sum += (((6.0*xk_inv + 6.0)*xk_inv + 3.0)*xk_inv + 1.0)/rk;
            rk -= 1.0;
            xk -= x;
        }
        return val_infinity / (x * x * x) - 3.0 * sum * ex;
    } else if (x < xcut) {
        double x3 = x*x*x;
        double sum = 6.0 + 6.0*x + 3.0*x*x + x3;
        return (val_infinity - 3.0*sum*exp(-x))/x3;
    } else return ((val_infinity/x)/x)/x;
}

double born_B(double t, double p);
double born_Q(double t, double p);
double born_N(double t, double p);
double born_U(double t, double p);
double born_Y(double t, double p);
double born_X(double t, double p);
double born_dUdT(double t, double p);
double born_dUdP(double t, double p);
double born_dNdT(double t, double p);
double born_dNdP(double t, double p);
double born_dXdT(double t, double p);
double gSolvent(double t, double p);
double DgSolventDt(double t, double p);
double DgSolventDp(double t, double p);
double D2gSolventDt2(double t, double p);
double D2gSolventDtDp(double t, double p);
double D2gSolventDp2(double t, double p);
double D3gSolventDt3(double t, double p);
double D3gSolventDt2Dp(double t, double p);
double D3gSolventDtDp2(double t, double p);
double D3gSolventDp3(double t, double p);
double D4gSolventDt4(double t, double p);

static double coder_g(double T, double P) {
    double result = 0.0;
    double x0 = pow(T, 1.0);
    double x1 = 561.56282998944005/T;
    double x2 = exp(x1) - 1.0;
    double x3 = ((T)*(T))*exp(-x1);
    double x4 = -1.4317209426149501e-7*pow(x2, 1.0)*x3 + 2.5674540394976316e-8*pow(x2, 2.0)*x3;

    result += -2.295235437018972e-5*P - 5983.6000000000004*sqrt(T) - 0.0013450000000000001*pow(T, 2.0) - 213.30000000000001*x0*log(T) + 1523.0992170717338*x0 - 2250221.3846901879*pow(x4 + 1.0, 0.75000196562190902) + 2250221.3846901879*pow(2.1621655621621624e-6*P + x4 + 0.99999783783443785, 0.75000196562190902) - 2078205.9892134282 + 705200.0/x0;
    return result;
}

static double coder_dgdt(double T, double P) {
    double result = 0.0;
    double x0 = ((T)*(T));
    double x1 = 561.56282998944005/T;
    double x2 = exp(x1) - 1.0;
    double x3 = exp(-x1);
    double x4 = pow(x2, 2.0)*x3;
    double x5 = pow(x2, 1.0);
    double x6 = x3*x5;
    double x7 = 2.5674540394976316e-8*x0*x4 - 1.4317209426149501e-7*x0*x6;
    double x8 = 0.086660326879622607*T*x4 - 0.48325462882167181*T*x6 + 24.332609205165408*x4 - 48.665218410330816*x5 - 135.68891848329721*x6 + 135.68891848329721;

    result += -705200.0*pow(T, -2.0) - 2991.8000000000002*pow(T, -0.5) - 0.0026900000000000001*pow(T, 1.0) - x8*pow(x7 + 1.0, -0.24999803437809098) + x8*pow(2.1621655621621624e-6*P + x7 + 0.99999783783443785, -0.24999803437809098) - 213.30000000000001*log(T) + 1309.7992170717339;
    return result;
}

static double coder_dgdp(double T, double P) {
    double result = 0.0;
    double x0 = 561.56282998944005/T;
    double x1 = exp(x0) - 1.0;
    double x2 = ((T)*(T))*exp(-x0);

    result += 3.6490229523543696*pow(2.1621655621621624e-6*P - 1.4317209426149501e-7*pow(x1, 1.0)*x2 + 2.5674540394976316e-8*pow(x1, 2.0)*x2 + 0.99999783783443785, -0.24999803437809098) - 2.295235437018972e-5;
    return result;
}

static double coder_d2gdt2(double T, double P) {
    double result = 0.0;
    double x0 = 1.0/T;
    double x1 = ((T)*(T));
    double x2 = 561.56282998944005*x0;
    double x3 = exp(x2);
    double x4 = x3 - 1.0;
    double x5 = exp(-x2);
    double x6 = pow(x4, 2.0)*x5;
    double x7 = pow(x4, 1.0);
    double x8 = x5*x7;
    double x9 = 2.5674540394976316e-8*x1*x6 - 1.4317209426149501e-7*x1*x8;
    double x10 = x9 + 1.0;
    double x11 = 1.0/x1;
    double x12 = 0.033862380644017295*x11;
    double x13 = 0.00012060050571600001*x0;
    double x14 = 0.012144839596003657*x11;
    double x15 = 2.1475870423665299e-7*x8;
    double x16 = 3.8511911525342681e-8*x6;
    double x17 = 48.665218410330816*x0*x6 - 97.330436820661632*x0*x7 + 13664.288886279786*x11*x6 - 2250221.3846901879*x12*x8 + 2250221.3846901879*x12 - 2250221.3846901879*x13*x8 + 2250221.3846901879*x13 + 2250221.3846901879*x14*x3 - 2250221.3846901879*x14*x7 - 2250221.3846901879*x15 + 2250221.3846901879*x16;
    double x18 = 2.1621655621621624e-6*P + x9 + 0.99999783783443785;
    double x19 = 2250221.3846901879*(T*x15 - T*x16 - 1.0813429012237185e-5*x6 + 2.162685802447437e-5*x7 + 6.0300252857999996e-5*x8 - 6.0300252857999996e-5)*(-1.283716926460995e-8*T*x6 + 7.1585484286337024e-8*T*x8 - 3.6044385506439111e-6*x6 + 7.2088771012878222e-6*x7 + 2.0099873571000004e-5*x8 - 2.0099873571000004e-5);

    result += 1410400.0*pow(T, -3.0) + 1495.9000000000001*pow(T, -1.5) - 213.30000000000001*x0 + pow(x10, -1.249998034378091)*x19 - pow(x10, -0.24999803437809098)*x17 + x17*pow(x18, -0.24999803437809098) - pow(x18, -1.249998034378091)*x19 - 0.0026900000000000001;
    return result;
}

static double coder_d2gdtdp(double T, double P) {
    double result = 0.0;
    double x0 = ((T)*(T));
    double x1 = 561.56282998944005/T;
    double x2 = exp(x1) - 1.0;
    double x3 = pow(x2, 1.0);
    double x4 = exp(-x1);
    double x5 = x3*x4;
    double x6 = pow(x2, 2.0)*x4;

    result += 5.4053714054054064e-7*pow(2.1621655621621624e-6*P - 1.4317209426149501e-7*x0*x5 + 2.5674540394976316e-8*x0*x6 + 0.99999783783443785, -1.249998034378091)*(0.48325462882167181*T*x5 - 0.086660326879622607*T*x6 + 48.665218410330816*x3 + 135.68891848329721*x5 - 24.332609205165408*x6 - 135.68891848329721);
    return result;
}

static double coder_d2gdp2(double T, double P) {
    double result = 0.0;
    double x0 = 561.56282998944005/T;
    double x1 = exp(x0) - 1.0;
    double x2 = ((T)*(T))*exp(-x0);

    result += -1.9724324324324322e-6*pow(2.1621655621621624e-6*P - 1.4317209426149501e-7*pow(x1, 1.0)*x2 + 2.5674540394976316e-8*pow(x1, 2.0)*x2 + 0.99999783783443785, -1.249998034378091);
    return result;
}

static double coder_d3gdt3(double T, double P) {
    double result = 0.0;
    double x0 = ((T)*(T));
    double x1 = 1.0/x0;
    double x2 = 1.0/T;
    double x3 = 561.56282998944005*x2;
    double x4 = exp(-x3);
    double x5 = exp(x3);
    double x6 = x5 - 1.0;
    double x7 = x4*pow(x6, 2.0);
    double x8 = pow(x6, 1.0);
    double x9 = x4*x8;
    double x10 = 2.5674540394976316e-8*x0*x7 - 1.4317209426149501e-7*x0*x9;
    double x11 = x10 + 1.0;
    double x12 = 19.01585430463399*x2;
    double x13 = x2*x8;
    double x14 = x2*x7;
    double x15 = 2250221.3846901879*(x12*x9 - x12 + 6.8200904932996211*x13 - 3.4100452466498106*x14 + 1.3877787807814457e-17*x9 - 1.3877787807814457e-17)/((T)*(T)*(T));
    double x16 = 2.1621655621621624e-6*P + x10 + 0.99999783783443785;
    double x17 = pow(x11, -1.249998034378091);
    double x18 = 7.1585484286337024e-8*x9;
    double x19 = 1.283716926460995e-8*x7;
    double x20 = T*x18 - T*x19 - 3.6044385506439111e-6*x7 + 7.2088771012878222e-6*x8 + 2.0099873571000004e-5*x9 - 2.0099873571000004e-5;
    double x21 = 0.033862380644017295*x1;
    double x22 = 0.00012060050571600001*x2;
    double x23 = 0.012144839596003657*x1;
    double x24 = 2.1475870423665299e-7*x9;
    double x25 = 3.8511911525342681e-8*x7;
    double x26 = x1*x7;
    double x27 = 4500442.7693803757*x20*(-4.3253716048948739e-5*x13 + 2.162685802447437e-5*x14 - x21*x9 + x21 - x22*x9 + x22 + x23*x5 - x23*x8 - x24 + x25 + 0.0060724197980018286*x26);
    double x28 = 0.011287341884960715*x1;
    double x29 = 4.0199747142000008e-5*x2;
    double x30 = 0.0040482374260452604*x1;
    double x31 = 2250221.3846901879*T*x24 - 2250221.3846901879*T*x25 - 24.332609205165408*x7 + 48.665218410330816*x8 + 135.68891848329721*x9 - 135.68891848329721;
    double x32 = x31*(-1.4417754202575644e-5*x13 + 7.2088771012878222e-6*x14 - x18 + x19 + 0.0020241187130226302*x26 - x28*x9 + x28 - x29*x9 + x29 + x30*x5 - x30*x8);
    double x33 = pow(x16, -1.249998034378091);
    double x34 = x20*x31*(-6.4186250054562577e-8*T*x7 + 3.5792967280932707e-7*T*x9 - 1.8022306113525005e-5*x7 + 3.6044612227050011e-5*x8 + 0.0001005*x9 - 0.0001005);

    result += -4231200.0*pow(T, -4.0) - 2243.8500000000004*pow(T, -2.5) + 213.30000000000001*x1 + pow(x11, -2.2499980343780912)*x34 + pow(x11, -0.24999803437809098)*x15 - x15*pow(x16, -0.24999803437809098) - pow(x16, -2.2499980343780912)*x34 - x17*x27 - x17*x32 + x27*x33 + x32*x33;
    return result;
}

static double coder_d3gdt2dp(double T, double P) {
    double result = 0.0;
    double x0 = ((T)*(T));
    double x1 = 1.0/T;
    double x2 = 561.56282998944005*x1;
    double x3 = exp(x2);
    double x4 = x3 - 1.0;
    double x5 = pow(x4, 1.0);
    double x6 = exp(-x2);
    double x7 = x5*x6;
    double x8 = pow(x4, 2.0)*x6;
    double x9 = 2.1621655621621624e-6*P - 1.4317209426149501e-7*x0*x7 + 2.5674540394976316e-8*x0*x8 + 0.99999783783443785;
    double x10 = 1.0/x0;
    double x11 = 76197.853061686808*x10;
    double x12 = 271.37783696659443*x1;
    double x13 = 27328.577772559573*x10;
    double x14 = T*x7;
    double x15 = T*x8;

    result += 6.0816794180815892*pow(x9, -2.2499980343780912)*(7.1585484286337024e-8*x14 - 1.283716926460995e-8*x15 + 7.2088771012878222e-6*x5 + 2.0099873571000004e-5*x7 - 3.6044385506439111e-6*x8 - 2.0099873571000004e-5)*(2.1475870423665299e-7*x14 - 3.8511911525342681e-8*x15 + 2.162685802447437e-5*x5 + 6.0300252857999996e-5*x7 - 1.0813429012237185e-5*x8 - 6.0300252857999996e-5) - 5.4053714054054064e-7*pow(x9, -1.249998034378091)*(-97.330436820661632*x1*x5 + 48.665218410330816*x1*x8 + 13664.288886279786*x10*x8 - x11*x7 + x11 - x12*x7 + x12 + x13*x3 - x13*x5 - 0.48325462882167181*x7 + 0.086660326879622607*x8);
    return result;
}

static double coder_d3gdtdp2(double T, double P) {
    double result = 0.0;
    double x0 = ((T)*(T));
    double x1 = 561.56282998944005/T;
    double x2 = exp(x1) - 1.0;
    double x3 = pow(x2, 1.0);
    double x4 = exp(-x1);
    double x5 = x3*x4;
    double x6 = pow(x2, 2.0)*x4;

    result += -1.4609111906501099e-12*pow(2.1621655621621624e-6*P - 1.4317209426149501e-7*x0*x5 + 2.5674540394976316e-8*x0*x6 + 0.99999783783443785, -2.2499980343780912)*(0.48325462882167181*T*x5 - 0.086660326879622607*T*x6 + 48.665218410330816*x3 + 135.68891848329721*x5 - 24.332609205165408*x6 - 135.68891848329721);
    return result;
}

static double coder_d3gdp3(double T, double P) {
    double result = 0.0;
    double x0 = 561.56282998944005/T;
    double x1 = exp(x0) - 1.0;
    double x2 = ((T)*(T))*exp(-x0);

    result += 5.3308984660336014e-12*pow(2.1621655621621624e-6*P - 1.4317209426149501e-7*pow(x1, 1.0)*x2 + 2.5674540394976316e-8*pow(x1, 2.0)*x2 + 0.99999783783443785, -2.2499980343780912);
    return result;
}


static double coder_s(double T, double P) {
    double result = -coder_dgdt(T, P);
    return result;
}

static double coder_v(double T, double P) {
    double result = coder_dgdp(T, P);
    return result;
}

static double coder_cv(double T, double P) {
    double result = -T*coder_d2gdt2(T, P);
    double dvdt = coder_d2gdtdp(T, P);
    double dvdp = coder_d2gdp2(T, P);
    result += T*dvdt*dvdt/dvdp;
    return result;
}

static double coder_cp(double T, double P) {
    double result = -T*coder_d2gdt2(T, P);
    return result;
}

static double coder_dcpdt(double T, double P) {
    double result = -T*coder_d3gdt3(T, P) - coder_d2gdt2(T, P);
    return result;
}

static double coder_alpha(double T, double P) {
    double result = coder_d2gdtdp(T, P)/coder_dgdp(T, P);
    return result;
}

static double coder_beta(double T, double P) {
    double result = -coder_d2gdp2(T, P)/coder_dgdp(T, P);
    return result;
}

static double coder_K(double T, double P) {
    double result = -coder_dgdp(T, P)/coder_d2gdp2(T, P);
    return result;
}

static double coder_Kp(double T, double P) {
    double result = coder_dgdp(T, P);
    result *= coder_d3gdp3(T, P);
    result /= pow(coder_d2gdp2(T, P), 2.0);
    return result - 1.0;
}


#include <math.h>

static double coder_dparam_g(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_dgdt(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_dgdp(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d2gdt2(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d2gdtdp(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d2gdp2(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d3gdt3(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d3gdt2dp(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d3gdtdp2(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d3gdp3(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static int coder_get_param_number(void) {
    return 0;
}

static const char *paramNames[0] = {  };

static const char *paramUnits[0] = {  };

static const char **coder_get_param_names(void) {
    return paramNames;
}

static const char **coder_get_param_units(void) {
    return paramUnits;
}

static void coder_get_param_values(double **values) {
}

static int coder_set_param_values(double *values) {
    return 1;
}

static double coder_get_param_value(int index) {
    double result = 0.0;
    switch (index) {
     default:
         break;
    }
    return result;
}

static int coder_set_param_value(int index, double value) {
    int result = 1;
    switch (index) {
     default:
         break;
    }
    return result;
}



const char *mscf_hgp_em_coder_calib_identifier(void) {
    return identifier;
}

const char *mscf_hgp_em_coder_calib_name(void) {
    return "mscf_hgp_em";
}

const char *mscf_hgp_em_coder_calib_formula(void) {
    return "Mg2O4Si";
}

const double mscf_hgp_em_coder_calib_mw(void) {
    return 140.6931;
}

static const double elmformula[106] = {
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,4.0,0.0,0.0,0.0,
        2.0,0.0,1.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0
    };

const double *mscf_hgp_em_coder_calib_elements(void) {
    return elmformula;
}

double mscf_hgp_em_coder_calib_g(double T, double P) {
    return coder_g(T, P);
}

double mscf_hgp_em_coder_calib_dgdt(double T, double P) {
    return coder_dgdt(T, P);
}

double mscf_hgp_em_coder_calib_dgdp(double T, double P) {
    return coder_dgdp(T, P);
}

double mscf_hgp_em_coder_calib_d2gdt2(double T, double P) {
    return coder_d2gdt2(T, P);
}

double mscf_hgp_em_coder_calib_d2gdtdp(double T, double P) {
    return coder_d2gdtdp(T, P);
}

double mscf_hgp_em_coder_calib_d2gdp2(double T, double P) {
    return coder_d2gdp2(T, P);
}

double mscf_hgp_em_coder_calib_d3gdt3(double T, double P) {
    return coder_d3gdt3(T, P);
}

double mscf_hgp_em_coder_calib_d3gdt2dp(double T, double P) {
    return coder_d3gdt2dp(T, P);
}

double mscf_hgp_em_coder_calib_d3gdtdp2(double T, double P) {
    return coder_d3gdtdp2(T, P);
}

double mscf_hgp_em_coder_calib_d3gdp3(double T, double P) {
    return coder_d3gdp3(T, P);
}

double mscf_hgp_em_coder_calib_s(double T, double P) {
    return coder_s(T, P);
}

double mscf_hgp_em_coder_calib_v(double T, double P) {
    return coder_v(T, P);
}

double mscf_hgp_em_coder_calib_cv(double T, double P) {
    return coder_cv(T, P);
}

double mscf_hgp_em_coder_calib_cp(double T, double P) {
    return coder_cp(T, P);
}

double mscf_hgp_em_coder_calib_dcpdt(double T, double P) {
    return coder_dcpdt(T, P);
}

double mscf_hgp_em_coder_calib_alpha(double T, double P) {
    return coder_alpha(T, P);
}

double mscf_hgp_em_coder_calib_beta(double T, double P) {
    return coder_beta(T, P);
}

double mscf_hgp_em_coder_calib_K(double T, double P) {
    return coder_K(T, P);
}

double mscf_hgp_em_coder_calib_Kp(double T, double P) {
    return coder_Kp(T, P);
}

int mscf_hgp_em_coder_get_param_number(void) {
    return coder_get_param_number();
}

const char **mscf_hgp_em_coder_get_param_names(void) {
    return coder_get_param_names();
}

const char **mscf_hgp_em_coder_get_param_units(void) {
    return coder_get_param_units();
}

void mscf_hgp_em_coder_get_param_values(double **values) {
    coder_get_param_values(values);
}

int mscf_hgp_em_coder_set_param_values(double *values) {
    return coder_set_param_values(values);
}

double mscf_hgp_em_coder_get_param_value(int index) {
    return coder_get_param_value(index);
}

int mscf_hgp_em_coder_set_param_value(int index, double value) {
    return coder_set_param_value(index, value);
}

double mscf_hgp_em_coder_dparam_g(double T, double P, int index) {
    return coder_dparam_g(T, P, index);
}

double mscf_hgp_em_coder_dparam_dgdt(double T, double P, int index) {
    return coder_dparam_dgdt(T, P, index);
}

double mscf_hgp_em_coder_dparam_dgdp(double T, double P, int index) {
    return coder_dparam_dgdp(T, P, index);
}

double mscf_hgp_em_coder_dparam_d2gdt2(double T, double P, int index) {
    return coder_dparam_d2gdt2(T, P, index);
}

double mscf_hgp_em_coder_dparam_d2gdtdp(double T, double P, int index) {
    return coder_dparam_d2gdtdp(T, P, index);
}

double mscf_hgp_em_coder_dparam_d2gdp2(double T, double P, int index) {
    return coder_dparam_d2gdp2(T, P, index);
}

double mscf_hgp_em_coder_dparam_d3gdt3(double T, double P, int index) {
    return coder_dparam_d3gdt3(T, P, index);
}

double mscf_hgp_em_coder_dparam_d3gdt2dp(double T, double P, int index) {
    return coder_dparam_d3gdt2dp(T, P, index);
}

double mscf_hgp_em_coder_dparam_d3gdtdp2(double T, double P, int index) {
    return coder_dparam_d3gdtdp2(T, P, index);
}

double mscf_hgp_em_coder_dparam_d3gdp3(double T, double P, int index) {
    return coder_dparam_d3gdp3(T, P, index);
}

