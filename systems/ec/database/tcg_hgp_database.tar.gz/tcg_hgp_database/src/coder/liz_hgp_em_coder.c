
static char *identifier = "liz_hgp_em.emml:c52216dadbd4272a8f0400be95d1109c0083551a:Mon Nov 21 18:01:14 2022";



#include <math.h>

#include <float.h>
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

static double chebvalat(double x) {
    double c[17] = {
        2.707737068327440945 / 2.0, 0.340068135211091751, -0.12945150184440869e-01, 0.7963755380173816e-03,
        -0.546360009590824e-04, 0.39243019598805e-05, -0.2894032823539e-06, 0.217317613962e-07, -0.16542099950e-08,
        0.1272796189e-09, -0.987963460e-11, 0.7725074e-12, -0.607797e-13, 0.48076e-14, -0.3820e-15, 0.305e-16, -0.24e-17
    };
    double x2 = 2 * x;
    double c0 = c[17-2];
    double c1 = c[17-1];
    for (int i=3; i<18; i++) {
        double tmp = c0;
        c0 = c[17-i] - c1;
        c1 = tmp + c1 * x2;
    }
    return c0 + c1 * x;
}

static double Debye(double x) {
    //
    // returns D_3(x) = 3/x^3\int_0^x t^3/(e^t - 1) dt
    //
    
    double val_infinity = 19.4818182068004875;
    double sqrt_eps = sqrt(DBL_EPSILON);
    double log_eps = log(DBL_EPSILON);
    double xcut = -log_eps;

    //Check for negative x (was returning zero)
    assert(x >= 0.);

    if (x < (2.0*sqrt(2.0)*sqrt_eps)) return 1.0 - 3.0*x/8.0 + x*x/20.0;
    else if (x <= 4.0) {
        double t = x*x/8.0 - 1.0;
        double c = chebvalat(t);
        return c - 0.375*x;
    } else if (x < -(log(2.0)+log_eps)) {
        int nexp = (int)(floor(xcut / x));
        double ex = exp(-x);
        double xk = nexp * x;
        double rk = nexp;
        double sum = 0.0;
        for (int i=nexp; i>0; i--) {
            double xk_inv = 1.0/xk;
            sum *= ex;
            sum += (((6.0*xk_inv + 6.0)*xk_inv + 3.0)*xk_inv + 1.0)/rk;
            rk -= 1.0;
            xk -= x;
        }
        return val_infinity / (x * x * x) - 3.0 * sum * ex;
    } else if (x < xcut) {
        double x3 = x*x*x;
        double sum = 6.0 + 6.0*x + 3.0*x*x + x3;
        return (val_infinity - 3.0*sum*exp(-x))/x3;
    } else return ((val_infinity/x)/x)/x;
}

double born_B(double t, double p);
double born_Q(double t, double p);
double born_N(double t, double p);
double born_U(double t, double p);
double born_Y(double t, double p);
double born_X(double t, double p);
double born_dUdT(double t, double p);
double born_dUdP(double t, double p);
double born_dNdT(double t, double p);
double born_dNdP(double t, double p);
double born_dXdT(double t, double p);
double gSolvent(double t, double p);
double DgSolventDt(double t, double p);
double DgSolventDp(double t, double p);
double D2gSolventDt2(double t, double p);
double D2gSolventDtDp(double t, double p);
double D2gSolventDp2(double t, double p);
double D3gSolventDt3(double t, double p);
double D3gSolventDt2Dp(double t, double p);
double D3gSolventDtDp2(double t, double p);
double D3gSolventDp3(double t, double p);
double D4gSolventDt4(double t, double p);

static double coder_g(double T, double P) {
    double result = 0.0;
    double x0 = pow(T, 1.0);
    double x1 = 583.82532324957299/T;
    double x2 = exp(x1) - 1.0;
    double x3 = ((T)*(T))*exp(-x1);
    double x4 = -1.2058429902508405e-7*pow(x2, 1.0)*x3 + 1.9812497960022863e-8*pow(x2, 2.0)*x3;

    result += -8.0978651730760908e-5*P - 22477.599999999999*sqrt(T) + 0.010385*pow(T, 2.0) - 614.70000000000005*x0*log(T) + 4559.3871681142564*x0 - 3435434.1941660666*pow(x4 + 1.0, 0.68750312010977033) + 3435434.1941660666*pow(4.507052967806841e-6*P + x4 + 0.99999549294703216, 0.68750312010977033) - 4363044.0012347568 + 860900.0/x0;
    return result;
}

static double coder_dgdt(double T, double P) {
    double result = 0.0;
    double x0 = ((T)*(T));
    double x1 = 583.82532324957299/T;
    double x2 = exp(x1) - 1.0;
    double x3 = exp(-x1);
    double x4 = pow(x2, 2.0)*x3;
    double x5 = pow(x2, 1.0);
    double x6 = x3*x5;
    double x7 = 1.9812497960022863e-8*x0*x4 - 1.2058429902508405e-7*x0*x6;
    double x8 = 0.093589157562727107*T*x4 - 0.56960929327644294*T*x6 + 27.319860083357181*x4 - 54.639720166714362*x5 - 166.27616488654007*x6 + 166.27616488654007;

    result += -860900.0*pow(T, -2.0) - 11238.799999999999*pow(T, -0.5) + 0.02077*pow(T, 1.0) - x8*pow(x7 + 1.0, -0.31249687989022967) + x8*pow(4.507052967806841e-6*P + x7 + 0.99999549294703216, -0.31249687989022967) - 614.70000000000005*log(T) + 3944.6871681142566;
    return result;
}

static double coder_dgdp(double T, double P) {
    double result = 0.0;
    double x0 = 583.82532324957299/T;
    double x1 = exp(x0) - 1.0;
    double x2 = ((T)*(T))*exp(-x0);

    result += 10.645080978651732*pow(4.507052967806841e-6*P - 1.2058429902508405e-7*pow(x1, 1.0)*x2 + 1.9812497960022863e-8*pow(x1, 2.0)*x2 + 0.99999549294703216, -0.31249687989022967) - 8.0978651730760908e-5;
    return result;
}

static double coder_d2gdt2(double T, double P) {
    double result = 0.0;
    double x0 = 1.0/T;
    double x1 = ((T)*(T));
    double x2 = 583.82532324957299*x0;
    double x3 = exp(x2);
    double x4 = x3 - 1.0;
    double x5 = exp(-x2);
    double x6 = pow(x4, 2.0)*x5;
    double x7 = pow(x4, 1.0);
    double x8 = x5*x7;
    double x9 = 1.9812497960022863e-8*x1*x6 - 1.2058429902508405e-7*x1*x8;
    double x10 = x9 + 1.0;
    double x11 = 1.0/x1;
    double x12 = 0.028257341059955393*x11;
    double x13 = 9.6800669428571436e-5*x0;
    double x14 = 0.0092855954984583221*x11;
    double x15 = 1.6580416363198963e-7*x8;
    double x16 = 2.7242308329368357e-8*x6;
    double x17 = 54.639720166714369*x0*x6 - 109.27944033342874*x0*x7 + 15950.02614429911*x11*x6 - 3435434.1941660666*x12*x8 + 3435434.1941660666*x12 - 3435434.1941660666*x13*x8 + 3435434.1941660666*x13 + 3435434.1941660666*x14*x3 - 3435434.1941660666*x14*x7 - 3435434.1941660666*x15 + 3435434.1941660666*x16;
    double x18 = 4.507052967806841e-6*P + x9 + 0.99999549294703216;
    double x19 = 3435434.1941660666*(T*x15 - T*x16 - 7.9523747332290064e-6*x6 + 1.5904749466458013e-5*x7 + 4.8400334714285725e-5*x8 - 4.8400334714285725e-5)*(-1.2382687590677371e-8*T*x6 + 7.5364434418178457e-8*T*x8 - 3.6146632926628458e-6*x6 + 7.2293265853256915e-6*x7 + 2.1999832642857143e-5*x8 - 2.1999832642857143e-5);

    result += 1721800.0*pow(T, -3.0) + 5619.3999999999996*pow(T, -1.5) - 614.70000000000005*x0 + pow(x10, -1.3124968798902297)*x19 - pow(x10, -0.31249687989022967)*x17 + x17*pow(x18, -0.31249687989022967) - pow(x18, -1.3124968798902297)*x19 + 0.02077;
    return result;
}

static double coder_d2gdtdp(double T, double P) {
    double result = 0.0;
    double x0 = ((T)*(T));
    double x1 = 583.82532324957299/T;
    double x2 = exp(x1) - 1.0;
    double x3 = pow(x2, 1.0);
    double x4 = exp(-x1);
    double x5 = x3*x4;
    double x6 = pow(x2, 2.0)*x4;

    result += 1.4084399899396376e-6*pow(4.507052967806841e-6*P - 1.2058429902508405e-7*x0*x5 + 1.9812497960022863e-8*x0*x6 + 0.99999549294703216, -1.3124968798902297)*(0.56960929327644294*T*x5 - 0.093589157562727107*T*x6 + 54.639720166714362*x3 + 166.27616488654007*x5 - 27.319860083357181*x6 - 166.27616488654007);
    return result;
}

static double coder_d2gdp2(double T, double P) {
    double result = 0.0;
    double x0 = 583.82532324957299/T;
    double x1 = exp(x0) - 1.0;
    double x2 = ((T)*(T))*exp(-x0);

    result += -1.4992957746478874e-5*pow(4.507052967806841e-6*P - 1.2058429902508405e-7*pow(x1, 1.0)*x2 + 1.9812497960022863e-8*pow(x1, 2.0)*x2 + 0.99999549294703216, -1.3124968798902297);
    return result;
}

static double coder_d3gdt3(double T, double P) {
    double result = 0.0;
    double x0 = ((T)*(T));
    double x1 = 1.0/x0;
    double x2 = 1.0/T;
    double x3 = 583.82532324957299*x2;
    double x4 = exp(x3);
    double x5 = x4 - 1.0;
    double x6 = exp(-x3);
    double x7 = pow(x5, 2.0)*x6;
    double x8 = pow(x5, 1.0);
    double x9 = x6*x8;
    double x10 = 1.9812497960022863e-8*x0*x7 - 1.2058429902508405e-7*x0*x9;
    double x11 = x10 + 1.0;
    double x12 = 16.497351278501888*x2;
    double x13 = 6.9388939039072284e-18*x8;
    double x14 = x2*x8;
    double x15 = x2*x7;
    double x16 = 3435434.1941660666*(-x12*x9 + x12 + x13*x6 - x13 - 5.4211657934522099*x14 + 2.710582896726105*x15 + 6.9388939039072284e-18*x4 + 3.4694469519536142e-18*x7 - 6.9388939039072284e-18)/((T)*(T)*(T));
    double x17 = 4.507052967806841e-6*P + x10 + 0.99999549294703216;
    double x18 = pow(x11, -1.3124968798902297);
    double x19 = 7.5364434418178457e-8*x9;
    double x20 = 1.2382687590677371e-8*x7;
    double x21 = T*x19 - T*x20 - 3.6146632926628458e-6*x7 + 7.2293265853256915e-6*x8 + 2.1999832642857143e-5*x9 - 2.1999832642857143e-5;
    double x22 = 0.028257341059955393*x1;
    double x23 = 9.6800669428571436e-5*x2;
    double x24 = 0.0092855954984583221*x1;
    double x25 = 1.6580416363198963e-7*x9;
    double x26 = 2.7242308329368357e-8*x7;
    double x27 = x1*x7;
    double x28 = 6870868.3883321332*x21*(-3.1809498932916032e-5*x14 + 1.5904749466458016e-5*x15 - x22*x9 + x22 - x23*x9 + x23 + x24*x4 - x24*x8 - x25 + x26 + 0.0046427977492291611*x27);
    double x29 = 0.012844059404152579*x1;
    double x30 = 4.3999665285714285e-5*x2;
    double x31 = 0.0042206639305545036*x1;
    double x32 = 3435434.1941660666*T*x25 - 3435434.1941660666*T*x26 - 27.319860083357181*x7 + 54.639720166714362*x8 + 166.27616488654007*x9 - 166.27616488654007;
    double x33 = x32*(-1.4458653170651385e-5*x14 + 7.2293265853256924e-6*x15 - x19 + x20 + 0.0021103319652772518*x27 - x29*x9 + x29 - x30*x9 + x30 + x31*x4 - x31*x8);
    double x34 = pow(x17, -1.3124968798902297);
    double x35 = x21*x32*(-5.2007683510723095e-8*T*x7 + 3.1653303246834657e-7*T*x9 - 1.5181701318554699e-5*x7 + 3.0363402637109398e-5*x8 + 9.240000000000001e-5*x9 - 9.240000000000001e-5);

    result += -5165400.0*pow(T, -4.0) - 8429.0999999999985*pow(T, -2.5) + 614.70000000000005*x1 + pow(x11, -2.3124968798902295)*x35 - pow(x11, -0.31249687989022967)*x16 + x16*pow(x17, -0.31249687989022967) - pow(x17, -2.3124968798902295)*x35 - x18*x28 - x18*x33 + x28*x34 + x33*x34;
    return result;
}

static double coder_d3gdt2dp(double T, double P) {
    double result = 0.0;
    double x0 = ((T)*(T));
    double x1 = 1.0/T;
    double x2 = 583.82532324957299*x1;
    double x3 = exp(x2);
    double x4 = x3 - 1.0;
    double x5 = pow(x4, 1.0);
    double x6 = exp(-x2);
    double x7 = x5*x6;
    double x8 = pow(x4, 2.0)*x6;
    double x9 = 4.507052967806841e-6*P - 1.2058429902508405e-7*x0*x7 + 1.9812497960022863e-8*x0*x8 + 0.99999549294703216;
    double x10 = 1.0/x0;
    double x11 = 97076.235713583563*x10;
    double x12 = 332.55232977308009*x1;
    double x13 = 31900.052288598221*x10;
    double x14 = T*x7;
    double x15 = T*x8;

    result += 20.322286782390815*pow(x9, -2.3124968798902295)*(7.5364434418178457e-8*x14 - 1.2382687590677371e-8*x15 + 7.2293265853256915e-6*x5 + 2.1999832642857143e-5*x7 - 3.6146632926628458e-6*x8 - 2.1999832642857143e-5)*(1.6580416363198963e-7*x14 - 2.7242308329368357e-8*x15 + 1.5904749466458013e-5*x5 + 4.8400334714285725e-5*x7 - 7.9523747332290064e-6*x8 - 4.8400334714285725e-5) - 1.4084399899396376e-6*pow(x9, -1.3124968798902297)*(-109.27944033342874*x1*x5 + 54.639720166714369*x1*x8 + 15950.02614429911*x10*x8 - x11*x7 + x11 - x12*x7 + x12 + x13*x3 - x13*x5 - 0.56960929327644294*x7 + 0.093589157562727107*x8);
    return result;
}

static double coder_d3gdtdp2(double T, double P) {
    double result = 0.0;
    double x0 = ((T)*(T));
    double x1 = 583.82532324957299/T;
    double x2 = exp(x1) - 1.0;
    double x3 = pow(x2, 1.0);
    double x4 = exp(-x1);
    double x5 = x3*x4;
    double x6 = pow(x2, 2.0)*x4;

    result += -8.3316168418964474e-12*pow(4.507052967806841e-6*P - 1.2058429902508405e-7*x0*x5 + 1.9812497960022863e-8*x0*x6 + 0.99999549294703216, -2.3124968798902295)*(0.56960929327644294*T*x5 - 0.093589157562727107*T*x6 + 54.639720166714362*x3 + 166.27616488654007*x5 - 27.319860083357181*x6 - 166.27616488654007);
    return result;
}

static double coder_d3gdp3(double T, double P) {
    double result = 0.0;
    double x0 = 583.82532324957299/T;
    double x1 = exp(x0) - 1.0;
    double x2 = ((T)*(T))*exp(-x0);

    result += 8.8690735965086288e-11*pow(4.507052967806841e-6*P - 1.2058429902508405e-7*pow(x1, 1.0)*x2 + 1.9812497960022863e-8*pow(x1, 2.0)*x2 + 0.99999549294703216, -2.3124968798902295);
    return result;
}


static double coder_s(double T, double P) {
    double result = -coder_dgdt(T, P);
    return result;
}

static double coder_v(double T, double P) {
    double result = coder_dgdp(T, P);
    return result;
}

static double coder_cv(double T, double P) {
    double result = -T*coder_d2gdt2(T, P);
    double dvdt = coder_d2gdtdp(T, P);
    double dvdp = coder_d2gdp2(T, P);
    result += T*dvdt*dvdt/dvdp;
    return result;
}

static double coder_cp(double T, double P) {
    double result = -T*coder_d2gdt2(T, P);
    return result;
}

static double coder_dcpdt(double T, double P) {
    double result = -T*coder_d3gdt3(T, P) - coder_d2gdt2(T, P);
    return result;
}

static double coder_alpha(double T, double P) {
    double result = coder_d2gdtdp(T, P)/coder_dgdp(T, P);
    return result;
}

static double coder_beta(double T, double P) {
    double result = -coder_d2gdp2(T, P)/coder_dgdp(T, P);
    return result;
}

static double coder_K(double T, double P) {
    double result = -coder_dgdp(T, P)/coder_d2gdp2(T, P);
    return result;
}

static double coder_Kp(double T, double P) {
    double result = coder_dgdp(T, P);
    result *= coder_d3gdp3(T, P);
    result /= pow(coder_d2gdp2(T, P), 2.0);
    return result - 1.0;
}


#include <math.h>

static double coder_dparam_g(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_dgdt(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_dgdp(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d2gdt2(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d2gdtdp(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d2gdp2(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d3gdt3(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d3gdt2dp(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d3gdtdp2(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d3gdp3(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static int coder_get_param_number(void) {
    return 0;
}

static const char *paramNames[0] = {  };

static const char *paramUnits[0] = {  };

static const char **coder_get_param_names(void) {
    return paramNames;
}

static const char **coder_get_param_units(void) {
    return paramUnits;
}

static void coder_get_param_values(double **values) {
}

static int coder_set_param_values(double *values) {
    return 1;
}

static double coder_get_param_value(int index) {
    double result = 0.0;
    switch (index) {
     default:
         break;
    }
    return result;
}

static int coder_set_param_value(int index, double value) {
    int result = 1;
    switch (index) {
     default:
         break;
    }
    return result;
}



const char *liz_hgp_em_coder_calib_identifier(void) {
    return identifier;
}

const char *liz_hgp_em_coder_calib_name(void) {
    return "liz_hgp_em";
}

const char *liz_hgp_em_coder_calib_formula(void) {
    return "H4Mg3O9Si2";
}

const double liz_hgp_em_coder_calib_mw(void) {
    return 277.1122;
}

static const double elmformula[106] = {
        0.0,4.0,0.0,0.0,0.0,0.0,
        0.0,0.0,9.0,0.0,0.0,0.0,
        3.0,0.0,2.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0
    };

const double *liz_hgp_em_coder_calib_elements(void) {
    return elmformula;
}

double liz_hgp_em_coder_calib_g(double T, double P) {
    return coder_g(T, P);
}

double liz_hgp_em_coder_calib_dgdt(double T, double P) {
    return coder_dgdt(T, P);
}

double liz_hgp_em_coder_calib_dgdp(double T, double P) {
    return coder_dgdp(T, P);
}

double liz_hgp_em_coder_calib_d2gdt2(double T, double P) {
    return coder_d2gdt2(T, P);
}

double liz_hgp_em_coder_calib_d2gdtdp(double T, double P) {
    return coder_d2gdtdp(T, P);
}

double liz_hgp_em_coder_calib_d2gdp2(double T, double P) {
    return coder_d2gdp2(T, P);
}

double liz_hgp_em_coder_calib_d3gdt3(double T, double P) {
    return coder_d3gdt3(T, P);
}

double liz_hgp_em_coder_calib_d3gdt2dp(double T, double P) {
    return coder_d3gdt2dp(T, P);
}

double liz_hgp_em_coder_calib_d3gdtdp2(double T, double P) {
    return coder_d3gdtdp2(T, P);
}

double liz_hgp_em_coder_calib_d3gdp3(double T, double P) {
    return coder_d3gdp3(T, P);
}

double liz_hgp_em_coder_calib_s(double T, double P) {
    return coder_s(T, P);
}

double liz_hgp_em_coder_calib_v(double T, double P) {
    return coder_v(T, P);
}

double liz_hgp_em_coder_calib_cv(double T, double P) {
    return coder_cv(T, P);
}

double liz_hgp_em_coder_calib_cp(double T, double P) {
    return coder_cp(T, P);
}

double liz_hgp_em_coder_calib_dcpdt(double T, double P) {
    return coder_dcpdt(T, P);
}

double liz_hgp_em_coder_calib_alpha(double T, double P) {
    return coder_alpha(T, P);
}

double liz_hgp_em_coder_calib_beta(double T, double P) {
    return coder_beta(T, P);
}

double liz_hgp_em_coder_calib_K(double T, double P) {
    return coder_K(T, P);
}

double liz_hgp_em_coder_calib_Kp(double T, double P) {
    return coder_Kp(T, P);
}

int liz_hgp_em_coder_get_param_number(void) {
    return coder_get_param_number();
}

const char **liz_hgp_em_coder_get_param_names(void) {
    return coder_get_param_names();
}

const char **liz_hgp_em_coder_get_param_units(void) {
    return coder_get_param_units();
}

void liz_hgp_em_coder_get_param_values(double **values) {
    coder_get_param_values(values);
}

int liz_hgp_em_coder_set_param_values(double *values) {
    return coder_set_param_values(values);
}

double liz_hgp_em_coder_get_param_value(int index) {
    return coder_get_param_value(index);
}

int liz_hgp_em_coder_set_param_value(int index, double value) {
    return coder_set_param_value(index, value);
}

double liz_hgp_em_coder_dparam_g(double T, double P, int index) {
    return coder_dparam_g(T, P, index);
}

double liz_hgp_em_coder_dparam_dgdt(double T, double P, int index) {
    return coder_dparam_dgdt(T, P, index);
}

double liz_hgp_em_coder_dparam_dgdp(double T, double P, int index) {
    return coder_dparam_dgdp(T, P, index);
}

double liz_hgp_em_coder_dparam_d2gdt2(double T, double P, int index) {
    return coder_dparam_d2gdt2(T, P, index);
}

double liz_hgp_em_coder_dparam_d2gdtdp(double T, double P, int index) {
    return coder_dparam_d2gdtdp(T, P, index);
}

double liz_hgp_em_coder_dparam_d2gdp2(double T, double P, int index) {
    return coder_dparam_d2gdp2(T, P, index);
}

double liz_hgp_em_coder_dparam_d3gdt3(double T, double P, int index) {
    return coder_dparam_d3gdt3(T, P, index);
}

double liz_hgp_em_coder_dparam_d3gdt2dp(double T, double P, int index) {
    return coder_dparam_d3gdt2dp(T, P, index);
}

double liz_hgp_em_coder_dparam_d3gdtdp2(double T, double P, int index) {
    return coder_dparam_d3gdtdp2(T, P, index);
}

double liz_hgp_em_coder_dparam_d3gdp3(double T, double P, int index) {
    return coder_dparam_d3gdp3(T, P, index);
}

