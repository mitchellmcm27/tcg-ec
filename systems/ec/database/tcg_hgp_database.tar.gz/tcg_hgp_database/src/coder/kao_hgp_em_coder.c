
static char *identifier = "kao_hgp_em.emml:3f52df2d9305ab03787d3f4eacc9037670965af5:Mon Nov 21 18:01:00 2022";



#include <math.h>

#include <float.h>
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

static double chebvalat(double x) {
    double c[17] = {
        2.707737068327440945 / 2.0, 0.340068135211091751, -0.12945150184440869e-01, 0.7963755380173816e-03,
        -0.546360009590824e-04, 0.39243019598805e-05, -0.2894032823539e-06, 0.217317613962e-07, -0.16542099950e-08,
        0.1272796189e-09, -0.987963460e-11, 0.7725074e-12, -0.607797e-13, 0.48076e-14, -0.3820e-15, 0.305e-16, -0.24e-17
    };
    double x2 = 2 * x;
    double c0 = c[17-2];
    double c1 = c[17-1];
    for (int i=3; i<18; i++) {
        double tmp = c0;
        c0 = c[17-i] - c1;
        c1 = tmp + c1 * x2;
    }
    return c0 + c1 * x;
}

static double Debye(double x) {
    //
    // returns D_3(x) = 3/x^3\int_0^x t^3/(e^t - 1) dt
    //
    
    double val_infinity = 19.4818182068004875;
    double sqrt_eps = sqrt(DBL_EPSILON);
    double log_eps = log(DBL_EPSILON);
    double xcut = -log_eps;

    //Check for negative x (was returning zero)
    assert(x >= 0.);

    if (x < (2.0*sqrt(2.0)*sqrt_eps)) return 1.0 - 3.0*x/8.0 + x*x/20.0;
    else if (x <= 4.0) {
        double t = x*x/8.0 - 1.0;
        double c = chebvalat(t);
        return c - 0.375*x;
    } else if (x < -(log(2.0)+log_eps)) {
        int nexp = (int)(floor(xcut / x));
        double ex = exp(-x);
        double xk = nexp * x;
        double rk = nexp;
        double sum = 0.0;
        for (int i=nexp; i>0; i--) {
            double xk_inv = 1.0/xk;
            sum *= ex;
            sum += (((6.0*xk_inv + 6.0)*xk_inv + 3.0)*xk_inv + 1.0)/rk;
            rk -= 1.0;
            xk -= x;
        }
        return val_infinity / (x * x * x) - 3.0 * sum * ex;
    } else if (x < xcut) {
        double x3 = x*x*x;
        double sum = 6.0 + 6.0*x + 3.0*x*x + x3;
        return (val_infinity - 3.0*sum*exp(-x))/x3;
    } else return ((val_infinity/x)/x)/x;
}

double born_B(double t, double p);
double born_Q(double t, double p);
double born_N(double t, double p);
double born_U(double t, double p);
double born_Y(double t, double p);
double born_X(double t, double p);
double born_dUdT(double t, double p);
double born_dUdP(double t, double p);
double born_dNdT(double t, double p);
double born_dNdP(double t, double p);
double born_dXdT(double t, double p);
double gSolvent(double t, double p);
double DgSolventDt(double t, double p);
double DgSolventDp(double t, double p);
double D2gSolventDt2(double t, double p);
double D2gSolventDtDp(double t, double p);
double D2gSolventDp2(double t, double p);
double D3gSolventDt3(double t, double p);
double D3gSolventDt2Dp(double t, double p);
double D3gSolventDtDp2(double t, double p);
double D3gSolventDp3(double t, double p);
double D4gSolventDt4(double t, double p);

static double coder_g(double T, double P) {
    double result = 0.0;
    double x0 = pow(T, 1.0);
    double x1 = 577.34210358260395/T;
    double x2 = exp(x1) - 1.0;
    double x3 = ((T)*(T))*exp(-x1);
    double x4 = -1.7911772193131619e-7*pow(x2, 1.0)*x3 + 3.0185762523536612e-8*pow(x2, 2.0)*x3;

    result += -8.009352075488696e-5*P - 10796.4*sqrt(T) + 0.0171475*pow(T, 2.0) - 436.69999999999999*x0*log(T) + 3046.3593629130401*x0 - 2053669.405417219*pow(x4 + 1.0, 0.75728398529074481) + 2053669.405417219*pow(6.3876093992248071e-6*P + x4 + 0.99999361239060081, 0.75728398529074481) - 4171000.5296747433 + 2027950.0/x0;
    return result;
}

static double coder_dgdt(double T, double P) {
    double result = 0.0;
    double x0 = ((T)*(T));
    double x1 = 577.34210358260395/T;
    double x2 = exp(x1) - 1.0;
    double x3 = exp(-x1);
    double x4 = pow(x2, 2.0)*x3;
    double x5 = pow(x2, 1.0);
    double x6 = x3*x5;
    double x7 = 3.0185762523536612e-8*x0*x4 - 1.7911772193131619e-7*x0*x6;
    double x8 = 0.093890456930319333*T*x4 - 0.55713168561954218*T*x6 + 27.103456955241224*x4 - 54.206913910482449*x5 - 160.82778967405423*x6 + 160.82778967405423;

    result += -2027950.0*pow(T, -2.0) - 5398.1999999999998*pow(T, -0.5) + 0.034294999999999999*pow(T, 1.0) - x8*pow(x7 + 1.0, -0.24271601470925519) + x8*pow(6.3876093992248071e-6*P + x7 + 0.99999361239060081, -0.24271601470925519) - 436.69999999999999*log(T) + 2609.6593629130402;
    return result;
}

static double coder_dgdp(double T, double P) {
    double result = 0.0;
    double x0 = 577.34210358260395/T;
    double x1 = exp(x0) - 1.0;
    double x2 = ((T)*(T))*exp(-x0);

    result += 9.9340800935207536*pow(6.3876093992248071e-6*P - 1.7911772193131619e-7*pow(x1, 1.0)*x2 + 3.0185762523536612e-8*pow(x1, 2.0)*x2 + 0.99999361239060081, -0.24271601470925519) - 8.009352075488696e-5;
    return result;
}

static double coder_d2gdt2(double T, double P) {
    double result = 0.0;
    double x0 = 1.0/T;
    double x1 = ((T)*(T));
    double x2 = 577.34210358260395*x0;
    double x3 = exp(x2);
    double x4 = x3 - 1.0;
    double x5 = exp(-x2);
    double x6 = pow(x4, 2.0)*x5;
    double x7 = pow(x4, 1.0);
    double x8 = x5*x7;
    double x9 = 3.0185762523536612e-8*x1*x6 - 1.7911772193131619e-7*x1*x8;
    double x10 = x9 + 1.0;
    double x11 = 1.0/x1;
    double x12 = 0.045213048487760532*x11;
    double x13 = 0.00015662480947500001*x0;
    double x14 = 0.015239031960668002*x11;
    double x15 = 2.7128596460069312e-7*x8;
    double x16 = 4.571838908572763e-8*x6;
    double x17 = 54.206913910482442*x0*x6 - 108.41382782096488*x0*x7 + 15647.966852899526*x11*x6 - 2053669.405417219*x12*x8 + 2053669.405417219*x12 - 2053669.405417219*x13*x8 + 2053669.405417219*x13 + 2053669.405417219*x14*x3 - 2053669.405417219*x14*x7 - 2053669.405417219*x15 + 2053669.405417219*x16;
    double x18 = 6.3876093992248071e-6*P + x9 + 0.99999361239060081;
    double x19 = 2053669.405417219*(T*x15 - T*x16 - 1.3197575463580977e-5*x6 + 2.6395150927161953e-5*x7 + 7.8312404737500003e-5*x8 - 7.8312404737500003e-5)*(-1.4653135961345593e-8*T*x6 + 8.6949479261939245e-8*T*x8 - 4.2299361700025831e-6*x6 + 8.4598723400051662e-6*x7 + 2.5099797631250001e-5*x8 - 2.5099797631250001e-5);

    result += 4055900.0*pow(T, -3.0) + 2699.0999999999999*pow(T, -1.5) - 436.69999999999999*x0 + pow(x10, -1.2427160147092553)*x19 - pow(x10, -0.24271601470925519)*x17 + x17*pow(x18, -0.24271601470925519) - pow(x18, -1.2427160147092553)*x19 + 0.034294999999999999;
    return result;
}

static double coder_d2gdtdp(double T, double P) {
    double result = 0.0;
    double x0 = ((T)*(T));
    double x1 = 577.34210358260395/T;
    double x2 = exp(x1) - 1.0;
    double x3 = pow(x2, 1.0);
    double x4 = exp(-x1);
    double x5 = x3*x4;
    double x6 = pow(x2, 2.0)*x4;

    result += 1.5503750968992251e-6*pow(6.3876093992248071e-6*P - 1.7911772193131619e-7*x0*x5 + 3.0185762523536612e-8*x0*x6 + 0.99999361239060081, -1.2427160147092553)*(0.55713168561954218*T*x5 - 0.093890456930319333*T*x6 + 54.206913910482449*x3 + 160.82778967405423*x5 - 27.103456955241224*x6 - 160.82778967405423);
    return result;
}

static double coder_d2gdp2(double T, double P) {
    double result = 0.0;
    double x0 = 577.34210358260395/T;
    double x1 = exp(x0) - 1.0;
    double x2 = ((T)*(T))*exp(-x0);

    result += -1.5401550387596901e-5*pow(6.3876093992248071e-6*P - 1.7911772193131619e-7*pow(x1, 1.0)*x2 + 3.0185762523536612e-8*pow(x1, 2.0)*x2 + 0.99999361239060081, -1.2427160147092553);
    return result;
}

static double coder_d3gdt3(double T, double P) {
    double result = 0.0;
    double x0 = ((T)*(T));
    double x1 = 1.0/x0;
    double x2 = 1.0/T;
    double x3 = 577.34210358260395*x2;
    double x4 = exp(x3);
    double x5 = x4 - 1.0;
    double x6 = exp(-x3);
    double x7 = pow(x5, 2.0)*x6;
    double x8 = pow(x5, 1.0);
    double x9 = x6*x8;
    double x10 = 3.0185762523536612e-8*x0*x7 - 1.7911772193131619e-7*x0*x9;
    double x11 = x10 + 1.0;
    double x12 = 26.103396523305936*x2;
    double x13 = x2*x8;
    double x14 = x2*x7;
    double x15 = 2053669.405417219*(x12*x9 - x12 + 8.798134768734597*x13 - 4.3990673843672985*x14 + 6.9388939039072284e-18*x4 + 3.4694469519536142e-18*x7 - 6.9388939039072284e-18*x8)/((T)*(T)*(T));
    double x16 = 6.3876093992248071e-6*P + x10 + 0.99999361239060081;
    double x17 = pow(x11, -1.2427160147092553);
    double x18 = 8.6949479261939245e-8*x9;
    double x19 = 1.4653135961345593e-8*x7;
    double x20 = T*x18 - T*x19 - 4.2299361700025831e-6*x7 + 8.4598723400051662e-6*x8 + 2.5099797631250001e-5*x9 - 2.5099797631250001e-5;
    double x21 = 0.045213048487760532*x1;
    double x22 = 0.00015662480947500001*x2;
    double x23 = 0.015239031960668002*x1;
    double x24 = 2.7128596460069312e-7*x9;
    double x25 = 4.571838908572763e-8*x7;
    double x26 = x1*x7;
    double x27 = 4107338.8108344381*x20*(-5.27903018543239e-5*x13 + 2.639515092716195e-5*x14 - x21*x9 + x21 - x22*x9 + x22 + x23*x4 - x23*x8 - x24 + x25 + 0.0076195159803340009*x26);
    double x28 = 0.014491169963923535*x1;
    double x29 = 5.0199595262500002e-5*x2;
    double x30 = 0.0048842404928188688*x1;
    double x31 = 2053669.405417219*T*x24 - 2053669.405417219*T*x25 - 27.103456955241224*x7 + 54.206913910482449*x8 + 160.82778967405423*x9 - 160.82778967405423;
    double x32 = x31*(-1.6919744680010332e-5*x13 + 8.4598723400051662e-6*x14 - x18 + x19 + 0.0024421202464094344*x26 - x28*x9 + x28 - x29*x9 + x29 + x30*x4 - x30*x8);
    double x33 = pow(x16, -1.2427160147092553);
    double x34 = x20*x31*(-7.5024661008418819e-8*T*x7 + 4.4518492312457164e-7*T*x9 - 2.1657447803586146e-5*x7 + 4.3314895607172292e-5*x8 + 0.00012851200000000001*x9 - 0.00012851200000000001);

    result += -12167700.0*pow(T, -4.0) - 4048.6499999999996*pow(T, -2.5) + 436.69999999999999*x1 + pow(x11, -2.2427160147092553)*x34 + pow(x11, -0.24271601470925519)*x15 - x15*pow(x16, -0.24271601470925519) - pow(x16, -2.2427160147092553)*x34 - x17*x27 - x17*x32 + x27*x33 + x32*x33;
    return result;
}

static double coder_d3gdt2dp(double T, double P) {
    double result = 0.0;
    double x0 = ((T)*(T));
    double x1 = 1.0/T;
    double x2 = 577.34210358260395*x1;
    double x3 = exp(x2);
    double x4 = x3 - 1.0;
    double x5 = pow(x4, 1.0);
    double x6 = exp(-x2);
    double x7 = x5*x6;
    double x8 = pow(x4, 2.0)*x6;
    double x9 = 6.3876093992248071e-6*P - 1.7911772193131619e-7*x0*x7 + 3.0185762523536612e-8*x0*x8 + 0.99999361239060081;
    double x10 = 1.0/x0;
    double x11 = 92852.654404959059*x10;
    double x12 = 321.65557934810846*x1;
    double x13 = 31295.933705799052*x10;
    double x14 = T*x7;
    double x15 = T*x8;

    result += 16.301995900366148*pow(x9, -2.2427160147092553)*(8.6949479261939245e-8*x14 - 1.4653135961345593e-8*x15 + 8.4598723400051662e-6*x5 + 2.5099797631250001e-5*x7 - 4.2299361700025831e-6*x8 - 2.5099797631250001e-5)*(2.7128596460069312e-7*x14 - 4.571838908572763e-8*x15 + 2.6395150927161953e-5*x5 + 7.8312404737500003e-5*x7 - 1.3197575463580977e-5*x8 - 7.8312404737500003e-5) - 1.5503750968992251e-6*pow(x9, -1.2427160147092553)*(-108.41382782096488*x1*x5 + 54.206913910482442*x1*x8 + 15647.966852899526*x10*x8 - x11*x7 + x11 - x12*x7 + x12 + x13*x3 - x13*x5 - 0.55713168561954218*x7 + 0.093890456930319333*x8);
    return result;
}

static double coder_d3gdtdp2(double T, double P) {
    double result = 0.0;
    double x0 = ((T)*(T));
    double x1 = 577.34210358260395/T;
    double x2 = exp(x1) - 1.0;
    double x3 = pow(x2, 1.0);
    double x4 = exp(-x1);
    double x5 = x3*x4;
    double x6 = pow(x2, 2.0)*x4;

    result += -1.2306853482362844e-11*pow(6.3876093992248071e-6*P - 1.7911772193131619e-7*x0*x5 + 3.0185762523536612e-8*x0*x6 + 0.99999361239060081, -2.2427160147092553)*(0.55713168561954218*T*x5 - 0.093890456930319333*T*x6 + 54.206913910482449*x3 + 160.82778967405423*x5 - 27.103456955241224*x6 - 160.82778967405423);
    return result;
}

static double coder_d3gdp3(double T, double P) {
    double result = 0.0;
    double x0 = 577.34210358260395/T;
    double x1 = exp(x0) - 1.0;
    double x2 = ((T)*(T))*exp(-x0);

    result += 1.222572681930173e-10*pow(6.3876093992248071e-6*P - 1.7911772193131619e-7*pow(x1, 1.0)*x2 + 3.0185762523536612e-8*pow(x1, 2.0)*x2 + 0.99999361239060081, -2.2427160147092553);
    return result;
}


static double coder_s(double T, double P) {
    double result = -coder_dgdt(T, P);
    return result;
}

static double coder_v(double T, double P) {
    double result = coder_dgdp(T, P);
    return result;
}

static double coder_cv(double T, double P) {
    double result = -T*coder_d2gdt2(T, P);
    double dvdt = coder_d2gdtdp(T, P);
    double dvdp = coder_d2gdp2(T, P);
    result += T*dvdt*dvdt/dvdp;
    return result;
}

static double coder_cp(double T, double P) {
    double result = -T*coder_d2gdt2(T, P);
    return result;
}

static double coder_dcpdt(double T, double P) {
    double result = -T*coder_d3gdt3(T, P) - coder_d2gdt2(T, P);
    return result;
}

static double coder_alpha(double T, double P) {
    double result = coder_d2gdtdp(T, P)/coder_dgdp(T, P);
    return result;
}

static double coder_beta(double T, double P) {
    double result = -coder_d2gdp2(T, P)/coder_dgdp(T, P);
    return result;
}

static double coder_K(double T, double P) {
    double result = -coder_dgdp(T, P)/coder_d2gdp2(T, P);
    return result;
}

static double coder_Kp(double T, double P) {
    double result = coder_dgdp(T, P);
    result *= coder_d3gdp3(T, P);
    result /= pow(coder_d2gdp2(T, P), 2.0);
    return result - 1.0;
}


#include <math.h>

static double coder_dparam_g(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_dgdt(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_dgdp(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d2gdt2(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d2gdtdp(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d2gdp2(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d3gdt3(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d3gdt2dp(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d3gdtdp2(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d3gdp3(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static int coder_get_param_number(void) {
    return 0;
}

static const char *paramNames[0] = {  };

static const char *paramUnits[0] = {  };

static const char **coder_get_param_names(void) {
    return paramNames;
}

static const char **coder_get_param_units(void) {
    return paramUnits;
}

static void coder_get_param_values(double **values) {
}

static int coder_set_param_values(double *values) {
    return 1;
}

static double coder_get_param_value(int index) {
    double result = 0.0;
    switch (index) {
     default:
         break;
    }
    return result;
}

static int coder_set_param_value(int index, double value) {
    int result = 1;
    switch (index) {
     default:
         break;
    }
    return result;
}



const char *kao_hgp_em_coder_calib_identifier(void) {
    return identifier;
}

const char *kao_hgp_em_coder_calib_name(void) {
    return "kao_hgp_em";
}

const char *kao_hgp_em_coder_calib_formula(void) {
    return "Al2H4O9Si2";
}

const double kao_hgp_em_coder_calib_mw(void) {
    return 258.16028;
}

static const double elmformula[106] = {
        0.0,4.0,0.0,0.0,0.0,0.0,
        0.0,0.0,9.0,0.0,0.0,0.0,
        0.0,2.0,2.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0
    };

const double *kao_hgp_em_coder_calib_elements(void) {
    return elmformula;
}

double kao_hgp_em_coder_calib_g(double T, double P) {
    return coder_g(T, P);
}

double kao_hgp_em_coder_calib_dgdt(double T, double P) {
    return coder_dgdt(T, P);
}

double kao_hgp_em_coder_calib_dgdp(double T, double P) {
    return coder_dgdp(T, P);
}

double kao_hgp_em_coder_calib_d2gdt2(double T, double P) {
    return coder_d2gdt2(T, P);
}

double kao_hgp_em_coder_calib_d2gdtdp(double T, double P) {
    return coder_d2gdtdp(T, P);
}

double kao_hgp_em_coder_calib_d2gdp2(double T, double P) {
    return coder_d2gdp2(T, P);
}

double kao_hgp_em_coder_calib_d3gdt3(double T, double P) {
    return coder_d3gdt3(T, P);
}

double kao_hgp_em_coder_calib_d3gdt2dp(double T, double P) {
    return coder_d3gdt2dp(T, P);
}

double kao_hgp_em_coder_calib_d3gdtdp2(double T, double P) {
    return coder_d3gdtdp2(T, P);
}

double kao_hgp_em_coder_calib_d3gdp3(double T, double P) {
    return coder_d3gdp3(T, P);
}

double kao_hgp_em_coder_calib_s(double T, double P) {
    return coder_s(T, P);
}

double kao_hgp_em_coder_calib_v(double T, double P) {
    return coder_v(T, P);
}

double kao_hgp_em_coder_calib_cv(double T, double P) {
    return coder_cv(T, P);
}

double kao_hgp_em_coder_calib_cp(double T, double P) {
    return coder_cp(T, P);
}

double kao_hgp_em_coder_calib_dcpdt(double T, double P) {
    return coder_dcpdt(T, P);
}

double kao_hgp_em_coder_calib_alpha(double T, double P) {
    return coder_alpha(T, P);
}

double kao_hgp_em_coder_calib_beta(double T, double P) {
    return coder_beta(T, P);
}

double kao_hgp_em_coder_calib_K(double T, double P) {
    return coder_K(T, P);
}

double kao_hgp_em_coder_calib_Kp(double T, double P) {
    return coder_Kp(T, P);
}

int kao_hgp_em_coder_get_param_number(void) {
    return coder_get_param_number();
}

const char **kao_hgp_em_coder_get_param_names(void) {
    return coder_get_param_names();
}

const char **kao_hgp_em_coder_get_param_units(void) {
    return coder_get_param_units();
}

void kao_hgp_em_coder_get_param_values(double **values) {
    coder_get_param_values(values);
}

int kao_hgp_em_coder_set_param_values(double *values) {
    return coder_set_param_values(values);
}

double kao_hgp_em_coder_get_param_value(int index) {
    return coder_get_param_value(index);
}

int kao_hgp_em_coder_set_param_value(int index, double value) {
    return coder_set_param_value(index, value);
}

double kao_hgp_em_coder_dparam_g(double T, double P, int index) {
    return coder_dparam_g(T, P, index);
}

double kao_hgp_em_coder_dparam_dgdt(double T, double P, int index) {
    return coder_dparam_dgdt(T, P, index);
}

double kao_hgp_em_coder_dparam_dgdp(double T, double P, int index) {
    return coder_dparam_dgdp(T, P, index);
}

double kao_hgp_em_coder_dparam_d2gdt2(double T, double P, int index) {
    return coder_dparam_d2gdt2(T, P, index);
}

double kao_hgp_em_coder_dparam_d2gdtdp(double T, double P, int index) {
    return coder_dparam_d2gdtdp(T, P, index);
}

double kao_hgp_em_coder_dparam_d2gdp2(double T, double P, int index) {
    return coder_dparam_d2gdp2(T, P, index);
}

double kao_hgp_em_coder_dparam_d3gdt3(double T, double P, int index) {
    return coder_dparam_d3gdt3(T, P, index);
}

double kao_hgp_em_coder_dparam_d3gdt2dp(double T, double P, int index) {
    return coder_dparam_d3gdt2dp(T, P, index);
}

double kao_hgp_em_coder_dparam_d3gdtdp2(double T, double P, int index) {
    return coder_dparam_d3gdtdp2(T, P, index);
}

double kao_hgp_em_coder_dparam_d3gdp3(double T, double P, int index) {
    return coder_dparam_d3gdp3(T, P, index);
}

