
static char *identifier = "cats_hgp_em.emml:34b248fb7151083cfa3e2cbcbe6a64088591829f:Thu Nov 17 19:18:56 2022";



#include <math.h>

#include <float.h>
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

static double chebvalat(double x) {
    double c[17] = {
        2.707737068327440945 / 2.0, 0.340068135211091751, -0.12945150184440869e-01, 0.7963755380173816e-03,
        -0.546360009590824e-04, 0.39243019598805e-05, -0.2894032823539e-06, 0.217317613962e-07, -0.16542099950e-08,
        0.1272796189e-09, -0.987963460e-11, 0.7725074e-12, -0.607797e-13, 0.48076e-14, -0.3820e-15, 0.305e-16, -0.24e-17
    };
    double x2 = 2 * x;
    double c0 = c[17-2];
    double c1 = c[17-1];
    for (int i=3; i<18; i++) {
        double tmp = c0;
        c0 = c[17-i] - c1;
        c1 = tmp + c1 * x2;
    }
    return c0 + c1 * x;
}

static double Debye(double x) {
    //
    // returns D_3(x) = 3/x^3\int_0^x t^3/(e^t - 1) dt
    //
    
    double val_infinity = 19.4818182068004875;
    double sqrt_eps = sqrt(DBL_EPSILON);
    double log_eps = log(DBL_EPSILON);
    double xcut = -log_eps;

    //Check for negative x (was returning zero)
    assert(x >= 0.);

    if (x < (2.0*sqrt(2.0)*sqrt_eps)) return 1.0 - 3.0*x/8.0 + x*x/20.0;
    else if (x <= 4.0) {
        double t = x*x/8.0 - 1.0;
        double c = chebvalat(t);
        return c - 0.375*x;
    } else if (x < -(log(2.0)+log_eps)) {
        int nexp = (int)(floor(xcut / x));
        double ex = exp(-x);
        double xk = nexp * x;
        double rk = nexp;
        double sum = 0.0;
        for (int i=nexp; i>0; i--) {
            double xk_inv = 1.0/xk;
            sum *= ex;
            sum += (((6.0*xk_inv + 6.0)*xk_inv + 3.0)*xk_inv + 1.0)/rk;
            rk -= 1.0;
            xk -= x;
        }
        return val_infinity / (x * x * x) - 3.0 * sum * ex;
    } else if (x < xcut) {
        double x3 = x*x*x;
        double sum = 6.0 + 6.0*x + 3.0*x*x + x3;
        return (val_infinity - 3.0*sum*exp(-x))/x3;
    } else return ((val_infinity/x)/x)/x;
}

double born_B(double t, double p);
double born_Q(double t, double p);
double born_N(double t, double p);
double born_U(double t, double p);
double born_Y(double t, double p);
double born_X(double t, double p);
double born_dUdT(double t, double p);
double born_dUdP(double t, double p);
double born_dNdT(double t, double p);
double born_dNdP(double t, double p);
double born_dXdT(double t, double p);
double gSolvent(double t, double p);
double DgSolventDt(double t, double p);
double DgSolventDp(double t, double p);
double D2gSolventDt2(double t, double p);
double D2gSolventDtDp(double t, double p);
double D2gSolventDp2(double t, double p);
double D3gSolventDt3(double t, double p);
double D3gSolventDt2Dp(double t, double p);
double D3gSolventDtDp2(double t, double p);
double D3gSolventDp3(double t, double p);
double D4gSolventDt4(double t, double p);

static double coder_g(double T, double P) {
    double result = 0.0;
    double x0 = pow(T, 1.0);
    double x1 = 533.40020060180495/T;
    double x2 = exp(x1) - 1.0;
    double x3 = ((T)*(T))*exp(-x1);
    double x4 = -2.0238495620556682e-7*pow(x2, 1.0)*x3 + 4.0609673610421284e-8*pow(x2, 2.0)*x3;

    result += -5.3854977800450678e-5*P - 11030.0*sqrt(T) + 0.0034870000000000001*pow(T, 2.0) - 347.60000000000002*x0*log(T) + 2520.4213067654578*x0 - 1808206.5759400837*pow(x4 + 1.0, 0.80732371976323136) + 1808206.5759400837*pow(4.3540339538766799e-6*P + x4 + 0.99999564596604618, 0.80732371976323136) - 3324124.8657169249 + 890800.0/x0;
    return result;
}

static double coder_dgdt(double T, double P) {
    double result = 0.0;
    double x0 = ((T)*(T));
    double x1 = 533.40020060180495/T;
    double x2 = exp(x1) - 1.0;
    double x3 = exp(-x1);
    double x4 = pow(x2, 2.0)*x3;
    double x5 = pow(x2, 1.0);
    double x6 = x3*x5;
    double x7 = 4.0609673610421284e-8*x0*x4 - 2.0238495620556682e-7*x0*x6;
    double x8 = 0.11856465761875368*T*x4 - 0.59088638017375483*T*x6 + 31.621206079063768*x4 - 63.242412158127536*x5 - 157.5894568587776*x6 + 157.5894568587776;

    result += -890800.0*pow(T, -2.0) - 5515.0*pow(T, -0.5) + 0.0069740000000000002*pow(T, 1.0) - x8*pow(x7 + 1.0, -0.19267628023676864) + x8*pow(4.3540339538766799e-6*P + x7 + 0.99999564596604618, -0.19267628023676864) - 347.60000000000002*log(T) + 2172.8213067654578;
    return result;
}

static double coder_dgdp(double T, double P) {
    double result = 0.0;
    double x0 = 533.40020060180495/T;
    double x1 = exp(x0) - 1.0;
    double x2 = ((T)*(T))*exp(-x0);

    result += 6.3560538549778007*pow(4.3540339538766799e-6*P - 2.0238495620556682e-7*pow(x1, 1.0)*x2 + 4.0609673610421284e-8*pow(x1, 2.0)*x2 + 0.99999564596604618, -0.19267628023676864) - 5.3854977800450678e-5;
    return result;
}

static double coder_d2gdt2(double T, double P) {
    double result = 0.0;
    double x0 = 1.0/T;
    double x1 = ((T)*(T));
    double x2 = 533.40020060180495*x0;
    double x3 = exp(x2);
    double x4 = x3 - 1.0;
    double x5 = exp(-x2);
    double x6 = pow(x4, 2.0)*x5;
    double x7 = pow(x4, 1.0);
    double x8 = x5*x7;
    double x9 = 4.0609673610421284e-8*x1*x6 - 2.0238495620556682e-7*x1*x8;
    double x10 = x9 + 1.0;
    double x11 = 1.0/x1;
    double x12 = 0.04648708229451036*x11;
    double x13 = 0.00017430470495534737*x0;
    double x14 = 0.018655786225171344*x11;
    double x15 = 3.2678035133599374e-7*x8;
    double x16 = 6.5570305515072085e-8*x6;
    double x17 = 63.242412158127536*x0*x6 - 126.48482431625507*x0*x7 + 16866.757665843626*x11*x6 - 1808206.5759400837*x12*x8 + 1808206.5759400837*x12 - 1808206.5759400837*x13*x8 + 1808206.5759400837*x13 + 1808206.5759400837*x14*x3 - 1808206.5759400837*x14*x7 - 1808206.5759400837*x15 + 1808206.5759400837*x16;
    double x18 = 4.3540339538766799e-6*P + x9 + 0.99999564596604618;
    double x19 = 1808206.5759400837*(T*x15 - T*x16 - 1.7487607057630544e-5*x6 + 3.4975214115261088e-5*x7 + 8.7152352477673685e-5*x8 - 8.7152352477673685e-5)*(-1.564904170577048e-8*T*x6 + 7.7989561075139877e-8*T*x8 - 4.1736009925419922e-6*x6 + 8.3472019850839844e-6*x7 + 2.0799823761163166e-5*x8 - 2.0799823761163166e-5);

    result += 1781600.0*pow(T, -3.0) + 2757.5*pow(T, -1.5) - 347.60000000000002*x0 + pow(x10, -1.1926762802367685)*x19 - pow(x10, -0.19267628023676864)*x17 + x17*pow(x18, -0.19267628023676864) - pow(x18, -1.1926762802367685)*x19 + 0.0069740000000000002;
    return result;
}

static double coder_d2gdtdp(double T, double P) {
    double result = 0.0;
    double x0 = ((T)*(T));
    double x1 = 533.40020060180495/T;
    double x2 = exp(x1) - 1.0;
    double x3 = pow(x2, 1.0);
    double x4 = exp(-x1);
    double x5 = x3*x4;
    double x6 = pow(x2, 2.0)*x4;

    result += 8.3891906625754899e-7*pow(4.3540339538766799e-6*P - 2.0238495620556682e-7*x0*x5 + 4.0609673610421284e-8*x0*x6 + 0.99999564596604618, -1.1926762802367685)*(0.59088638017375483*T*x5 - 0.11856465761875368*T*x6 + 63.242412158127536*x3 + 157.5894568587776*x5 - 31.621206079063768*x6 - 157.5894568587776);
    return result;
}

static double coder_d2gdp2(double T, double P) {
    double result = 0.0;
    double x0 = 533.40020060180495/T;
    double x1 = exp(x0) - 1.0;
    double x2 = ((T)*(T))*exp(-x0);

    result += -5.3322147651006712e-6*pow(4.3540339538766799e-6*P - 2.0238495620556682e-7*pow(x1, 1.0)*x2 + 4.0609673610421284e-8*pow(x1, 2.0)*x2 + 0.99999564596604618, -1.1926762802367685);
    return result;
}

static double coder_d3gdt3(double T, double P) {
    double result = 0.0;
    double x0 = ((T)*(T));
    double x1 = 1.0/x0;
    double x2 = 1.0/T;
    double x3 = 533.40020060180495*x2;
    double x4 = exp(-x3);
    double x5 = exp(x3);
    double x6 = x5 - 1.0;
    double x7 = x4*pow(x6, 2.0);
    double x8 = pow(x6, 1.0);
    double x9 = x4*x8;
    double x10 = 4.0609673610421284e-8*x0*x7 - 2.0238495620556682e-7*x0*x9;
    double x11 = x10 + 1.0;
    double x12 = 1808206.5759400837*(-4.9755000574453918*x7 + 9.9510001148907836*x8 + 24.79621902128444*x9 - 24.79621902128444)/((T)*(T)*(T)*(T));
    double x13 = 4.3540339538766799e-6*P + x10 + 0.99999564596604618;
    double x14 = pow(x11, -1.1926762802367685);
    double x15 = 7.7989561075139877e-8*x9;
    double x16 = 1.564904170577048e-8*x7;
    double x17 = T*x15 - T*x16 - 4.1736009925419922e-6*x7 + 8.3472019850839844e-6*x8 + 2.0799823761163166e-5*x9 - 2.0799823761163166e-5;
    double x18 = 0.04648708229451036*x1;
    double x19 = 0.00017430470495534737*x2;
    double x20 = 0.018655786225171344*x1;
    double x21 = x2*x8;
    double x22 = 3.2678035133599374e-7*x9;
    double x23 = 6.5570305515072085e-8*x7;
    double x24 = x1*x7;
    double x25 = x2*x7;
    double x26 = 3616413.1518801674*x17*(-x18*x9 + x18 - x19*x9 + x19 + x20*x5 - x20*x8 - 6.9950428230522175e-5*x21 - x22 + x23 + 0.009327893112585672*x24 + 3.4975214115261088e-5*x25);
    double x27 = 0.011094630166686622*x1;
    double x28 = 4.1599647522326332e-5*x2;
    double x29 = 0.0044523992133075818*x1;
    double x30 = 1808206.5759400837*T*x22 - 1808206.5759400837*T*x23 - 31.621206079063768*x7 + 63.242412158127536*x8 + 157.5894568587776*x9 - 157.5894568587776;
    double x31 = x30*(-x15 + x16 - 1.6694403970167972e-5*x21 + 0.0022261996066537909*x24 + 8.3472019850839861e-6*x25 - x27*x9 + x27 - x28*x9 + x28 + x29*x5 - x29*x8);
    double x32 = pow(x13, -1.1926762802367685);
    double x33 = x17*x30*(-9.6868388926613038e-8*T*x7 + 4.8275947348627347e-7*T*x9 - 2.5834809042714526e-5*x7 + 5.1669618085429053e-5*x8 + 0.00012875200000000002*x9 - 0.00012875200000000002);

    result += -5344800.0*pow(T, -4.0) - 4136.25*pow(T, -2.5) + 347.60000000000002*x1 + pow(x11, -2.1926762802367685)*x33 + pow(x11, -0.19267628023676864)*x12 - x12*pow(x13, -0.19267628023676864) - pow(x13, -2.1926762802367685)*x33 - x14*x26 - x14*x31 + x26*x32 + x31*x32;
    return result;
}

static double coder_d3gdt2dp(double T, double P) {
    double result = 0.0;
    double x0 = ((T)*(T));
    double x1 = 1.0/T;
    double x2 = 533.40020060180495*x1;
    double x3 = exp(x2);
    double x4 = x3 - 1.0;
    double x5 = pow(x4, 1.0);
    double x6 = exp(-x2);
    double x7 = x5*x6;
    double x8 = pow(x4, 2.0)*x6;
    double x9 = 4.3540339538766799e-6*P - 2.0238495620556682e-7*x0*x7 + 4.0609673610421284e-8*x0*x8 + 0.99999564596604618;
    double x10 = 1.0/x0;
    double x11 = 84058.247901201466*x10;
    double x12 = 315.17891371755519*x1;
    double x13 = 33733.515331687253*x10;
    double x14 = T*x7;
    double x15 = T*x8;

    result += 9.3899317995546312*pow(x9, -2.1926762802367685)*(7.7989561075139877e-8*x14 - 1.564904170577048e-8*x15 + 8.3472019850839844e-6*x5 + 2.0799823761163166e-5*x7 - 4.1736009925419922e-6*x8 - 2.0799823761163166e-5)*(3.2678035133599374e-7*x14 - 6.5570305515072085e-8*x15 + 3.4975214115261088e-5*x5 + 8.7152352477673685e-5*x7 - 1.7487607057630544e-5*x8 - 8.7152352477673685e-5) - 8.3891906625754899e-7*pow(x9, -1.1926762802367685)*(-126.48482431625507*x1*x5 + 63.242412158127536*x1*x8 + 16866.757665843626*x10*x8 - x11*x7 + x11 - x12*x7 + x12 + x13*x3 - x13*x5 - 0.59088638017375483*x7 + 0.11856465761875368*x8);
    return result;
}

static double coder_d3gdtdp2(double T, double P) {
    double result = 0.0;
    double x0 = ((T)*(T));
    double x1 = 533.40020060180495/T;
    double x2 = exp(x1) - 1.0;
    double x3 = pow(x2, 1.0);
    double x4 = exp(-x1);
    double x5 = x3*x4;
    double x6 = pow(x2, 2.0)*x4;

    result += -4.3564672987703261e-12*pow(4.3540339538766799e-6*P - 2.0238495620556682e-7*x0*x5 + 4.0609673610421284e-8*x0*x6 + 0.99999564596604618, -2.1926762802367685)*(0.59088638017375483*T*x5 - 0.11856465761875368*T*x6 + 63.242412158127536*x3 + 157.5894568587776*x5 - 31.621206079063768*x6 - 157.5894568587776);
    return result;
}

static double coder_d3gdp3(double T, double P) {
    double result = 0.0;
    double x0 = 533.40020060180495/T;
    double x1 = exp(x0) - 1.0;
    double x2 = ((T)*(T))*exp(-x0);

    result += 2.7689940768433859e-11*pow(4.3540339538766799e-6*P - 2.0238495620556682e-7*pow(x1, 1.0)*x2 + 4.0609673610421284e-8*pow(x1, 2.0)*x2 + 0.99999564596604618, -2.1926762802367685);
    return result;
}


static double coder_s(double T, double P) {
    double result = -coder_dgdt(T, P);
    return result;
}

static double coder_v(double T, double P) {
    double result = coder_dgdp(T, P);
    return result;
}

static double coder_cv(double T, double P) {
    double result = -T*coder_d2gdt2(T, P);
    double dvdt = coder_d2gdtdp(T, P);
    double dvdp = coder_d2gdp2(T, P);
    result += T*dvdt*dvdt/dvdp;
    return result;
}

static double coder_cp(double T, double P) {
    double result = -T*coder_d2gdt2(T, P);
    return result;
}

static double coder_dcpdt(double T, double P) {
    double result = -T*coder_d3gdt3(T, P) - coder_d2gdt2(T, P);
    return result;
}

static double coder_alpha(double T, double P) {
    double result = coder_d2gdtdp(T, P)/coder_dgdp(T, P);
    return result;
}

static double coder_beta(double T, double P) {
    double result = -coder_d2gdp2(T, P)/coder_dgdp(T, P);
    return result;
}

static double coder_K(double T, double P) {
    double result = -coder_dgdp(T, P)/coder_d2gdp2(T, P);
    return result;
}

static double coder_Kp(double T, double P) {
    double result = coder_dgdp(T, P);
    result *= coder_d3gdp3(T, P);
    result /= pow(coder_d2gdp2(T, P), 2.0);
    return result - 1.0;
}


#include <math.h>

static double coder_dparam_g(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_dgdt(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_dgdp(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d2gdt2(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d2gdtdp(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d2gdp2(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d3gdt3(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d3gdt2dp(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d3gdtdp2(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d3gdp3(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static int coder_get_param_number(void) {
    return 0;
}

static const char *paramNames[0] = {  };

static const char *paramUnits[0] = {  };

static const char **coder_get_param_names(void) {
    return paramNames;
}

static const char **coder_get_param_units(void) {
    return paramUnits;
}

static void coder_get_param_values(double **values) {
}

static int coder_set_param_values(double *values) {
    return 1;
}

static double coder_get_param_value(int index) {
    double result = 0.0;
    switch (index) {
     default:
         break;
    }
    return result;
}

static int coder_set_param_value(int index, double value) {
    int result = 1;
    switch (index) {
     default:
         break;
    }
    return result;
}



const char *cats_hgp_em_coder_calib_identifier(void) {
    return identifier;
}

const char *cats_hgp_em_coder_calib_name(void) {
    return "cats_hgp_em";
}

const char *cats_hgp_em_coder_calib_formula(void) {
    return "Al2.0Ca1.0O6.0Si1.0";
}

const double cats_hgp_em_coder_calib_mw(void) {
    return 218.12498;
}

static const double elmformula[106] = {
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,6.0,0.0,0.0,0.0,
        0.0,2.0,1.0,0.0,0.0,0.0,
        0.0,0.0,1.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0
    };

const double *cats_hgp_em_coder_calib_elements(void) {
    return elmformula;
}

double cats_hgp_em_coder_calib_g(double T, double P) {
    return coder_g(T, P);
}

double cats_hgp_em_coder_calib_dgdt(double T, double P) {
    return coder_dgdt(T, P);
}

double cats_hgp_em_coder_calib_dgdp(double T, double P) {
    return coder_dgdp(T, P);
}

double cats_hgp_em_coder_calib_d2gdt2(double T, double P) {
    return coder_d2gdt2(T, P);
}

double cats_hgp_em_coder_calib_d2gdtdp(double T, double P) {
    return coder_d2gdtdp(T, P);
}

double cats_hgp_em_coder_calib_d2gdp2(double T, double P) {
    return coder_d2gdp2(T, P);
}

double cats_hgp_em_coder_calib_d3gdt3(double T, double P) {
    return coder_d3gdt3(T, P);
}

double cats_hgp_em_coder_calib_d3gdt2dp(double T, double P) {
    return coder_d3gdt2dp(T, P);
}

double cats_hgp_em_coder_calib_d3gdtdp2(double T, double P) {
    return coder_d3gdtdp2(T, P);
}

double cats_hgp_em_coder_calib_d3gdp3(double T, double P) {
    return coder_d3gdp3(T, P);
}

double cats_hgp_em_coder_calib_s(double T, double P) {
    return coder_s(T, P);
}

double cats_hgp_em_coder_calib_v(double T, double P) {
    return coder_v(T, P);
}

double cats_hgp_em_coder_calib_cv(double T, double P) {
    return coder_cv(T, P);
}

double cats_hgp_em_coder_calib_cp(double T, double P) {
    return coder_cp(T, P);
}

double cats_hgp_em_coder_calib_dcpdt(double T, double P) {
    return coder_dcpdt(T, P);
}

double cats_hgp_em_coder_calib_alpha(double T, double P) {
    return coder_alpha(T, P);
}

double cats_hgp_em_coder_calib_beta(double T, double P) {
    return coder_beta(T, P);
}

double cats_hgp_em_coder_calib_K(double T, double P) {
    return coder_K(T, P);
}

double cats_hgp_em_coder_calib_Kp(double T, double P) {
    return coder_Kp(T, P);
}

int cats_hgp_em_coder_get_param_number(void) {
    return coder_get_param_number();
}

const char **cats_hgp_em_coder_get_param_names(void) {
    return coder_get_param_names();
}

const char **cats_hgp_em_coder_get_param_units(void) {
    return coder_get_param_units();
}

void cats_hgp_em_coder_get_param_values(double **values) {
    coder_get_param_values(values);
}

int cats_hgp_em_coder_set_param_values(double *values) {
    return coder_set_param_values(values);
}

double cats_hgp_em_coder_get_param_value(int index) {
    return coder_get_param_value(index);
}

int cats_hgp_em_coder_set_param_value(int index, double value) {
    return coder_set_param_value(index, value);
}

double cats_hgp_em_coder_dparam_g(double T, double P, int index) {
    return coder_dparam_g(T, P, index);
}

double cats_hgp_em_coder_dparam_dgdt(double T, double P, int index) {
    return coder_dparam_dgdt(T, P, index);
}

double cats_hgp_em_coder_dparam_dgdp(double T, double P, int index) {
    return coder_dparam_dgdp(T, P, index);
}

double cats_hgp_em_coder_dparam_d2gdt2(double T, double P, int index) {
    return coder_dparam_d2gdt2(T, P, index);
}

double cats_hgp_em_coder_dparam_d2gdtdp(double T, double P, int index) {
    return coder_dparam_d2gdtdp(T, P, index);
}

double cats_hgp_em_coder_dparam_d2gdp2(double T, double P, int index) {
    return coder_dparam_d2gdp2(T, P, index);
}

double cats_hgp_em_coder_dparam_d3gdt3(double T, double P, int index) {
    return coder_dparam_d3gdt3(T, P, index);
}

double cats_hgp_em_coder_dparam_d3gdt2dp(double T, double P, int index) {
    return coder_dparam_d3gdt2dp(T, P, index);
}

double cats_hgp_em_coder_dparam_d3gdtdp2(double T, double P, int index) {
    return coder_dparam_d3gdtdp2(T, P, index);
}

double cats_hgp_em_coder_dparam_d3gdp3(double T, double P, int index) {
    return coder_dparam_d3gdp3(T, P, index);
}

