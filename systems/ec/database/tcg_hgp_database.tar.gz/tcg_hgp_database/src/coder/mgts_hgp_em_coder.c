
static char *identifier = "mgts_hgp_em.emml:c67f57f8afd42cbcadbf4bfda63a145d95d4e59b:Thu Nov 17 19:21:22 2022";



#include <math.h>

#include <float.h>
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

static double chebvalat(double x) {
    double c[17] = {
        2.707737068327440945 / 2.0, 0.340068135211091751, -0.12945150184440869e-01, 0.7963755380173816e-03,
        -0.546360009590824e-04, 0.39243019598805e-05, -0.2894032823539e-06, 0.217317613962e-07, -0.16542099950e-08,
        0.1272796189e-09, -0.987963460e-11, 0.7725074e-12, -0.607797e-13, 0.48076e-14, -0.3820e-15, 0.305e-16, -0.24e-17
    };
    double x2 = 2 * x;
    double c0 = c[17-2];
    double c1 = c[17-1];
    for (int i=3; i<18; i++) {
        double tmp = c0;
        c0 = c[17-i] - c1;
        c1 = tmp + c1 * x2;
    }
    return c0 + c1 * x;
}

static double Debye(double x) {
    //
    // returns D_3(x) = 3/x^3\int_0^x t^3/(e^t - 1) dt
    //
    
    double val_infinity = 19.4818182068004875;
    double sqrt_eps = sqrt(DBL_EPSILON);
    double log_eps = log(DBL_EPSILON);
    double xcut = -log_eps;

    //Check for negative x (was returning zero)
    assert(x >= 0.);

    if (x < (2.0*sqrt(2.0)*sqrt_eps)) return 1.0 - 3.0*x/8.0 + x*x/20.0;
    else if (x <= 4.0) {
        double t = x*x/8.0 - 1.0;
        double c = chebvalat(t);
        return c - 0.375*x;
    } else if (x < -(log(2.0)+log_eps)) {
        int nexp = (int)(floor(xcut / x));
        double ex = exp(-x);
        double xk = nexp * x;
        double rk = nexp;
        double sum = 0.0;
        for (int i=nexp; i>0; i--) {
            double xk_inv = 1.0/xk;
            sum *= ex;
            sum += (((6.0*xk_inv + 6.0)*xk_inv + 3.0)*xk_inv + 1.0)/rk;
            rk -= 1.0;
            xk -= x;
        }
        return val_infinity / (x * x * x) - 3.0 * sum * ex;
    } else if (x < xcut) {
        double x3 = x*x*x;
        double sum = 6.0 + 6.0*x + 3.0*x*x + x3;
        return (val_infinity - 3.0*sum*exp(-x))/x3;
    } else return ((val_infinity/x)/x)/x;
}

double born_B(double t, double p);
double born_Q(double t, double p);
double born_N(double t, double p);
double born_U(double t, double p);
double born_Y(double t, double p);
double born_X(double t, double p);
double born_dUdT(double t, double p);
double born_dUdP(double t, double p);
double born_dNdT(double t, double p);
double born_dNdP(double t, double p);
double born_dXdT(double t, double p);
double gSolvent(double t, double p);
double DgSolventDt(double t, double p);
double DgSolventDp(double t, double p);
double D2gSolventDt2(double t, double p);
double D2gSolventDtDp(double t, double p);
double D2gSolventDp2(double t, double p);
double D3gSolventDt3(double t, double p);
double D3gSolventDt2Dp(double t, double p);
double D3gSolventDtDp2(double t, double p);
double D3gSolventDp3(double t, double p);
double D4gSolventDt4(double t, double p);

static double coder_g(double T, double P) {
    double result = 0.0;
    double x0 = pow(T, 1.0);
    double x1 = 551.37376879212002/T;
    double x2 = exp(x1) - 1.0;
    double x3 = ((T)*(T))*exp(-x1);
    double x4 = -3.3649622883587245e-7*pow(x2, 1.0)*x3 + 6.2832188451161005e-8*pow(x2, 2.0)*x3;

    result += -5.405390702561963e-5*P - 14188.4*sqrt(T) + 0.0020409999999999998*pow(T, 2.0) - 371.39999999999998*x0*log(T) + 2770.8638400225859*x0 - 823766.99968289433*pow(x4 + 1.0, 0.8830421028543598) + 823766.99968289433*pow(8.317129313667569e-6*P + x4 + 0.99999168287068629, 0.8830421028543598) - 3190052.02116002 + 199200.0/x0;
    return result;
}

static double coder_dgdt(double T, double P) {
    double result = 0.0;
    double x0 = ((T)*(T));
    double x1 = 551.37376879212002/T;
    double x2 = exp(x1) - 1.0;
    double x3 = exp(-x1);
    double x4 = pow(x2, 2.0)*x3;
    double x5 = pow(x2, 1.0);
    double x6 = x3*x5;
    double x7 = 6.2832188451161005e-8*x0*x4 - 3.3649622883587245e-7*x0*x6;
    double x8 = 0.091410899630985532*T*x4 - 0.48954880863699585*T*x6 + 25.200786119107356*x4 - 50.401572238214712*x5 - 134.96218581293635*x6 + 134.96218581293635;

    result += -199200.0*pow(T, -2.0) - 7094.1999999999998*pow(T, -0.5) + 0.0040819999999999997*pow(T, 1.0) - x8*pow(x7 + 1.0, -0.1169578971456402) + x8*pow(8.317129313667569e-6*P + x7 + 0.99999168287068629, -0.1169578971456402) - 371.39999999999998*log(T) + 2399.4638400225858;
    return result;
}

static double coder_dgdp(double T, double P) {
    double result = 0.0;
    double x0 = 551.37376879212002/T;
    double x1 = exp(x0) - 1.0;
    double x2 = ((T)*(T))*exp(-x0);

    result += 6.0500540539070267*pow(8.317129313667569e-6*P - 3.3649622883587245e-7*pow(x1, 1.0)*x2 + 6.2832188451161005e-8*pow(x1, 2.0)*x2 + 0.99999168287068629, -0.1169578971456402) - 5.405390702561963e-5;
    return result;
}

static double coder_d2gdt2(double T, double P) {
    double result = 0.0;
    double x0 = 1.0/T;
    double x1 = ((T)*(T));
    double x2 = 551.37376879212002*x0;
    double x3 = exp(x2);
    double x4 = x3 - 1.0;
    double x5 = exp(-x2);
    double x6 = pow(x4, 2.0)*x5;
    double x7 = pow(x4, 1.0);
    double x8 = x5*x7;
    double x9 = 6.2832188451161005e-8*x1*x6 - 3.3649622883587245e-7*x1*x8;
    double x10 = x9 + 1.0;
    double x11 = 1.0/x1;
    double x12 = 0.090334535208070624*x11;
    double x13 = 0.00032767077551028269*x0;
    double x14 = 0.033735394654957555*x11;
    double x15 = 5.9428067502758136e-7*x8;
    double x16 = 1.1096693563370927e-7*x6;
    double x17 = 50.401572238214712*x0*x6 - 100.80314447642942*x0*x7 + 13895.052419016367*x11*x6 - 823766.99968289433*x12*x8 + 823766.99968289433*x12 - 823766.99968289433*x13*x8 + 823766.99968289433*x13 + 823766.99968289433*x14*x3 - 823766.99968289433*x14*x7 - 823766.99968289433*x15 + 823766.99968289433*x16;
    double x18 = 8.317129313667569e-6*P + x9 + 0.99999168287068629;
    double x19 = 823766.99968289433*(T*x15 - T*x16 - 3.0592128755835442e-5*x6 + 6.1184257511670884e-5*x7 + 0.00016383538775514132*x8 - 0.00016383538775514132)*(-1.4697441268612742e-8*T*x6 + 7.8711782644163554e-8*T*x8 - 4.0518917919379226e-6*x6 + 8.1037835838758453e-6*x7 + 2.169980612242932e-5*x8 - 2.169980612242932e-5);

    result += 398400.0*pow(T, -3.0) + 3547.0999999999999*pow(T, -1.5) - 371.39999999999998*x0 + pow(x10, -1.1169578971456402)*x19 - pow(x10, -0.1169578971456402)*x17 + x17*pow(x18, -0.1169578971456402) - pow(x18, -1.1169578971456402)*x19 + 0.0040819999999999997;
    return result;
}

static double coder_d2gdtdp(double T, double P) {
    double result = 0.0;
    double x0 = ((T)*(T));
    double x1 = 551.37376879212002/T;
    double x2 = exp(x1) - 1.0;
    double x3 = pow(x2, 1.0);
    double x4 = exp(-x1);
    double x5 = x3*x4;
    double x6 = pow(x2, 2.0)*x4;

    result += 9.7275395481492052e-7*pow(8.317129313667569e-6*P - 3.3649622883587245e-7*x0*x5 + 6.2832188451161005e-8*x0*x6 + 0.99999168287068629, -1.1169578971456402)*(0.48954880863699585*T*x5 - 0.091410899630985532*T*x6 + 50.401572238214712*x3 + 134.96218581293635*x5 - 25.200786119107356*x6 - 134.96218581293635);
    return result;
}

static double coder_d2gdp2(double T, double P) {
    double result = 0.0;
    double x0 = 551.37376879212002/T;
    double x1 = exp(x0) - 1.0;
    double x2 = ((T)*(T))*exp(-x0);

    result += -5.8852140077821025e-6*pow(8.317129313667569e-6*P - 3.3649622883587245e-7*pow(x1, 1.0)*x2 + 6.2832188451161005e-8*pow(x1, 2.0)*x2 + 0.99999168287068629, -1.1169578971456402);
    return result;
}

static double coder_d3gdt3(double T, double P) {
    double result = 0.0;
    double x0 = ((T)*(T));
    double x1 = 1.0/x0;
    double x2 = 1.0/T;
    double x3 = 551.37376879212002*x2;
    double x4 = exp(-x3);
    double x5 = exp(x3);
    double x6 = x5 - 1.0;
    double x7 = x4*pow(x6, 2.0);
    double x8 = pow(x6, 1.0);
    double x9 = x4*x8;
    double x10 = 6.2832188451161005e-8*x0*x7 - 3.3649622883587245e-7*x0*x9;
    double x11 = x10 + 1.0;
    double x12 = 49.808093129758355*x2;
    double x13 = x2*x8;
    double x14 = x2*x7;
    double x15 = 823766.99968289433*(x12*x9 - x12 + 18.600811692593489*x13 - 9.3004058462967443*x14 + 2.7755575615628914e-17*x9 - 2.7755575615628914e-17)/((T)*(T)*(T));
    double x16 = 8.317129313667569e-6*P + x10 + 0.99999168287068629;
    double x17 = pow(x11, -1.1169578971456402);
    double x18 = 7.8711782644163554e-8*x9;
    double x19 = 1.4697441268612742e-8*x7;
    double x20 = T*x18 - T*x19 - 4.0518917919379226e-6*x7 + 8.1037835838758453e-6*x8 + 2.169980612242932e-5*x9 - 2.169980612242932e-5;
    double x21 = 0.090334535208070624*x1;
    double x22 = 0.00032767077551028269*x2;
    double x23 = 0.033735394654957555*x1;
    double x24 = 5.9428067502758136e-7*x9;
    double x25 = 1.1096693563370927e-7*x7;
    double x26 = x1*x7;
    double x27 = 1647533.9993657887*x20*(-0.00012236851502334177*x13 + 6.1184257511670884e-5*x14 - x21*x9 + x21 - x22*x9 + x22 + x23*x5 - x23*x8 - x24 + x25 + 0.016867697327478778*x26);
    double x28 = 0.011964703883782174*x1;
    double x29 = 4.3399612244858641e-5*x2;
    double x30 = 0.0044682136961173378*x1;
    double x31 = 823766.99968289433*T*x24 - 823766.99968289433*T*x25 - 25.200786119107356*x7 + 50.401572238214712*x8 + 134.96218581293635*x9 - 134.96218581293635;
    double x32 = x31*(-1.6207567167751691e-5*x13 + 8.1037835838758453e-6*x14 - x18 + x19 + 0.0022341068480586689*x26 - x28*x9 + x28 - x29*x9 + x29 + x30*x5 - x30*x8);
    double x33 = pow(x16, -1.1169578971456402);
    double x34 = x20*x31*(-1.4036181817093474e-7*T*x7 + 7.5170424031590842e-7*T*x9 - 3.8695912339711287e-5*x7 + 7.7391824679422575e-5*x8 + 0.00020723499999999998*x9 - 0.00020723499999999998);

    result += -1195200.0*pow(T, -4.0) - 5320.6499999999996*pow(T, -2.5) + 371.39999999999998*x1 + pow(x11, -2.1169578971456402)*x34 + pow(x11, -0.1169578971456402)*x15 - x15*pow(x16, -0.1169578971456402) - pow(x16, -2.1169578971456402)*x34 - x17*x27 - x17*x32 + x27*x33 + x32*x33;
    return result;
}

static double coder_d3gdt2dp(double T, double P) {
    double result = 0.0;
    double x0 = ((T)*(T));
    double x1 = 1.0/T;
    double x2 = 551.37376879212002*x1;
    double x3 = exp(x2);
    double x4 = x3 - 1.0;
    double x5 = pow(x4, 1.0);
    double x6 = exp(-x2);
    double x7 = x5*x6;
    double x8 = pow(x4, 2.0)*x6;
    double x9 = 8.317129313667569e-6*P - 3.3649622883587245e-7*x0*x7 + 6.2832188451161005e-8*x0*x8 + 0.99999168287068629;
    double x10 = 1.0/x0;
    double x11 = 74414.609036101116*x10;
    double x12 = 269.92437162587277*x1;
    double x13 = 27790.104838032734*x10;
    double x14 = T*x7;
    double x15 = T*x8;

    result += 7.6526992674821397*pow(x9, -2.1169578971456402)*(7.8711782644163554e-8*x14 - 1.4697441268612742e-8*x15 + 8.1037835838758453e-6*x5 + 2.169980612242932e-5*x7 - 4.0518917919379226e-6*x8 - 2.169980612242932e-5)*(5.9428067502758136e-7*x14 - 1.1096693563370927e-7*x15 + 6.1184257511670884e-5*x5 + 0.00016383538775514132*x7 - 3.0592128755835442e-5*x8 - 0.00016383538775514132) - 9.7275395481492052e-7*pow(x9, -1.1169578971456402)*(-100.80314447642942*x1*x5 + 50.401572238214712*x1*x8 + 13895.052419016367*x10*x8 - x11*x7 + x11 - x12*x7 + x12 + x13*x3 - x13*x5 - 0.48954880863699585*x7 + 0.091410899630985532*x8);
    return result;
}

static double coder_d3gdtdp2(double T, double P) {
    double result = 0.0;
    double x0 = ((T)*(T));
    double x1 = 551.37376879212002/T;
    double x2 = exp(x1) - 1.0;
    double x3 = pow(x2, 1.0);
    double x4 = exp(-x1);
    double x5 = x3*x4;
    double x6 = pow(x2, 2.0)*x4;

    result += -9.0367706891853006e-12*pow(8.317129313667569e-6*P - 3.3649622883587245e-7*x0*x5 + 6.2832188451161005e-8*x0*x6 + 0.99999168287068629, -2.1169578971456402)*(0.48954880863699585*T*x5 - 0.091410899630985532*T*x6 + 50.401572238214712*x3 + 134.96218581293635*x5 - 25.200786119107356*x6 - 134.96218581293635);
    return result;
}

static double coder_d3gdp3(double T, double P) {
    double result = 0.0;
    double x0 = 551.37376879212002/T;
    double x1 = exp(x0) - 1.0;
    double x2 = ((T)*(T))*exp(-x0);

    result += 5.4672951142333725e-11*pow(8.317129313667569e-6*P - 3.3649622883587245e-7*pow(x1, 1.0)*x2 + 6.2832188451161005e-8*pow(x1, 2.0)*x2 + 0.99999168287068629, -2.1169578971456402);
    return result;
}


static double coder_s(double T, double P) {
    double result = -coder_dgdt(T, P);
    return result;
}

static double coder_v(double T, double P) {
    double result = coder_dgdp(T, P);
    return result;
}

static double coder_cv(double T, double P) {
    double result = -T*coder_d2gdt2(T, P);
    double dvdt = coder_d2gdtdp(T, P);
    double dvdp = coder_d2gdp2(T, P);
    result += T*dvdt*dvdt/dvdp;
    return result;
}

static double coder_cp(double T, double P) {
    double result = -T*coder_d2gdt2(T, P);
    return result;
}

static double coder_dcpdt(double T, double P) {
    double result = -T*coder_d3gdt3(T, P) - coder_d2gdt2(T, P);
    return result;
}

static double coder_alpha(double T, double P) {
    double result = coder_d2gdtdp(T, P)/coder_dgdp(T, P);
    return result;
}

static double coder_beta(double T, double P) {
    double result = -coder_d2gdp2(T, P)/coder_dgdp(T, P);
    return result;
}

static double coder_K(double T, double P) {
    double result = -coder_dgdp(T, P)/coder_d2gdp2(T, P);
    return result;
}

static double coder_Kp(double T, double P) {
    double result = coder_dgdp(T, P);
    result *= coder_d3gdp3(T, P);
    result /= pow(coder_d2gdp2(T, P), 2.0);
    return result - 1.0;
}


#include <math.h>

static double coder_dparam_g(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_dgdt(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_dgdp(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d2gdt2(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d2gdtdp(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d2gdp2(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d3gdt3(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d3gdt2dp(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d3gdtdp2(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d3gdp3(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static int coder_get_param_number(void) {
    return 0;
}

static const char *paramNames[0] = {  };

static const char *paramUnits[0] = {  };

static const char **coder_get_param_names(void) {
    return paramNames;
}

static const char **coder_get_param_units(void) {
    return paramUnits;
}

static void coder_get_param_values(double **values) {
}

static int coder_set_param_values(double *values) {
    return 1;
}

static double coder_get_param_value(int index) {
    double result = 0.0;
    switch (index) {
     default:
         break;
    }
    return result;
}

static int coder_set_param_value(int index, double value) {
    int result = 1;
    switch (index) {
     default:
         break;
    }
    return result;
}



const char *mgts_hgp_em_coder_calib_identifier(void) {
    return identifier;
}

const char *mgts_hgp_em_coder_calib_name(void) {
    return "mgts_hgp_em";
}

const char *mgts_hgp_em_coder_calib_formula(void) {
    return "Al2.0Mg1.0O6.0Si1.0";
}

const double mgts_hgp_em_coder_calib_mw(void) {
    return 202.34998;
}

static const double elmformula[106] = {
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,6.0,0.0,0.0,0.0,
        1.0,2.0,1.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0
    };

const double *mgts_hgp_em_coder_calib_elements(void) {
    return elmformula;
}

double mgts_hgp_em_coder_calib_g(double T, double P) {
    return coder_g(T, P);
}

double mgts_hgp_em_coder_calib_dgdt(double T, double P) {
    return coder_dgdt(T, P);
}

double mgts_hgp_em_coder_calib_dgdp(double T, double P) {
    return coder_dgdp(T, P);
}

double mgts_hgp_em_coder_calib_d2gdt2(double T, double P) {
    return coder_d2gdt2(T, P);
}

double mgts_hgp_em_coder_calib_d2gdtdp(double T, double P) {
    return coder_d2gdtdp(T, P);
}

double mgts_hgp_em_coder_calib_d2gdp2(double T, double P) {
    return coder_d2gdp2(T, P);
}

double mgts_hgp_em_coder_calib_d3gdt3(double T, double P) {
    return coder_d3gdt3(T, P);
}

double mgts_hgp_em_coder_calib_d3gdt2dp(double T, double P) {
    return coder_d3gdt2dp(T, P);
}

double mgts_hgp_em_coder_calib_d3gdtdp2(double T, double P) {
    return coder_d3gdtdp2(T, P);
}

double mgts_hgp_em_coder_calib_d3gdp3(double T, double P) {
    return coder_d3gdp3(T, P);
}

double mgts_hgp_em_coder_calib_s(double T, double P) {
    return coder_s(T, P);
}

double mgts_hgp_em_coder_calib_v(double T, double P) {
    return coder_v(T, P);
}

double mgts_hgp_em_coder_calib_cv(double T, double P) {
    return coder_cv(T, P);
}

double mgts_hgp_em_coder_calib_cp(double T, double P) {
    return coder_cp(T, P);
}

double mgts_hgp_em_coder_calib_dcpdt(double T, double P) {
    return coder_dcpdt(T, P);
}

double mgts_hgp_em_coder_calib_alpha(double T, double P) {
    return coder_alpha(T, P);
}

double mgts_hgp_em_coder_calib_beta(double T, double P) {
    return coder_beta(T, P);
}

double mgts_hgp_em_coder_calib_K(double T, double P) {
    return coder_K(T, P);
}

double mgts_hgp_em_coder_calib_Kp(double T, double P) {
    return coder_Kp(T, P);
}

int mgts_hgp_em_coder_get_param_number(void) {
    return coder_get_param_number();
}

const char **mgts_hgp_em_coder_get_param_names(void) {
    return coder_get_param_names();
}

const char **mgts_hgp_em_coder_get_param_units(void) {
    return coder_get_param_units();
}

void mgts_hgp_em_coder_get_param_values(double **values) {
    coder_get_param_values(values);
}

int mgts_hgp_em_coder_set_param_values(double *values) {
    return coder_set_param_values(values);
}

double mgts_hgp_em_coder_get_param_value(int index) {
    return coder_get_param_value(index);
}

int mgts_hgp_em_coder_set_param_value(int index, double value) {
    return coder_set_param_value(index, value);
}

double mgts_hgp_em_coder_dparam_g(double T, double P, int index) {
    return coder_dparam_g(T, P, index);
}

double mgts_hgp_em_coder_dparam_dgdt(double T, double P, int index) {
    return coder_dparam_dgdt(T, P, index);
}

double mgts_hgp_em_coder_dparam_dgdp(double T, double P, int index) {
    return coder_dparam_dgdp(T, P, index);
}

double mgts_hgp_em_coder_dparam_d2gdt2(double T, double P, int index) {
    return coder_dparam_d2gdt2(T, P, index);
}

double mgts_hgp_em_coder_dparam_d2gdtdp(double T, double P, int index) {
    return coder_dparam_d2gdtdp(T, P, index);
}

double mgts_hgp_em_coder_dparam_d2gdp2(double T, double P, int index) {
    return coder_dparam_d2gdp2(T, P, index);
}

double mgts_hgp_em_coder_dparam_d3gdt3(double T, double P, int index) {
    return coder_dparam_d3gdt3(T, P, index);
}

double mgts_hgp_em_coder_dparam_d3gdt2dp(double T, double P, int index) {
    return coder_dparam_d3gdt2dp(T, P, index);
}

double mgts_hgp_em_coder_dparam_d3gdtdp2(double T, double P, int index) {
    return coder_dparam_d3gdtdp2(T, P, index);
}

double mgts_hgp_em_coder_dparam_d3gdp3(double T, double P, int index) {
    return coder_dparam_d3gdp3(T, P, index);
}

