
static char *identifier = "and_hgp_em.emml:d86e68b570085f93cfa9b277962f7d76ca6f6b89:Mon Nov 21 17:58:57 2022";



#include <math.h>

#include <float.h>
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

static double chebvalat(double x) {
    double c[17] = {
        2.707737068327440945 / 2.0, 0.340068135211091751, -0.12945150184440869e-01, 0.7963755380173816e-03,
        -0.546360009590824e-04, 0.39243019598805e-05, -0.2894032823539e-06, 0.217317613962e-07, -0.16542099950e-08,
        0.1272796189e-09, -0.987963460e-11, 0.7725074e-12, -0.607797e-13, 0.48076e-14, -0.3820e-15, 0.305e-16, -0.24e-17
    };
    double x2 = 2 * x;
    double c0 = c[17-2];
    double c1 = c[17-1];
    for (int i=3; i<18; i++) {
        double tmp = c0;
        c0 = c[17-i] - c1;
        c1 = tmp + c1 * x2;
    }
    return c0 + c1 * x;
}

static double Debye(double x) {
    //
    // returns D_3(x) = 3/x^3\int_0^x t^3/(e^t - 1) dt
    //
    
    double val_infinity = 19.4818182068004875;
    double sqrt_eps = sqrt(DBL_EPSILON);
    double log_eps = log(DBL_EPSILON);
    double xcut = -log_eps;

    //Check for negative x (was returning zero)
    assert(x >= 0.);

    if (x < (2.0*sqrt(2.0)*sqrt_eps)) return 1.0 - 3.0*x/8.0 + x*x/20.0;
    else if (x <= 4.0) {
        double t = x*x/8.0 - 1.0;
        double c = chebvalat(t);
        return c - 0.375*x;
    } else if (x < -(log(2.0)+log_eps)) {
        int nexp = (int)(floor(xcut / x));
        double ex = exp(-x);
        double xk = nexp * x;
        double rk = nexp;
        double sum = 0.0;
        for (int i=nexp; i>0; i--) {
            double xk_inv = 1.0/xk;
            sum *= ex;
            sum += (((6.0*xk_inv + 6.0)*xk_inv + 3.0)*xk_inv + 1.0)/rk;
            rk -= 1.0;
            xk -= x;
        }
        return val_infinity / (x * x * x) - 3.0 * sum * ex;
    } else if (x < xcut) {
        double x3 = x*x*x;
        double sum = 6.0 + 6.0*x + 3.0*x*x + x3;
        return (val_infinity - 3.0*sum*exp(-x))/x3;
    } else return ((val_infinity/x)/x)/x;
}

double born_B(double t, double p);
double born_Q(double t, double p);
double born_N(double t, double p);
double born_U(double t, double p);
double born_Y(double t, double p);
double born_X(double t, double p);
double born_dUdT(double t, double p);
double born_dUdP(double t, double p);
double born_dNdT(double t, double p);
double born_dNdP(double t, double p);
double born_dXdT(double t, double p);
double gSolvent(double t, double p);
double DgSolventDt(double t, double p);
double DgSolventDp(double t, double p);
double D2gSolventDt2(double t, double p);
double D2gSolventDtDp(double t, double p);
double D2gSolventDp2(double t, double p);
double D3gSolventDt3(double t, double p);
double D3gSolventDt2Dp(double t, double p);
double D3gSolventDtDp2(double t, double p);
double D3gSolventDp3(double t, double p);
double D4gSolventDt4(double t, double p);

static double coder_g(double T, double P) {
    double result = 0.0;
    double x0 = pow(T, 1.0);
    double x1 = 589.98751906809002/T;
    double x2 = exp(x1) - 1.0;
    double x3 = ((T)*(T))*exp(-x1);
    double x4 = -2.1137592703904997e-7*pow(x2, 1.0)*x3 + 3.3905545433833173e-8*pow(x2, 2.0)*x3;

    result += -4.5205725849464692e-5*P - 9062.3999999999996*sqrt(T) + 0.0032940000000000001*pow(T, 2.0) - 277.30000000000001*x0*log(T) + 2035.764951925652*x0 - 1261573.6930448955*pow(x4 + 1.0, 0.85486357704655735) + 1261573.6930448955*pow(4.7780920753284144e-6*P + x4 + 0.99999522190792467, 0.85486357704655735) - 2599163.7791885734 + 957050.0/x0;
    return result;
}

static double coder_dgdt(double T, double P) {
    double result = 0.0;
    double x0 = ((T)*(T));
    double x1 = 589.98751906809002/T;
    double x2 = exp(x1) - 1.0;
    double x3 = exp(-x1);
    double x4 = pow(x2, 2.0)*x3;
    double x5 = pow(x2, 1.0);
    double x6 = x3*x5;
    double x7 = 3.3905545433833173e-8*x0*x4 - 2.1137592703904997e-7*x0*x6;
    double x8 = 0.073132457721976879*T*x4 - 0.45592662940032058*T*x6 + 21.573618647370559*x4 - 43.147237294741117*x5 - 134.49551047848584*x6 + 134.49551047848584;

    result += -957050.0*pow(T, -2.0) - 4531.1999999999998*pow(T, -0.5) + 0.0065880000000000001*pow(T, 1.0) - x8*pow(x7 + 1.0, -0.14513642295344265) + x8*pow(4.7780920753284144e-6*P + x7 + 0.99999522190792467, -0.14513642295344265) - 277.30000000000001*log(T) + 1758.464951925652;
    return result;
}

static double coder_dgdp(double T, double P) {
    double result = 0.0;
    double x0 = 589.98751906809002/T;
    double x1 = exp(x0) - 1.0;
    double x2 = ((T)*(T))*exp(-x0);

    result += 5.1530452057258493*pow(4.7780920753284144e-6*P - 2.1137592703904997e-7*pow(x1, 1.0)*x2 + 3.3905545433833173e-8*pow(x1, 2.0)*x2 + 0.99999522190792467, -0.14513642295344265) - 4.5205725849464692e-5;
    return result;
}

static double coder_d2gdt2(double T, double P) {
    double result = 0.0;
    double x0 = 1.0/T;
    double x1 = ((T)*(T));
    double x2 = 589.98751906809002*x0;
    double x3 = exp(x2);
    double x4 = x3 - 1.0;
    double x5 = exp(-x2);
    double x6 = pow(x4, 2.0)*x5;
    double x7 = pow(x4, 1.0);
    double x8 = x5*x7;
    double x9 = 3.3905545433833173e-8*x1*x6 - 2.1137592703904997e-7*x1*x8;
    double x10 = x9 + 1.0;
    double x11 = 1.0/x1;
    double x12 = 0.062898166782060769*x11;
    double x13 = 0.00021321863513794678*x0;
    double x14 = 0.02017823582285222*x11;
    double x15 = 3.6139516218026875e-7*x8;
    double x16 = 5.7969231702562391e-8*x6;
    double x17 = 43.147237294741117*x0*x6 - 86.294474589482235*x0*x7 + 12728.16574308324*x11*x6 - 1261573.6930448955*x12*x8 + 1261573.6930448955*x12 - 1261573.6930448955*x13*x8 + 1261573.6930448955*x13 + 1261573.6930448955*x14*x3 - 1261573.6930448955*x14*x7 - 1261573.6930448955*x15 + 1261573.6930448955*x16;
    double x18 = 4.7780920753284144e-6*P + x9 + 0.99999522190792467;
    double x19 = 1261573.6930448955*(T*x15 - T*x16 - 1.7100561597239028e-5*x6 + 3.4201123194478056e-5*x7 + 0.00010660931756897341*x8 - 0.00010660931756897341)*(-9.8418591651039543e-9*T*x6 + 6.1356691897831183e-8*T*x8 - 2.903287035918613e-6*x6 + 5.8065740718372261e-6*x7 + 1.8099841215513298e-5*x8 - 1.8099841215513298e-5);

    result += 1914100.0*pow(T, -3.0) + 2265.5999999999999*pow(T, -1.5) - 277.30000000000001*x0 + pow(x10, -1.1451364229534426)*x19 - pow(x10, -0.14513642295344265)*x17 + x17*pow(x18, -0.14513642295344265) - pow(x18, -1.1451364229534426)*x19 + 0.0065880000000000001;
    return result;
}

static double coder_d2gdtdp(double T, double P) {
    double result = 0.0;
    double x0 = ((T)*(T));
    double x1 = 589.98751906809002/T;
    double x2 = exp(x1) - 1.0;
    double x3 = pow(x2, 1.0);
    double x4 = exp(-x1);
    double x5 = x3*x4;
    double x6 = pow(x2, 2.0)*x4;

    result += 6.9347519235535723e-7*pow(4.7780920753284144e-6*P - 2.1137592703904997e-7*x0*x5 + 3.3905545433833173e-8*x0*x6 + 0.99999522190792467, -1.1451364229534426)*(0.45592662940032058*T*x5 - 0.073132457721976879*T*x6 + 43.147237294741117*x3 + 134.49551047848584*x5 - 21.573618647370559*x6 - 134.49551047848584);
    return result;
}

static double coder_d2gdp2(double T, double P) {
    double result = 0.0;
    double x0 = 589.98751906809002/T;
    double x1 = exp(x0) - 1.0;
    double x2 = ((T)*(T))*exp(-x0);

    result += -3.5735090152565849e-6*pow(4.7780920753284144e-6*P - 2.1137592703904997e-7*pow(x1, 1.0)*x2 + 3.3905545433833173e-8*pow(x1, 2.0)*x2 + 0.99999522190792467, -1.1451364229534426);
    return result;
}

static double coder_d3gdt3(double T, double P) {
    double result = 0.0;
    double x0 = ((T)*(T));
    double x1 = 1.0/x0;
    double x2 = 1.0/T;
    double x3 = 589.98751906809002*x2;
    double x4 = exp(-x3);
    double x5 = exp(x3);
    double x6 = x5 - 1.0;
    double x7 = x4*pow(x6, 2.0);
    double x8 = pow(x6, 1.0);
    double x9 = x4*x8;
    double x10 = 3.3905545433833173e-8*x0*x7 - 2.1137592703904997e-7*x0*x9;
    double x11 = x10 + 1.0;
    double x12 = 37.109133373678986*x2;
    double x13 = x2*x8;
    double x14 = x2*x7;
    double x15 = 1261573.6930448955*(-x12*x9 + x12 - 11.904907292295441*x13 + 5.9524536461477204*x14 + 2.7755575615628914e-17*x9 - 2.7755575615628914e-17)/((T)*(T)*(T));
    double x16 = 4.7780920753284144e-6*P + x10 + 0.99999522190792467;
    double x17 = pow(x11, -1.1451364229534426);
    double x18 = 6.1356691897831183e-8*x9;
    double x19 = 9.8418591651039543e-9*x7;
    double x20 = T*x18 - T*x19 - 2.903287035918613e-6*x7 + 5.8065740718372261e-6*x8 + 1.8099841215513298e-5*x9 - 1.8099841215513298e-5;
    double x21 = 0.062898166782060769*x1;
    double x22 = 0.00021321863513794678*x2;
    double x23 = 0.02017823582285222*x1;
    double x24 = 3.6139516218026875e-7*x9;
    double x25 = 5.7969231702562391e-8*x7;
    double x26 = x1*x7;
    double x27 = 2523147.3860897911*x20*(-6.8402246388956113e-5*x13 + 3.4201123194478056e-5*x14 - x21*x9 + x21 - x22*x9 + x22 + x23*x5 - x23*x8 - x24 + x25 + 0.01008911791142611*x26);
    double x28 = 0.010678680414267054*x1;
    double x29 = 3.6199682431026602e-5*x2;
    double x30 = 0.0034258062309283424*x1;
    double x31 = 1261573.6930448955*T*x24 - 1261573.6930448955*T*x25 - 21.573618647370559*x7 + 43.147237294741117*x8 + 134.49551047848584*x9 - 134.49551047848584;
    double x32 = x31*(-1.1613148143674452e-5*x13 + 5.8065740718372261e-6*x14 - x18 + x19 + 0.0017129031154641712*x26 - x28*x9 + x28 - x29*x9 + x29 + x30*x5 - x30*x8);
    double x33 = pow(x16, -1.1451364229534426);
    double x34 = x20*x31*(-7.7652950032770306e-8*T*x7 + 4.8410854597593106e-7*T*x9 - 2.2907135669076253e-5*x7 + 4.5814271338152507e-5*x8 + 0.00014280900000000001*x9 - 0.00014280900000000001);

    result += -5742300.0*pow(T, -4.0) - 3398.3999999999996*pow(T, -2.5) + 277.30000000000001*x1 + pow(x11, -2.1451364229534429)*x34 - pow(x11, -0.14513642295344265)*x15 + x15*pow(x16, -0.14513642295344265) - pow(x16, -2.1451364229534429)*x34 - x17*x27 - x17*x32 + x27*x33 + x32*x33;
    return result;
}

static double coder_d3gdt2dp(double T, double P) {
    double result = 0.0;
    double x0 = ((T)*(T));
    double x1 = 1.0/T;
    double x2 = 589.98751906809002*x1;
    double x3 = exp(x2);
    double x4 = x3 - 1.0;
    double x5 = pow(x4, 1.0);
    double x6 = exp(-x2);
    double x7 = x5*x6;
    double x8 = pow(x4, 2.0)*x6;
    double x9 = 4.7780920753284144e-6*P - 2.1137592703904997e-7*x0*x7 + 3.3905545433833173e-8*x0*x8 + 0.99999522190792467;
    double x10 = 1.0/x0;
    double x11 = 79350.672552998178*x10;
    double x12 = 268.99102095697168*x1;
    double x13 = 25456.33148616648*x10;
    double x14 = T*x7;
    double x15 = T*x8;

    result += 6.9027853246353841*pow(x9, -2.1451364229534429)*(6.1356691897831183e-8*x14 - 9.8418591651039543e-9*x15 + 5.8065740718372261e-6*x5 + 1.8099841215513298e-5*x7 - 2.903287035918613e-6*x8 - 1.8099841215513298e-5)*(3.6139516218026875e-7*x14 - 5.7969231702562391e-8*x15 + 3.4201123194478056e-5*x5 + 0.00010660931756897341*x7 - 1.7100561597239028e-5*x8 - 0.00010660931756897341) - 6.9347519235535723e-7*pow(x9, -1.1451364229534426)*(-86.294474589482235*x1*x5 + 43.147237294741117*x1*x8 + 12728.16574308324*x10*x8 - x11*x7 + x11 - x12*x7 + x12 + x13*x3 - x13*x5 - 0.45592662940032058*x7 + 0.073132457721976879*x8);
    return result;
}

static double coder_d3gdtdp2(double T, double P) {
    double result = 0.0;
    double x0 = ((T)*(T));
    double x1 = 589.98751906809002/T;
    double x2 = exp(x1) - 1.0;
    double x3 = pow(x2, 1.0);
    double x4 = exp(-x1);
    double x5 = x3*x4;
    double x6 = pow(x2, 2.0)*x4;

    result += -3.7943961634422798e-12*pow(4.7780920753284144e-6*P - 2.1137592703904997e-7*x0*x5 + 3.3905545433833173e-8*x0*x6 + 0.99999522190792467, -2.1451364229534429)*(0.45592662940032058*T*x5 - 0.073132457721976879*T*x6 + 43.147237294741117*x3 + 134.49551047848584*x5 - 21.573618647370559*x6 - 134.49551047848584);
    return result;
}

static double coder_d3gdp3(double T, double P) {
    double result = 0.0;
    double x0 = 589.98751906809002/T;
    double x1 = exp(x0) - 1.0;
    double x2 = ((T)*(T))*exp(-x0);

    result += 1.9552694958650797e-11*pow(4.7780920753284144e-6*P - 2.1137592703904997e-7*pow(x1, 1.0)*x2 + 3.3905545433833173e-8*pow(x1, 2.0)*x2 + 0.99999522190792467, -2.1451364229534429);
    return result;
}


static double coder_s(double T, double P) {
    double result = -coder_dgdt(T, P);
    return result;
}

static double coder_v(double T, double P) {
    double result = coder_dgdp(T, P);
    return result;
}

static double coder_cv(double T, double P) {
    double result = -T*coder_d2gdt2(T, P);
    double dvdt = coder_d2gdtdp(T, P);
    double dvdp = coder_d2gdp2(T, P);
    result += T*dvdt*dvdt/dvdp;
    return result;
}

static double coder_cp(double T, double P) {
    double result = -T*coder_d2gdt2(T, P);
    return result;
}

static double coder_dcpdt(double T, double P) {
    double result = -T*coder_d3gdt3(T, P) - coder_d2gdt2(T, P);
    return result;
}

static double coder_alpha(double T, double P) {
    double result = coder_d2gdtdp(T, P)/coder_dgdp(T, P);
    return result;
}

static double coder_beta(double T, double P) {
    double result = -coder_d2gdp2(T, P)/coder_dgdp(T, P);
    return result;
}

static double coder_K(double T, double P) {
    double result = -coder_dgdp(T, P)/coder_d2gdp2(T, P);
    return result;
}

static double coder_Kp(double T, double P) {
    double result = coder_dgdp(T, P);
    result *= coder_d3gdp3(T, P);
    result /= pow(coder_d2gdp2(T, P), 2.0);
    return result - 1.0;
}


#include <math.h>

static double coder_dparam_g(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_dgdt(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_dgdp(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d2gdt2(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d2gdtdp(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d2gdp2(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d3gdt3(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d3gdt2dp(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d3gdtdp2(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d3gdp3(double T, double P, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static int coder_get_param_number(void) {
    return 0;
}

static const char *paramNames[0] = {  };

static const char *paramUnits[0] = {  };

static const char **coder_get_param_names(void) {
    return paramNames;
}

static const char **coder_get_param_units(void) {
    return paramUnits;
}

static void coder_get_param_values(double **values) {
}

static int coder_set_param_values(double *values) {
    return 1;
}

static double coder_get_param_value(int index) {
    double result = 0.0;
    switch (index) {
     default:
         break;
    }
    return result;
}

static int coder_set_param_value(int index, double value) {
    int result = 1;
    switch (index) {
     default:
         break;
    }
    return result;
}



const char *and_hgp_em_coder_calib_identifier(void) {
    return identifier;
}

const char *and_hgp_em_coder_calib_name(void) {
    return "and_hgp_em";
}

const char *and_hgp_em_coder_calib_formula(void) {
    return "Al2O5Si";
}

const double and_hgp_em_coder_calib_mw(void) {
    return 162.04558;
}

static const double elmformula[106] = {
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,5.0,0.0,0.0,0.0,
        0.0,2.0,1.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0
    };

const double *and_hgp_em_coder_calib_elements(void) {
    return elmformula;
}

double and_hgp_em_coder_calib_g(double T, double P) {
    return coder_g(T, P);
}

double and_hgp_em_coder_calib_dgdt(double T, double P) {
    return coder_dgdt(T, P);
}

double and_hgp_em_coder_calib_dgdp(double T, double P) {
    return coder_dgdp(T, P);
}

double and_hgp_em_coder_calib_d2gdt2(double T, double P) {
    return coder_d2gdt2(T, P);
}

double and_hgp_em_coder_calib_d2gdtdp(double T, double P) {
    return coder_d2gdtdp(T, P);
}

double and_hgp_em_coder_calib_d2gdp2(double T, double P) {
    return coder_d2gdp2(T, P);
}

double and_hgp_em_coder_calib_d3gdt3(double T, double P) {
    return coder_d3gdt3(T, P);
}

double and_hgp_em_coder_calib_d3gdt2dp(double T, double P) {
    return coder_d3gdt2dp(T, P);
}

double and_hgp_em_coder_calib_d3gdtdp2(double T, double P) {
    return coder_d3gdtdp2(T, P);
}

double and_hgp_em_coder_calib_d3gdp3(double T, double P) {
    return coder_d3gdp3(T, P);
}

double and_hgp_em_coder_calib_s(double T, double P) {
    return coder_s(T, P);
}

double and_hgp_em_coder_calib_v(double T, double P) {
    return coder_v(T, P);
}

double and_hgp_em_coder_calib_cv(double T, double P) {
    return coder_cv(T, P);
}

double and_hgp_em_coder_calib_cp(double T, double P) {
    return coder_cp(T, P);
}

double and_hgp_em_coder_calib_dcpdt(double T, double P) {
    return coder_dcpdt(T, P);
}

double and_hgp_em_coder_calib_alpha(double T, double P) {
    return coder_alpha(T, P);
}

double and_hgp_em_coder_calib_beta(double T, double P) {
    return coder_beta(T, P);
}

double and_hgp_em_coder_calib_K(double T, double P) {
    return coder_K(T, P);
}

double and_hgp_em_coder_calib_Kp(double T, double P) {
    return coder_Kp(T, P);
}

int and_hgp_em_coder_get_param_number(void) {
    return coder_get_param_number();
}

const char **and_hgp_em_coder_get_param_names(void) {
    return coder_get_param_names();
}

const char **and_hgp_em_coder_get_param_units(void) {
    return coder_get_param_units();
}

void and_hgp_em_coder_get_param_values(double **values) {
    coder_get_param_values(values);
}

int and_hgp_em_coder_set_param_values(double *values) {
    return coder_set_param_values(values);
}

double and_hgp_em_coder_get_param_value(int index) {
    return coder_get_param_value(index);
}

int and_hgp_em_coder_set_param_value(int index, double value) {
    return coder_set_param_value(index, value);
}

double and_hgp_em_coder_dparam_g(double T, double P, int index) {
    return coder_dparam_g(T, P, index);
}

double and_hgp_em_coder_dparam_dgdt(double T, double P, int index) {
    return coder_dparam_dgdt(T, P, index);
}

double and_hgp_em_coder_dparam_dgdp(double T, double P, int index) {
    return coder_dparam_dgdp(T, P, index);
}

double and_hgp_em_coder_dparam_d2gdt2(double T, double P, int index) {
    return coder_dparam_d2gdt2(T, P, index);
}

double and_hgp_em_coder_dparam_d2gdtdp(double T, double P, int index) {
    return coder_dparam_d2gdtdp(T, P, index);
}

double and_hgp_em_coder_dparam_d2gdp2(double T, double P, int index) {
    return coder_dparam_d2gdp2(T, P, index);
}

double and_hgp_em_coder_dparam_d3gdt3(double T, double P, int index) {
    return coder_dparam_d3gdt3(T, P, index);
}

double and_hgp_em_coder_dparam_d3gdt2dp(double T, double P, int index) {
    return coder_dparam_d3gdt2dp(T, P, index);
}

double and_hgp_em_coder_dparam_d3gdtdp2(double T, double P, int index) {
    return coder_dparam_d3gdtdp2(T, P, index);
}

double and_hgp_em_coder_dparam_d3gdp3(double T, double P, int index) {
    return coder_dparam_d3gdp3(T, P, index);
}

