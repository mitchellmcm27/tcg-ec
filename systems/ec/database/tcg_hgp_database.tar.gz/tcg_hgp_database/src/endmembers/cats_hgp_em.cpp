#include "endmembers/cats_hgp_em.h"
#include "tcgversion.h"

//-----------------------------------------------------------------------------
cats_hgp_em::cats_hgp_em()
{
  // Do Nothing
}
//-----------------------------------------------------------------------------
cats_hgp_em::~cats_hgp_em()
{
  // Do nothing
}
//-----------------------------------------------------------------------------
std::string cats_hgp_em::identifier()
{
    std::string _str(cats_hgp_em_coder_calib_identifier());
    return _str;
}
//-----------------------------------------------------------------------------
std::string cats_hgp_em::name()
{
    std::string _str(cats_hgp_em_coder_calib_name());
    return _str;
}
//-----------------------------------------------------------------------------
std::string cats_hgp_em::tcg_build_version()
{
    return TCG_VERSION;
}
//-----------------------------------------------------------------------------
std::string cats_hgp_em::tcg_build_git_sha()
{
    return TCG_GIT_SHA;
}
//-----------------------------------------------------------------------------
std::string cats_hgp_em::tcg_generation_version()
{
    return "0.6.9";
}
//-----------------------------------------------------------------------------
std::string cats_hgp_em::tcg_generation_git_sha()
{
    return "56dfef7059e95dd8cdde839c4942089d910bdcbd Fri Aug 19 17:22:58 2022 -0400";
}
//-----------------------------------------------------------------------------
std::string cats_hgp_em::formula()
{
    std::string _str(cats_hgp_em_coder_calib_formula());
    return _str;
}
//-----------------------------------------------------------------------------
double cats_hgp_em::molecular_weight()
{
    return cats_hgp_em_coder_calib_mw();
}
//-----------------------------------------------------------------------------
std::vector<double> cats_hgp_em::elements()
{
  std::vector<double> _elements;
  const double *el = cats_hgp_em_coder_calib_elements();
  _elements.assign(el, el + 106);
  return _elements;
}
//-----------------------------------------------------------------------------
double cats_hgp_em::G(const double &T, const double &P)
{
  return cats_hgp_em_coder_calib_g(T,P);
}
//-----------------------------------------------------------------------------
double cats_hgp_em::dGdT(const double &T, const double &P)
{
  return cats_hgp_em_coder_calib_dgdt(T,P);
}
//-----------------------------------------------------------------------------
double cats_hgp_em::dGdP(const double &T, const double &P)
{
  return cats_hgp_em_coder_calib_dgdp(T,P);
}
//-----------------------------------------------------------------------------
double cats_hgp_em::d2GdT2(const double &T, const double &P)
{
  return cats_hgp_em_coder_calib_d2gdt2(T,P);
}
//-----------------------------------------------------------------------------
double cats_hgp_em::d2GdTdP(const double &T, const double &P)
{
  return cats_hgp_em_coder_calib_d2gdtdp(T,P);
}
//-----------------------------------------------------------------------------
double cats_hgp_em::d2GdP2(const double &T, const double &P)
{
  return cats_hgp_em_coder_calib_d2gdp2(T,P);
}
//-----------------------------------------------------------------------------
double cats_hgp_em::d3GdT3(const double &T, const double &P)
{
  return cats_hgp_em_coder_calib_d3gdt3(T,P);
}
//-----------------------------------------------------------------------------
double cats_hgp_em::d3GdT2dP(const double &T, const double &P)
{
  return cats_hgp_em_coder_calib_d3gdt2dp(T,P);
}
//-----------------------------------------------------------------------------
double cats_hgp_em::d3GdTdP2(const double &T, const double &P)
{
  return cats_hgp_em_coder_calib_d3gdtdp2(T,P);
}
//-----------------------------------------------------------------------------
double cats_hgp_em::d3GdP3(const double &T, const double &P)
{
  return cats_hgp_em_coder_calib_d3gdp3(T,P);
}
//**************************************************************************
// Convenience functions of T and P
//**************************************************************************

//-----------------------------------------------------------------------------
double cats_hgp_em::S(const double& T, const double& P)
{
  return cats_hgp_em_coder_calib_s(T,P);
}
//-----------------------------------------------------------------------------
double cats_hgp_em::V(const double& T, const double& P)
{
  return cats_hgp_em_coder_calib_v(T,P);
}
//-----------------------------------------------------------------------------
double cats_hgp_em::dVdT(const double& T, const double& P)
{
  return cats_hgp_em_coder_calib_d2gdtdp(T,P);
}
//-----------------------------------------------------------------------------
double cats_hgp_em::dVdP(const double& T, const double& P)
{
  return cats_hgp_em_coder_calib_d2gdp2(T,P);
}
//-----------------------------------------------------------------------------
double cats_hgp_em::Cv(const double& T, const double& P)
{
  return cats_hgp_em_coder_calib_cv(T,P);
}
//-----------------------------------------------------------------------------
double cats_hgp_em::Cp(const double& T, const double& P)
{
  return cats_hgp_em_coder_calib_cp(T,P);
}
//-----------------------------------------------------------------------------
double cats_hgp_em::dCpdT(const double& T, const double& P)
{
  return cats_hgp_em_coder_calib_dcpdt(T,P);
}
//-----------------------------------------------------------------------------
double cats_hgp_em::alpha(const double& T, const double& P)
{
  return cats_hgp_em_coder_calib_alpha(T,P);
}
//-----------------------------------------------------------------------------
double cats_hgp_em::beta(const double& T, const double& P)
{
  return cats_hgp_em_coder_calib_beta(T,P);
}
//-----------------------------------------------------------------------------
double cats_hgp_em::K(const double& T, const double& P)
{
  return cats_hgp_em_coder_calib_K(T,P);
}
//-----------------------------------------------------------------------------
double cats_hgp_em::Kp(const double& T, const double& P)
{
  return cats_hgp_em_coder_calib_Kp(T,P);
}
//**************************************************************************
// Active parameter functions directly from coder
//**************************************************************************

//-----------------------------------------------------------------------------
int cats_hgp_em::get_param_number()
{
   return cats_hgp_em_coder_get_param_number();
}
//-----------------------------------------------------------------------------
std::vector<std::string> cats_hgp_em::get_param_names()
{
  std::vector<std::string> _param_names;
  const char **p = cats_hgp_em_coder_get_param_names();
  _param_names.assign(p, p + cats_hgp_em_coder_get_param_number());
  return _param_names;
}
//-----------------------------------------------------------------------------
std::vector<std::string> cats_hgp_em::get_param_units()
{
  std::vector<std::string> _param_units;
  const char **p = cats_hgp_em_coder_get_param_units();
  _param_units.assign(p, p + cats_hgp_em_coder_get_param_number());
  return _param_units;
}
//-----------------------------------------------------------------------------
std::vector<double> cats_hgp_em::get_param_values()
{
  std::vector<double> values(cats_hgp_em_coder_get_param_number());
  double* v = values.data();
  double** v_ptr = &v;
  cats_hgp_em_coder_get_param_values(v_ptr);
  return values;
}
//-----------------------------------------------------------------------------
void cats_hgp_em::get_param_values(std::vector<double>& values)
{
  double* v = values.data();
  double** v_ptr = &v;
  cats_hgp_em_coder_get_param_values(v_ptr);
}
//-----------------------------------------------------------------------------
int cats_hgp_em::set_param_values(std::vector<double>& values)
{
  cats_hgp_em_coder_set_param_values(values.data());
  return 1;
}
//-----------------------------------------------------------------------------
double cats_hgp_em::get_param_value(int& index)
{
  return cats_hgp_em_coder_get_param_value(index);
}
//-----------------------------------------------------------------------------
int cats_hgp_em::set_param_value(int& index, double& value)
{
  return cats_hgp_em_coder_set_param_value(index,value);
}
//-----------------------------------------------------------------------------
double cats_hgp_em::dparam_g(double& T, double& P, int& index)
{
  return cats_hgp_em_coder_dparam_g(T,P,index);
}
//-----------------------------------------------------------------------------
double cats_hgp_em::dparam_dgdt(double& T, double& P, int& index)
{
  return cats_hgp_em_coder_dparam_dgdt(T,P,index);
}
//-----------------------------------------------------------------------------
double cats_hgp_em::dparam_dgdp(double& T, double& P, int& index)
{
  return cats_hgp_em_coder_dparam_dgdp(T,P,index);
}
//-----------------------------------------------------------------------------
double cats_hgp_em::dparam_d2gdt2(double& T, double& P, int& index)
{
  return cats_hgp_em_coder_dparam_d2gdt2(T,P,index);
}
//-----------------------------------------------------------------------------
double cats_hgp_em::dparam_d2gdtdp(double& T, double& P, int& index)
{
  return cats_hgp_em_coder_dparam_d2gdtdp(T,P,index);
}
//-----------------------------------------------------------------------------
double cats_hgp_em::dparam_d2gdp2(double& T, double& P, int& index)
{
  return cats_hgp_em_coder_dparam_d2gdp2(T,P,index);
}
//-----------------------------------------------------------------------------
double cats_hgp_em::dparam_d3gdt3(double& T, double& P, int& index)
{
  return cats_hgp_em_coder_dparam_d3gdt3(T,P,index);
}
//-----------------------------------------------------------------------------
double cats_hgp_em::dparam_d3gdt2dp(double& T, double& P, int& index)
{
  return cats_hgp_em_coder_dparam_d3gdt2dp(T,P,index);
}
//-----------------------------------------------------------------------------
double cats_hgp_em::dparam_d3gdtdp2(double& T, double& P, int& index)
{
  return cats_hgp_em_coder_dparam_d3gdtdp2(T,P,index);
}
//-----------------------------------------------------------------------------
double cats_hgp_em::dparam_d3gdp3(double& T, double& P, int& index)
{
  return cats_hgp_em_coder_dparam_d3gdp3(T,P,index);
}
//-----------------------------------------------------------------------------
