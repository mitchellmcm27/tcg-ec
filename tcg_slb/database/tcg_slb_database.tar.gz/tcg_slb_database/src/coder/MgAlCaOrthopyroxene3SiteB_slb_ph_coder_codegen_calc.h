#include <math.h>


static double coder_g(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = n1 + n3;
    double x1 = n2 + x0;
    double x2 = 1.0/x1;
    double x3 = n1 + n2;

result = 1.0*x2*(48000.0*n2*n3 + 1.0*x1*(8.3144626181532395*T*(1.0*n2*log(n2*x2) + 2.0*n3*log(n3*x2) + 1.0*x0*log(x0*x2) + 2.0*x3*log(x2*x3)) + n1*(*endmember[0].mu0)(T, P) + n2*(*endmember[1].mu0)(T, P) + n3*(*endmember[2].mu0)(T, P)));
    return result;
}
        
static void coder_dgdn(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = n1 + n3;
    double x1 = n2 + x0;
    double x2 = pow(x1, -2);
    double x3 = 48000.0*n3;
    double x4 = (*endmember[0].mu0)(T, P);
    double x5 = (*endmember[1].mu0)(T, P);
    double x6 = (*endmember[2].mu0)(T, P);
    double x7 = 1.0/x1;
    double x8 = log(n2*x7);
    double x9 = 1.0*n2;
    double x10 = n3*x7;
    double x11 = 2.0*log(x10);
    double x12 = n1 + n2;
    double x13 = 2.0*log(x12*x7);
    double x14 = 1.0*log(x0*x7);
    double x15 = 8.3144626181532395*T;
    double x16 = x15*(n3*x11 + x0*x14 + x12*x13 + x8*x9);
    double x17 = 1.0*x1;
    double x18 = -1.0*x2*(n2*x3 + x17*(n1*x4 + n2*x5 + n3*x6 + x16));
    double x19 = 1.0*n1;
    double x20 = 1.0*n3;
    double x21 = x19 + x20;
    double x22 = x21 + x9;
    double x23 = 2.0*n1 + 2.0*n2;
    double x24 = x1*x23*(-x12*x2 + x7)/x12 - 2.0*x10 + x13;
    double x25 = x14 - x7*x9 + x1*x21*(-x0*x2 + x7)/x0;
    double x26 = x16 + x19*x4 + x20*x6 + x5*x9;
    double x27 = 1.0*x7;

result[0] = x18 + x27*(x22*(x15*(x24 + x25) + x4) + x26);
result[1] = x18 + x27*(x22*(x15*(x17*(-n2*x2 + x7) - x21*x7 + x24 + 1.0*x8) + x5) + x26 + x3);
result[2] = x18 + x27*(48000.0*n2 + x22*(x15*(2.0*x1*(-n3*x2 + x7) + x11 - x23*x7 + x25) + x6) + x26);
}
        
static void coder_d2gdn2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = n1 + n3;
    double x1 = n2 + x0;
    double x2 = pow(x1, -3);
    double x3 = 48000.0*n3;
    double x4 = (*endmember[0].mu0)(T, P);
    double x5 = (*endmember[1].mu0)(T, P);
    double x6 = (*endmember[2].mu0)(T, P);
    double x7 = 1.0/x1;
    double x8 = log(n2*x7);
    double x9 = 1.0*n2;
    double x10 = n3*x7;
    double x11 = 2.0*log(x10);
    double x12 = n1 + n2;
    double x13 = 2.0*log(x12*x7);
    double x14 = 1.0*log(x0*x7);
    double x15 = 8.3144626181532395*T;
    double x16 = x15*(n3*x11 + x0*x14 + x12*x13 + x8*x9);
    double x17 = 1.0*x1;
    double x18 = 2.0*x2*(n2*x3 + x17*(n1*x4 + n2*x5 + n3*x6 + x16));
    double x19 = 1.0*n1;
    double x20 = 1.0*n3;
    double x21 = x19 + x20;
    double x22 = x21 + x9;
    double x23 = 2.0*n1;
    double x24 = 2.0*n2;
    double x25 = x23 + x24;
    double x26 = 1.0/x12;
    double x27 = pow(x1, -2);
    double x28 = -x12*x27 + x7;
    double x29 = x26*x28;
    double x30 = x25*x29;
    double x31 = x1*x30 - 2.0*x10 + x13;
    double x32 = 1.0/x0;
    double x33 = -x0*x27 + x7;
    double x34 = x32*x33;
    double x35 = x21*x34;
    double x36 = x1*x35 + x14 - x7*x9;
    double x37 = T*(x31 + x36);
    double x38 = 8.3144626181532395*x37;
    double x39 = x16 + x19*x4 + x20*x6 + x5*x9;
    double x40 = x22*(x38 + x4) + x39;
    double x41 = 2.0*x27;
    double x42 = x27*x9;
    double x43 = x35 + x42;
    double x44 = -2*x27;
    double x45 = 2*x2;
    double x46 = x1*x25;
    double x47 = x26*x46;
    double x48 = n3*x27;
    double x49 = 2.0*x48;
    double x50 = x30 + x49;
    double x51 = 4.0*x1*x29 + x47*(x12*x45 + x44) + x50 - x28*x46/((x12)*(x12));
    double x52 = x43 + x51;
    double x53 = 2.0*x1;
    double x54 = x1*x21;
    double x55 = x32*x54;
    double x56 = x34*x53 + x55*(x0*x45 + x44) - x33*x54/((x0)*(x0));
    double x57 = x15*x22;
    double x58 = 1.0*x7;
    double x59 = 2.0*x7;
    double x60 = -x27;
    double x61 = -n1;
    double x62 = x38 + 1.0*x4;
    double x63 = x17*(-n2*x27 + x7);
    double x64 = -x21*x7 + x31 + x63 + 1.0*x8;
    double x65 = x15*x64;
    double x66 = 1.0*x5 + x65;
    double x67 = x22*(x5 + x65) + x3 + x39;
    double x68 = 1.0*x27;
    double x69 = -x67*x68;
    double x70 = x18 - x40*x68;
    double x71 = x47*(-x45*(-n2 + x61) + x60) + x50;
    double x72 = x43 + x56;
    double x73 = x53*(-x48 + x7);
    double x74 = x11 - x25*x7 + x36 + x73;
    double x75 = x15*x74;
    double x76 = 1.0*x6 + x75;
    double x77 = 48000.0*n2 + x22*(x6 + x75) + x39;
    double x78 = -x68*x77;
    double x79 = 16.628925236306479*T;
    double x80 = -x42;
    double x81 = x2*x24;

result[0] = x18 - x40*x41 + x58*(16.628925236306479*x37 + 2.0*x4 + x57*(x52 + x56));
result[1] = x58*(x57*(x52 + x55*(-x45*(-n3 + x61) + x60) - x59) + x62 + x66) + x69 + x70;
result[2] = x58*(x57*(-4.0*x7 + x71 + x72) + x62 + x76) + x70 + x78;
result[3] = x18 - x41*x67 + x58*(2.0*x5 + x57*(x1*(-x41 + x81) - x27*(-x19 - x20) + x51 + x58 + x80 + x63/n2) + x64*x79);
result[4] = x18 + x58*(x57*(x1*(-x68 + x81) + x21*x27 - 5.0*x7 + x71 + x80) + x66 + x76 + 48000.0) + x69 + x78;
result[5] = x18 - x41*x77 + x58*(x57*(x1*(4.0*n3*x2 - 4.0*x27) - x27*(-x23 - x24) - x49 + x59 + x72 + x73/n3) + 2.0*x6 + x74*x79);
}
        
static void coder_d3gdn3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = 48000.0*n3;
    double x1 = (*endmember[0].mu0)(T, P);
    double x2 = (*endmember[1].mu0)(T, P);
    double x3 = (*endmember[2].mu0)(T, P);
    double x4 = n1 + n2;
    double x5 = n3 + x4;
    double x6 = 1.0/x5;
    double x7 = log(n2*x6);
    double x8 = 1.0*n2;
    double x9 = n3*x6;
    double x10 = 2.0*log(x9);
    double x11 = 2.0*log(x4*x6);
    double x12 = n1 + n3;
    double x13 = 1.0*log(x12*x6);
    double x14 = 8.3144626181532395*T;
    double x15 = x14*(n3*x10 + x11*x4 + x12*x13 + x7*x8);
    double x16 = 1.0*x5;
    double x17 = pow(x5, -4);
    double x18 = 6.0*x17;
    double x19 = -x18*(n2*x0 + x16*(n1*x1 + n2*x2 + n3*x3 + x15));
    double x20 = 1.0*n1;
    double x21 = 1.0*n3;
    double x22 = x20 + x21;
    double x23 = x22 + x8;
    double x24 = 2.0*n1;
    double x25 = 2.0*n2;
    double x26 = x24 + x25;
    double x27 = 1.0/x4;
    double x28 = pow(x5, -2);
    double x29 = -x28*x4 + x6;
    double x30 = x27*x29;
    double x31 = x26*x30;
    double x32 = x11 + x31*x5 - 2.0*x9;
    double x33 = 1.0/x12;
    double x34 = -x12*x28 + x6;
    double x35 = x33*x34;
    double x36 = x22*x35;
    double x37 = x13 + x36*x5 - x6*x8;
    double x38 = x32 + x37;
    double x39 = x14*x38;
    double x40 = x1*x20 + x15 + x2*x8 + x21*x3;
    double x41 = x23*(x1 + x39) + x40;
    double x42 = pow(x5, -3);
    double x43 = 6.0*x42;
    double x44 = 16.628925236306479*T;
    double x45 = x28*x8;
    double x46 = x36 + x45;
    double x47 = 4.0*x30;
    double x48 = -2*x28;
    double x49 = 2*x42;
    double x50 = x4*x49 + x48;
    double x51 = x26*x27;
    double x52 = x50*x51;
    double x53 = pow(x4, -2);
    double x54 = x29*x53;
    double x55 = x26*x54;
    double x56 = 2.0*x28;
    double x57 = n3*x56;
    double x58 = x31 + x57;
    double x59 = x47*x5 + x5*x52 - x5*x55 + x58;
    double x60 = x46 + x59;
    double x61 = 2.0*x35;
    double x62 = x12*x49 + x48;
    double x63 = x22*x33;
    double x64 = x62*x63;
    double x65 = pow(x12, -2);
    double x66 = x34*x65;
    double x67 = x22*x66;
    double x68 = x5*x61 + x5*x64 - x5*x67;
    double x69 = T*(x60 + x68);
    double x70 = 8.3144626181532395*x69;
    double x71 = 2.0*x1 + x23*x70 + x38*x44;
    double x72 = 3.0*x28;
    double x73 = 4.0*x42;
    double x74 = n3*x73;
    double x75 = -x74;
    double x76 = x25*x42;
    double x77 = -x76;
    double x78 = x75 + x77;
    double x79 = 6.0*x5;
    double x80 = 6*x42;
    double x81 = 6*x17;
    double x82 = x5*x51;
    double x83 = x26*x53;
    double x84 = 2*x5;
    double x85 = x26*x29*x84/((x4)*(x4)*(x4)) + x27*x50*x79 + 6.0*x30 - x50*x83*x84 + 2*x52 - x54*x79 - 2*x55 + x82*(-x4*x81 + x80);
    double x86 = x78 + x85;
    double x87 = 3.0*x5;
    double x88 = x5*x63;
    double x89 = x22*x65;
    double x90 = x33*x62*x87 + 3.0*x35 - x62*x84*x89 + 2*x64 - x66*x87 - 2*x67 + x88*(-x12*x81 + x80) + x22*x34*x84/((x12)*(x12)*(x12));
    double x91 = x14*x23;
    double x92 = 1.0*x6;
    double x93 = 2.0*x6;
    double x94 = -x28;
    double x95 = -n1;
    double x96 = -n3 + x95;
    double x97 = -x49*x96 + x94;
    double x98 = x63*x97;
    double x99 = x5*x98 + x60 - x93;
    double x100 = x44*x99;
    double x101 = 1.0*x28;
    double x102 = x5*x97;
    double x103 = 4*x42;
    double x104 = 2*n1;
    double x105 = 2*n3;
    double x106 = 3*x17;
    double x107 = -x106*(x104 + x105);
    double x108 = -x102*x89 + x64 - x67 + x98;
    double x109 = -n2*x28 + x6;
    double x110 = x109*x16;
    double x111 = x110 - x22*x6 + x32 + 1.0*x7;
    double x112 = x111*x14;
    double x113 = x0 + x23*(x112 + x2) + x40;
    double x114 = 2.0*x42;
    double x115 = x113*x114;
    double x116 = x14*x99;
    double x117 = 1.0*x1 + x39;
    double x118 = x112 + 1.0*x2;
    double x119 = x116*x23 + x117 + x118;
    double x120 = -x119*x56 + x19;
    double x121 = -x101*x71 + x41*x73;
    double x122 = -x49*(-n2 + x95) + x94;
    double x123 = x122*x51;
    double x124 = x123*x5 + x58;
    double x125 = x46 + x68;
    double x126 = x124 + x125 - 4.0*x6;
    double x127 = x126*x44;
    double x128 = x78 + x90;
    double x129 = x122*x5;
    double x130 = 2*n2;
    double x131 = -x106*(x104 + x130);
    double x132 = x123 + 4.0*x129*x27 - x129*x83 + x47 + x52 - x55 + x82*(x103 + x131);
    double x133 = -2.0*n3*x28 + 2.0*x6;
    double x134 = x133*x5;
    double x135 = x10 + x134 - x26*x6 + x37;
    double x136 = x135*x14;
    double x137 = 48000.0*n2 + x23*(x136 + x3) + x40;
    double x138 = x114*x137;
    double x139 = x126*x14;
    double x140 = x136 + 1.0*x3;
    double x141 = x117 + x139*x23 + x140;
    double x142 = -x141*x56 + x19;
    double x143 = -x45;
    double x144 = -x20 - x21;
    double x145 = 1.0/n2;
    double x146 = x110*x145 + x143 - x144*x28 + x5*(-x56 + x76) + x59 + x92;
    double x147 = x14*x146;
    double x148 = x114*x41;
    double x149 = x111*x44 + x147*x23 + 2.0*x2;
    double x150 = -x101*x149 + x113*x73;
    double x151 = x124 + x143 + x22*x28 + x5*(-x101 + x76) - 5.0*x6;
    double x152 = x14*x151;
    double x153 = x118 + x140 + x152*x23 + 48000.0;
    double x154 = 4.0*x28;
    double x155 = -x154;
    double x156 = 1.0/n3;
    double x157 = x125 + x134*x156 - x28*(-x24 - x25) + x5*(x155 + x74) - x57 + x93;
    double x158 = x14*x157;
    double x159 = 2*x123 + x82*(x131 + x49);
    double x160 = x135*x44 + x158*x23 + 2.0*x3;
    double x161 = -x101*x160 + x137*x73;
    double x162 = 24.943387854459719*T;
    double x163 = 1.0*x109*x145;
    double x164 = -n2*x18;
    double x165 = x130*x42;
    double x166 = x145*x16;
    double x167 = n2*x73 + x75;
    double x168 = x167 - x22*x49;
    double x169 = x151*x44;
    double x170 = -x153*x56 + x19;

result[0] = x19 + x41*x43 - x71*x72 + x92*(24.943387854459719*x69 + x91*(x86 + x90));
result[1] = x115 + x120 + x121 + x92*(x100 + x70 + x91*(x101 + 2.0*x102*x33 + x108 + x61 + x86 + x88*(x103 + x107)));
result[2] = x121 + x138 + x142 + x92*(x127 + x70 + x91*(x128 + x132 + x56));
result[3] = x120 + x148 + x150 + x92*(x100 + x147 + x91*(x72 + x86 + x88*(x107 + x49) + 2*x98));
result[4] = -x101*x119 - x101*x141 - x101*x153 + x115 + x138 + x148 + x19 + x92*(x116 + x139 + x152 + x91*(x108 + x132 + x154 + x16*x33*x97 + 1.0*x35 + x78 + x88*(x103 + x81*x96)));
result[5] = x142 + x148 + x161 + x92*(x127 + x158 + x91*(x128 + x159 + 6.0*x28));
result[6] = x113*x43 - x149*x72 + x19 + x92*(x146*x162 + x91*(x155 + x163 + x166*(x165 + x48) + x168 + x5*(x164 + x43) + x85 - x110/((n2)*(n2))));
result[7] = x138 + x150 + x170 + x92*(x147 + x169 + x91*(x132 + x144*x49 + x163 + x166*(x165 + x94) + x167 + x5*(x164 + x73)));
result[8] = x115 + x161 + x170 + x92*(x158 + x169 + x91*(x159 + x168 + 7.0*x28 + x5*(x114 + x164)));
result[9] = x137*x43 - x160*x72 + x19 + x92*(x157*x162 + x91*(8.0*n3*x42 + x133*x156 + 2.0*x156*x5*(x105*x42 + x48) - x26*x49 - 8.0*x28 + x5*(-12.0*n3*x17 + 12.0*x42) + x77 + x90 - x134/((n3)*(n3))));
}
        
static double coder_dgdt(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = n1 + n3;
    double x1 = 1.0/(n2 + x0);
    double x2 = n1 + n2;

result = 1.0*x1*(1.0*n1 + 1.0*n2 + 1.0*n3)*(n1*(*endmember[0].dmu0dT)(T, P) + 8.3144626181532395*n2*log(n2*x1) + n2*(*endmember[1].dmu0dT)(T, P) + 16.628925236306479*n3*log(n3*x1) + n3*(*endmember[2].dmu0dT)(T, P) + 8.3144626181532395*x0*log(x0*x1) + 16.628925236306479*x2*log(x1*x2));
    return result;
}
        
static void coder_d2gdndt(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = (*endmember[0].dmu0dT)(T, P);
    double x1 = n1 + n2;
    double x2 = n1 + n3;
    double x3 = n2 + x2;
    double x4 = 1.0/x3;
    double x5 = 16.628925236306479*log(x1*x4);
    double x6 = n3*x4;
    double x7 = 16.628925236306479*n1 + 16.628925236306479*n2;
    double x8 = pow(x3, -2);
    double x9 = x5 - 16.628925236306479*x6 + x3*x7*(-x1*x8 + x4)/x1;
    double x10 = 8.3144626181532395*log(x2*x4);
    double x11 = n2*x4;
    double x12 = 8.3144626181532395*n1 + 8.3144626181532395*n3;
    double x13 = x10 - 8.3144626181532395*x11 + x12*x3*(-x2*x8 + x4)/x2;
    double x14 = 1.0*n1 + 1.0*n2 + 1.0*n3;
    double x15 = 1.0*x4;
    double x16 = x14*x15;
    double x17 = (*endmember[1].dmu0dT)(T, P);
    double x18 = (*endmember[2].dmu0dT)(T, P);
    double x19 = 8.3144626181532395*log(x11);
    double x20 = 16.628925236306479*log(x6);
    double x21 = n1*x0 + n2*x17 + n2*x19 + n3*x18 + n3*x20 + x1*x5 + x10*x2;
    double x22 = -1.0*x14*x21*x8 + x15*x21;

result[0] = x16*(x0 + x13 + x9) + x22;
result[1] = x16*(-x12*x4 + x17 + x19 + 8.3144626181532395*x3*(-n2*x8 + x4) + x9) + x22;
result[2] = x16*(x13 + x18 + x20 + 16.628925236306479*x3*(-n3*x8 + x4) - x4*x7) + x22;
}
        
static void coder_d3gdn2dt(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = n1 + n3;
    double x1 = n2 + x0;
    double x2 = 1.0/x1;
    double x3 = (*endmember[0].dmu0dT)(T, P);
    double x4 = n1 + n2;
    double x5 = 16.628925236306479*log(x2*x4);
    double x6 = n3*x2;
    double x7 = 16.628925236306479*n1;
    double x8 = 16.628925236306479*n2;
    double x9 = x7 + x8;
    double x10 = 1.0/x4;
    double x11 = pow(x1, -2);
    double x12 = -x11*x4 + x2;
    double x13 = x10*x12;
    double x14 = x13*x9;
    double x15 = x1*x14 + x5 - 16.628925236306479*x6;
    double x16 = 8.3144626181532395*log(x0*x2);
    double x17 = n2*x2;
    double x18 = 8.3144626181532395*n1;
    double x19 = 8.3144626181532395*n3;
    double x20 = x18 + x19;
    double x21 = 1.0/x0;
    double x22 = -x0*x11 + x2;
    double x23 = x21*x22;
    double x24 = x20*x23;
    double x25 = x1*x24 + x16 - 8.3144626181532395*x17;
    double x26 = x15 + x25 + x3;
    double x27 = x2*x26;
    double x28 = n2*x11;
    double x29 = 8.3144626181532395*x28;
    double x30 = x24 + x29;
    double x31 = -2*x11;
    double x32 = pow(x1, -3);
    double x33 = 2*x32;
    double x34 = x1*x9;
    double x35 = x10*x34;
    double x36 = n3*x11;
    double x37 = 16.628925236306479*x36;
    double x38 = x14 + x37;
    double x39 = 33.257850472612958*x1*x13 - x12*x34/((x4)*(x4)) + x35*(x31 + x33*x4) + x38;
    double x40 = x30 + x39;
    double x41 = 16.628925236306479*x1;
    double x42 = x1*x20;
    double x43 = x21*x42;
    double x44 = x23*x41 + x43*(x0*x33 + x31) - x22*x42/((x0)*(x0));
    double x45 = 1.0*n1 + 1.0*n2 + 1.0*n3;
    double x46 = 1.0*x2;
    double x47 = x45*x46;
    double x48 = x11*x45;
    double x49 = x26*x48;
    double x50 = (*endmember[1].dmu0dT)(T, P);
    double x51 = (*endmember[2].dmu0dT)(T, P);
    double x52 = 8.3144626181532395*log(x17);
    double x53 = 16.628925236306479*log(x6);
    double x54 = 2.0*n1*x3 + 2.0*n2*x50 + 2.0*n2*x52 + 2.0*n3*x51 + 2.0*n3*x53 + 2.0*x0*x16 + 2.0*x4*x5;
    double x55 = -x11*x54 + x32*x45*x54;
    double x56 = 16.628925236306479*x2;
    double x57 = -x11;
    double x58 = -n1;
    double x59 = 1.0*x27 - 1.0*x49 + x55;
    double x60 = 8.3144626181532395*x1*(x2 - x28);
    double x61 = x15 - x2*x20 + x50 + x52 + x60;
    double x62 = 1.0*x48;
    double x63 = x46*x61 - x61*x62;
    double x64 = x35*(-x33*(-n2 + x58) + x57) + x38;
    double x65 = x30 + x44;
    double x66 = x41*(x2 - x36);
    double x67 = -x2*x9 + x25 + x51 + x53 + x66;
    double x68 = x46*x67 - x62*x67;
    double x69 = 2.0*x2;
    double x70 = -x29;
    double x71 = x32*x8;
    double x72 = 2.0*x48;

result[0] = 2.0*x27 + x47*(x40 + x44) - 2.0*x49 + x55;
result[1] = x47*(x40 + x43*(-x33*(-n3 + x58) + x57) - x56) + x59 + x63;
result[2] = x47*(-33.257850472612958*x2 + x64 + x65) + x59 + x68;
result[3] = x47*(x1*(-16.628925236306479*x11 + x71) - x11*(-x18 - x19) + 8.3144626181532395*x2 + x39 + x70 + x60/n2) + x55 + x61*x69 - x61*x72;
result[4] = x47*(x1*(-8.3144626181532395*x11 + x71) + x11*x20 - 41.572313090766201*x2 + x64 + x70) + x55 + x63 + x68;
result[5] = x47*(x1*(33.257850472612958*n3*x32 - 33.257850472612958*x11) - x11*(-x7 - x8) - x37 + x56 + x65 + x66/n3) + x55 + x67*x69 - x67*x72;
}
        
static void coder_d4gdn3dt(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = n1 + n2;
    double x1 = n3 + x0;
    double x2 = 1.0/x1;
    double x3 = pow(x1, -2);
    double x4 = n2*x3;
    double x5 = 8.3144626181532395*x4;
    double x6 = 8.3144626181532395*n1;
    double x7 = 8.3144626181532395*n3;
    double x8 = x6 + x7;
    double x9 = n1 + n3;
    double x10 = 1.0/x9;
    double x11 = x2 - x3*x9;
    double x12 = x10*x11;
    double x13 = x12*x8;
    double x14 = x13 + x5;
    double x15 = 1.0/x0;
    double x16 = -x0*x3 + x2;
    double x17 = x15*x16;
    double x18 = 33.257850472612958*x17;
    double x19 = -2*x3;
    double x20 = pow(x1, -3);
    double x21 = 2*x20;
    double x22 = x0*x21 + x19;
    double x23 = 16.628925236306479*n1;
    double x24 = 16.628925236306479*n2;
    double x25 = x23 + x24;
    double x26 = x15*x25;
    double x27 = x22*x26;
    double x28 = pow(x0, -2);
    double x29 = x16*x28;
    double x30 = x25*x29;
    double x31 = n3*x3;
    double x32 = 16.628925236306479*x31;
    double x33 = x17*x25;
    double x34 = x32 + x33;
    double x35 = x1*x18 + x1*x27 - x1*x30 + x34;
    double x36 = x14 + x35;
    double x37 = 16.628925236306479*x12;
    double x38 = x19 + x21*x9;
    double x39 = x10*x8;
    double x40 = x38*x39;
    double x41 = pow(x9, -2);
    double x42 = x11*x41;
    double x43 = x42*x8;
    double x44 = x1*x37 + x1*x40 - x1*x43;
    double x45 = x36 + x44;
    double x46 = x2*x45;
    double x47 = (*endmember[0].dmu0dT)(T, P);
    double x48 = 16.628925236306479*log(x0*x2);
    double x49 = n3*x2;
    double x50 = x1*x33 + x48 - 16.628925236306479*x49;
    double x51 = 8.3144626181532395*log(x2*x9);
    double x52 = n2*x2;
    double x53 = x1*x13 + x51 - 8.3144626181532395*x52;
    double x54 = x47 + x50 + x53;
    double x55 = x3*x54;
    double x56 = 33.257850472612958*x20;
    double x57 = n3*x56;
    double x58 = -x57;
    double x59 = x20*x24;
    double x60 = -x59;
    double x61 = x58 + x60;
    double x62 = 49.886775708919437*x1;
    double x63 = 6*x20;
    double x64 = pow(x1, -4);
    double x65 = 6*x64;
    double x66 = x1*x26;
    double x67 = x25*x28;
    double x68 = 2*x1;
    double x69 = x15*x22*x62 + 49.886775708919437*x17 - x22*x67*x68 + 2*x27 - x29*x62 - 2*x30 + x66*(-x0*x65 + x63) + x16*x25*x68/((x0)*(x0)*(x0));
    double x70 = x61 + x69;
    double x71 = 24.943387854459719*x1;
    double x72 = x1*x39;
    double x73 = x41*x8;
    double x74 = x10*x38*x71 + x11*x68*x8/((x9)*(x9)*(x9)) + 24.943387854459719*x12 - x38*x68*x73 + 2*x40 - x42*x71 - 2*x43 + x72*(x63 - x65*x9);
    double x75 = 1.0*n1 + 1.0*n2 + 1.0*n3;
    double x76 = 1.0*x2;
    double x77 = x75*x76;
    double x78 = 6.0*x20;
    double x79 = x54*x75;
    double x80 = x3*x75;
    double x81 = x45*x80;
    double x82 = (*endmember[1].dmu0dT)(T, P);
    double x83 = (*endmember[2].dmu0dT)(T, P);
    double x84 = 8.3144626181532395*log(x52);
    double x85 = 16.628925236306479*log(x49);
    double x86 = n1*x47 + n2*x82 + n2*x84 + n3*x83 + n3*x85 + x0*x48 + x51*x9;
    double x87 = -6.0*x64*x75*x86 + x78*x86;
    double x88 = 8.3144626181532395*x3;
    double x89 = -x3;
    double x90 = -n1;
    double x91 = -n3 + x90;
    double x92 = -x21*x91 + x89;
    double x93 = x1*x92;
    double x94 = x10*x93;
    double x95 = 4*x20;
    double x96 = 2*n1;
    double x97 = 2*n3;
    double x98 = 3*x64;
    double x99 = -x98*(x96 + x97);
    double x100 = x39*x92;
    double x101 = x100 + x40 - x43 - x73*x93;
    double x102 = 16.628925236306479*x2;
    double x103 = x1*x100 - x102 + x36;
    double x104 = 2.0*x2;
    double x105 = 2.0*x3;
    double x106 = x105*x75;
    double x107 = x103*x104 - x103*x106 + x87;
    double x108 = 8.3144626181532395*x2 - 8.3144626181532395*x4;
    double x109 = x1*x108;
    double x110 = x109 - x2*x8 + x50 + x82 + x84;
    double x111 = 2.0*x20;
    double x112 = x110*x75;
    double x113 = -x105*x110 + x111*x112;
    double x114 = 4.0*x20;
    double x115 = x114*x79 + 1.0*x46 - 4.0*x55 - 1.0*x81;
    double x116 = 16.628925236306479*x3;
    double x117 = x61 + x74;
    double x118 = -x21*(-n2 + x90) + x89;
    double x119 = x118*x26;
    double x120 = x1*x118;
    double x121 = 2*n2;
    double x122 = -x98*(x121 + x96);
    double x123 = x119 + 33.257850472612958*x120*x15 - x120*x67 + x18 + x27 - x30 + x66*(x122 + x95);
    double x124 = x1*x119 + x34;
    double x125 = x14 + x44;
    double x126 = x124 + x125 - 33.257850472612958*x2;
    double x127 = x104*x126 - x106*x126 + x87;
    double x128 = 16.628925236306479*x2 - 16.628925236306479*x31;
    double x129 = x1*x128;
    double x130 = x129 - x2*x25 + x53 + x83 + x85;
    double x131 = x130*x75;
    double x132 = -x105*x130 + x111*x131;
    double x133 = x111*x79 - 2.0*x55;
    double x134 = -x5;
    double x135 = -x6 - x7;
    double x136 = 1.0/n2;
    double x137 = x1*(-x116 + x59) + x109*x136 + x134 - x135*x3 + 8.3144626181532395*x2 + x35;
    double x138 = 4.0*x3;
    double x139 = 1.0*x80;
    double x140 = -x110*x138 + x112*x114 - x137*x139 + x137*x76;
    double x141 = x1*(x59 - x88) + x124 + x134 - 41.572313090766201*x2 + x3*x8;
    double x142 = 33.257850472612958*x3;
    double x143 = x132 + x87;
    double x144 = 2*x119 + x66*(x122 + x21);
    double x145 = -x142;
    double x146 = 1.0/n3;
    double x147 = x1*(x145 + x57) + x102 + x125 + x129*x146 - x3*(-x23 - x24) - x32;
    double x148 = x114*x131 - x130*x138 - x139*x147 + x147*x76;
    double x149 = 3.0*x2;
    double x150 = 6.0*x3;
    double x151 = x108*x136;
    double x152 = -49.886775708919437*n2*x64;
    double x153 = x121*x20;
    double x154 = 8.3144626181532395*x1*x136;
    double x155 = n2*x56 + x58;
    double x156 = x155 - x21*x8;
    double x157 = 3.0*x80;
    double x158 = x104*x141 - x106*x141;

result[0] = 3.0*x46 - 6.0*x55 + x77*(x70 + x74) + x78*x79 - 3.0*x81 + x87;
result[1] = x107 + x113 + x115 + x77*(x101 + x37 + x70 + x72*(x95 + x99) + x88 + 16.628925236306479*x94);
result[2] = x115 + x127 + x132 + x77*(x116 + x117 + x123);
result[3] = x107 + x133 + x140 + x77*(2*x100 + 24.943387854459719*x3 + x70 + x72*(x21 + x99));
result[4] = -x103*x139 + x103*x76 + x113 - x126*x139 + x126*x76 + x133 - x139*x141 + x141*x76 + x143 + x77*(x101 + 8.3144626181532395*x12 + x123 + x142 + x61 + x72*(x65*x91 + x95) + 8.3144626181532395*x94);
result[5] = x127 + x133 + x148 + x77*(x117 + x144 + 49.886775708919437*x3);
result[6] = -x110*x150 + x112*x78 + x137*x149 - x137*x157 + x77*(x1*(x152 + 49.886775708919437*x20) + x145 + x151 + x154*(x153 + x19) + x156 + x69 - x109/((n2)*(n2))) + x87;
result[7] = x140 + x143 + x158 + x77*(x1*(x152 + x56) + x123 + x135*x21 + x151 + x154*(x153 + x89) + x155);
result[8] = x113 + x148 + x158 + x77*(x1*(x152 + 16.628925236306479*x20) + x144 + x156 + 58.20123832707268*x3) + x87;
result[9] = -x130*x150 + x131*x78 + x147*x149 - x147*x157 + x77*(66.515700945225916*n3*x20 + 16.628925236306479*x1*x146*(x19 + x20*x97) + x1*(-99.773551417838874*n3*x64 + 99.773551417838874*x20) + x128*x146 - x21*x25 - 66.515700945225916*x3 + x60 + x74 - x129/((n3)*(n3))) + x87;
}
        
static double coder_dgdp(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    

result = 1.0*(1.0*n1 + 1.0*n2 + 1.0*n3)*(n1*(*endmember[0].dmu0dP)(T, P) + n2*(*endmember[1].dmu0dP)(T, P) + n3*(*endmember[2].dmu0dP)(T, P))/(n1 + n2 + n3);
    return result;
}
        
static void coder_d2gdndp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = (*endmember[0].dmu0dP)(T, P);
    double x1 = 1.0*n1 + 1.0*n2 + 1.0*n3;
    double x2 = n1 + n2 + n3;
    double x3 = 1.0/x2;
    double x4 = x1*x3;
    double x5 = (*endmember[1].dmu0dP)(T, P);
    double x6 = (*endmember[2].dmu0dP)(T, P);
    double x7 = n1*x0 + n2*x5 + n3*x6;
    double x8 = -1.0*x1*x7/((x2)*(x2)) + x3*x7;

result[0] = x0*x4 + x8;
result[1] = x4*x5 + x8;
result[2] = x4*x6 + x8;
}
        
static void coder_d3gdn2dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = (*endmember[0].dmu0dP)(T, P);
    double x1 = n1 + n2 + n3;
    double x2 = 1.0/x1;
    double x3 = x0*x2;
    double x4 = pow(x1, -2);
    double x5 = 1.0*n1 + 1.0*n2 + 1.0*n3;
    double x6 = x4*x5;
    double x7 = x0*x6;
    double x8 = (*endmember[1].dmu0dP)(T, P);
    double x9 = (*endmember[2].dmu0dP)(T, P);
    double x10 = 2.0*n1*x0 + 2.0*n2*x8 + 2.0*n3*x9;
    double x11 = -x10*x4 + x10*x5/((x1)*(x1)*(x1));
    double x12 = x11 + 1.0*x3 - 1.0*x7;
    double x13 = 1.0*x2;
    double x14 = 1.0*x6;
    double x15 = x13*x8 - x14*x8;
    double x16 = x13*x9 - x14*x9;
    double x17 = 2.0*x2;
    double x18 = 2.0*x6;

result[0] = x11 + 2.0*x3 - 2.0*x7;
result[1] = x12 + x15;
result[2] = x12 + x16;
result[3] = x11 + x17*x8 - x18*x8;
result[4] = x11 + x15 + x16;
result[5] = x11 + x17*x9 - x18*x9;
}
        
static void coder_d4gdn3dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = (*endmember[0].dmu0dP)(T, P);
    double x1 = n1 + n2 + n3;
    double x2 = pow(x1, -2);
    double x3 = x0*x2;
    double x4 = pow(x1, -3);
    double x5 = 6.0*x4;
    double x6 = 1.0*n1 + 1.0*n2 + 1.0*n3;
    double x7 = x0*x6;
    double x8 = (*endmember[1].dmu0dP)(T, P);
    double x9 = (*endmember[2].dmu0dP)(T, P);
    double x10 = n1*x0 + n2*x8 + n3*x9;
    double x11 = x10*x5 - 6.0*x10*x6/((x1)*(x1)*(x1)*(x1));
    double x12 = 4.0*x4;
    double x13 = x11 + x12*x7 - 4.0*x3;
    double x14 = 2.0*x2;
    double x15 = 2.0*x4;
    double x16 = x6*x8;
    double x17 = -x14*x8 + x15*x16;
    double x18 = x6*x9;
    double x19 = -x14*x9 + x15*x18;
    double x20 = x11 + x15*x7 - 2.0*x3;
    double x21 = 4.0*x2;
    double x22 = x12*x16 - x21*x8;
    double x23 = x12*x18 - x21*x9;
    double x24 = 6.0*x2;

result[0] = x11 - 6.0*x3 + x5*x7;
result[1] = x13 + x17;
result[2] = x13 + x19;
result[3] = x20 + x22;
result[4] = x17 + x19 + x20;
result[5] = x20 + x23;
result[6] = x11 + x16*x5 - x24*x8;
result[7] = x11 + x19 + x22;
result[8] = x11 + x17 + x23;
result[9] = x11 + x18*x5 - x24*x9;
}
        
static double coder_d2gdt2(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    

result = 1.0*(n1*(*endmember[0].d2mu0dT2)(T, P) + n2*(*endmember[1].d2mu0dT2)(T, P) + n3*(*endmember[2].d2mu0dT2)(T, P));
    return result;
}
        
static void coder_d3gdndt2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 1.0*(*endmember[0].d2mu0dT2)(T, P);
result[1] = 1.0*(*endmember[1].d2mu0dT2)(T, P);
result[2] = 1.0*(*endmember[2].d2mu0dT2)(T, P);
}
        
static void coder_d4gdn2dt2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d5gdn3dt2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d2gdtdp(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    

result = 1.0*n1*(*endmember[0].d2mu0dTdP)(T, P) + 1.0*n2*(*endmember[1].d2mu0dTdP)(T, P) + 1.0*n3*(*endmember[2].d2mu0dTdP)(T, P);
    return result;
}
        
static void coder_d3gdndtdp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 1.0*(*endmember[0].d2mu0dTdP)(T, P);
result[1] = 1.0*(*endmember[1].d2mu0dTdP)(T, P);
result[2] = 1.0*(*endmember[2].d2mu0dTdP)(T, P);
}
        
static void coder_d4gdn2dtdp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d5gdn3dtdp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d2gdp2(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    

result = 1.0*(n1*(*endmember[0].d2mu0dP2)(T, P) + n2*(*endmember[1].d2mu0dP2)(T, P) + n3*(*endmember[2].d2mu0dP2)(T, P));
    return result;
}
        
static void coder_d3gdndp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 1.0*(*endmember[0].d2mu0dP2)(T, P);
result[1] = 1.0*(*endmember[1].d2mu0dP2)(T, P);
result[2] = 1.0*(*endmember[2].d2mu0dP2)(T, P);
}
        
static void coder_d4gdn2dp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d5gdn3dp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d3gdt3(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    

result = 1.0*(n1*(*endmember[0].d3mu0dT3)(T, P) + n2*(*endmember[1].d3mu0dT3)(T, P) + n3*(*endmember[2].d3mu0dT3)(T, P));
    return result;
}
        
static void coder_d4gdndt3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 1.0*(*endmember[0].d3mu0dT3)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dT3)(T, P);
result[2] = 1.0*(*endmember[2].d3mu0dT3)(T, P);
}
        
static void coder_d5gdn2dt3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d6gdn3dt3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d3gdt2dp(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    

result = 1.0*(n1*(*endmember[0].d3mu0dT2dP)(T, P) + n2*(*endmember[1].d3mu0dT2dP)(T, P) + n3*(*endmember[2].d3mu0dT2dP)(T, P));
    return result;
}
        
static void coder_d4gdndt2dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 1.0*(*endmember[0].d3mu0dT2dP)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dT2dP)(T, P);
result[2] = 1.0*(*endmember[2].d3mu0dT2dP)(T, P);
}
        
static void coder_d5gdn2dt2dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d6gdn3dt2dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d3gdtdp2(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    

result = 1.0*n1*(*endmember[0].d3mu0dTdP2)(T, P) + 1.0*n2*(*endmember[1].d3mu0dTdP2)(T, P) + 1.0*n3*(*endmember[2].d3mu0dTdP2)(T, P);
    return result;
}
        
static void coder_d4gdndtdp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 1.0*(*endmember[0].d3mu0dTdP2)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dTdP2)(T, P);
result[2] = 1.0*(*endmember[2].d3mu0dTdP2)(T, P);
}
        
static void coder_d5gdn2dtdp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d6gdn3dtdp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d3gdp3(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    

result = 1.0*(n1*(*endmember[0].d3mu0dP3)(T, P) + n2*(*endmember[1].d3mu0dP3)(T, P) + n3*(*endmember[2].d3mu0dP3)(T, P));
    return result;
}
        
static void coder_d4gdndp3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 1.0*(*endmember[0].d3mu0dP3)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dP3)(T, P);
result[2] = 1.0*(*endmember[2].d3mu0dP3)(T, P);
}
        
static void coder_d5gdn2dp3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d6gdn3dp3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_s(double T, double P, double n[3]) {
    double result = -coder_dgdt(T, P, n);
    return result;
}

static double coder_dsdt(double T, double P, double n[3]) {
    double result = -coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dsdp(double T, double P, double n[3]) {
    double result = -coder_d2gdtdp(T, P, n);
    return result;
}

static double coder_v(double T, double P, double n[3]) {
    double result = coder_dgdp(T, P, n);
    return result;
}

static double coder_cv(double T, double P, double n[3]) {
    double result = -T*coder_d2gdt2(T, P, n);
    double dvdt = coder_d2gdtdp(T, P, n);
    double dvdp = coder_d2gdp2(T, P, n);
    result += T*dvdt*dvdt/dvdp;
    return result;
}

static double coder_cp(double T, double P, double n[3]) {
    double result = -T*coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdt(double T, double P, double n[3]) {
    double result = -T*coder_d3gdt3(T, P, n) - coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdp(double T, double P, double n[3]) {
    double result = -T*coder_d3gdt2dp(T, P, n);
    return result;
}

static double coder_alpha(double T, double P, double n[3]) {
    double result = coder_d2gdtdp(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_dalphadt(double T, double P, double n[3]) {
    double dgdp = coder_dgdp(T, P, n);
    double d2gdtdp = coder_d2gdtdp(T, P, n);
    double result = coder_d3gdt2dp(T, P, n)/dgdp - d2gdtdp*d2gdtdp/dgdp/dgdp;
    return result;
}

static double coder_dalphadp(double T, double P, double n[3]) {
    double dgdp = coder_dgdp(T, P, n);
    double result = coder_d3gdtdp2(T, P, n)/dgdp - coder_d2gdp2(T, P, n)*coder_d2gdtdp(T, P, n)/dgdp/dgdp;
    return result;
}

static double coder_beta(double T, double P, double n[3]) {
    double result = -coder_d2gdp2(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_K(double T, double P, double n[3]) {
    double result = -coder_dgdp(T, P, n)/coder_d2gdp2(T, P, n);
    return result;
}

static double coder_Kp(double T, double P, double n[3]) {
    double result = coder_dgdp(T, P, n);
    result *= coder_d3gdp3(T, P, n);
    result /= pow(coder_d2gdp2(T, P, n), 2.0);
    return result - 1.0;
}

