
#if !defined(CODEREXTFUNCTIONS_H)
#define CODEREXTFUNCTIONS_H

#include <math.h>
#include <stdarg.h>

static double LMax(int n, ...) {
    //
    // returns the entry from the first n variadic arguments corresponding to the maximum of the second n arguments
    //
    
    double vs[n], dvs[n];
    int i, imax = 0;
    double vmax = -HUGE_VAL;

    va_list args;
    va_start(args, n);

    for (i = 0; i < n; i++)
    {
      dvs[i] = va_arg(args, double);
    }
    for (i = 0; i < n; i++)
    {
      vs[i] = va_arg(args, double);
    }

    va_end(args);

    for (i = 0; i < n; i++)
    {
      if (vs[i] > vmax) 
      {
        vmax = vs[i];
        imax = i;
      }
    }

    return dvs[imax];
}

static double LAbsMax(int n, ...) {
    //
    // returns the entry from the first n variadic arguments corresponding to the absolute maximum of the second n arguments
    //
    
    double vs[n], dvs[n];
    int i, imax = 0;
    double vmax = -HUGE_VAL;

    va_list args;
    va_start(args, n);

    for (i = 0; i < n; i++)
    {
      dvs[i] = va_arg(args, double);
    }
    for (i = 0; i < n; i++)
    {
      vs[i] = fabs(va_arg(args, double));
    }

    va_end(args);

    for (i = 0; i < n; i++)
    {
      if (vs[i] > vmax) 
      {
        vmax = vs[i];
        imax = i;
      }
    }

    return dvs[imax];
}

static double LMin(int n, ...) {
    //
    // returns the entry from the first n variadic arguments corresponding to the minimum of the second n arguments
    //
    
    double vs[n], dvs[n];
    int i, imin = 0;
    double vmin = HUGE_VAL;

    va_list args;
    va_start(args, n);

    for (i = 0; i < n; i++)
    {
      dvs[i] = va_arg(args, double);
    }
    for (i = 0; i < n; i++)
    {
      vs[i] = va_arg(args, double);
    }

    va_end(args);

    for (i = 0; i < n; i++)
    {
      if (vs[i] < vmin)
      {
        vmin = vs[i];
        imin = i;
      }
    }

    return dvs[imin];
}

#endif
