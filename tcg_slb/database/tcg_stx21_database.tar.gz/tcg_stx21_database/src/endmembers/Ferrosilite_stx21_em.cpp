#include "endmembers/Ferrosilite_stx21_em.h"
#include "tcgversion.h"

//-----------------------------------------------------------------------------
Ferrosilite_stx21_em::Ferrosilite_stx21_em()
{
  // Do Nothing
}
//-----------------------------------------------------------------------------
Ferrosilite_stx21_em::~Ferrosilite_stx21_em()
{
  // Do nothing
}
//-----------------------------------------------------------------------------
std::string Ferrosilite_stx21_em::identifier()
{
    std::string _str(Ferrosilite_stx21_em_coder_calib_identifier());
    return _str;
}
//-----------------------------------------------------------------------------
std::string Ferrosilite_stx21_em::name()
{
    std::string _str(Ferrosilite_stx21_em_coder_calib_name());
    return _str;
}
//-----------------------------------------------------------------------------
std::string Ferrosilite_stx21_em::tcg_build_version()
{
    return TCG_VERSION;
}
//-----------------------------------------------------------------------------
std::string Ferrosilite_stx21_em::tcg_build_git_sha()
{
    return TCG_GIT_SHA;
}
//-----------------------------------------------------------------------------
std::string Ferrosilite_stx21_em::tcg_generation_version()
{
    return "1.0.0";
}
//-----------------------------------------------------------------------------
std::string Ferrosilite_stx21_em::tcg_generation_git_sha()
{
    return "cf602b232599e8a8de52582a4bd5ef0f299e2571 Mon May 29 19:37:39 2023 -0400";
}
//-----------------------------------------------------------------------------
std::string Ferrosilite_stx21_em::formula()
{
    std::string _str(Ferrosilite_stx21_em_coder_calib_formula());
    return _str;
}
//-----------------------------------------------------------------------------
double Ferrosilite_stx21_em::molecular_weight()
{
    return Ferrosilite_stx21_em_coder_calib_mw();
}
//-----------------------------------------------------------------------------
std::vector<double> Ferrosilite_stx21_em::elements()
{
  std::vector<double> _elements;
  const double *el = Ferrosilite_stx21_em_coder_calib_elements();
  _elements.assign(el, el + 106);
  return _elements;
}
//-----------------------------------------------------------------------------
double Ferrosilite_stx21_em::G(const double &T, const double &P)
{
  return Ferrosilite_stx21_em_coder_calib_g(T,P);
}
//-----------------------------------------------------------------------------
double Ferrosilite_stx21_em::dGdT(const double &T, const double &P)
{
  return Ferrosilite_stx21_em_coder_calib_dgdt(T,P);
}
//-----------------------------------------------------------------------------
double Ferrosilite_stx21_em::dGdP(const double &T, const double &P)
{
  return Ferrosilite_stx21_em_coder_calib_dgdp(T,P);
}
//-----------------------------------------------------------------------------
double Ferrosilite_stx21_em::d2GdT2(const double &T, const double &P)
{
  return Ferrosilite_stx21_em_coder_calib_d2gdt2(T,P);
}
//-----------------------------------------------------------------------------
double Ferrosilite_stx21_em::d2GdTdP(const double &T, const double &P)
{
  return Ferrosilite_stx21_em_coder_calib_d2gdtdp(T,P);
}
//-----------------------------------------------------------------------------
double Ferrosilite_stx21_em::d2GdP2(const double &T, const double &P)
{
  return Ferrosilite_stx21_em_coder_calib_d2gdp2(T,P);
}
//-----------------------------------------------------------------------------
double Ferrosilite_stx21_em::d3GdT3(const double &T, const double &P)
{
  return Ferrosilite_stx21_em_coder_calib_d3gdt3(T,P);
}
//-----------------------------------------------------------------------------
double Ferrosilite_stx21_em::d3GdT2dP(const double &T, const double &P)
{
  return Ferrosilite_stx21_em_coder_calib_d3gdt2dp(T,P);
}
//-----------------------------------------------------------------------------
double Ferrosilite_stx21_em::d3GdTdP2(const double &T, const double &P)
{
  return Ferrosilite_stx21_em_coder_calib_d3gdtdp2(T,P);
}
//-----------------------------------------------------------------------------
double Ferrosilite_stx21_em::d3GdP3(const double &T, const double &P)
{
  return Ferrosilite_stx21_em_coder_calib_d3gdp3(T,P);
}
//**************************************************************************
// Convenience functions of T and P
//**************************************************************************

//-----------------------------------------------------------------------------
double Ferrosilite_stx21_em::S(const double& T, const double& P)
{
  return Ferrosilite_stx21_em_coder_calib_s(T,P);
}
//-----------------------------------------------------------------------------
double Ferrosilite_stx21_em::V(const double& T, const double& P)
{
  return Ferrosilite_stx21_em_coder_calib_v(T,P);
}
//-----------------------------------------------------------------------------
double Ferrosilite_stx21_em::dVdT(const double& T, const double& P)
{
  return Ferrosilite_stx21_em_coder_calib_d2gdtdp(T,P);
}
//-----------------------------------------------------------------------------
double Ferrosilite_stx21_em::dVdP(const double& T, const double& P)
{
  return Ferrosilite_stx21_em_coder_calib_d2gdp2(T,P);
}
//-----------------------------------------------------------------------------
double Ferrosilite_stx21_em::Cv(const double& T, const double& P)
{
  return Ferrosilite_stx21_em_coder_calib_cv(T,P);
}
//-----------------------------------------------------------------------------
double Ferrosilite_stx21_em::Cp(const double& T, const double& P)
{
  return Ferrosilite_stx21_em_coder_calib_cp(T,P);
}
//-----------------------------------------------------------------------------
double Ferrosilite_stx21_em::dCpdT(const double& T, const double& P)
{
  return Ferrosilite_stx21_em_coder_calib_dcpdt(T,P);
}
//-----------------------------------------------------------------------------
double Ferrosilite_stx21_em::alpha(const double& T, const double& P)
{
  return Ferrosilite_stx21_em_coder_calib_alpha(T,P);
}
//-----------------------------------------------------------------------------
double Ferrosilite_stx21_em::beta(const double& T, const double& P)
{
  return Ferrosilite_stx21_em_coder_calib_beta(T,P);
}
//-----------------------------------------------------------------------------
double Ferrosilite_stx21_em::K(const double& T, const double& P)
{
  return Ferrosilite_stx21_em_coder_calib_K(T,P);
}
//-----------------------------------------------------------------------------
double Ferrosilite_stx21_em::Kp(const double& T, const double& P)
{
  return Ferrosilite_stx21_em_coder_calib_Kp(T,P);
}
//**************************************************************************
// Active parameter functions directly from coder
//**************************************************************************

//-----------------------------------------------------------------------------
int Ferrosilite_stx21_em::get_param_number()
{
   return Ferrosilite_stx21_em_coder_get_param_number();
}
//-----------------------------------------------------------------------------
std::vector<std::string> Ferrosilite_stx21_em::get_param_names()
{
  std::vector<std::string> _param_names;
  const char **p = Ferrosilite_stx21_em_coder_get_param_names();
  _param_names.assign(p, p + Ferrosilite_stx21_em_coder_get_param_number());
  return _param_names;
}
//-----------------------------------------------------------------------------
std::vector<std::string> Ferrosilite_stx21_em::get_param_units()
{
  std::vector<std::string> _param_units;
  const char **p = Ferrosilite_stx21_em_coder_get_param_units();
  _param_units.assign(p, p + Ferrosilite_stx21_em_coder_get_param_number());
  return _param_units;
}
//-----------------------------------------------------------------------------
std::vector<double> Ferrosilite_stx21_em::get_param_values()
{
  std::vector<double> values(Ferrosilite_stx21_em_coder_get_param_number());
  double* v = values.data();
  double** v_ptr = &v;
  Ferrosilite_stx21_em_coder_get_param_values(v_ptr);
  return values;
}
//-----------------------------------------------------------------------------
void Ferrosilite_stx21_em::get_param_values(std::vector<double>& values)
{
  double* v = values.data();
  double** v_ptr = &v;
  Ferrosilite_stx21_em_coder_get_param_values(v_ptr);
}
//-----------------------------------------------------------------------------
int Ferrosilite_stx21_em::set_param_values(std::vector<double>& values)
{
  Ferrosilite_stx21_em_coder_set_param_values(values.data());
  return 1;
}
//-----------------------------------------------------------------------------
double Ferrosilite_stx21_em::get_param_value(int& index)
{
  return Ferrosilite_stx21_em_coder_get_param_value(index);
}
//-----------------------------------------------------------------------------
int Ferrosilite_stx21_em::set_param_value(int& index, double& value)
{
  return Ferrosilite_stx21_em_coder_set_param_value(index,value);
}
//-----------------------------------------------------------------------------
double Ferrosilite_stx21_em::dparam_g(double& T, double& P, int& index)
{
  return Ferrosilite_stx21_em_coder_dparam_g(T,P,index);
}
//-----------------------------------------------------------------------------
double Ferrosilite_stx21_em::dparam_dgdt(double& T, double& P, int& index)
{
  return Ferrosilite_stx21_em_coder_dparam_dgdt(T,P,index);
}
//-----------------------------------------------------------------------------
double Ferrosilite_stx21_em::dparam_dgdp(double& T, double& P, int& index)
{
  return Ferrosilite_stx21_em_coder_dparam_dgdp(T,P,index);
}
//-----------------------------------------------------------------------------
double Ferrosilite_stx21_em::dparam_d2gdt2(double& T, double& P, int& index)
{
  return Ferrosilite_stx21_em_coder_dparam_d2gdt2(T,P,index);
}
//-----------------------------------------------------------------------------
double Ferrosilite_stx21_em::dparam_d2gdtdp(double& T, double& P, int& index)
{
  return Ferrosilite_stx21_em_coder_dparam_d2gdtdp(T,P,index);
}
//-----------------------------------------------------------------------------
double Ferrosilite_stx21_em::dparam_d2gdp2(double& T, double& P, int& index)
{
  return Ferrosilite_stx21_em_coder_dparam_d2gdp2(T,P,index);
}
//-----------------------------------------------------------------------------
double Ferrosilite_stx21_em::dparam_d3gdt3(double& T, double& P, int& index)
{
  return Ferrosilite_stx21_em_coder_dparam_d3gdt3(T,P,index);
}
//-----------------------------------------------------------------------------
double Ferrosilite_stx21_em::dparam_d3gdt2dp(double& T, double& P, int& index)
{
  return Ferrosilite_stx21_em_coder_dparam_d3gdt2dp(T,P,index);
}
//-----------------------------------------------------------------------------
double Ferrosilite_stx21_em::dparam_d3gdtdp2(double& T, double& P, int& index)
{
  return Ferrosilite_stx21_em_coder_dparam_d3gdtdp2(T,P,index);
}
//-----------------------------------------------------------------------------
double Ferrosilite_stx21_em::dparam_d3gdp3(double& T, double& P, int& index)
{
  return Ferrosilite_stx21_em_coder_dparam_d3gdp3(T,P,index);
}
//-----------------------------------------------------------------------------
